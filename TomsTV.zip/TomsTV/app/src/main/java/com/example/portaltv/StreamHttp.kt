package com.example.portaltv

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Ein gemeinsamer HTTP-Client für alle Streams. Verbindungen zum Stream-Server bleiben offen
 * und werden beim Umschalten und für jedes HLS-Segment wiederverwendet (kein neuer TCP/TLS-Aufbau).
 */
object StreamHttp {
    private val base: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(8, 5, TimeUnit.MINUTES))
            .dispatcher(Dispatcher().apply { maxRequestsPerHost = 16 })
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    // Live: schnell aufgeben, damit Wächter/Quellenwechsel greifen. Filme: etwas geduldiger.
    private val live: OkHttpClient by lazy {
        base.newBuilder().connectTimeout(6, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    }
    private val vod: OkHttpClient by lazy {
        base.newBuilder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    }

    fun forPlayer(isLive: Boolean): OkHttpClient = if (isLive) live else vod
}
