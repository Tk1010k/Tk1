package com.example.portaltv

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Einfaches Fehlerprotokoll: letzte Meldungen im Speicher und in einer Datei, plus letzter Absturz. */
object AppLog {
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("dd.MM. HH:mm:ss", Locale.GERMANY)

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "log.txt")
        file = f
        try {
            if (f.exists()) f.readLines().takeLast(300).forEach { lines.addLast(it) }
        } catch (e: Exception) { }
    }

    @Synchronized
    fun add(msg: String) {
        val line = fmt.format(Date()) + "  " + msg.replace('\n', ' ')
        lines.addLast(line)
        while (lines.size > 300) lines.removeFirst()
        try {
            val f = file
            if (f != null) {
                if (f.length() > 200_000) f.writeText(lines.joinToString("\n") + "\n") else f.appendText(line + "\n")
            }
        } catch (e: Exception) { }
    }

    fun crash(t: Throwable) {
        val where = t.stackTrace.take(4).joinToString(" < ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
        add("ABSTURZ: " + t.javaClass.simpleName + ": " + t.message + " @ " + where)
    }

    @Synchronized
    fun all(): List<String> = lines.toList().asReversed()

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
        try { file?.writeText("") } catch (e: Exception) { }
    }
}
