package com.example.portaltv

import android.content.SharedPreferences
import org.json.JSONObject

/** Messwerte eines Portals: wie oft gestartet, gehangen, neu geladen, umgeschaltet und wie schnell es startet. */
class PStat(
    var plays: Int = 0, var stalls: Int = 0, var reloads: Int = 0, var failovers: Int = 0,
    var startMs: Long = 0L, var startN: Int = 0, var drops: Long = 0L, var underruns: Int = 0, var hdr: Int = 0
) {
    fun stallRate(): Float = if (plays <= 0) 0f else (stalls + reloads).toFloat() / plays

    /** Höher = schlechter. */
    fun score(): Float = stallRate() * 10f + (if (startN > 0) startMs / 1000f else 0f) + failovers * 0.5f

    fun rating(): String = when {
        plays < 3 -> "noch zu wenig Daten"
        stallRate() < 0.15f && (startN == 0 || startMs < 2500) -> "sehr gut"
        stallRate() < 0.4f && (startN == 0 || startMs < 5000) -> "gut"
        else -> "schwach"
    }
}

/** Speichert die Messwerte je Portal dauerhaft in den Einstellungen. */
class PortalStats(private val sp: SharedPreferences) {
    private val map = LinkedHashMap<String, PStat>()

    init {
        try {
            val o = JSONObject(sp.getString("pstats", "{}") ?: "{}")
            o.keys().forEach { k ->
                val j = o.getJSONObject(k)
                map[k] = PStat(j.optInt("p"), j.optInt("s"), j.optInt("r"), j.optInt("f"), j.optLong("ms"),
                    j.optInt("n"), j.optLong("d"), j.optInt("u"), j.optInt("h"))
            }
        } catch (e: Exception) { }
    }

    private fun save() {
        val o = JSONObject()
        map.forEach { (k, v) ->
            o.put(k, JSONObject().put("p", v.plays).put("s", v.stalls).put("r", v.reloads).put("f", v.failovers)
                .put("ms", v.startMs).put("n", v.startN).put("d", v.drops).put("u", v.underruns).put("h", v.hdr))
        }
        sp.edit().putString("pstats", o.toString()).apply()
    }

    fun peek(key: String): PStat? = map[key]

    fun all(): List<Pair<String, PStat>> = map.entries.map { it.key to it.value }

    fun update(key: String, f: (PStat) -> Unit) {
        val s = map.getOrPut(key) { PStat() }
        f(s)
        // Alte Werte langsam vergessen, damit sich Verbesserungen bemerkbar machen
        if (s.plays > 300) {
            s.plays /= 2; s.stalls /= 2; s.reloads /= 2; s.failovers /= 2; s.drops /= 2; s.underruns /= 2
        }
        save()
    }

    fun reset() { map.clear(); save() }
}
