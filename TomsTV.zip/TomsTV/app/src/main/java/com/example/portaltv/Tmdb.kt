package com.example.portaltv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Optionale Zusatzinfos (Poster, Beschreibung, Bewertung) von TMDB. Braucht einen kostenlosen Schlüssel. */
object Tmdb {
    data class Info(val poster: String?, val backdrop: String?, val overview: String, val rating: String)

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
    private val cache = HashMap<String, Info?>()

    private fun img(o: JSONObject, key: String, size: String): String? {
        val v = o.optString(key)
        return if (v.isBlank() || v == "null") null else "https://image.tmdb.org/t/p/" + size + v
    }

    fun lookup(key: String, rawName: String, year: String, series: Boolean): Info? {
        val name = rawName.replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
            .replace(Regex("^[A-Za-z]{2}\\s*[-|:]\\s*"), "").trim()
        if (name.length < 2 || key.isBlank()) return null
        val ck = (if (series) "tv:" else "mv:") + name.lowercase() + year
        synchronized(cache) { if (cache.containsKey(ck)) return cache[ck] }
        val kind = if (series) "tv" else "movie"
        val y = year.take(4).takeIf { it.length == 4 && it.all { c -> c.isDigit() } }
        val url = "https://api.themoviedb.org/3/search/" + kind + "?api_key=" + key.trim() +
            "&language=de-DE&query=" + URLEncoder.encode(name, "UTF-8") +
            (if (y != null) (if (series) "&first_air_date_year=" else "&year=") + y else "")
        val info: Info? = try {
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) {
                    AppLog.add("TMDB: HTTP " + r.code + " (Schlüssel prüfen)")
                    return null
                }
                val o = JSONObject(r.body?.string().orEmpty()).optJSONArray("results")?.optJSONObject(0)
                if (o == null) null else {
                    val vote = o.optDouble("vote_average", 0.0)
                    Info(img(o, "poster_path", "w500"), img(o, "backdrop_path", "w1280"), o.optString("overview"),
                        if (vote > 0) String.format(Locale.US, "%.1f", vote) else "")
                }
            }
        } catch (e: Exception) { return null }
        synchronized(cache) { cache[ck] = info }
        return info
    }
}
