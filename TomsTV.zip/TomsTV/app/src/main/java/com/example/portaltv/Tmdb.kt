package com.example.portaltv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Optionale Zusatzinfos (Poster, Beschreibung, Bewertung) von TMDB. Braucht einen kostenlosen Schlüssel. */
object Tmdb {
    data class Info(val poster: String?, val backdrop: String?, val overview: String, val rating: String, val id: Int = 0)
    data class Person(val name: String, val role: String, val photo: String?)
    data class Extras(val cast: List<Person>, val trailer: String?)
    private val extraCache = HashMap<String, Extras?>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
    private val cache = HashMap<String, Info?>()

    private fun img(o: JSONObject, key: String, size: String): String? {
        val v = o.optString(key)
        return if (v.isBlank() || v == "null") null else "https://image.tmdb.org/t/p/" + size + v
    }

    fun lookup(key: String, rawName: String, year: String, series: Boolean): Info? {
        val name = rawName.replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
            .replace(Regex("^[A-Za-z]{2}\\s*[-|:]\\s*"), " ")
            .replace(Regex("(?i)(^|[^a-z0-9])(4k|uhd|hdr10\\+?|hdr|dolby ?vision|fhd|full ?hd|hd|blu-?ray|bdrip|web-?dl|2160p?|1080[pi]?|720p?|multi|german|ger)(?![a-z0-9])"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (name.length < 2 || key.isBlank()) return null
        val ck = (if (series) "tv:" else "mv:") + name.lowercase() + year
        synchronized(cache) { if (cache.containsKey(ck)) return cache[ck] }
        val kind = if (series) "tv" else "movie"
        val y = year.take(4).takeIf { it.length == 4 && it.all { c -> c.isDigit() } }
        fun search(withYear: Boolean): Info? {
            val url = "https://api.themoviedb.org/3/search/" + kind + "?api_key=" + key.trim() +
                "&language=de-DE&query=" + URLEncoder.encode(name, "UTF-8") +
                (if (withYear && y != null) (if (series) "&first_air_date_year=" else "&year=") + y else "")
            return http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) {
                    AppLog.add("TMDB: HTTP " + r.code + " (Schlüssel prüfen)")
                    throw java.io.IOException("http")
                }
                val o = JSONObject(r.body?.string().orEmpty()).optJSONArray("results")?.optJSONObject(0)
                if (o == null) null else {
                    val vote = o.optDouble("vote_average", 0.0)
                    Info(img(o, "poster_path", "w500"), img(o, "backdrop_path", "w1280"), o.optString("overview"),
                        if (vote > 0) String.format(Locale.US, "%.1f", vote) else "", o.optInt("id", 0))
                }
            }
        }
        val info: Info? = try {
            search(true) ?: (if (y != null) search(false) else null)
        } catch (e: Exception) { return null }
        if (info == null) AppLog.add("TMDB: kein Treffer für \"" + name + "\"")
        synchronized(cache) { cache[ck] = info }
        return info
    }

    /** Besetzung und Trailer (YouTube-Schlüssel) zu einem gefundenen Titel. */
    fun extras(key: String, id: Int, series: Boolean): Extras? {
        if (id <= 0 || key.isBlank()) return null
        val ck = (if (series) "tv:" else "mv:") + id
        synchronized(extraCache) { if (extraCache.containsKey(ck)) return extraCache[ck] }
        val kind = if (series) "tv" else "movie"
        val url = "https://api.themoviedb.org/3/" + kind + "/" + id + "?api_key=" + key.trim() +
            "&language=de-DE&append_to_response=credits,videos&include_video_language=de,en,null"
        val ex: Extras? = try {
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return null
                val o = JSONObject(r.body?.string().orEmpty())
                val cast = ArrayList<Person>()
                val ca = o.optJSONObject("credits")?.optJSONArray("cast")
                if (ca != null) for (i in 0 until minOf(ca.length(), 14)) {
                    val c = ca.optJSONObject(i) ?: continue
                    val n = c.optString("name")
                    if (n.isBlank()) continue
                    cast.add(Person(n, c.optString("character"), img(c, "profile_path", "w185")))
                }
                var trailer: String? = null
                val va = o.optJSONObject("videos")?.optJSONArray("results")
                if (va != null) {
                    val yt = ArrayList<JSONObject>()
                    for (i in 0 until va.length()) {
                        val v = va.optJSONObject(i) ?: continue
                        if (v.optString("site") == "YouTube" && v.optString("key").isNotBlank()) yt.add(v)
                    }
                    val pick = yt.firstOrNull { it.optString("type") == "Trailer" && it.optString("iso_639_1") == "de" }
                        ?: yt.firstOrNull { it.optString("type") == "Trailer" }
                        ?: yt.firstOrNull { it.optString("type") == "Teaser" }
                    trailer = pick?.optString("key")
                }
                Extras(cast, trailer)
            }
        } catch (e: Exception) { return null }
        synchronized(extraCache) { extraCache[ck] = ex }
        return ex
    }

    /** Kurzvorschau über die iTunes-Suche (direkter Video-Link, kein Schlüssel nötig). Nur für Filme sinnvoll. */
    fun itunesPreview(rawName: String, series: Boolean): String? {
        val name = rawName.replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
            .replace(Regex("^[A-Za-z]{2}\\s*[-|:]\\s*"), " ")
            .replace(Regex("(?i)(^|[^a-z0-9])(4k|uhd|hdr10\\+?|hdr|dolby ?vision|fhd|full ?hd|hd|blu-?ray|bdrip|web-?dl|2160p?|1080[pi]?|720p?|multi|german|ger)(?![a-z0-9])"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (name.length < 2) return null
        val url = "https://itunes.apple.com/search?term=" + URLEncoder.encode(name, "UTF-8") +
            "&country=de&limit=3&entity=" + (if (series) "tvSeason" else "movie")
        return try {
            http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return null
                val arr = JSONObject(r.body?.string().orEmpty()).optJSONArray("results") ?: return null
                for (i in 0 until arr.length()) {
                    val p = arr.optJSONObject(i)?.optString("previewUrl").orEmpty()
                    if (p.startsWith("http")) return p
                }
                null
            }
        } catch (e: Exception) { null }
    }

    private val recCache = HashMap<String, List<Pair<String, String>>>()

    /** Name ohne Klammern, Länderkürzel und Qualitätsangaben (für Vergleiche). */
    fun cleanName(rawName: String): String = rawName.replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
        .replace(Regex("^[A-Za-z]{2}\\s*[-|:]\\s*"), " ")
        .replace(Regex("(?i)(^|[^a-z0-9])(4k|uhd|hdr10\\+?|hdr|dolby ?vision|fhd|full ?hd|hd|blu-?ray|bdrip|web-?dl|2160p?|1080[pi]?|720p?|multi|german|ger)(?![a-z0-9])"), " ")
        .replace(Regex("\\s+"), " ").trim()

    /** Empfehlungen von TMDB: Paare aus deutschem und Originaltitel. */
    fun recommendations(key: String, id: Int, series: Boolean): List<Pair<String, String>> {
        if (id <= 0 || key.isBlank()) return emptyList()
        val ck = (if (series) "tv:" else "mv:") + id
        synchronized(recCache) { recCache[ck]?.let { return it } }
        val kind = if (series) "tv" else "movie"
        val out = ArrayList<Pair<String, String>>()
        for (part in listOf("recommendations", "similar")) {
            try {
                val url = "https://api.themoviedb.org/3/" + kind + "/" + id + "/" + part + "?api_key=" + key.trim() + "&language=de-DE&page=1"
                http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val arr = JSONObject(r.body?.string().orEmpty()).optJSONArray("results") ?: return@use
                    for (i in 0 until minOf(arr.length(), 14)) {
                        val o = arr.optJSONObject(i) ?: continue
                        val t = o.optString(if (series) "name" else "title")
                        val orig = o.optString(if (series) "original_name" else "original_title")
                        if (t.isNotBlank() && out.none { it.first == t }) out.add(t to orig)
                    }
                }
            } catch (e: Exception) { }
        }
        synchronized(recCache) { recCache[ck] = out }
        return out
    }
}
