package com.example.portaltv

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/** Startet die App nach dem Einschalten der Box, wenn der Autostart in den Einstellungen an ist. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (!sp.getBoolean("autostart", false)) return
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(ctx)) return
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }
}
