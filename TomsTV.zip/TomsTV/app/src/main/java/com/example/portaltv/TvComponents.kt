package com.example.portaltv

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focus.onFocusChanged
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.tv.foundation.lazy.list.TvLazyRow
import androidx.tv.material3.Text
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface

@Composable
fun TvChannelCard(
    channelName: String,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val scaleModifier by animateFloatAsState(targetValue = if (isFocused) 1.08f else 1.0f)

    Surface(
        modifier = Modifier
            .width(180.dp)
            .height(100.dp)
            .scale(scaleModifier)
            .onFocusChanged { isFocused = it.isFocused }
            .border(
                width = if (isFocused) 3.dp else 0.dp,
                color = if (isFocused) Color(0xFF1A73E8) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = channelName,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
fun TvChannelRow(
    categoryName: String,
    channels: List<String>,
    onChannelSelect: (String) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(
            text = categoryName,
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp),
            color = Color.White
        )
        TvLazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(channels.size) { index ->
                TvChannelCard(channelName = channels[index]) {
                    onChannelSelect(channels[index])
                }
            }
        }
    }
}
