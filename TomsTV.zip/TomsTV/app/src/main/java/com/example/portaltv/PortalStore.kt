package com.example.portaltv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PortalStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("portals", Context.MODE_PRIVATE)

    fun load(): List<Portal> = try {
        val a = JSONArray(sp.getString("list", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Portal(o.getString("id"), o.getString("name"), o.getString("url"), o.getString("mac"),
                o.optString("login"), o.optString("pw"))
        }
    } catch (e: Exception) { emptyList() }

    fun save(list: List<Portal>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                .put("mac", it.mac).put("login", it.login).put("pw", it.password))
        }
        sp.edit().putString("list", a.toString()).apply()
    }
}

data class Resume(val key: String, val title: String, val cmd: String, val ep: Int?, val pos: Long)

/** Favoriten und Wiedergabe-Positionen, getrennt pro Portal. */
class UserData(ctx: Context) {
    private val sp = ctx.getSharedPreferences("userdata", Context.MODE_PRIVATE)

    fun favs(portalId: String, type: String): List<Item> = try {
        val a = JSONArray(sp.getString("fav:$portalId:$type", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val e = o.optJSONArray("eps")
            Item(o.getString("id"), o.getString("name"), o.optString("cmd"),
                o.optString("logo").ifBlank { null }, o.optString("cat"),
                if (e == null) emptyList() else (0 until e.length()).map { j -> e.getInt(j) })
        }
    } catch (e: Exception) { emptyList() }

    fun saveFavs(portalId: String, type: String, list: List<Item>) {
        val a = JSONArray()
        list.forEach { f ->
            a.put(JSONObject().put("id", f.id).put("name", f.name).put("cmd", f.cmd)
                .put("logo", f.logo ?: "").put("cat", f.cat).put("eps", JSONArray(f.episodes)))
        }
        sp.edit().putString("fav:$portalId:$type", a.toString()).apply()
    }

    private fun strSet(key: String): Set<String> = try {
        val a = JSONArray(sp.getString(key, "[]"))
        (0 until a.length()).map { a.getString(it) }.toSet()
    } catch (e: Exception) { emptySet() }

    private fun saveStrSet(key: String, set: Set<String>) {
        sp.edit().putString(key, JSONArray(set.toList()).toString()).apply()
    }

    fun hiddenCats(portalId: String, type: String): Set<String> = strSet("hcat:$portalId:$type")
    fun saveHiddenCats(portalId: String, type: String, set: Set<String>) = saveStrSet("hcat:$portalId:$type", set)
    fun hiddenItems(portalId: String, type: String): Set<String> = strSet("hitem:$portalId:$type")
    fun saveHiddenItems(portalId: String, type: String, set: Set<String>) = saveStrSet("hitem:$portalId:$type", set)
    fun hiddenChans(portalId: String): Set<String> = strSet("hch:$portalId")
    fun saveHiddenChans(portalId: String, set: Set<String>) = saveStrSet("hch:$portalId", set)

    fun resumes(portalId: String): List<Resume> = try {
        val a = JSONArray(sp.getString("res:$portalId", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Resume(o.getString("key"), o.getString("title"), o.getString("cmd"),
                if (o.has("ep")) o.getInt("ep") else null, o.getLong("pos"))
        }
    } catch (e: Exception) { emptyList() }

    private fun writeResumes(portalId: String, list: List<Resume>) {
        val a = JSONArray()
        list.take(30).forEach { r ->
            val o = JSONObject().put("key", r.key).put("title", r.title).put("cmd", r.cmd).put("pos", r.pos)
            r.ep?.let { o.put("ep", it) }
            a.put(o)
        }
        sp.edit().putString("res:$portalId", a.toString()).apply()
    }

    fun putResume(portalId: String, r: Resume) =
        writeResumes(portalId, listOf(r) + resumes(portalId).filterNot { it.key == r.key })

    fun removeResume(portalId: String, key: String) =
        writeResumes(portalId, resumes(portalId).filterNot { it.key == key })
}
