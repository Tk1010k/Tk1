// Store logic
class PortalStore {}