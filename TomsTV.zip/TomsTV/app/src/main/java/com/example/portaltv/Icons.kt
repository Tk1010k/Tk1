package com.example.portaltv

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp

/** Selbst gezeichnete Symbole (3D/Glow) und Comic-Profilbilder – ohne Bilddateien. Koordinaten: Mitte = 0/0, Radius ca. 90. */

private val OUT = Color(0xFF10142E)
private val RIM = Color(0x99FFFFFF)

private fun vg(a: Long, b: Long): Brush = Brush.verticalGradient(listOf(Color(a), Color(b)), startY = -70f, endY = 70f)
private val CR = vg(0xFFFF6B6B, 0xFFB3122A)
private val GD = vg(0xFFFFE27A, 0xFFE0901A)
private val BL = vg(0xFF6FB4FF, 0xFF2447D6)
private val GR = vg(0xFF6BFFB8, 0xFF0A9A63)
private val PU = vg(0xFFD28BFF, 0xFF6A21C9)
private val PK = vg(0xFFFF9CCF, 0xFFC2336B)
private val DK = vg(0xFF3A4166, 0xFF12162E)
private val SL = vg(0xFFF4F6FF, 0xFF8D99BD)
private fun solid(c: Long): Brush = Brush.verticalGradient(listOf(Color(c), Color(c)))

private fun DrawScope.unit90(block: DrawScope.() -> Unit) {
    val s = size.minDimension / 190f
    withTransform({ translate(size.width / 2f, size.height / 2f); scale(s, s, Offset.Zero) }) { block() }
}

private fun DrawScope.glow(cx: Float, cy: Float, r: Float, c: Long, k: Float = 1f) {
    drawCircle(Brush.radialGradient(listOf(Color(c).copy(alpha = 0.55f * k), Color.Transparent), center = Offset(cx, cy), radius = r),
        radius = r, center = Offset(cx, cy))
}

private fun DrawScope.rr(x: Float, y: Float, w: Float, h: Float, r: Float, b: Brush, line: Color? = RIM, lw: Float = 3f) {
    drawRoundRect(b, Offset(x, y), Size(w, h), CornerRadius(r, r))
    if (line != null) drawRoundRect(line, Offset(x, y), Size(w, h), CornerRadius(r, r), style = Stroke(lw))
}

private fun DrawScope.ci(cx: Float, cy: Float, r: Float, b: Brush, line: Color? = RIM, lw: Float = 3f) {
    drawCircle(b, r, Offset(cx, cy))
    if (line != null) drawCircle(line, r, Offset(cx, cy), style = Stroke(lw))
}

private fun DrawScope.pf(b: Brush, line: Color? = RIM, lw: Float = 3f, build: Path.() -> Unit) {
    val p = Path().apply(build)
    drawPath(p, b)
    if (line != null) drawPath(p, line, style = Stroke(lw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.ln(x1: Float, y1: Float, x2: Float, y2: Float, c: Color, w: Float) {
    drawLine(c, Offset(x1, y1), Offset(x2, y2), strokeWidth = w, cap = StrokeCap.Round)
}

@Composable
fun GlowIcon(kind: String, size: Dp) {
    val gl = if (LocalPerf.current) 0f else LocalGlow.current
    Canvas(Modifier.size(size)) {
        val g: DrawScope.(Float, Float, Float, Long) -> Unit = { cx, cy, r, c -> if (gl > 0f) glow(cx, cy, r, c, gl) }
        unit90 {
            when (kind) {
                "home" -> {
                    g(0f, 0f, 80f, 0xFF4DA3FF)
                    pf(CR) { moveTo(-62f, -4f); lineTo(0f, -62f); lineTo(62f, -4f); close() }
                    rr(-46f, -6f, 92f, 64f, 6f, BL)
                    rr(-14f, 18f, 28f, 40f, 5f, solid(0xFF0A1238), null)
                }
                "tv" -> {
                    g(0f, 0f, 90f, 0xFF4DA3FF)
                    pf(solid(0x00000000), Color(0xFFCFD6EA), 6f) { moveTo(-18f, -50f); lineTo(0f, -28f); lineTo(18f, -50f) }
                    rr(-70f, -30f, 140f, 92f, 14f, DK)
                    rr(-58f, -18f, 116f, 68f, 8f, BL, null)
                    pf(solid(0x00000000), Color(0x80FFFFFF), 5f) { moveTo(-40f, -8f); quadraticBezierTo(-20f, -14f, 0f, -8f) }
                }
                "film" -> {
                    g(0f, 0f, 90f, 0xFFFF3B5C)
                    rr(-62f, -14f, 124f, 76f, 10f, DK)
                    pf(CR) { moveTo(-64f, -16f); lineTo(-56f, -52f); lineTo(64f, -34f); lineTo(60f, -16f); close() }
                    ln(-34f, -46f, -14f, -16f, Color.White, 10f); ln(2f, -42f, 22f, -16f, Color.White, 10f); ln(38f, -38f, 58f, -16f, Color.White, 10f)
                    rr(-44f, 10f, 88f, 7f, 3f, solid(0xB3FFFFFF), null)
                }
                "popcorn" -> {
                    g(0f, 0f, 85f, 0xFFFFD54A)
                    val pc = solid(0xFFFFF6D6); val pl = Color(0xFFF1C24A)
                    ci(-26f, -34f, 17f, pc, pl); ci(0f, -44f, 19f, pc, pl); ci(26f, -34f, 17f, pc, pl)
                    pf(CR) { moveTo(-46f, -14f); lineTo(46f, -14f); lineTo(34f, 58f); lineTo(-34f, 58f); close() }
                    ln(-22f, -14f, -16f, 58f, Color(0xD9FFFFFF), 8f); ln(0f, -14f, 0f, 58f, Color(0xD9FFFFFF), 8f); ln(22f, -14f, 16f, 58f, Color(0xD9FFFFFF), 8f)
                }
                "resume" -> {
                    g(0f, 0f, 85f, 0xFF6BFFB8)
                    ci(0f, 0f, 62f, GR)
                    pf(solid(0xFFFFFFFF), null) { moveTo(-20f, -34f); lineTo(38f, 0f); lineTo(-20f, 34f); close() }
                    pf(solid(0x00000000), Color(0xCCFFFFFF), 6f) { moveTo(-50f, -22f); quadraticBezierTo(-56f, 0f, -50f, 22f) }
                }
                "bookmark" -> {
                    g(0f, 0f, 80f, 0xFFFF5FA2)
                    pf(PK) { moveTo(-42f, -62f); lineTo(42f, -62f); lineTo(42f, 60f); lineTo(0f, 30f); lineTo(-42f, 60f); close() }
                    ln(-26f, -46f, -26f, -14f, Color(0x99FFFFFF), 7f)
                }
                "calendar" -> {
                    g(0f, 0f, 90f, 0xFF6BFFB8)
                    rr(-62f, -52f, 124f, 112f, 14f, SL)
                    rr(-62f, -52f, 124f, 34f, 14f, GR, null)
                    rr(-62f, -36f, 124f, 18f, 0f, GR, null)
                    ci(-30f, -58f, 7f, solid(0xFF12162E), null); ci(30f, -58f, 7f, solid(0xFF12162E), null)
                    val cell = solid(0xFF3A4166)
                    rr(-44f, -4f, 20f, 16f, 3f, cell, null); rr(-10f, -4f, 20f, 16f, 3f, cell, null); rr(24f, -4f, 20f, 16f, 3f, cell, null)
                    rr(-44f, 24f, 20f, 16f, 3f, cell, null); rr(-10f, 24f, 20f, 16f, 3f, solid(0xFFFF6B6B), null)
                }
                "ticket" -> {
                    g(0f, 0f, 95f, 0xFFFFD54A)
                    pf(GD) {
                        moveTo(-74f, -34f); lineTo(74f, -34f); lineTo(74f, -10f); quadraticBezierTo(56f, 0f, 74f, 10f)
                        lineTo(74f, 34f); lineTo(-74f, 34f); lineTo(-74f, 10f); quadraticBezierTo(-56f, 0f, -74f, -10f); close()
                    }
                    drawLine(Color(0xCCFFFFFF), Offset(30f, -34f), Offset(30f, 34f), strokeWidth = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 7f)))
                    rr(-54f, -8f, 62f, 8f, 4f, solid(0xCCFFFFFF), null); rr(-54f, 10f, 40f, 7f, 3f, solid(0x80FFFFFF), null)
                }
                "ball" -> {
                    g(0f, 0f, 85f, 0xFF6BFFB8)
                    ci(0f, 0f, 70f, vg(0xFFF4F6FF, 0xFFB9C2D8))
                    pf(solid(0xFF12162E), null) { moveTo(0f, -24f); lineTo(23f, -7f); lineTo(14f, 20f); lineTo(-14f, 20f); lineTo(-23f, -7f); close() }
                    val d = Color(0xFF12162E)
                    ln(0f, -24f, 0f, -64f, d, 4f); ln(23f, -7f, 58f, -22f, d, 4f); ln(14f, 20f, 36f, 52f, d, 4f)
                    ln(-14f, 20f, -36f, 52f, d, 4f); ln(-23f, -7f, -58f, -22f, d, 4f)
                }
                "pad" -> {
                    g(0f, 0f, 95f, 0xFFA65BFF)
                    withTransform({ scale(0.8f, 0.8f, Offset.Zero) }) {
                        pf(PU) {
                            moveTo(-80f, -56f); quadraticBezierTo(-92f, -56f, -96f, -30f); lineTo(-104f, 18f)
                            quadraticBezierTo(-108f, 44f, -88f, 44f); quadraticBezierTo(-70f, 44f, -62f, 24f); lineTo(-52f, 4f)
                            lineTo(52f, 4f); lineTo(62f, 24f); quadraticBezierTo(70f, 44f, 88f, 44f)
                            quadraticBezierTo(108f, 44f, 104f, 18f); lineTo(96f, -30f); quadraticBezierTo(92f, -56f, 80f, -56f); close()
                        }
                        ln(-62f, -26f, -42f, -26f, Color.White, 7f); ln(-52f, -36f, -52f, -16f, Color.White, 7f)
                        ci(52f, -34f, 7f, solid(0xFF6BFFB8), null); ci(68f, -22f, 7f, solid(0xFFFF6B6B), null)
                        ci(36f, -22f, 7f, solid(0xFF4DA3FF), null); ci(52f, -10f, 7f, solid(0xFFFFD54A), null)
                    }
                }
                "news" -> {
                    g(0f, 0f, 90f, 0xFF4DA3FF)
                    rr(-62f, -48f, 124f, 96f, 10f, SL)
                    rr(-48f, -34f, 60f, 22f, 4f, BL, null); rr(22f, -34f, 26f, 26f, 4f, CR, null)
                    rr(-48f, -2f, 96f, 8f, 3f, DK, null); rr(-48f, 16f, 96f, 8f, 3f, DK, null); rr(-48f, 32f, 66f, 8f, 3f, DK, null)
                }
                "music" -> {
                    g(0f, 0f, 85f, 0xFFFF5FA2)
                    rr(-8f, -56f, 12f, 96f, 4f, PK, null); rr(40f, -68f, 12f, 96f, 4f, PK, null)
                    pf(PK) { moveTo(-8f, -56f); lineTo(52f, -70f); lineTo(52f, -48f); lineTo(-8f, -34f); close() }
                    ci(-26f, 40f, 22f, PK); ci(30f, 28f, 22f, PK)
                }
                "star" -> {
                    g(0f, 0f, 85f, 0xFFFFD54A)
                    pf(GD) {
                        for (i in 0 until 10) {
                            val a = -Math.PI / 2 + i * Math.PI / 5
                            val r = if (i % 2 == 0) 66f else 28f
                            val x = (r * Math.cos(a)).toFloat(); val y = (r * Math.sin(a)).toFloat()
                            if (i == 0) moveTo(x, y) else lineTo(x, y)
                        }
                        close()
                    }
                }
                "gear" -> {
                    g(0f, 0f, 85f, 0xFFA65BFF)
                    for (i in 0 until 8) rotate(i * 45f, Offset.Zero) { rr(-12f, -66f, 24f, 26f, 5f, PU) }
                    ci(0f, 0f, 46f, PU)
                    ci(0f, 0f, 20f, solid(0xFF12162E), null)
                }
            }
        }
    }
}

/** Profilbilder: acht Farbverläufe (g0 bis g7). Alte Tier-Namen werden auf die Farben abgebildet. */
val AVATARS = (0 until 8).map { "g$it" }
private val LEGACY_AV = listOf("lion", "robot", "astro", "panda", "fox", "ninja", "owl", "cat")
private val ORB = listOf(
    0xFF22D3EE to 0xFF8B5CF6, 0xFFFF4D8D to 0xFFFF9F43, 0xFF34D399 to 0xFF3B82F6, 0xFFF59E0B to 0xFFEF4444,
    0xFFA78BFA to 0xFFEC4899, 0xFF38BDF8 to 0xFF22C55E, 0xFFFB7185 to 0xFFF59E0B, 0xFF2DD4BF to 0xFF6366F1
)

private fun orbOf(kind: String): Pair<Color, Color> {
    val i = (if (kind.startsWith("g")) kind.drop(1).toIntOrNull() else LEGACY_AV.indexOf(kind).takeIf { it >= 0 }) ?: 0
    val p = ORB[((i % ORB.size) + ORB.size) % ORB.size]
    return Color(p.first) to Color(p.second)
}

/** Erster Buchstabe oder erste Ziffer des Namens, groß. */
fun initialOf(name: String): String = name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "?"

private fun DrawScope.co(cx: Float, cy: Float, r: Float, c: Long) {
    drawCircle(Color(c), r, Offset(cx, cy)); drawCircle(OUT, r, Offset(cx, cy), style = Stroke(5f))
}

private fun DrawScope.po(c: Long, build: Path.() -> Unit) {
    val p = Path().apply(build)
    drawPath(p, Color(c)); drawPath(p, OUT, style = Stroke(5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

private fun DrawScope.eo(cx: Float, cy: Float, rx: Float, ry: Float, c: Long, deg: Float = 0f) {
    rotate(deg, Offset(cx, cy)) {
        drawOval(Color(c), Offset(cx - rx, cy - ry), Size(rx * 2, ry * 2))
        drawOval(OUT, Offset(cx - rx, cy - ry), Size(rx * 2, ry * 2), style = Stroke(5f))
    }
}

private fun DrawScope.ro(x: Float, y: Float, w: Float, h: Float, r: Float, c: Long) {
    drawRoundRect(Color(c), Offset(x, y), Size(w, h), CornerRadius(r, r))
    drawRoundRect(OUT, Offset(x, y), Size(w, h), CornerRadius(r, r), style = Stroke(5f))
}

/** Profilbild: weicher Farbverlauf-Orb mit Anfangsbuchstabe. */
@Composable
fun Avatar(kind: String, size: Dp, letter: String = "") {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().clip(CircleShape)) {
            val (ca, cb) = orbOf(kind)
            val w = this.size.minDimension
            drawRect(Color(0xFF10121F))
            val pa = Offset(w * 0.26f, w * 0.24f)
            val pb = Offset(w * 0.80f, w * 0.82f)
            drawRect(Brush.radialGradient(listOf(ca.copy(alpha = 0.95f), Color.Transparent), center = pa, radius = w * 0.75f))
            drawRect(Brush.radialGradient(listOf(cb.copy(alpha = 0.98f), Color.Transparent), center = pb, radius = w * 0.72f))
            drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Transparent),
                center = Offset(w * 0.30f, w * 0.25f), radius = w * 0.5f))
            val st = w * 0.03f
            drawCircle(Color.White.copy(alpha = 0.38f), radius = w / 2f - st / 2f, style = Stroke(st))
        }
        if (letter.isNotEmpty()) {
            Text(letter, fontSize = (size.value * 0.46f).sp, fontWeight = FontWeight.Light, color = Color.White)
        }
    }
}

/** Passendes Symbol zu einem Kategorienamen (nur eine Schätzung nach dem Namen). */
fun catKind(title: String): String? {
    val t = title.lowercase()
    return when {
        listOf("sport", "fußball", "fussball", "bundesliga", "dazn", "eurosport").any { it in t } -> "ball"
        listOf("game", "gaming", "spiel").any { it in t } -> "pad"
        listOf("news", "nachricht", "info").any { it in t } -> "news"
        listOf("music", "musik", "radio").any { it in t } -> "music"
        listOf("kid", "kinder", "cartoon", "junior").any { it in t } -> "star"
        listOf("movie", "film", "kino", "cinema").any { it in t } -> "film"
        listOf("serie", "series").any { it in t } -> "popcorn"
        else -> null
    }
}
