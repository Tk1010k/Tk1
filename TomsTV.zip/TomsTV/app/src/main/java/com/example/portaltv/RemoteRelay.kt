package com.example.portaltv

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Fernzugriff über einen öffentlichen Nachrichten-Relay (ntfy.sh, ohne Konto).
 * Alles wird mit einem Schlüssel aus dem Koppel-Code verschlüsselt (AES-GCM),
 * der Relay sieht nur verschlüsselte Daten. Die Box fragt regelmäßig nach Befehlen.
 */
object RemoteRelay {
    const val RELAY = "https://ntfy.sh"
    private const val ALPHA = "abcdefghjkmnpqrstuvwxyz23456789"
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    private val keys = HashMap<String, SecretKeySpec>()
    private val rnd = SecureRandom()

    class Msg(val id: String, val text: String?)

    fun newCode(): String = (1..10).map { ALPHA[rnd.nextInt(ALPHA.length)] }.joinToString("")
    fun norm(c: String): String = c.lowercase().filter { it.isLetterOrDigit() }
    fun pretty(c: String): String = norm(c).chunked(5).joinToString("-")

    fun topic(code: String): String {
        val h = MessageDigest.getInstance("SHA-256").digest(("tomstv-topic:" + norm(code)).toByteArray())
        return h.joinToString("") { "%02x".format(it) }.take(32)
    }

    @Synchronized
    private fun key(code: String): SecretKeySpec = keys.getOrPut(norm(code)) {
        val spec = PBEKeySpec(norm(code).toCharArray(), "tomstv-remote".toByteArray(), 50000, 256)
        SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded, "AES")
    }

    fun encrypt(code: String, text: String): String {
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(code), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + c.doFinal(text.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun decrypt(code: String, b64: String): String? = try {
        val a = Base64.decode(b64, Base64.DEFAULT)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(code), GCMParameterSpec(128, a.copyOfRange(0, 12)))
        String(c.doFinal(a.copyOfRange(12, a.size)), Charsets.UTF_8)
    } catch (e: Exception) { null }

    /** Sendet eine Antwort an das Handy. Passt die Portalliste an, wenn sie für eine Nachricht zu lang ist. */
    fun publish(code: String, dir: String, json: JSONObject) {
        var body = encrypt(code, json.toString())
        val arr: JSONArray? = json.optJSONArray("portals")
        while (body.length > 3900 && arr != null && arr.length() > 0) {
            arr.remove(arr.length() - 1)
            body = encrypt(code, json.toString())
        }
        val req = Request.Builder().url("$RELAY/${topic(code)}$dir")
            .post(body.toRequestBody("text/plain".toMediaTypeOrNull())).build()
        http.newCall(req).execute().use { if (!it.isSuccessful) throw java.io.IOException("HTTP " + it.code) }
    }

    fun fetch(code: String, dir: String, since: String): List<Msg> {
        val req = Request.Builder().url("$RELAY/${topic(code)}$dir/json?poll=1&since=$since").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw java.io.IOException("HTTP " + r.code)
            val out = ArrayList<Msg>()
            for (line in (r.body?.string() ?: "").lineSequence()) {
                if (line.isBlank()) continue
                val j = try { JSONObject(line) } catch (e: Exception) { continue }
                if (j.optString("event") != "message") continue
                out.add(Msg(j.optString("id"), decrypt(code, j.optString("message"))))
            }
            return out
        }
    }
}
