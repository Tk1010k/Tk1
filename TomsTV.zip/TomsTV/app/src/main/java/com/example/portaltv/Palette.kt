package com.example.portaltv

import androidx.compose.ui.graphics.Color

object Palette {
    // Kinoreifer, dunkler Hintergrund für TV-Bildschirme
    val Background = Color(0xFF121214) 
    val Surface = Color(0xFF1E1E24)
    val SurfaceSecondary = Color(0xFF2A2A32)

    // Moderne Akzentfarben (Neon-Blau und Cyan)
    val Primary = Color(0xFF00D2FF)
    val Secondary = Color(0xFF0072FF)
    
    // Textfarben mit hohem Kontrast
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFB3B3B3)
    val TextMuted = Color(0xFF757575)

    // Statusfarben
    val Error = Color(0xFFFF4A4A)
    val Success = Color(0xFF2ECC71)
}