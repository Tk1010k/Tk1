// Palette definitions
class Palette {}