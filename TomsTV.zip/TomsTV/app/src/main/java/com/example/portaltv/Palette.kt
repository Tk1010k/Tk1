package com.example.portaltv

import androidx.compose.ui.graphics.Color

/** Wählbare Farben: Schrift und Akzent (Rahmen, Balken, Knöpfe). */
object Palette {
    val GOLD = Color(0xFFE8B84A)
    val RED = Color(0xFFE5432D)

    val textOptions: List<Pair<String, Color>> = listOf(
        "Weiß" to Color(0xFFFFFFFF),
        "Gold" to GOLD,
        "Gelb" to Color(0xFFFFEB3B),
        "Hellblau" to Color(0xFF4FC3F7),
        "Grün" to Color(0xFF69F0AE),
        "Orange" to Color(0xFFFFA726),
        "Pink" to Color(0xFFFF80AB)
    )

    val CINEMA_RED = Color(0xFFE50914)

    val accentOptions: List<Pair<String, Color>> = listOf(
        "Kino-Rot" to CINEMA_RED,
        "Rot" to RED,
        "Gold" to GOLD,
        "Orange" to Color(0xFFFF8F00),
        "Hellblau" to Color(0xFF29B6F6),
        "Grün" to Color(0xFF00C853),
        "Pink" to Color(0xFFFF4081)
    )

    fun text(name: String): Color = textOptions.firstOrNull { it.first == name }?.second ?: textOptions[0].second
    fun accent(name: String): Color = accentOptions.firstOrNull { it.first == name }?.second ?: accentOptions[0].second
}
