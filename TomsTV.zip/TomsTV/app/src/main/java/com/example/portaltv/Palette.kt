package com.example.portaltv

import androidx.compose.ui.graphics.Color

/** Wählbare Farben: Schrift und Akzent (Rahmen, Balken, Knöpfe). */
object Palette {
    val GOLD = Color(0xFFE8B84A)
    val RED = Color(0xFFE5432D)

    val textOptions: List<Pair<String, Color>> = listOf(
        "Weiß" to Color(0xFFFFFFFF),
        "Gold" to GOLD,
        "Gelb" to Color(0xFFFFEB3B),
        "Hellblau" to Color(0xFF4FC3F7),
        "Grün" to Color(0xFF69F0AE),
        "Orange" to Color(0xFFFFA726),
        "Pink" to Color(0xFFFF80AB),
        "Champagner" to Color(0xFFF3E5C3),
        "Platin" to Color(0xFFE5E4E2),
        "Eisblau" to Color(0xFFCDE9FF),
        "Roségold" to Color(0xFFF4C7B8),
        "Mint" to Color(0xFFB8F2E0),
        "Lavendel" to Color(0xFFD9C8FF)
    )

    val CINEMA_RED = Color(0xFFE50914)

    val accentOptions: List<Pair<String, Color>> = listOf(
        "Kino-Rot" to CINEMA_RED,
        "Rot" to RED,
        "Gold" to GOLD,
        "Orange" to Color(0xFFFF8F00),
        "Hellblau" to Color(0xFF29B6F6),
        "Grün" to Color(0xFF00C853),
        "Pink" to Color(0xFFFF4081),
        "Königsblau" to Color(0xFF3D5AFE),
        "Saphir" to Color(0xFF2962FF),
        "Smaragd" to Color(0xFF00BFA5),
        "Amethyst" to Color(0xFF9C4DFF),
        "Bordeaux" to Color(0xFFB0203F),
        "Roségold" to Color(0xFFE8A598),
        "Bernstein" to Color(0xFFFFB300),
        "Türkis" to Color(0xFF1DE9B6),
        "Magenta" to Color(0xFFE040FB),
        "Platin" to Color(0xFFCFD8DC)
    )

    fun text(name: String): Color = textOptions.firstOrNull { it.first == name }?.second ?: textOptions[0].second
    fun accent(name: String): Color = accentOptions.firstOrNull { it.first == name }?.second ?: accentOptions[0].second
}
