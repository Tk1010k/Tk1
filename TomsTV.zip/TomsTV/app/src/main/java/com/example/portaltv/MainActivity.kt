@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.portaltv

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.Coil
import coil.ImageLoader
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

val LocalLight = compositionLocalOf { false }
val LocalMuted = compositionLocalOf { Color(0xFFB0B7BF) }
val LocalPerf = compositionLocalOf { false }
/** Streaming-Premium-Design aktiv (schwarz, Kino-Rot, große Kacheln). */
val LocalPremium = compositionLocalOf { false }

/** Titel-Schrift: im Premium-Design moderne, kräftige Sans-Schrift, sonst Serif. */
val titleFont: FontFamily
    @Composable get() = if (LocalPremium.current) FontFamily.SansSerif else FontFamily.Serif

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.crash(e)
            oldHandler?.uncaughtException(t, e)
        }
        Coil.setImageLoader(ImageLoader.Builder(this).crossfade(350).build())
        setContent {
            val vm: AppVM = viewModel()
            val light = false
            val ac = Palette.accent(vm.accentName)
            val tc = if (light) Color(0xFF14161B) else Palette.text(vm.textColorName)
            val premium = vm.designMode == "premium"
            val bg = when (vm.designMode) {
                "premium" -> Color(0xFF000000)
                "oled" -> Color(0xFF000000)
                "night" -> Color(0xFF070B16)
                else -> Color(0xFF0A0A0F)
            }
            val onAc = if (ac.luminance() > 0.5f) Color(0xFF0A0A0F) else Color.White
            val scheme = if (light) {
                lightColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc,
                    onSurfaceVariant = tc, background = bg, surface = bg)
            } else {
                darkColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc, onSurfaceVariant = tc)
            }
            val muted = if (light) Color(0xFF5B6270) else if (premium) Color(0xFFA8A8A8) else Color(0xFFB0B7BF)
            CompositionLocalProvider(LocalLight provides light, LocalMuted provides muted, LocalPerf provides vm.perfMode,
                LocalPremium provides premium) {
                MaterialTheme(colorScheme = scheme) {
                    Surface(Modifier.fillMaxSize(), color = bg, contentColor = tc) { App(vm) }
                }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Menü-Taste der Fernbedienung = Favorit umschalten. */
fun Modifier.favKey(onFav: () -> Unit): Modifier = onKeyEvent { e ->
    if (e.type == KeyEventType.KeyDown && e.key == Key.Menu) { onFav(); true } else false
}

/** Milchglas-Fläche: sanft durchscheinend mit feiner Kante. */
fun Modifier.glass(radius: Dp = 16.dp): Modifier = composed {
    val light = LocalLight.current
    val shape = RoundedCornerShape(radius)
    if (LocalPremium.current) {
        // Premium: flache, dunkle Fläche statt Milchglas
        return@composed this.clip(RoundedCornerShape(radius.coerceAtMost(10.dp))).background(Color(0x17FFFFFF))
    }
    this.clip(shape)
        .background(Brush.linearGradient(
            if (light) listOf(Color(0xEEFFFFFF), Color(0x99FFFFFF)) else listOf(Color(0x30FFFFFF), Color(0x0AFFFFFF))))
        .border(1.dp, Brush.linearGradient(
            if (light) listOf(Color(0x33000000), Color(0x0F000000)) else listOf(Color(0x66FFFFFF), Color(0x10FFFFFF))), shape)
}

/** Fokus für die Fernbedienung: Zoom, Leuchten und Rahmen in der Akzentfarbe. */
fun Modifier.tvFocus(zoom: Float = 1.03f): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val perf = LocalPerf.current
    if (LocalPremium.current) {
        // Premium: Kachel wächst deutlich, weißer Rahmen – wie bei großen Streaming-Diensten
        val z = 1f + (zoom - 1f) * 1.6f
        val scale by animateFloatAsState(if (f && !perf) z else 1f, tween(180), label = "focusZoomP")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .border(if (f) 3.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(8.dp))
    }
    val scale by animateFloatAsState(if (f && !perf) zoom else 1f, label = "focusZoom")
    val accent = MaterialTheme.colorScheme.primary
    this.onFocusChanged { f = it.hasFocus }
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .shadow(if (f && !perf) 18.dp else 0.dp, RoundedCornerShape(14.dp), clip = false, ambientColor = accent, spotColor = accent)
        .border(if (f) 2.dp else 0.dp, if (f) accent else Color.Transparent, RoundedCornerShape(14.dp))
}

@Composable
fun App(vm: AppVM = viewModel()) {
    val activity = LocalContext.current as? Activity
    val lastBack = remember { longArrayOf(0L) }
    BackHandler {
        if (!vm.back()) {
            val now = System.currentTimeMillis()
            if (now - lastBack[0] < 2500) activity?.finish()
            else {
                lastBack[0] = now
                vm.showNotice("Nochmal Zurück zum Beenden")
            }
        }
    }
    val mode = vm.designMode
    val perfFast = vm.perfMode
    val glow = MaterialTheme.colorScheme.primary
    val glowA = when (mode) { "oled" -> 0.10f; "premium" -> 0.11f; else -> 0.26f }
    val blueA = when (mode) {
        "night" -> 0.30f
        "oled", "premium" -> 0.0f
        else -> 0.16f
    }
    Box(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(
            when (mode) {
                "oled" -> listOf(Color.Black, Color.Black)
                "premium" -> listOf(Color(0xFF0B0B0B), Color.Black)
                "night" -> listOf(Color(0xFF0B1426), Color(0xFF050810))
                else -> listOf(Color(0xFF0C0C13), Color(0xFF07070B))
            }))
        .drawBehind {
            drawRect(Brush.radialGradient(listOf(glow.copy(alpha = glowA), Color.Transparent),
                center = Offset(size.width * 0.12f, 0f), radius = size.maxDimension * 0.6f))
            drawRect(Brush.radialGradient(listOf(Color(0xFF3B5BDB).copy(alpha = blueA), Color.Transparent),
                center = Offset(size.width, size.height), radius = size.maxDimension * 0.55f))
        }) {
        if (!vm.introDone) {
            IntroScreen(vm.designMode == "premium", vm.introSound && !vm.perfMode) { vm.introDone = true }
        } else AnimatedContent(
            targetState = vm.stack.last(),
            transitionSpec = {
                if (perfFast) (EnterTransition.None togetherWith ExitTransition.None)
                else (fadeIn(tween(260)) togetherWith fadeOut(tween(160)))
            },
            label = "screen"
        ) { s -> when (s) {
            Screen.Portals -> Shell(vm, "portals") { PortalsScreen(vm) }
            is Screen.Form -> FormScreen(vm, s.edit)
            Screen.Home -> Shell(vm, "home") { HomeScreen(vm) }
            is Screen.Browse -> Shell(vm, s.type) { BrowseScreen(vm, s.type) }
            is Screen.Seasons -> {
                val rows: List<Pair<String, () -> Unit>> = vm.seasons.map { se -> se.name to { vm.openSeason(se) } }
                SimpleList(s.title, rows)
            }
            is Screen.Episodes -> {
                val se = s.season
                val rows: List<Pair<String, () -> Unit>> = se.episodes.map { n ->
                    (if (vm.isSeen(se, n)) "✓  " else "") + "Episode $n" to { vm.playEpisode(se, n) }
                }
                SimpleList(se.name, rows)
            }
            Screen.ResumeList -> {
                val rows: List<Pair<String, () -> Unit>> = vm.resumeList.map { r ->
                    "${r.title}  ·  ${fmtTime(r.pos)}" to { vm.playResume(r) }
                }
                val empty: List<Pair<String, () -> Unit>> = listOf("Noch nichts angefangen" to { })
                SimpleList("Weiterschauen", if (rows.isEmpty()) empty else rows)
            }
            Screen.Guide -> Shell(vm, "epg") { GuideScreen(vm) }
            Screen.Favs -> Shell(vm, "fav") { FavsScreen(vm) }
            Screen.Watch -> Shell(vm, "watch") { WatchScreen(vm) }
            Screen.Settings -> Shell(vm, "settings") { SettingsScreen(vm) }
            Screen.AppSettings -> SettingsScreen(vm)
            Screen.LogView -> LogScreen(vm)
            is Screen.Detail -> DetailScreen(vm, s.item)
            Screen.EditCats -> EditCatsScreen(vm)
            Screen.EditChans -> EditChansScreen(vm)
            Screen.PhoneAdd -> PhoneAddScreen(vm)
            Screen.Play -> PlayerScreen(vm)
        } }
        if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
        if (vm.introDone) {
            UpdateDialog(vm)
            ReminderDialog(vm)
        }
        vm.notice?.let {
            Text(it, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
                    .background(Color(0xDD0D47A1), RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 8.dp))
        }
        vm.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(12.dp))
        }
    }
}

@Composable
fun ListRow(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(
        text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(12.dp)
    )
}

@Composable
fun SimpleList(title: String, rows: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(rows) { (label, act) -> ListRow(label, false, act) } }
    }
}

@Composable
fun PortalsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TOM’S TV", fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
            letterSpacing = 6.sp)
        Box(Modifier.padding(vertical = 6.dp).width(120.dp).height(2.dp).background(accent))
        Text("PORTALE · ALLE SIND AKTIV", fontSize = 11.sp, letterSpacing = 4.sp, color = accent,
            modifier = Modifier.align(Alignment.Start).padding(top = 6.dp, bottom = 6.dp))
        if (vm.portals.isEmpty()) {
            Text("Noch kein Portal eingetragen. Füge unten dein erstes Portal hinzu.", color = gray,
                modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).widthIn(max = 900.dp).fillMaxWidth()) {
            items(vm.portals, key = { it.id }) { p ->
                PortalRow(vm, p, if (p.id == vm.portals.first().id) Modifier.focusRequester(fr) else Modifier)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.tvFocus()) { Text("+ Portal") }
            Button(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) { Text("📱 Per Handy") }
            OutlinedButton(onClick = { vm.refreshAllPortals(true) }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
    }
}

@Composable
fun PortalRow(vm: AppVM, p: Portal, modifier: Modifier = Modifier) {
    var confirm by remember { mutableStateOf(false) }
    val host = remember(p.url) { runCatching { java.net.URL(p.url).host }.getOrDefault(p.url) }
    val st = vm.status[p.id]
    val statusText = when {
        st == null || st == "loading" -> "⏳ lädt …"
        st == "ok" -> "● aktiv"
        else -> "⚠ nicht erreichbar"
    }
    val statusColor = when {
        st == null || st == "loading" -> LocalMuted.current
        st == "ok" -> Color(0xFF69F0AE)
        else -> Color(0xFFFF8A80)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(modifier.weight(1f).tvFocus(1.02f).clip(RoundedCornerShape(16.dp))
            .glass(16.dp)
            .clickable { vm.push(Screen.Form(p)) }.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("🎟", fontSize = 28.sp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(host, fontSize = 12.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(statusText, fontSize = 12.sp, color = statusColor, maxLines = 1)
                val line = vm.portalLine(p)
                if (line.isNotBlank()) {
                    Text(line, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (vm.portalWarn(p)) Color(0xFFFFB74D) else LocalMuted.current)
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.push(Screen.Form(p)) }, modifier = Modifier.tvFocus()) { Text("Bearbeiten") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { if (confirm) vm.deletePortal(p) else confirm = true }, modifier = Modifier.tvFocus()) {
            Text(if (confirm) "Wirklich löschen?" else "Löschen")
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().tvFocus())
}

@Composable
fun FormScreen(vm: AppVM, edit: Portal?) {
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var url by remember { mutableStateOf(edit?.url ?: "http://") }
    var mac by remember { mutableStateOf(edit?.mac ?: "") }
    var login by remember { mutableStateOf(edit?.login ?: "") }
    var pw by remember { mutableStateOf(edit?.password ?: "") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (edit == null) "Portal hinzufügen" else "Portal bearbeiten", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Field("Name", name) { name = it }
        Field("Portal-URL (z. B. http://host/c/)", url) { url = it }
        Field("MAC-Adresse (00:1A:79:XX:XX:XX)", mac) { mac = it }
        Field("Login (optional)", login) { login = it }
        Field("Passwort (optional)", pw) { pw = it }
        err?.let { Text(it, color = Color(0xFFFF8A80)) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(modifier = Modifier.tvFocus(), onClick = {
                val m = mac.trim().uppercase()
                val u = url.trim()
                when {
                    name.isBlank() -> err = "Name fehlt"
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        vm.savePortal(Portal(edit?.id ?: UUID.randomUUID().toString(), name.trim(), u, m, login.trim(), pw))
                        vm.back()
                    }
                }
            }) { Text("Speichern") }
            OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Abbrechen") }
        }
    }
}

@Composable
fun HomeScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 5 -> "Gute Nacht"
        hour < 11 -> "Guten Morgen"
        hour < 18 -> "Guten Tag"
        else -> "Guten Abend"
    }
    val hero = vm.homeNew.take(5)
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(hero.size) {
        while (hero.size > 1 && !vm.perfMode) {
            delay(8000)
            idx = (idx + 1) % hero.size
        }
    }
    val fr = remember { FocusRequester() }
    LaunchedEffect(hero.isNotEmpty()) {
        if (hero.isNotEmpty()) {
            delay(150)
            runCatching { fr.requestFocus() }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(greeting, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont)
                Text("${vm.status.values.count { it == "ok" }} VON ${vm.portals.size} PORTALEN AKTIV", fontSize = 11.sp,
                    letterSpacing = 3.sp, color = gray)
                if (vm.portals.isNotEmpty()) {
                    Text(vm.portals.joinToString("    ") { p ->
                        val st = vm.status[p.id]
                        (if (st == "ok") "●" else if (st != null && st.startsWith("err")) "⚠" else "…") + " " + p.name + vm.portalShort(p)
                    }, fontSize = 11.sp, color = gray, maxLines = 2, modifier = Modifier.padding(top = 2.dp))
                }
            }
            Clock()
        }
        if (hero.isNotEmpty()) {
            HeroBanner(vm, hero[idx % hero.size], idx % hero.size, hero.size, fr)
        } else {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (vm.portals.isEmpty()) {
                    Text("Noch kein Portal eingetragen.", color = gray)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("+ Portal hinzufügen")
                        }
                        OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) {
                            Text("📱 Per Handy")
                        }
                    }
                } else {
                    Text(
                        if (vm.allLoading) "Portale werden verbunden …"
                        else "Keine Inhalte gefunden. Prüfe unter Portale, ob die Portale erreichbar sind.",
                        color = gray
                    )
                }
            }
        }
        if (vm.homeNew.isNotEmpty()) {
            SectionHeader("Neu im Angebot", "Alle anzeigen") { vm.goTo("vod") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.homeNew) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
            }
        }
        if (vm.homeNewByPortal.size > 1) {
            for ((pname, plist) in vm.homeNewByPortal) {
                if (plist.isEmpty()) continue
                SectionHeader("Neu bei " + pname)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(plist) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
                }
            }
        }
        val watch = remember { vm.watchFor("vod") + vm.watchFor("series") }
        if (watch.isNotEmpty()) {
            SectionHeader("Meine Merkliste", "Alle anzeigen") { vm.goTo("watch") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(watch) { w -> MiniPoster(w) { vm.openHomeItem(w, vm.watchType(w)) } }
            }
        }
        if (vm.recentChans.isNotEmpty()) {
            SectionHeader("Zuletzt gesehen")
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.recentChans) { c -> ChannelTile(c) { vm.openRecent(c) } }
            }
        }
        if (vm.homeChannels.isNotEmpty()) {
            SectionHeader("Live TV – Beliebte Sender", "Alle anzeigen") { vm.goTo("itv") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.homeChannels) { c -> ChannelTile(c) { vm.openHomeItem(c, "itv") } }
            }
        }
        if (vm.resumeList.isNotEmpty()) {
            SectionHeader("Weiterschauen")
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.resumeList) { r ->
                    Column(Modifier.width(190.dp).tvFocus(1.05f).clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF)).clickable { vm.playResume(r) }.padding(12.dp)) {
                        Text("⏯  ${fmtTime(r.pos)}", fontSize = 12.sp, color = gray)
                        Text(r.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Tile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(170.dp).tvFocus(1.08f).clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3A0F18), Color(0xFF14080B))))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 46.sp)
        Spacer(Modifier.height(10.dp))
        Text(label.uppercase(), fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BrowseScreen(vm: AppVM, type: String) {
    DisposableEffect(Unit) { onDispose { vm.stopPreview() } }
    Row(Modifier.fillMaxSize()) {
        CategoryPane(vm, type)
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.queryText,
                    onValueChange = { vm.queryText = it; if (type == "itv") vm.search(it) },
                    label = { Text("Suche") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(vm.queryText) }),
                    modifier = Modifier.weight(1f).tvFocus()
                )
                if (type == "itv") {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.push(Screen.Guide) }, modifier = Modifier.tvFocus()) { Text("Programm") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.openEditChannels() }, modifier = Modifier.tvFocus()) { Text("Kanäle") }
                }
                Spacer(Modifier.width(8.dp))
                if (type != "itv") {
                    OutlinedButton(onClick = { vm.toggleEditMode() }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.editMode) "Fertig" else "Ausblenden")
                    }
                    Spacer(Modifier.width(8.dp))
                }
                OutlinedButton(onClick = { vm.push(Screen.EditCats) }, modifier = Modifier.tvFocus()) { Text("Kategorien") }
            }
            Text(if (vm.editMode && type != "itv") "AUSBLENDEN-MODUS: OK blendet einen Eintrag aus oder wieder ein. Beenden mit Fertig."
                else "OK lange drücken oder Menü-Taste = Favorit", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            if (type == "itv" && vm.previewOn && !vm.perfMode && LocalConfiguration.current.screenHeightDp >= 480) PreviewCard(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (type != "itv" && vm.selCat?.endsWith(":resume") == true) {
                    ResumeListView(vm)
                } else if (type == "itv") {
                    LazyColumn(state = vm.listState, modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(vm.items) { ch -> ChannelRow(vm, ch) }
                    }
                } else {
                    val last by remember { derivedStateOf { vm.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 } }
                    val shown = vm.shownItems()
                    LaunchedEffect(last, shown.size, vm.hasMore) {
                        if (vm.hasMore && last >= shown.size - 6) vm.loadMore()
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), state = vm.gridState,
                        modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(shown) { entry -> PosterCard(vm, entry) }
                    }
                    if (vm.busyList) Text("Lade …", Modifier.align(Alignment.BottomCenter).padding(8.dp))
                }
                if (vm.items.isEmpty() && !vm.busyList && !vm.loading && vm.selCat?.endsWith(":resume") != true) Text("Keine Einträge", Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun ChannelRow(vm: AppVM, ch: Item) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).tvFocus(1.02f).onFocusChanged { if (it.hasFocus) vm.requestPreview(ch) }
        .glass(12.dp).favKey { vm.toggleFav(ch) }
        .combinedClickable(onClick = { vm.openItem(ch) }, onLongClick = { vm.toggleFav(ch) }).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(6.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text((if (vm.isFav(ch)) "★ " else "") + ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 13.sp, color = LocalMuted.current,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                vm.epgProgress(now)?.let { p ->
                    LinearProgressIndicator(progress = { p },
                        modifier = Modifier.padding(top = 5.dp).fillMaxWidth().height(3.dp))
                }
            }
        }
    }
}

@Composable
fun PosterCard(vm: AppVM, entry: Item) {
    val hidden = vm.editMode && entry.id in vm.hiddenItems
    Box(Modifier.padding(6.dp)) {
        Box(Modifier.alpha(if (hidden) 0.35f else 1f).tvFocus(1.06f).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF222A33)).favKey { vm.toggleFav(entry) }
            .combinedClickable(onClick = { vm.openItem(entry) }, onLongClick = { vm.toggleFav(entry) })) {
            AsyncImage(model = entry.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                .padding(start = 10.dp, end = 10.dp, top = 30.dp, bottom = 10.dp)) {
                Text((if (hidden) "✗ " else if (vm.isFav(entry)) "★ " else "") + entry.name,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val mac = vm.portal?.mac ?: ""
    val ds = remember {
        DefaultHttpDataSource.Factory().setUserAgent(vm.streamUserAgent()).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (vm.isLive) 6_000 else 10_000).setReadTimeoutMs(if (vm.isLive) 8_000 else 15_000)
            .setDefaultRequestProperties(vm.streamHeaders())
    }
    val exo = remember {
        val selector = DefaultTrackSelector(ctx)
        val maxQ = vm.qualityMode != "auto"
        val forceHigh = vm.qualityMode == "max"
        if (maxQ) {
            // Immer die höchste Bild- und Tonqualität nehmen, die das Gerät kann (nicht an die Bildschirmgröße gebunden).
            selector.setParameters(
                selector.buildUponParameters()
                    .setForceHighestSupportedBitrate(forceHigh)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setConstrainAudioChannelCountToDeviceCapabilities(false)
                    .build()
            )
        }
        if (vm.fourKHelp) {
            // Tunneling gibt es nur über den Track-Selector (DefaultTrackSelector.Parameters)
            selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(true).build())
        }
        val rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        if (vm.fourKHelp) rf.forceEnableMediaCodecAsynchronousQueueing()
        ExoPlayer.Builder(ctx, rf)
            .setTrackSelector(selector)
            // Größerer Puffer: ruhigeres Bild bei 4K und schwankendem Netz
            .setLoadControl(buildLoadControl(vm.isLive, vm.bufferMode))
            // Richtiger Audio-Modus für Filme (Surround, Lautstärke, Fokus)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply {
                playWhenReady = true
                // Tonspur: Deutsch bevorzugen, sonst Standard des Senders
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguages(*(if (vm.prefAudioLang.isNotEmpty()) arrayOf(vm.prefAudioLang) else arrayOf("de", "deu", "ger")))
                    .apply {
                        if (vm.prefTextLang == "off") setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        else if (vm.prefTextLang.isNotEmpty()) setPreferredTextLanguage(vm.prefTextLang)
                    }
                    .build()
                if (maxQ) {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                        .setMaxVideoBitrate(Int.MAX_VALUE)
                        .setMaxAudioBitrate(Int.MAX_VALUE)
                        .setMaxAudioChannelCount(Int.MAX_VALUE)
                        .clearViewportSizeConstraints()
                        .build()
                }
            }
    }
    var retries by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf(false) }
    var audioMenu by remember { mutableStateOf(false) }
    var infoOn by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var qualityText by remember { mutableStateOf("") }
    var skipped by remember(vm.playUrl) { mutableStateOf(false) }
    var controls by remember { mutableStateOf(false) }
    var ctrlTick by remember { mutableIntStateOf(0) }
    val ctrlFr = remember { FocusRequester() }
    // Schnelleres Spulen: 10 s, bei wiederholtem Drücken 30 s, dann 60 s
    val seekState = remember { longArrayOf(0L, 0L) }
    fun stepSeek(dir: Int) {
        val now = System.currentTimeMillis()
        seekState[1] = if (now - seekState[0] < 1200) seekState[1] + 1 else 0L
        seekState[0] = now
        val sec = when {
            seekState[1] < 2 -> 10
            seekState[1] < 5 -> 30
            else -> 60
        }
        val dur = exo.duration
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + dir * sec * 1000L).coerceIn(0L, max))
        vm.showNotice((if (dir < 0) "⏪ " else "") + sec + " s" + (if (dir > 0) " ⏩" else ""))
    }
    val showSkip by remember {
        derivedStateOf {
            val end = if (vm.isEpisode) vm.introEndMs() else 0L
            vm.isEpisode && !skipped && posMs >= 3_000L && posMs <= (if (end > 0L) end - 2_000L else 240_000L)
        }
    }
    val fr = remember { FocusRequester() }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                AppLog.add("Wiedergabefehler (" + vm.playTitle + "): " + error.errorCodeName)
                val http = error.cause as? HttpDataSource.InvalidResponseCodeException
                if (http != null) AppLog.add("HTTP " + http.responseCode + " von " + (http.dataSpec.uri.host ?: "?"))
                // Server lehnt ab: erst andere Kennungen probieren, jeweils mit frischem Link
                if (error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS && vm.nextHeaderMode()) {
                    AppLog.add("Neuer Versuch mit anderer Anfrage-Kennung (Stufe " + vm.headerStage() + ")")
                    vm.reload()
                    return
                }
                if (vm.isLive) {
                    when {
                        retries < 2 -> { retries++; vm.reload() }
                        vm.tryAlternate() -> retries = 0
                        retries < 5 -> { retries++; vm.reload() }
                        else -> vm.error = playErrorText(error)
                    }
                } else vm.error = playErrorText(error)
            }
            private var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING && last == Player.STATE_READY) AppLog.add("Puffert nach: " + vm.playTitle)
                last = state
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !vm.isLive) vm.onEnded()
            }
        }
        exo.addListener(l)
        onDispose {
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
            exo.removeListener(l); exo.release()
        }
    }

    LaunchedEffect(vm.playUrl, vm.playNonce) {
        vm.playUrl?.let { u ->
            ds.setUserAgent(vm.streamUserAgent())
            ds.setDefaultRequestProperties(vm.streamHeaders())
            val pos = if (vm.isLive) 0L else vm.resumePos()
            if (pos > 0) {
                exo.setMediaItem(MediaItem.fromUri(u), pos)
                vm.showNotice("Weiter bei ${fmtTime(pos)}")
            } else exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare(); exo.play()
        }
    }
    LaunchedEffect(Unit) { fr.requestFocus() }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration
            qualityText = qualityLabel(exo)
            delay(1000)
        }
    }
    BackHandler(enabled = audioMenu) { audioMenu = false }
    BackHandler(enabled = controls) { controls = false }
    LaunchedEffect(controls) {
        if (controls) {
            delay(150)
            runCatching { ctrlFr.requestFocus() }
        } else {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    // Leiste blendet sich nach 7 Sekunden ohne Bedienung aus
    LaunchedEffect(controls, ctrlTick) {
        if (controls) {
            delay(7_000)
            controls = false
        }
    }
    LaunchedEffect(vm.playUrl) {
        if (vm.autoSkipIntro && vm.isEpisode && vm.playUrl != null && vm.resumePos() == 0L) {
            var waited = 0
            while (exo.playbackState != Player.STATE_READY && waited < 15_000) {
                delay(250)
                waited += 250
            }
            delay(1200)
            if (exo.currentPosition < 120_000) {
                exo.seekTo(vm.skipTarget(exo.currentPosition))
                skipped = true
            }
        }
    }
    LaunchedEffect(audioMenu) {
        if (!audioMenu) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.chanPanel) {
        if (!vm.chanPanel) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.playChId, vm.isLive) {
        while (vm.isLive) { vm.loadEpg(vm.playChId); delay(60_000) }
    }
    // Läuft ein Sender 40 Sekunden stabil, zählt das als gute Quelle
    LaunchedEffect(vm.playChId, vm.playNonce) {
        if (vm.isLive) {
            delay(40_000)
            if (exo.isPlaying) vm.markGood(vm.playChId)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
        }
    }
    LaunchedEffect(tick, vm.playTitle) { info = true; delay(4000); if (!detail) info = false }

    // Wächter: Bei Hängern im Live-TV (Puffern oder Standbild > 20 s) neuen Link holen.
    LaunchedEffect(Unit) {
        var stuck = 0
        var stalls = 0
        var lastPos = -1L
        while (true) {
            delay(2000)
            val pos = exo.currentPosition
            val bad = vm.isLive && !vm.loading && exo.playWhenReady &&
                (exo.playbackState == Player.STATE_BUFFERING ||
                    (exo.playbackState == Player.STATE_READY && pos == lastPos))
            lastPos = pos
            if (exo.isPlaying) stalls = 0
            if (bad) stuck++ else stuck = 0
            if (stuck >= 4) {
                stuck = 0
                stalls++
                vm.markBad(vm.playChId)
                if (stalls >= 2 && vm.tryAlternate()) stalls = 0 else vm.reload()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
        if (vm.chanPanel || audioMenu || controls) return@onKeyEvent false
        tick++
        val dg = digitOf(e.key)
        if (vm.isLive && dg >= 0) {
            vm.digit(dg)
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_LAST_CHANNEL) ||
                e.key == Key(android.view.KeyEvent.KEYCODE_PROG_RED))) {
            vm.toggleLast()
            return@onKeyEvent true
        }
        if (e.key == Key.MediaPlay) { exo.playWhenReady = true; return@onKeyEvent true }
        if (e.key == Key.MediaPause) { exo.playWhenReady = false; return@onKeyEvent true }
        // Farbtasten der Strong-Fernbedienung: Grün = Ton/Untertitel, Gelb/Info = Infos bzw. Bedienleiste, Blau/Guide = Senderliste
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_GREEN)) { audioMenu = true; return@onKeyEvent true }
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_YELLOW) || e.key == Key(android.view.KeyEvent.KEYCODE_INFO)) {
            if (vm.isLive) detail = !detail else controls = true
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_BLUE) || e.key == Key(android.view.KeyEvent.KEYCODE_GUIDE))) {
            vm.openChannelPanel()
            return@onKeyEvent true
        }
        if (vm.numberBuffer.isNotEmpty() && (e.key == Key.DirectionCenter || e.key == Key.Enter)) {
            vm.commitNumber()
            return@onKeyEvent true
        }
        when (e.key) {
            Key.DirectionUp, Key.ChannelUp -> if (vm.isLive) { detail = false; vm.zap(1); true } else false
            Key.DirectionDown, Key.ChannelDown -> if (vm.isLive) { detail = false; vm.zap(-1); true } else false
            Key.DirectionLeft, Key.MediaRewind ->
                if (!vm.isLive) { stepSeek(-1); true } else { vm.openChannelPanel(); true }
            Key.DirectionRight, Key.MediaFastForward ->
                if (!vm.isLive) { stepSeek(1); true } else { audioMenu = true; true }
            Key.Menu -> if (vm.isLive) { vm.openChannelPanel(); true } else { audioMenu = true; true }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                if (vm.isLive) detail = !detail
                else if (e.key == Key.MediaPlayPause) exo.playWhenReady = !exo.playWhenReady
                else controls = true
                true
            }
            else -> false
        }
    }) {
        AndroidView(factory = { c ->
            PlayerView(c).apply {
                useController = false
                isFocusable = false
                isFocusableInTouchMode = false
                keepScreenOn = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = exo
            }
        }, modifier = Modifier.fillMaxSize())
        if ((info || detail) && !vm.chanPanel && !controls) InfoPanel(vm, detail, posMs, durMs, qualityText, Modifier.align(Alignment.BottomCenter))
        if (controls && !vm.isLive && !vm.chanPanel && !audioMenu) {
            PlayerControls(exo, posMs, durMs, showSkip, ctrlFr, Modifier.align(Alignment.BottomCenter),
                onTick = { ctrlTick++ },
                onSkipIntro = {
                    exo.seekTo(vm.skipTarget(exo.currentPosition))
                    skipped = true
                    controls = false
                })
        }
        if (vm.chanPanel) ChannelPanel(vm, Modifier.align(Alignment.CenterStart))
        if (audioMenu) AudioMenu(exo, vm, infoOn, { infoOn = !infoOn }) { audioMenu = false }
        if (infoOn) StreamInfo(vm, exo, qualityText, Modifier.align(Alignment.TopStart))
        if (vm.numberBuffer.isNotEmpty()) {
            Text(vm.numberBuffer, fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(32.dp)
                    .background(Color(0x99000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 8.dp))
        }
        vm.upNext?.let { nxt ->
            Text("Nächste Folge in 5 s:  $nxt     (Zurück = abbrechen)", fontSize = 16.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
        if (showSkip && !vm.chanPanel && !audioMenu && !controls && vm.upNext == null) {
            Text("⏭  Intro überspringen  (OK drücken, dann Intro)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 120.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
    }
}

/** Bedienleiste für Filme und Serien: erscheint mit OK. */
@Composable
fun PlayerControls(
    exo: ExoPlayer, pos: Long, dur: Long, canSkip: Boolean, playFr: FocusRequester, modifier: Modifier,
    onTick: () -> Unit, onSkipIntro: () -> Unit
) {
    var playing by remember { mutableStateOf(exo.playWhenReady) }
    LaunchedEffect(Unit) {
        while (true) {
            playing = exo.playWhenReady
            delay(300)
        }
    }
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    fun seekBy(delta: Long) {
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, max))
        onTick()
    }
    Column(modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(20.dp)
        .onPreviewKeyEvent { if (it.type == KeyEventType.KeyDown) onTick(); false }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(pos), fontSize = 14.sp, color = Color.White)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
            }
            Spacer(Modifier.width(12.dp))
            Text(if (dur > 0) fmtTime(dur) else "--:--", fontSize = 14.sp, color = gray)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { seekBy(-60_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 60 s") }
            OutlinedButton(onClick = { seekBy(-10_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 10 s") }
            Button(onClick = {
                exo.playWhenReady = !exo.playWhenReady
                playing = exo.playWhenReady
                onTick()
            }, modifier = Modifier.focusRequester(playFr).tvFocus()) {
                Text(if (playing) "⏸  Pause" else "▶  Weiter", fontSize = 18.sp)
            }
            OutlinedButton(onClick = { seekBy(10_000) }, modifier = Modifier.tvFocus()) { Text("10 s ⏩") }
            OutlinedButton(onClick = { seekBy(60_000) }, modifier = Modifier.tvFocus()) { Text("60 s ⏩") }
            if (canSkip) {
                OutlinedButton(onClick = onSkipIntro, modifier = Modifier.tvFocus()) { Text("⏭ Intro") }
            }
        }
        Text("Zurück schließt die Leiste.", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun InfoPanel(vm: AppVM, detail: Boolean, pos: Long, dur: Long, quality: String, modifier: Modifier) {
    val gray = Color(0xFFB0BAC4)
    val list = vm.epgList(vm.playChId)
    val now = if (vm.isLive) vm.currentEpg(vm.playChId) else null
    Box(modifier.fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
        .padding(start = 32.dp, end = 32.dp, top = 56.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            vm.playLogo?.let { logo ->
                AsyncImage(model = logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(10.dp))
                Spacer(Modifier.width(18.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(vm.playTitle, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (quality.isNotEmpty()) {
                    Text(quality, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
                if (vm.isLive) {
                    if (now != null) {
                        Text("${now.start}–${now.end}  ${now.title}", fontSize = 18.sp, color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        vm.epgProgress(now)?.let { p ->
                            LinearProgressIndicator(progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                        }
                        if (detail && now.descr.isNotBlank()) {
                            Text(now.descr, fontSize = 14.sp, color = gray, maxLines = 5, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(bottom = 6.dp))
                        }
                        list.dropWhile { it != now }.drop(1).take(if (detail) 4 else 1).forEach { n ->
                            Text("${n.start}  ${n.title}", fontSize = 15.sp, color = gray, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    } else {
                        Text("Keine Programminfo", fontSize = 14.sp, color = gray)
                    }
                    if (!detail) Text("OK = Details   ·   ◀ Senderliste   ·   ▶ Optionen   ·   0 = letzter Sender", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                } else if (dur > 0) {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                    Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 14.sp, color = gray)
                }
            }
        }
    }
}

@Composable
fun GuideScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val hours = 6
    val dpPerMin = 4
    val nameW = 150.dp
    val totalW = nameW + (hours * 60 * dpPerMin).dp
    val hScroll = rememberScrollState()
    val startSec = remember { (System.currentTimeMillis() / 1000 / 1800) * 1800 - 1800 }
    val timeFmt = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("EPG  ·  PROGRAMMÜBERSICHT   (OK auf kommende Sendung = 🔔 Erinnerung)", fontSize = 14.sp, letterSpacing = 3.sp, color = accent,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
        Box(Modifier.weight(1f).fillMaxWidth().glass(18.dp)) {
            Column(Modifier.fillMaxHeight().horizontalScroll(hScroll)) {
                Box(Modifier.width(totalW).height(30.dp)) {
                    for (i in 0..(hours * 2)) {
                        Text(timeFmt.format(java.util.Date((startSec + i * 1800L) * 1000)), fontSize = 11.sp, color = gray,
                            modifier = Modifier.offset(x = nameW + (i * 30 * dpPerMin).dp, y = 8.dp))
                    }
                }
                LazyColumn(Modifier.width(totalW).weight(1f)) {
                    items(vm.items, key = { it.id }) { ch -> GuideRow(vm, ch, startSec, hours, dpPerMin, nameW, hScroll) }
                }
            }
        }
    }
}

@Composable
fun GuideRow(vm: AppVM, ch: Item, startSec: Long, hours: Int, dpPerMin: Int, nameW: Dp, hScroll: ScrollState) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id, 12) }
    val list = vm.epgList(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val light = LocalLight.current
    val nowSec = System.currentTimeMillis() / 1000
    val endSec = startSec + hours * 3600L
    Box(Modifier.width(nameW + (hours * 60 * dpPerMin).dp).height(64.dp).padding(vertical = 3.dp)) {
        for (e in list) {
            if (e.startTs <= 0 || e.stopTs <= e.startTs) continue
            val s0 = maxOf(e.startTs, startSec)
            val s1 = minOf(e.stopTs, endSec)
            if (s1 <= s0) continue
            val left = nameW + (((s0 - startSec) / 60f) * dpPerMin).dp
            val w = maxOf((((s1 - s0) / 60f) * dpPerMin).dp - 3.dp, 10.dp)
            val isNow = nowSec in e.startTs until e.stopTs
            Text((if (vm.isReminder(ch.id, e.startTs)) "🔔 " else "") + e.start + "  " + e.title, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.offset(x = left).width(w).fillMaxHeight().tvFocus(1.02f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isNow) accent.copy(alpha = 0.35f) else if (light) Color(0x14000000) else Color(0x1FFFFFFF))
                    .clickable {
                        if (e.startTs > System.currentTimeMillis() / 1000) vm.toggleReminder(ch, e) else vm.openItem(ch)
                    }.padding(8.dp))
        }
        if (list.isEmpty()) {
            Text("Keine Programminfo", fontSize = 12.sp, color = gray,
                modifier = Modifier.align(Alignment.CenterStart).offset(x = nameW + 8.dp))
        }
        // Sendername bleibt beim seitlichen Scrollen links stehen
        Row(Modifier.offset { IntOffset(hScroll.value, 0) }.width(nameW).fillMaxHeight()
            .background(if (light) Color(0xFFEAECF2) else Color(0xFF101018))
            .tvFocus(1.02f).clickable { vm.openItem(ch) }.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
            Spacer(Modifier.width(8.dp))
            Text(ch.name, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun EditCatsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var kw by remember { mutableStateOf("DE, German, Deutsch") }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kategorien auswählen", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.allCats.count { it.id !in vm.hiddenCats }} von ${vm.allCats.size} sichtbar",
            fontSize = 13.sp, color = gray)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = kw, onValueChange = { kw = it }, singleLine = true,
                label = { Text("Suchbegriffe, z. B. DE, German") }, modifier = Modifier.weight(1f).tvFocus())
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.showOnlyMatching(kw) }, modifier = Modifier.tvFocus()) { Text("Nur passende") }
        }
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setAllCats(true) }, modifier = Modifier.tvFocus()) { Text("Alle anzeigen") }
            OutlinedButton(onClick = { vm.setAllCats(false) }, modifier = Modifier.tvFocus()) { Text("Alle ausblenden") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(vm.allCats) { c ->
                val on = c.id !in vm.hiddenCats
                Text((if (on) "✓  " else "✗  ") + c.title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleCat(c.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun EditChansScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var filter by remember { mutableStateOf("") }
    val shown = vm.editChans.filter { filter.isBlank() || it.name.contains(filter.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kanäle ein-/ausblenden", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.editChans.count { it.id !in vm.hiddenChans }} von ${vm.editChans.size} sichtbar",
            fontSize = 13.sp, color = gray)
        OutlinedTextField(value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Filter nach Name") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).tvFocus())
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, true) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte ausblenden")
            }
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, false) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte einblenden")
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { ch ->
                val on = ch.id !in vm.hiddenChans
                Text((if (on) "✓  " else "✗  ") + ch.name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleChan(ch.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, item: Item) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    val isSeries = vm.browseType == "series"
    val res = remember(item) { vm.resumeFor(item) }
    val tm by produceState<Tmdb.Info?>(null, item.id, vm.tmdbKey) {
        value = if (vm.tmdbKey.isBlank()) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Tmdb.lookup(vm.tmdbKey, item.name, item.year, isSeries) }
    }
    val posterUrl = item.logo?.takeIf { it.isNotBlank() } ?: tm?.poster
    val backUrl = item.backdrop ?: tm?.backdrop
    val descrText = if (item.descr.isNotBlank()) item.descr else (tm?.overview ?: "")
    val ratingText = if (tm != null && tm!!.rating.isNotBlank() && !item.meta.contains("Bewertung")) "Bewertung: " + tm!!.rating else ""
    Box(Modifier.fillMaxSize()) {
        AsyncImage(model = backUrl ?: posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (backUrl != null) 0.4f else 0.22f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0A0A0F), Color(0xCC0A0A0F), Color(0x330A0A0F)))))
        Row(Modifier.fillMaxSize().padding(40.dp)) {
            AsyncImage(model = posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(240.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(16.dp)))
            Spacer(Modifier.width(32.dp))
            Column(Modifier.weight(1f).fillMaxHeight().glass(24.dp).verticalScroll(rememberScrollState()).padding(24.dp)) {
                Text(if (isSeries) "SERIE" else "FILM", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                Text(item.name, fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    modifier = Modifier.padding(top = 4.dp))
                if (item.year.isNotBlank()) {
                    Text(item.year, fontSize = 16.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                }
                Box(Modifier.padding(top = 12.dp).width(64.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.height(16.dp))
                Text(if (descrText.isNotBlank()) descrText else "Keine Beschreibung vorhanden.", fontSize = 16.sp,
                    color = if (descrText.isNotBlank()) MaterialTheme.colorScheme.onSurface else gray)
                val metaText = listOf(item.meta, ratingText).filter { it.isNotBlank() }.joinToString("\n")
                if (metaText.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(metaText, fontSize = 14.sp, color = gray)
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (res != null) {
                        Button(onClick = { vm.playResume(res) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("▶ Weiter bei " + fmtTime(res.pos) +
                                (if (isSeries) "  ·  " + res.title.substringAfter(" – ") else ""), fontSize = 18.sp)
                        }
                    }
                    Button(onClick = { if (res != null && !isSeries) vm.startFresh(item) else vm.startItem(item) },
                        modifier = (if (res == null) Modifier.focusRequester(fr) else Modifier).tvFocus()) {
                        Text(if (isSeries) "Staffeln ansehen" else if (res != null) "↺ Von vorne" else "▶ Abspielen", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleFav(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isFav(item)) "★ Favorit entfernen" else "☆ Zu Favoriten", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatch(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isWatch(item)) "✓ In Merkliste" else "＋ Merkliste", fontSize = 18.sp)
                    }
                }
            }
        }
    }
}

/** Kurzer Vorspann: Logo blendet ein, Goldlinie zieht auf. Beliebige Taste oder Tippen überspringt ihn. */
@Composable
fun IntroScreen(premium: Boolean, sound: Boolean, onDone: () -> Unit) {
    if (premium) { PremiumIntro(sound, onDone); return }
    val ctx = LocalContext.current
    DisposableEffect(sound) {
        val mp = if (sound) runCatching { android.media.MediaPlayer.create(ctx, R.raw.intro_boom) }.getOrNull() else null
        mp?.setOnCompletionListener { it.release() }
        runCatching { mp?.start() }
        onDispose { }
    }
    val fade = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(900))
        line.animateTo(1f, tween(700))
        delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { onDone(); true } else false }
            .clickable { onDone() },
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(fade.value).graphicsLayer { scaleX = 0.92f + 0.08f * fade.value; scaleY = 0.92f + 0.08f * fade.value },
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎬", fontSize = 56.sp)
            Spacer(Modifier.height(12.dp))
            Text("TOM’S TV", fontSize = 48.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                letterSpacing = 10.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.width((240 * line.value).dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 13.sp, letterSpacing = 5.sp, color = LocalMuted.current)
        }
    }
}

/** Premium-Intro: Logo zoomt mit dem Kino-Boom ins Bild, Lichtstreifen läuft darunter auf. */
@Composable
fun PremiumIntro(sound: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val red = Palette.CINEMA_RED
    val appear = remember { Animatable(0f) }
    val zoom = remember { Animatable(1.45f) }
    val beam = remember { Animatable(0f) }
    val out = remember { Animatable(1f) }
    val fr = remember { FocusRequester() }
    var finished by remember { mutableStateOf(false) }
    val finish = { if (!finished) { finished = true; onDone() } }
    DisposableEffect(sound) {
        val mp = if (sound) runCatching { android.media.MediaPlayer.create(ctx, R.raw.intro_boom) }.getOrNull() else null
        mp?.setOnCompletionListener { it.release() }
        runCatching { mp?.start() }
        onDispose { }
    }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    LaunchedEffect(Unit) {
        delay(120)
        // Schlag bei ca. 0,32 s im Sound – Logo „landet“ genau dann
        kotlinx.coroutines.coroutineScope {
            launch { appear.animateTo(1f, tween(320)) }
            launch { zoom.animateTo(1f, tween(520, easing = androidx.compose.animation.core.FastOutSlowInEasing)) }
        }
        beam.animateTo(1f, tween(650))
        delay(700)
        out.animateTo(0f, tween(420))
        finish()
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { finish(); true } else false }
            .clickable { finish() },
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(appear.value * out.value)
            .graphicsLayer { scaleX = zoom.value; scaleY = zoom.value },
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("TOM’S TV", fontSize = 64.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.SansSerif,
                letterSpacing = (4 + 10 * (zoom.value - 1f)).sp, color = red)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.width((320 * beam.value).dp).height(3.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, red, Color.White, red, Color.Transparent))))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 12.sp, letterSpacing = 6.sp,
                color = Color(0xFFA8A8A8), modifier = Modifier.alpha(beam.value))
        }
    }
}

@Composable
fun Clock() {
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        while (true) {
            time = f.format(java.util.Date())
            delay(20_000)
        }
    }
    Text(time, fontSize = 14.sp, color = LocalMuted.current)
}

@Composable
fun Shell(vm: AppVM, current: String, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Sidebar(vm, current)
        Box(Modifier.weight(1f).fillMaxHeight()) { content() }
    }
}

@Composable
fun Sidebar(vm: AppVM, current: String) {
    val accent = MaterialTheme.colorScheme.primary
    val compact = when (vm.sidebarMode) {
        "compact" -> true
        "normal" -> false
        else -> LocalConfiguration.current.screenHeightDp < 480
    }
    val width by animateDpAsState(if (compact) 76.dp else 224.dp, label = "sidebarWidth")
    val menu = listOf(
        Triple("home", "🏠", "Startseite"), Triple("itv", "📺", "Live TV"), Triple("vod", "🎬", "Filme"),
        Triple("series", "🍿", "Serien"), Triple("watch", "🔖", "Merkliste"),
        Triple("epg", "🗓", "EPG"), Triple("portals", "🎟", "Portale"), Triple("settings", "⚙", "Einstellungen")
    )
    val premium = LocalPremium.current
    Column(Modifier.width(width).fillMaxHeight()
        .then(if (premium) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF000000), Color(0xE6050505))))
                .padding(horizontal = 8.dp, vertical = 16.dp)
              else Modifier.padding(10.dp).glass(22.dp).padding(horizontal = 8.dp, vertical = 10.dp))) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start) {
            if (!compact) {
                Text("TOM’S TV", fontSize = if (premium) 20.sp else 17.sp,
                    fontWeight = if (premium) FontWeight.Black else FontWeight.Bold, fontFamily = titleFont,
                    color = if (premium) Palette.CINEMA_RED else Color.Unspecified,
                    letterSpacing = if (premium) 2.sp else 3.sp, modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (compact) "▶" else "◀", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.setSidebar(if (compact) "normal" else "compact") }
                    .padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            menu.forEach { (id, emoji, label) ->
                val sel = id == current
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(14.dp))
                    .then(if (sel && premium) Modifier.background(Color(0x22FFFFFF)).drawBehind {
                              drawRect(accent, size = androidx.compose.ui.geometry.Size(4.dp.toPx(), size.height))
                          }
                          else if (sel) Modifier.background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.55f))))
                          else Modifier)
                    .clickable { vm.goTo(id) }
                    .padding(horizontal = if (compact) 0.dp else 12.dp, vertical = if (compact) 11.dp else 10.dp),
                    horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = if (compact) 20.sp else 16.sp)
                    if (!compact) {
                        Spacer(Modifier.width(10.dp))
                        Text(label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel && premium) Color.White else if (sel) MaterialTheme.colorScheme.onPrimary
                                    else if (premium) Color(0xFFB3B3B3) else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 22.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (!LocalPremium.current) {
            Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(accent))
            Spacer(Modifier.width(10.dp))
        }
        Text(title, fontSize = if (LocalPremium.current) 20.sp else 18.sp,
            fontWeight = if (LocalPremium.current) FontWeight.ExtraBold else FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text("$action  ›", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.tvFocus(1.05f).clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction)
                    .padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

@Composable
fun HeroBanner(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    if (LocalPremium.current) { PremiumHero(vm, item, index, count, fr); return }
    val accent = MaterialTheme.colorScheme.primary
    val gray = Color(0xFFC3CAD1)
    Box(Modifier.fillMaxWidth().height(270.dp).padding(horizontal = 16.dp, vertical = 4.dp)
        .clip(RoundedCornerShape(24.dp))) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (item.backdrop != null) 0.7f else 0.45f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF07070B), Color(0xE607070B), Color(0x4007070B)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC07070B)))))
        Row(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(accent).padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text("NEU", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                            color = MaterialTheme.colorScheme.onPrimary)
                    }
                    if (item.year.isNotBlank()) {
                        Spacer(Modifier.width(10.dp))
                        Text(item.year, fontSize = 14.sp, color = gray)
                    }
                }
                Text(item.name, fontSize = 38.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp))
                Text(item.descr, fontSize = 14.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 10.dp, end = 24.dp))
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                        Text("▶  Jetzt ansehen", fontSize = 16.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatchOf(item, "vod") }, modifier = Modifier.tvFocus()) {
                        Text("＋ Merkliste", fontSize = 16.sp)
                    }
                }
            }
            AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(160.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)))
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(if (i == index) 18.dp else 7.dp, 7.dp).clip(CircleShape)
                    .background(if (i == index) accent else Color(0x66FFFFFF)))
            }
        }
    }
}

/** Premium-Banner: randlos, groß, Bild läuft nach links und unten ins Schwarz aus. */
@Composable
fun PremiumHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val gray = Color(0xFFD0D0D0)
    val red = MaterialTheme.colorScheme.primary
    Box(Modifier.fillMaxWidth().height(360.dp)) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (item.backdrop != null) 0.95f else 0.5f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(0f to Color.Black, 0.38f to Color(0xD9000000), 0.75f to Color(0x14000000), 1f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(0f to Color(0x66000000), 0.25f to Color.Transparent, 0.7f to Color.Transparent, 1f to Color.Black)))
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = 32.dp, top = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("T", fontSize = 22.sp, fontWeight = FontWeight.Black, color = red)
                Spacer(Modifier.width(8.dp))
                Text("NEU IM ANGEBOT", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = gray)
            }
            Text(item.name, fontSize = 44.sp, lineHeight = 46.sp, fontWeight = FontWeight.Black, color = Color.White,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Neu", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF46D369))
                if (item.year.isNotBlank()) {
                    Spacer(Modifier.width(12.dp))
                    Text(item.year, fontSize = 14.sp, color = gray)
                }
            }
            Text(item.descr, fontSize = 15.sp, lineHeight = 21.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).tvFocus(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text("▶  Abspielen", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Button(onClick = { vm.toggleWatchOf(item, "vod") }, modifier = Modifier.tvFocus(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xB36D6D6E), contentColor = Color.White)) {
                    Text("＋  Merkliste", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(if (i == index) 22.dp else 12.dp, 3.dp)
                    .background(if (i == index) Color.White else Color(0x55FFFFFF)))
            }
        }
    }
}

@Composable
fun MiniPoster(entry: Item, onClick: () -> Unit) {
    val premium = LocalPremium.current
    val r = if (premium) 6.dp else 14.dp
    Box(Modifier.width(if (premium) 142.dp else 132.dp)) {
        Box(Modifier.tvFocus(1.06f).clip(RoundedCornerShape(r)).background(if (premium) Color(0xFF1A1A1A) else Color(0xFF222A33))
            .border(if (premium) 0.dp else 1.dp, if (premium) Color.Transparent else Color(0x22FFFFFF), RoundedCornerShape(r))
            .clickable(onClick = onClick)) {
            AsyncImage(model = entry.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .padding(start = 8.dp, end = 8.dp, top = 28.dp, bottom = 8.dp)) {
                Text(entry.name, fontSize = 12.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun ChannelTile(ch: Item, onClick: () -> Unit) {
    Column(Modifier.width(124.dp).tvFocus(1.06f).glass(14.dp).clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.height(48.dp).fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(ch.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FavsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember {
        listOf("itv" to "Live TV", "vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.favsFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Text("FAVORITEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch keine Favoriten. Halte OK gedrückt oder nutze die Menü-Taste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { f ->
                        if (type == "itv") ChannelTile(f) { vm.openFavorite(type, f) }
                        else MiniPoster(f) { vm.openFavorite(type, f) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("EINSTELLUNGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Spacer(Modifier.height(16.dp))
        Column(Modifier.glass(22.dp).padding(20.dp)) { SettingsBlock(vm) }
    }
}

@Composable
fun SettingsBlock(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.padding(top = 10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { vm.checkUpdate() }, modifier = Modifier.tvFocus()) { Text("Nach Updates suchen") }
            if (vm.updateInfo != null) {
                Button(onClick = { vm.installUpdate() }, modifier = Modifier.tvFocus()) { Text("Jetzt installieren") }
            }
        }
        vm.updateMsg?.let { Text(it, fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 6.dp)) }
        if (vm.updateProgress >= 0) {
            LinearProgressIndicator(progress = { vm.updateProgress / 100f },
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(top = 6.dp))
        }
        Text("SCHRIFTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Palette.textOptions.forEach { (name, c) ->
                OutlinedButton(onClick = { vm.setTextColor(name) }, modifier = Modifier.tvFocus()) {
                    Text((if (vm.textColorName == name) "● " else "") + name, color = c)
                }
            }
        }
        Text("AKZENTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Palette.accentOptions.forEach { (name, c) ->
                OutlinedButton(onClick = { vm.setAccent(name) }, modifier = Modifier.tvFocus()) {
                    Text((if (vm.accentName == name) "● " else "") + name, color = c)
                }
            }
        }
        Text("SEITENLEISTE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.cycleSidebar() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text((when (vm.sidebarMode) {
                "compact" -> "Kompakt (nur Symbole)"
                "normal" -> "Normal (mit Namen)"
                else -> "Automatisch"
            }) + "  ⟳")
        }
        Text("DESIGN", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.toggleDesign() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text(when (vm.designMode) {
                "premium" -> "Streaming Premium  ⟳"
                "oled" -> "OLED-Schwarz  ⟳"
                "night" -> "Mitternachtsblau  ⟳"
                else -> "Cinema (dunkel)  ⟳"
            })
        }
        OutlinedButton(onClick = { vm.toggleIntroSound() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.introSound) "Start-Sound: an  ⟳" else "Start-Sound: aus  ⟳")
        }
        OutlinedButton(onClick = { vm.togglePreview() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.previewOn) "Live-Vorschau in der Senderliste: an  ⟳" else "Live-Vorschau in der Senderliste: aus  ⟳")
        }
        Text("Manche Anbieter erlauben nur einen Stream gleichzeitig. Dann die Vorschau ausschalten.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        Text("LEISTUNG", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.togglePerf() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text(if (vm.perfMode) "Leistungsmodus: an  ⟳" else "Leistungsmodus: aus  ⟳")
        }
        Text("An: keine Animationen, keine Vorschau, kein Banner-Wechsel. Gut für ältere Boxen.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        Text("KOMFORT", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.cycleSleep() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text("Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min.") + "  ⟳")
        }
        OutlinedButton(onClick = { vm.toggleResumeLast() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.resumeLastOnStart) "Beim Start letzten Sender fortsetzen: an  ⟳"
                else "Beim Start letzten Sender fortsetzen: aus  ⟳")
        }
        Text("SERIEN", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.toggleAutoNext() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text(if (vm.autoNext) "Nächste Folge automatisch: an  ⟳" else "Nächste Folge automatisch: aus  ⟳")
        }
        OutlinedButton(onClick = { vm.cycleIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text("Intro überspringen: " + vm.introSeconds + " Sekunden  ⟳")
        }
        OutlinedButton(onClick = { vm.toggleAutoIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.autoSkipIntro) "Intro automatisch überspringen: an  ⟳" else "Intro automatisch überspringen: aus  ⟳")
        }
        Text("Tipp: Am Ende des Vorspanns im Player Menü öffnen und „Intro-Ende hier merken“ wählen. Das gilt dann für alle Folgen dieser Serie. Sonst springt die App die eingestellte Zeit vor.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        Text("ZUSATZINFOS (OPTIONAL)", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        Box(Modifier.padding(top = 4.dp)) { Field("TMDB-Schlüssel (kostenlos auf themoviedb.org)", vm.tmdbKey) { vm.updateTmdbKey(it) } }
        Text("Mit Schlüssel ergänzt die App fehlende Poster, Beschreibungen und Bewertungen bei Filmen und Serien.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        Text("SPEICHER", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        LaunchedEffect(Unit) { vm.refreshCacheSize() }
        OutlinedButton(onClick = { vm.clearCache() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text("🗑  Cache leeren" + (if (vm.cacheSizeText.isNotEmpty()) "  (jetzt " + vm.cacheSizeText + ")" else ""))
        }
        OutlinedButton(onClick = { vm.cycleCacheLimit() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text("Automatisch leeren ab: " + (if (vm.cacheLimitMb == 0) "aus" else vm.cacheLimitMb.toString() + " MB") + "  ⟳")
        }
        Text("Leert Bilder und Update-Dateien. Beim Leeren per Knopf werden auch die gespeicherten Senderlisten gelöscht, der nächste Start dauert dann etwas länger.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        Text("SICHERUNG & HILFE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text("📱 Backup und Wiederherstellung (per Handy)")
        }
        OutlinedButton(onClick = { vm.push(Screen.LogView) }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text("🧾 Fehlerprotokoll ansehen")
        }
        Text("BILD & TON", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.cycleQuality() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text(when (vm.qualityMode) {
                "max" -> "Maximale Qualität (immer die höchste)  ⟳"
                "adaptive" -> "Beste Qualität, passt sich der Leitung an  ⟳"
                else -> "Automatisch (an Bildschirm angepasst)  ⟳"
            })
        }
        Text("Gilt ab dem nächsten gestarteten Stream. Bild und Ton werden nicht umgerechnet.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        OutlinedButton(onClick = { vm.cycleBuffer() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(when (vm.bufferMode) {
                "fast" -> "Pufferung: schnell (kurz)  ⟳"
                "stable" -> "Pufferung: stabil (groß, für 4K)  ⟳"
                else -> "Pufferung: ausgewogen  ⟳"
            })
        }
        OutlinedButton(onClick = { vm.toggle4kHelp() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.fourKHelp) "4K-Hilfe (Tunneling): an  ⟳" else "4K-Hilfe (Tunneling): aus  ⟳")
        }
        Text("Bei Rucklern in 4K: Pufferung auf stabil stellen, danach die 4K-Hilfe testen. Ein Netzwerkkabel hilft am meisten.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        OutlinedButton(onClick = { vm.toggleDedupe() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.dedupe) "Gleichnamige Sender: zusammenfassen  ⟳"
                else "Gleichnamige Sender: alle zeigen  ⟳")
        }
        Text("Version ${BuildConfig.RUN_NUMBER}", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun PhoneAddScreen(vm: AppVM) {
    val gray = LocalMuted.current
    DisposableEffect(Unit) {
        vm.startPhoneAdd()
        onDispose { vm.stopPhoneAdd() }
    }
    val url = vm.qrUrl
    val bmp = remember(url) { url?.let { qrBitmap(it).asImageBitmap() } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Row(Modifier.fillMaxSize().padding(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 32.dp)) {
            Text("PORTAL PER HANDY HINZUFÜGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(80.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(20.dp))
            Text("1.  Das Handy muss im selben WLAN sein wie diese Box.", fontSize = 16.sp)
            Text("2.  Kamera-App öffnen und den QR-Code scannen.", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
            Text("3.  Formular ausfüllen und auf Portal hinzufügen tippen.", fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp))
            Text("Das Portal erscheint sofort in deiner Liste. Du kannst mehrere nacheinander eintragen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
            Text("Auf derselben Seite: Backup herunterladen und wiederherstellen, Fehlerprotokoll ansehen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
            if (url != null) {
                Text("Oder im Handy-Browser öffnen:", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
                Text(url, fontSize = 13.sp, color = gray)
            }
            Text("Portale gesamt: ${vm.portals.size}", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 12.dp))
            Spacer(Modifier.height(20.dp))
            Button(onClick = { vm.back() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Fertig") }
        }
        Box(Modifier.size(320.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(14.dp),
            contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(bitmap = bmp, contentDescription = "QR-Code", modifier = Modifier.fillMaxSize())
            } else {
                Text("…", color = Color.Black, fontSize = 24.sp)
            }
        }
    }
}

@Composable
fun ChannelPanel(vm: AppVM, modifier: Modifier) {
    val cats = remember(vm.chanPanel) { vm.panelCategories() }
    var catsOpen by remember { mutableStateOf(true) }
    val rows = remember(vm.panelGroups, vm.panelExpanded, vm.chanPanel) {
        val out = ArrayList<PaneRow>()
        if (vm.panelGroups.isNotEmpty()) {
            for (g in vm.panelGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.panelExpanded) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in vm.panelVisibleCats(g)) out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                }
            }
        } else {
            for (c in cats) out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    val catState = rememberLazyListState(initialFirstVisibleItemIndex = rows.indexOfFirst { it.id == vm.panelCat }.coerceAtLeast(0))
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Row(modifier.fillMaxHeight().width(740.dp)
        .background(Brush.horizontalGradient(listOf(Color(0xF2000000), Color(0xE6000000), Color(0x00000000))))
        .padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 70.dp)) {
        Column(Modifier.width(if (catsOpen) 220.dp else 48.dp).fillMaxHeight()) {
            Text(if (catsOpen) "◀  Kategorien" else "▶", fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().tvFocus(1.05f).clip(RoundedCornerShape(8.dp))
                    .clickable { catsOpen = !catsOpen }.padding(8.dp))
            if (catsOpen) {
                LazyColumn(state = catState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(rows, key = { it.id }) { r ->
                        if (r.kind == 0) {
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).glass(10.dp)
                                .clickable { vm.togglePanelGroup(r.pfx) }.padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(if (r.pfx in vm.panelExpanded) "▾" else "▸", fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(r.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            ListRow((if (r.pfx.isNotEmpty()) "   " else "") + r.title, r.id == vm.panelCat) { vm.panelCat = r.id }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        key(vm.panelCat) {
            val list = remember { vm.panelList() }
            val cur = list.indexOfFirst { it.id == vm.playChId }
            val state = rememberLazyListState(initialFirstVisibleItemIndex = cur.coerceAtLeast(0))
            if (list.isEmpty()) {
                Text("Keine Sender", color = Color(0xFFB0BAC4), modifier = Modifier.weight(1f).padding(12.dp))
            } else {
                LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    items(list) { ch ->
                        val isCur = ch.id == vm.playChId
                        val anchor = isCur || (cur < 0 && ch.id == list.first().id)
                        PanelRow(vm, ch, isCur, if (anchor) Modifier.focusRequester(fr) else Modifier) {
                            vm.playFromPanel(ch, list)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PanelRow(vm: AppVM, ch: Item, current: Boolean, modifier: Modifier, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    Row(modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(10.dp))
        .background(if (current) accent.copy(alpha = 0.3f) else Color(0x22FFFFFF))
        .clickable(onClick = onClick).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text((if (current) "▶ " else "") + ch.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal)
            if (now != null) {
                Text("${now.start}  ${now.title}", fontSize = 11.sp, color = Color(0xFFB0BAC4), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun WatchScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember {
        listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.watchFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Text("MERKLISTE", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch nichts gemerkt. Öffne einen Film oder eine Serie und wähle ＋ Merkliste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { w -> MiniPoster(w) { vm.openWatch(type, w) } }
                }
            }
        }
    }
}

/** Zeigt die tatsächlich ankommende Qualität, zum Beispiel "4K 3840×2160 · 50 fps · HEVC | Dolby Digital Plus 5.1". */
fun qualityLabel(p: ExoPlayer): String {
    val parts = ArrayList<String>()
    val v = p.videoFormat
    if (v != null && v.height > 0) {
        val res = when {
            v.height >= 2000 -> "4K"
            v.height >= 1000 -> "FHD"
            v.height >= 700 -> "HD"
            else -> "SD"
        }
        val fps = if (v.frameRate > 0f) " · " + Math.round(v.frameRate) + " fps" else ""
        val codec = when (v.sampleMimeType) {
            "video/hevc" -> " · HEVC"
            "video/avc" -> " · H.264"
            "video/av01" -> " · AV1"
            "video/x-vnd.on2.vp9" -> " · VP9"
            "video/mpeg2" -> " · MPEG-2"
            else -> ""
        }
        parts.add(res + " " + v.width + "×" + v.height + fps + codec)
    }
    val a = p.audioFormat
    if (a != null) {
        val codec = when (a.sampleMimeType) {
            "audio/ac3" -> "Dolby Digital"
            "audio/eac3" -> "Dolby Digital Plus"
            "audio/eac3-joc" -> "Dolby Atmos"
            "audio/true-hd" -> "Dolby TrueHD"
            "audio/vnd.dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MPEG-Audio"
            "audio/mpeg-L2" -> "MPEG-Audio"
            else -> "Audio"
        }
        val ch = when (a.channelCount) {
            1 -> "Mono"
            2 -> "Stereo"
            6 -> "5.1"
            8 -> "7.1"
            else -> if (a.channelCount > 0) a.channelCount.toString() + " Kanäle" else ""
        }
        parts.add((codec + " " + ch).trim())
    }
    return parts.joinToString("   |   ")
}

class PaneRow(val kind: Int, val id: String, val title: String, val pfx: String)

@Composable
fun CategoryPane(vm: AppVM, type: String) {
    val open = vm.catPaneOpen
    val accent = MaterialTheme.colorScheme.primary
    val width by animateDpAsState(if (open) 280.dp else 56.dp, label = "catPaneWidth")
    val rows = remember(vm.portalGroups, vm.expandedPortals, vm.hiddenCats, vm.categories, type) {
        val out = ArrayList<PaneRow>()
        if (vm.portalGroups.isNotEmpty()) {
            for (g in vm.portalGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.expandedPortals) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    if (type != "itv") out.add(PaneRow(1, "p:" + g.pfx + ":resume", "⏯ Weiterschauen", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in g.cats.filter { it.id !in vm.hiddenCats }) {
                        out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                    }
                }
            }
        } else {
            out.add(PaneRow(1, "fav", "★ Favoriten", ""))
            for (c in vm.categories) if (c.id != "fav") out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    Column(Modifier.width(width).fillMaxHeight().padding(start = 4.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)
        .glass(20.dp).padding(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (open) Arrangement.Start else Arrangement.Center) {
            if (open) {
                Text("PORTALE", fontSize = 11.sp, letterSpacing = 3.sp, color = accent,
                    modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (open) "◀" else "▶", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.toggleCatPane() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (open) {
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(rows, key = { it.id }) { r ->
                    if (r.kind == 0) {
                        val expanded = r.pfx in vm.expandedPortals
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).tvFocus(1.02f).glass(12.dp)
                            .clickable { vm.toggleGroup(r.pfx) }
                            .padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (expanded) "▾" else "▸", fontSize = 14.sp, color = accent)
                            Spacer(Modifier.width(10.dp))
                            Text(r.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    } else {
                        ListRow((if (r.pfx.isNotEmpty()) "     " else "") + r.title, r.id == vm.selCat) { vm.selectCategory(r.id) }
                    }
                }
            }
        }
    }
}

/** Auswahl der Tonspur (Sprache, Format, Kanäle) während der Wiedergabe. */
@Composable
fun AudioMenu(exo: ExoPlayer, vm: AppVM, infoOn: Boolean, onToggleInfo: () -> Unit, onClose: () -> Unit) {
    val groups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO } }
    val tgroups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(560.dp).heightIn(max = 440.dp).glass(22.dp).background(Color(0xEE0A0A0F))
            .verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text("TON", fontSize = 14.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            if (groups.isEmpty()) {
                Text("Keine auswählbaren Tonspuren gefunden.", color = LocalMuted.current)
            }
            var first = true
            for (g in groups) {
                for (ti in 0 until g.length) {
                    val selected = g.isTrackSelected(ti)
                    val label = (if (selected) "●  " else "○  ") + audioLabel(g.getTrackFormat(ti))
                    val rowMod = if (first) Modifier.focusRequester(fr) else Modifier
                    first = false
                    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = rowMod.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti))
                                    .build()
                                g.getTrackFormat(ti).language?.takeIf { it.isNotEmpty() && it != "und" }?.let { vm.setAudioLang(it) }
                                onClose()
                            }
                            .padding(12.dp))
                }
            }
            if (tgroups.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("UNTERTITEL", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                val off = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
                MenuRow((if (off) "●  " else "○  ") + "Aus", off) {
                    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    vm.setTextLang("off")
                    onClose()
                }
                for (g in tgroups) {
                    for (ti in 0 until g.length) {
                        val sel = g.isTrackSelected(ti) && !off
                        val lang = g.getTrackFormat(ti).language
                        val nm = if (lang.isNullOrEmpty() || lang == "und") "Untertitel"
                        else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
                        MenuRow((if (sel) "●  " else "○  ") + nm, sel) {
                            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
                            vm.setTextLang(if (lang.isNullOrEmpty() || lang == "und") "" else lang)
                            onClose()
                        }
                    }
                }
            }
            if (vm.isLive) {
                val alts = vm.alternativesFor(vm.playChId)
                if (alts.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    Text("QUELLE (PORTAL)", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                    for ((pname, ch) in alts) {
                        val cur = ch.id == vm.playChId
                        MenuRow((if (cur) "●  " else "○  ") + pname, cur) {
                            vm.chooseSource(ch)
                            onClose()
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("OPTIONEN", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            if (vm.isEpisode) {
                MenuRow("⏭  Intro-Ende hier merken (" + fmtTime(exo.currentPosition) + ")", false) {
                    vm.saveIntroEnd(exo.currentPosition)
                    onClose()
                }
            }
            MenuRow("⏾  Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min."), false) { vm.cycleSleep() }
            MenuRow((if (infoOn) "☑" else "☐") + "  Stream-Info anzeigen", false) {
                onToggleInfo()
                onClose()
            }
            Text("Zurück schließt das Menü.", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}

fun audioLabel(f: androidx.media3.common.Format): String {
    val lang = f.language
    val langName = if (lang.isNullOrEmpty() || lang == "und") "Tonspur"
    else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
    val codec = when (f.sampleMimeType) {
        "audio/ac3" -> "Dolby Digital"
        "audio/eac3" -> "Dolby Digital Plus"
        "audio/eac3-joc" -> "Dolby Atmos"
        "audio/true-hd" -> "Dolby TrueHD"
        "audio/vnd.dts" -> "DTS"
        "audio/vnd.dts.hd" -> "DTS-HD"
        "audio/mp4a-latm" -> "AAC"
        "audio/mpeg" -> "MPEG-Audio"
        "audio/mpeg-L2" -> "MPEG-Audio"
        else -> "Audio"
    }
    val ch = when (f.channelCount) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> if (f.channelCount > 0) f.channelCount.toString() + " Kanäle" else ""
    }
    return (langName + "  ·  " + codec + " " + ch).trim()
}

/** Kleines Live-Bild (ohne Ton) des markierten Senders, ersetzt die Vorschau-Zeile in der Senderliste. */
@Composable
fun PreviewCard(vm: AppVM) {
    val ctx = LocalContext.current
    val gray = LocalMuted.current
    val exo = remember {
        val ds = DefaultHttpDataSource.Factory().setUserAgent(UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8_000).setReadTimeoutMs(10_000)
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply { volume = 0f }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    val url = vm.previewUrl
    LaunchedEffect(url) {
        if (url == null) {
            exo.stop()
            exo.clearMediaItems()
        } else {
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.play()
        }
    }
    val ch = vm.previewChannel
    val now = if (ch != null) vm.currentEpg(ch.id) else null
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(260.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            AndroidView(factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = exo
                }
            }, modifier = Modifier.fillMaxSize())
            if (url == null) {
                Text(if (ch == null) "Sender wählen" else "Vorschau lädt …", fontSize = 12.sp, color = Color(0xFFB0B7BF))
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(ch?.name ?: "", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (now.descr.isNotBlank()) {
                    Text(now.descr, fontSize = 12.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
            Text("Vorschau ohne Ton", fontSize = 11.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/** Angefangene Filme und Serien eines Portals, mit Weiter-Knopf und Löschen. */
@Composable
fun ResumeListView(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    LaunchedEffect(Unit) { vm.refreshResumeShown() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("WEITERSCHAUEN", fontSize = 13.sp, letterSpacing = 3.sp, color = accent, modifier = Modifier.weight(1f))
            if (vm.resumeEntries.isNotEmpty()) {
                OutlinedButton(onClick = { vm.clearResumeShown() }, modifier = Modifier.tvFocus()) { Text("🗑 Alle löschen") }
            }
        }
        if (vm.resumeEntries.isEmpty()) {
            Text("Nichts angefangen. Filme und Serien, die du ansiehst, erscheinen hier.", color = gray,
                modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp)) {
            items(vm.resumeEntries, key = { it.key }) { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(16.dp).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.width(54.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222A33)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fmtTime(r.pos) + (if (r.dur > 0) " / " + fmtTime(r.dur) else ""), fontSize = 12.sp, color = gray)
                        if (r.dur > 0) {
                            LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { vm.playResume(r) }, modifier = Modifier.tvFocus()) { Text("▶ Weiter") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.removeResume(r) }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
                }
            }
        }
    }
}

fun digitOf(k: Key): Int = when (k) {
    Key.Zero, Key.NumPad0 -> 0
    Key.One, Key.NumPad1 -> 1
    Key.Two, Key.NumPad2 -> 2
    Key.Three, Key.NumPad3 -> 3
    Key.Four, Key.NumPad4 -> 4
    Key.Five, Key.NumPad5 -> 5
    Key.Six, Key.NumPad6 -> 6
    Key.Seven, Key.NumPad7 -> 7
    Key.Eight, Key.NumPad8 -> 8
    Key.Nine, Key.NumPad9 -> 9
    else -> -1
}

@Composable
fun MenuRow(label: String, bold: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(12.dp))
}

/** Kleines Fenster mit Puffer, Bildrate und Quelle zum Prüfen von Rucklern. */
@Composable
fun StreamInfo(vm: AppVM, exo: ExoPlayer, quality: String, modifier: Modifier) {
    var buf by remember { mutableStateOf(0L) }
    var rate by remember { mutableStateOf(0) }
    var state by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            buf = exo.totalBufferedDuration
            rate = exo.videoFormat?.bitrate ?: 0
            state = when (exo.playbackState) {
                Player.STATE_BUFFERING -> "Puffert"
                Player.STATE_READY -> if (exo.isPlaying) "Läuft" else "Pause"
                Player.STATE_ENDED -> "Ende"
                else -> "Leerlauf"
            }
            delay(1000)
        }
    }
    Column(modifier.padding(16.dp).glass(14.dp).padding(12.dp)) {
        Text("STREAM-INFO", fontSize = 10.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary)
        Text(state + "  ·  Puffer " + (buf / 1000) + " s", fontSize = 12.sp, color = Color.White)
        if (quality.isNotEmpty()) Text(quality, fontSize = 12.sp, color = Color.White)
        if (rate > 0) Text("Videorate " + (rate / 1000) + " kbit/s", fontSize = 12.sp, color = Color.White)
        Text("Quelle: " + vm.sourceName(), fontSize = 12.sp, color = Color.White)
    }
}

/** Fehlerprotokoll: letzte Meldungen und Abstürze. */
@Composable
fun LogScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var lines by remember { mutableStateOf(AppLog.all()) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("FEHLERPROTOKOLL", fontSize = 18.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("⟳ Neu laden") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { AppLog.clear(); lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
        }
        if (lines.isEmpty()) {
            Text("Keine Einträge.", color = gray, modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp).glass(16.dp).padding(12.dp)) {
            items(lines) { l ->
                Text(l, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

/** Hinweisfenster beim App-Start, wenn eine neuere Version bereitsteht. */
@Composable
fun UpdateDialog(vm: AppVM) {
    val info = vm.updatePrompt ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(info) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("UPDATE VERFÜGBAR", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text("Eine neue Version von Tom’s TV ist bereit (${info.tag}).", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = Color.White)
            Text("Die Installation dauert nur einen Moment. Deine Daten bleiben erhalten.", fontSize = 14.sp,
                color = Color(0xFFB0B7BF), modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.updatePrompt = null; vm.installUpdate() },
                    modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt installieren") }
                OutlinedButton(onClick = { vm.updatePrompt = null }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

@Composable
fun ReminderDialog(vm: AppVM) {
    LaunchedEffect(Unit) {
        while (true) {
            vm.checkReminders()
            delay(15_000)
        }
    }
    val r = vm.dueReminder ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(r) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("🔔  ERINNERUNG", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(r.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("beginnt gleich auf " + r.chName, fontSize = 14.sp, color = Color(0xFFB0B7BF),
                modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.acceptReminder() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt umschalten") }
                OutlinedButton(onClick = { vm.dismissReminder() }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

/** Puffergrößen für Live-TV und Filme. */
fun buildLoadControl(live: Boolean, mode: String): DefaultLoadControl {
    val b = DefaultLoadControl.Builder()
    when (mode) {
        "fast" -> b.setBufferDurationsMs(12_000, 40_000, 1_000, 2_500)
        "stable" -> {
            b.setBufferDurationsMs(40_000, 120_000, 2_500, 8_000)
            b.setTargetBufferBytes(128 * 1024 * 1024)
        }
        else -> if (live) b.setBufferDurationsMs(25_000, 60_000, 1_500, 4_000)
        else b.setBufferDurationsMs(30_000, 90_000, 2_500, 6_000)
    }
    return b.build()
}

/** Verständliche Fehlermeldung statt "error code bad http status". */
fun playErrorText(e: PlaybackException): String {
    val h = e.cause as? HttpDataSource.InvalidResponseCodeException
    if (h != null) {
        return when (h.responseCode) {
            401, 403 -> "Das Portal lehnt den Stream ab (HTTP " + h.responseCode + "). Abo und Gerät (MAC) beim Anbieter prüfen."
            404 -> "Stream nicht gefunden (HTTP 404). Der Sender ist beim Anbieter vielleicht offline."
            in 500..599 -> "Fehler beim Anbieter-Server (HTTP " + h.responseCode + "). Später erneut versuchen."
            else -> "Der Server antwortet mit HTTP " + h.responseCode + "."
        }
    }
    return "Wiedergabefehler: " + e.errorCodeName
}
