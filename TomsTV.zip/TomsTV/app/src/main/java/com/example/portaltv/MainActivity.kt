package com.example.portaltv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.tv.foundation.lazy.list.TvLazyColumn
import androidx.tv.material3.MaterialTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TvLazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF121212))
                ) {
                    item {
                        TvChannelRow(
                            categoryName = "Meine Sender",
                            channels = listOf("Das Erste", "ZDF", "RTL", "ProSieben", "Sat.1"),
                            onChannelSelect = { channel -> }
                        )
                    }
                    item {
                        TvChannelRow(
                            categoryName = "Sport & Unterhaltung",
                            channels = listOf("Sky Sport", "DAZN", "Eurosport", "Sport1"),
                            onChannelSelect = { }
                        )
                    }
                }
            }
        }
    }
}
