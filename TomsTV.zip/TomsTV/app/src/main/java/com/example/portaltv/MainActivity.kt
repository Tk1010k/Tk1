@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.portaltv

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.Coil
import coil.ImageLoader
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

val LocalLight = compositionLocalOf { false }
val LocalMuted = compositionLocalOf { Color(0xFFB0B7BF) }
val LocalPerf = compositionLocalOf { false }
val LocalGlow = compositionLocalOf { 1f }
val LocalBadges = compositionLocalOf { true }

/** Streaming-Premium-Design aktiv (schwarz, Kino-Rot, große Kacheln). */
val LocalPremium = compositionLocalOf { false }
val LocalBlue = compositionLocalOf { false }
val LocalNeon = compositionLocalOf { false }
val LocalAmbientSink = androidx.compose.runtime.staticCompositionLocalOf<(String?) -> Unit> { { } }
val LocalAmbient = compositionLocalOf { Color(0xFF5B6BFF) }

/** Farbton verschieben (für den zweiten Farbverlauf im Neon-Glas-Design). */
fun shiftHue(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt()), hsv)
    hsv[0] = (hsv[0] + deg + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Titel-Schrift: im Premium-Design moderne, kräftige Sans-Schrift, sonst Serif. */
val titleFont: FontFamily
    @Composable get() = if (LocalPremium.current) FontFamily.SansSerif else FontFamily.Serif

class MainActivity : ComponentActivity() {
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            runCatching { coil.Coil.imageLoader(this).memoryCache?.clear() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.crash(e)
            oldHandler?.uncaughtException(t, e)
        }
        Coil.setImageLoader(ImageLoader.Builder(this).crossfade(120).respectCacheHeaders(false)
            .allowRgb565(true)
            .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.12).build() }
            .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("img_cache")).maxSizeBytes(150L * 1024 * 1024).build() }
            .build())
        setContent {
            val vm: AppVM = viewModel()
            val light = false
            val ac = Palette.accent(vm.accentName)
            val tc = if (light) Color(0xFF14161B) else Palette.text(vm.textColorName)
            val premium = vm.designMode == "premium"
            val bg = when (vm.designMode) {
                "premium" -> Color(0xFF000000)
                "oled" -> Color(0xFF000000)
                "night" -> Color(0xFF040714)
                "neon" -> Color(0xFF07070D)
                else -> Color(0xFF0A0A0F)
            }
            val ambAnim by androidx.compose.animation.animateColorAsState(vm.ambient, tween(700), label = "ambient")
            val ambSink = remember(vm) { { u: String? -> vm.focusAmbient(u) } }
            val onAc = if (ac.luminance() > 0.5f) Color(0xFF0A0A0F) else Color.White
            val scheme = if (light) {
                lightColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc,
                    onSurfaceVariant = tc, background = bg, surface = bg)
            } else {
                darkColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc, onSurfaceVariant = tc)
            }
            val muted = if (light) Color(0xFF5B6270) else if (premium) Color(0xFFA8A8A8) else Color(0xFFB0B7BF)
            val baseDensity = LocalDensity.current
            val scaled = Density(baseDensity.density * vm.uiScale(), baseDensity.fontScale * vm.fontPct / 100f)
            CompositionLocalProvider(LocalLight provides light, LocalMuted provides muted, LocalPerf provides vm.perfMode,
                LocalPremium provides premium, LocalBlue provides (vm.designMode == "night" || vm.designMode == "neon"), LocalNeon provides (vm.designMode == "neon"), LocalAmbient provides ambAnim, LocalAmbientSink provides ambSink, LocalGlow provides vm.glowFactor(), LocalBadges provides vm.badges, LocalDensity provides scaled) {
                MaterialTheme(colorScheme = scheme) {
                    Surface(Modifier.fillMaxSize(), color = bg, contentColor = tc) { App(vm) }
                }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Menü-Taste der Fernbedienung = Favorit umschalten. */
fun Modifier.favKey(onFav: () -> Unit): Modifier = onKeyEvent { e ->
    if (e.type == KeyEventType.KeyDown && e.key == Key.Menu) { onFav(); true } else false
}

/** Milchglas-Fläche: sanft durchscheinend mit feiner Kante. */
fun Modifier.glass(radius: Dp = 16.dp): Modifier = composed {
    val light = LocalLight.current
    if (LocalPerf.current) {
        return@composed this.clip(RoundedCornerShape(radius.coerceAtMost(12.dp))).background(Color(0x22FFFFFF))
    }
    if (LocalPremium.current) {
        // Premium: flache, dunkle Fläche statt Milchglas
        return@composed this.clip(RoundedCornerShape(radius.coerceAtMost(10.dp))).background(Color(0x17FFFFFF))
    }
    val shape = RoundedCornerShape(radius)
    if (LocalNeon.current && !light) {
        val amb = LocalAmbient.current
        return@composed this.clip(shape)
            .background(Brush.linearGradient(listOf(Color(0x2EFFFFFF), amb.copy(alpha = 0.06f), Color(0x08FFFFFF))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x99FFFFFF), amb.copy(alpha = 0.40f), Color(0x12FFFFFF))), shape)
    }
    this.clip(shape)
        .background(Brush.linearGradient(
            if (light) listOf(Color(0xEEFFFFFF), Color(0x99FFFFFF)) else listOf(Color(0x30FFFFFF), Color(0x0AFFFFFF))))
        .border(1.dp, Brush.linearGradient(
            if (light) listOf(Color(0x33000000), Color(0x0F000000)) else listOf(Color(0x66FFFFFF), Color(0x10FFFFFF))), shape)
}

/** Fokus für die Fernbedienung: Zoom, Leuchten und Rahmen in der Akzentfarbe. */
fun Modifier.tvFocus(zoom: Float = 1.03f): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val perf = LocalPerf.current
    if (perf) {
        // Leicht-Modus: nur ein Rahmen, kein Zoom, kein Schatten, keine Animation
        return@composed this.onFocusChanged { f = it.hasFocus }
            .border(if (f) 3.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(10.dp))
    }
    if (LocalPremium.current) {
        // Premium: Kachel wächst deutlich, weißer Rahmen – wie bei großen Streaming-Diensten
        val z = 1f + (zoom - 1f) * 1.6f
        val scaleP by animateFloatAsState(if (f && !perf) z else 1f, tween(180), label = "focusZoomP")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scaleP; scaleY = scaleP }
            .border(if (f) 3.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(8.dp))
    }
    val glowK = LocalGlow.current
    if (LocalBlue.current) {
        val neon = LocalNeon.current
        val tint = if (neon) LocalAmbient.current else Color(0xFF7FA6FF)
        val zb = 1f + (zoom - 1f) * 1.8f
        val scaleB by animateFloatAsState(if (f && !perf) zb else 1f, tween(160), label = "focusZoomB")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scaleB; scaleY = scaleB }
            .shadow(if (f && !perf) ((if (neon) 32f else 22f) * glowK).dp else 0.dp, RoundedCornerShape(14.dp), clip = false,
                ambientColor = tint, spotColor = tint)
            .border(if (f) 2.dp else 0.dp, if (f) Color(0xE6FFFFFF) else Color.Transparent, RoundedCornerShape(14.dp))
    }
    val scale by animateFloatAsState(if (f && !perf) zoom else 1f, animationSpec = tween(100), label = "focusZoom")
    val accent = MaterialTheme.colorScheme.primary
    this.onFocusChanged { f = it.hasFocus }
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .shadow(if (f && !perf) (18f * glowK).dp else 0.dp, RoundedCornerShape(14.dp), clip = false, ambientColor = accent, spotColor = accent)
        .border(if (f) 2.dp else 0.dp, if (f) accent else Color.Transparent, RoundedCornerShape(14.dp))
}

@Composable
fun App(vm: AppVM = viewModel()) {
    val activity = LocalContext.current as? Activity
    val lastBack = remember { longArrayOf(0L) }
    BackHandler {
        if (System.currentTimeMillis() - vm.swallowBackAt < 3500) { vm.swallowBackAt = 0L; return@BackHandler }
        if (!vm.back()) {
            val now = System.currentTimeMillis()
            if (now - lastBack[0] < 2500) activity?.finish()
            else {
                lastBack[0] = now
                vm.showNotice("Nochmal Zurück zum Beenden")
            }
        }
    }
    val mode = vm.designMode
    val perfFast = vm.perfMode
    val glow = MaterialTheme.colorScheme.primary
    val LocalGlowValue = LocalGlow.current
    val amb = LocalAmbient.current
    val glowA = when (mode) { "oled" -> 0.10f; "premium" -> 0.11f; "night" -> 0.08f; "neon" -> 0f; else -> 0.26f }
    val blueA = when (mode) {
        "night" -> 0.55f
        "oled", "premium", "neon" -> 0.0f
        else -> 0.16f
    }
    Box(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(
            when (mode) {
                "premium" -> listOf(Color(0xFF0B0B0B), Color.Black)
                "oled" -> listOf(Color.Black, Color.Black)
                "night" -> listOf(Color(0xFF16277A), Color(0xFF0A1238), Color(0xFF040714))
                "neon" -> listOf(Color(0xFF0A0A14), Color(0xFF07070D))
                else -> listOf(Color(0xFF0C0C13), Color(0xFF07070B))
            }))
        .drawBehind {
            if (!perfFast) {
                val gk = LocalGlowValue
                drawRect(Brush.radialGradient(listOf(glow.copy(alpha = glowA * gk), Color.Transparent),
                    center = Offset(size.width * 0.12f, 0f), radius = size.maxDimension * 0.6f))
                drawRect(Brush.radialGradient(listOf(Color(0xFF3B5BDB).copy(alpha = blueA * gk), Color.Transparent),
                    center = Offset(size.width, size.height), radius = size.maxDimension * 0.55f))
                if (mode == "neon") {
                    // Weiche Farbwolken in der Farbe des fokussierten Posters
                    val k = 0.35f + 0.65f * gk
                    drawRect(Brush.radialGradient(listOf(amb.copy(alpha = 0.50f * k), Color.Transparent),
                        center = Offset(size.width * 0.80f, size.height * 0.16f), radius = size.maxDimension * 0.55f))
                    drawRect(Brush.radialGradient(listOf(shiftHue(amb, 45f).copy(alpha = 0.38f * k), Color.Transparent),
                        center = Offset(size.width * 0.96f, size.height * 0.82f), radius = size.maxDimension * 0.50f))
                    drawRect(Brush.radialGradient(listOf(shiftHue(amb, -60f).copy(alpha = 0.20f * k), Color.Transparent),
                        center = Offset(size.width * 0.22f, size.height * 1.02f), radius = size.maxDimension * 0.42f))
                }
            }
        }) {
        if (!vm.introDone) {
            IntroScreen(vm.designMode == "premium", vm.introSound && !vm.perfMode, vm.perfMode) { vm.introDone = true }
        } else if (!vm.profilePicked) {
            ProfilePicker(vm)
        } else AnimatedContent(
            targetState = vm.stack.last(),
            transitionSpec = {
                // Beim Verlassen und Betreten des Players ohne Überblendung: fühlt sich schneller an
                if (perfFast || initialState is Screen.Play || targetState is Screen.Play)
                    (EnterTransition.None togetherWith ExitTransition.None)
                else (fadeIn(tween(120)) togetherWith fadeOut(tween(80)))
            },
            label = "screen"
        ) { s -> when (s) {
            Screen.Portals -> Shell(vm, "portals") { PortalsScreen(vm) }
            is Screen.Form -> FormScreen(vm, s.edit)
            Screen.Home -> Shell(vm, "home") { HomeScreen(vm) }
            is Screen.Browse -> Shell(vm, s.type) { BrowseScreen(vm, s.type) }
            is Screen.Seasons -> {
                val rows: List<Pair<String, () -> Unit>> = vm.seasons.map { se -> se.name to { vm.openSeason(se) } }
                SimpleList(s.title, rows)
            }
            is Screen.Episodes -> {
                val se = s.season
                val rows: List<Pair<String, () -> Unit>> = se.episodes.map { n ->
                    (if (vm.isSeen(se, n)) "✓  " else "") + "Episode $n" to { vm.playEpisode(se, n) }
                }
                SimpleList(se.name, rows)
            }
            Screen.ResumeList -> {
                val rows: List<Pair<String, () -> Unit>> = vm.resumeList.map { r ->
                    "${r.title}  ·  ${fmtTime(r.pos)}" to { vm.playResume(r) }
                }
                val empty: List<Pair<String, () -> Unit>> = listOf("Noch nichts angefangen" to { })
                SimpleList("Weiterschauen", if (rows.isEmpty()) empty else rows)
            }
            Screen.Guide -> Shell(vm, "epg") { GuideScreen(vm) }
            Screen.Favs -> Shell(vm, "fav") { FavsScreen(vm) }
            Screen.Watch -> Shell(vm, "watch") { WatchScreen(vm) }
            Screen.Settings -> Shell(vm, "settings") { SettingsScreen(vm) }
            Screen.AppSettings -> SettingsScreen(vm)
            Screen.LogView -> LogScreen(vm)
            is Screen.Detail -> DetailScreen(vm, s.item)
            Screen.EditCats -> EditCatsScreen(vm)
            Screen.EditChans -> EditChansScreen(vm)
            Screen.DesignScale -> DesignScaleScreen(vm)
            Screen.ResumeAll -> Shell(vm, "resume") { ResumeAllView(vm) }
            Screen.HomeLayout -> HomeLayoutScreen(vm)
            is Screen.HomeAddRow -> {
                val rows: List<Pair<String, () -> Unit>> = vm.homeCatChoices.map { c -> c.title to { vm.addHomeCustom(s.type, c) } }
                val wait: List<Pair<String, () -> Unit>> = listOf("Lade Kategorien …" to { })
                SimpleList(if (s.type == "series") "Serien-Kategorie als Reihe wählen" else "Film-Kategorie als Reihe wählen",
                    if (rows.isEmpty()) wait else rows)
            }
            Screen.FavLists -> FavListsScreen(vm)
            is Screen.FavListEdit -> FavListEditScreen(vm, s.id)
            Screen.PhoneAdd -> PhoneAddScreen(vm)
            Screen.Play -> PlayerScreen(vm)
        } }
        if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
        if (vm.introDone) {
            UpdateDialog(vm)
            ReminderDialog(vm)
            FavPickDialog(vm)
        }
        vm.notice?.let {
            Text(it, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
                    .background(Color(0xDD0D47A1), RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 8.dp))
        }
        vm.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(12.dp))
        }
    }
}

@Composable
fun ListRow(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(
        text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(12.dp)
    )
}

/** Listenzeile mit kleinem Symbol vor dem Text (z. B. Kategorien). */
@Composable
fun ListRowK(text: String, selected: Boolean, kind: String?, onClick: () -> Unit) {
    if (kind == null) { ListRow(text, selected, onClick); return }
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
        .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
        .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        GlowIcon(kind, 26.dp)
        Spacer(Modifier.width(10.dp))
        Text(text.trim(), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun SimpleList(title: String, rows: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(rows) { (label, act) -> ListRow(label, false, act) } }
    }
}

@Composable
fun PortalsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TOM’S TV", fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
            letterSpacing = 6.sp)
        Box(Modifier.padding(vertical = 6.dp).width(120.dp).height(2.dp).background(accent))
        Text("PORTALE · ALLE SIND AKTIV", fontSize = 11.sp, letterSpacing = 4.sp, color = accent,
            modifier = Modifier.align(Alignment.Start).padding(top = 6.dp, bottom = 6.dp))
        if (vm.portals.isEmpty()) {
            Text("Noch kein Portal eingetragen. Füge unten dein erstes Portal hinzu.", color = gray,
                modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).widthIn(max = 900.dp).fillMaxWidth()) {
            items(vm.portals, key = { it.id }) { p ->
                PortalRow(vm, p, if (p.id == vm.portals.first().id) Modifier.focusRequester(fr) else Modifier)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.tvFocus()) { Text("+ Portal") }
            Button(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) { Text("📱 Per Handy") }
            OutlinedButton(onClick = { vm.refreshAllPortals(true) }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
    }
}

@Composable
fun PortalRow(vm: AppVM, p: Portal, modifier: Modifier = Modifier) {
    var confirm by remember { mutableStateOf(false) }
    val host = remember(p.url) { runCatching { java.net.URL(p.url).host }.getOrDefault(p.url) }
    val st = vm.status[p.id]
    val statusText = when {
        st == null || st == "loading" -> "⏳ lädt …"
        st == "ok" -> "● aktiv"
        else -> "⚠ nicht erreichbar"
    }
    val statusColor = when {
        st == null || st == "loading" -> LocalMuted.current
        st == "ok" -> Color(0xFF69F0AE)
        else -> Color(0xFFFF8A80)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(modifier.weight(1f).tvFocus(1.02f).clip(RoundedCornerShape(16.dp))
            .glass(16.dp)
            .clickable { vm.push(Screen.Form(p)) }.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            GlowIcon("ticket", 40.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(host, fontSize = 12.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(statusText, fontSize = 12.sp, color = statusColor, maxLines = 1)
                val line = vm.portalLine(p)
                if (line.isNotBlank()) {
                    Text(line, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (vm.portalWarn(p)) Color(0xFFFFB74D) else LocalMuted.current)
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        val pos = vm.portals.indexOfFirst { it.id == p.id }
        OutlinedButton(onClick = { vm.movePortal(p, -1) }, enabled = pos > 0,
            contentPadding = PaddingValues(horizontal = 14.dp), modifier = Modifier.tvFocus()) { Text("▲") }
        Spacer(Modifier.width(6.dp))
        OutlinedButton(onClick = { vm.movePortal(p, 1) }, enabled = pos in 0 until vm.portals.size - 1,
            contentPadding = PaddingValues(horizontal = 14.dp), modifier = Modifier.tvFocus()) { Text("▼") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.refreshSingle(p) }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.push(Screen.Form(p)) }, modifier = Modifier.tvFocus()) { Text("Bearbeiten") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { if (confirm) vm.deletePortal(p) else confirm = true }, modifier = Modifier.tvFocus()) {
            Text(if (confirm) "Wirklich löschen?" else "Löschen")
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().tvFocus())
}

@Composable
fun FormScreen(vm: AppVM, edit: Portal?) {
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var url by remember { mutableStateOf(edit?.url ?: "http://") }
    var mac by remember { mutableStateOf(edit?.mac ?: "") }
    var login by remember { mutableStateOf(edit?.login ?: "") }
    var pw by remember { mutableStateOf(edit?.password ?: "") }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.testResult = null }
    Column(Modifier.fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (edit == null) "Portal hinzufügen" else "Portal bearbeiten", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Field("Name", name) { name = it }
        Field("Portal-URL (z. B. http://host/c/)", url) { url = it }
        Field("MAC-Adresse (00:1A:79:XX:XX:XX)", mac) { mac = it }
        Field("Login (optional)", login) { login = it }
        Field("Passwort (optional)", pw) { pw = it }
        err?.let { Text(it, color = Color(0xFFFF8A80)) }
        if (vm.testing) Text("⏳  Portal wird getestet … (kann bis zu einer Minute dauern)", color = LocalMuted.current)
        vm.testResult?.let {
            Text(it, color = if (it.startsWith("✓")) Color(0xFF69F0AE) else Color(0xFFFF8A80))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(modifier = Modifier.tvFocus(), onClick = {
                val m = mac.trim().uppercase()
                val u = url.trim()
                when {
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        err = null
                        vm.testPortal(Portal("test", name.trim().ifBlank { "Test" }, u, m, login.trim(), pw))
                    }
                }
            }) { Text("🔍 Testen") }
            Button(modifier = Modifier.tvFocus(), onClick = {
                val m = mac.trim().uppercase()
                val u = url.trim()
                when {
                    name.isBlank() -> err = "Name fehlt"
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        vm.savePortal(Portal(edit?.id ?: UUID.randomUUID().toString(), name.trim(), u, m, login.trim(), pw))
                        vm.back()
                    }
                }
            }) { Text("Speichern") }
            OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Abbrechen") }
        }
    }
}

@Composable
fun HomeHeaderTexts(vm: AppVM, greeting: String, gray: Color) {
    Text(if (vm.profiles.size > 1) greeting + ", " + vm.profileName() else greeting,
        fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont)
    Text("${vm.status.values.count { it == "ok" }} VON ${vm.portals.size} PORTALEN AKTIV", fontSize = 11.sp,
        letterSpacing = 3.sp, color = gray)
    if (vm.portals.isNotEmpty()) {
        Text(vm.portals.joinToString("    ") { p ->
            val st = vm.status[p.id]
            (if (st == "ok") "●" else if (st != null && st.startsWith("err")) "⚠" else "…") + " " + p.name + vm.portalShort(p)
        }, fontSize = 11.sp, color = gray, maxLines = 2, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
fun HomeScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 5 -> "Gute Nacht"
        hour < 11 -> "Guten Morgen"
        hour < 18 -> "Guten Tag"
        else -> "Guten Abend"
    }
    val newList = vm.homeNew.ifEmpty { vm.homeCached }
    val hero = newList.take(5)
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(hero.size) {
        while (hero.size > 1 && !vm.perfMode) {
            delay(8000)
            idx = (idx + 1) % hero.size
        }
    }
    var heroShown by remember { mutableStateOf(true) }
    LaunchedEffect(idx) { heroShown = false; delay(30); heroShown = true }
    val heroAlpha by animateFloatAsState(if (heroShown || vm.perfMode) 1f else 0f, tween(450), label = "heroFade")
    val fr = remember { FocusRequester() }
    LaunchedEffect(hero.isNotEmpty()) {
        if (hero.isNotEmpty()) {
            delay(150)
            runCatching { fr.requestFocus() }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { HomeHeaderTexts(vm, greeting, gray) }
            if (vm.profiles.size > 1) {
                OutlinedButton(onClick = { vm.nextProfile() }, modifier = Modifier.padding(end = 12.dp).tvFocus()) {
                    Avatar(vm.profileAvatar(), 28.dp, initialOf(vm.profileName()))
                    Spacer(Modifier.width(8.dp))
                    Text(vm.profileName())
                }
            }
            Clock()
        }
        if (hero.isNotEmpty()) {
            Box(Modifier.alpha(heroAlpha)) { HeroBanner(vm, hero[idx % hero.size], idx % hero.size, hero.size, fr) }
        } else {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (vm.portals.isEmpty()) {
                    Text("Noch kein Portal eingetragen.", color = gray)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("+ Portal hinzufügen")
                        }
                        OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) {
                            Text("📱 Per Handy")
                        }
                    }
                } else {
                    Text(
                        if (vm.allLoading) "Portale werden verbunden …"
                        else "Keine Inhalte gefunden. Prüfe unter Portale, ob die Portale erreichbar sind.",
                        color = gray
                    )
                    if (!vm.allLoading) {
                        vm.portals.filter { (vm.status[it.id] ?: "").startsWith("err") }.forEach { p ->
                            Text("⚠ " + p.name + ": " + (vm.status[p.id] ?: "").removePrefix("err:"), fontSize = 13.sp,
                                color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 4.dp))
                        }
                        Button(onClick = { vm.refreshAllPortals(true) }, modifier = Modifier.padding(top = 10.dp).tvFocus()) {
                            Text("⟳ Erneut versuchen")
                        }
                    }
                }
            }
        }
        if (LocalBlue.current) BrandTiles(vm)
        for (sid in vm.homeSections()) {
            if (sid in vm.homeOff) continue
            androidx.compose.runtime.key(sid) {
                when {
                    sid == "eps" -> {
                        if (vm.newEpisodes.isNotEmpty()) {
                            SectionHeader("Neue Folgen bei deinen Serien")
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.newEpisodes) { pr -> MiniPoster(pr.first) { vm.openHomeItem(pr.first, "series") } }
                            }
                        }
                    }
                    sid == "new" -> {
                        if (newList.isNotEmpty()) {
                            SectionHeader("Neu im Angebot", "Alle anzeigen") { vm.goTo("vod") }
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(newList) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
                            }
                        }
                    }
                    sid == "byportal" -> {
                        if (vm.homeNewByPortal.size > 1) {
                            val shownIds = vm.homeNew.map { it.id }.toSet()
                            for ((pname, plist0) in vm.homeNewByPortal) {
                                // Nur zeigen, was nicht schon oben unter „Neu im Angebot“ steht
                                val plist = plist0.filter { it.id !in shownIds }
                                if (plist.size < 3) continue
                                SectionHeader("Neu bei " + pname)
                                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(plist) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
                                }
                            }
                        }
                    }
                    sid == "watch" -> {
                        val watch = remember(vm.profileId) { vm.watchFor("vod") + vm.watchFor("series") }
                        if (watch.isNotEmpty()) {
                            SectionHeader("Meine Merkliste", "Alle anzeigen") { vm.goTo("watch") }
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(watch) { w -> MiniPoster(w) { vm.openHomeItem(w, vm.watchType(w)) } }
                            }
                        }
                    }
                    sid == "recent" -> {
                        if (vm.recentChans.isNotEmpty()) {
                            SectionHeader("Zuletzt gesehen")
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.recentChans) { c -> ChannelTile(c) { vm.openRecent(c) } }
                            }
                        }
                    }
                    sid == "live" || sid.startsWith("live:") -> LiveNowRow(vm, sid)
                    sid == "pop" -> {
                        if (vm.homeChannels.isNotEmpty()) {
                            SectionHeader("Live TV – Beliebte Sender", "Alle anzeigen") { vm.goTo("itv") }
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.homeChannels) { c -> ChannelTile(c) { vm.openHomeItem(c, "itv") } }
                            }
                        }
                    }
                    sid == "resume" -> {
                        if (vm.resumeList.isNotEmpty()) {
                            SectionHeader("Weiterschauen")
                            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.resumeList) { r ->
                                    Column(Modifier.width(190.dp).tvFocus(1.05f).clip(RoundedCornerShape(12.dp))
                                        .background(Color(0x22FFFFFF)).clickable { vm.playResume(r) }.padding(12.dp)) {
                                        Text("⏯  ${fmtTime(r.pos)}", fontSize = 12.sp, color = gray)
                                        Text(r.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2,
                                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                    sid.startsWith("c:") -> CustomHomeRow(vm, sid)
                }
                Unit
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ---------- Startseite einrichten und Jetzt live ----------
@Composable
fun LiveNowRow(vm: AppVM, sid: String) {
    val list = remember(sid, vm.favTick, vm.homeTick, vm.homeChannels) { vm.liveItems(sid) }
    if (list.isEmpty()) return
    SectionHeader(if (sid == "live") "Jetzt live" else "Jetzt live – " + vm.listName(sid.removePrefix("live:")))
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.id }) { ch -> LiveTile(vm, ch) { vm.openLiveFrom(sid, list, ch) } }
    }
}

@Composable
fun LiveTile(vm: AppVM, ch: Item, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Column(Modifier.width(210.dp).tvFocus(1.05f).glass(14.dp).clickable(onClick = onClick).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(8.dp))
            Text(ch.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(now?.title ?: "…", fontSize = 12.sp, color = LocalMuted.current, maxLines = 2,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp).height(34.dp))
        val pr = now?.let { vm.epgProgress(it) }
        if (pr != null) {
            LinearProgressIndicator(progress = { pr }, modifier = Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp))
        } else Spacer(Modifier.height(3.dp))
    }
}

@Composable
fun CustomHomeRow(vm: AppVM, sid: String) {
    val hc = vm.homeCustom.firstOrNull { it.id == sid } ?: return
    LaunchedEffect(sid, vm.homeTick) { vm.loadCustom(sid) }
    val l = vm.customItems[sid] ?: return
    if (l.isEmpty()) return
    SectionHeader(hc.title)
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(l) { m -> MiniPoster(m) { vm.openHomeItem(m, hc.type) } }
    }
}

@Composable
fun HomeLayoutScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val sections = vm.homeSections()
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("STARTSEITE EINRICHTEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Text("Reihen ein- oder ausschalten und mit ▲ ▼ verschieben. Eigene Reihen kommen aus Film- oder Serien-Kategorien.",
            fontSize = 13.sp, color = gray, modifier = Modifier.padding(vertical = 10.dp))
        sections.forEachIndexed { i, id ->
            androidx.compose.runtime.key(id) {
                val on = id !in vm.homeOff
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(14.dp).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { vm.toggleHomeSection(id) },
                        modifier = (if (i == 0) Modifier.focusRequester(fr) else Modifier).tvFocus()) { Text(if (on) "✓" else "✗") }
                    Spacer(Modifier.width(12.dp))
                    Text(vm.homeLabel(id), fontSize = 16.sp, color = if (on) Color.Unspecified else gray,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.moveHomeSection(id, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = { vm.moveHomeSection(id, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                    if (id.startsWith("c:")) {
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = { vm.removeHomeCustom(id) }, modifier = Modifier.tvFocus()) { Text("🗑") }
                    }
                }
            }
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.openHomeAdd("vod") }, modifier = Modifier.tvFocus()) { Text("＋ Reihe aus Filme-Kategorie") }
            Button(onClick = { vm.openHomeAdd("series") }, modifier = Modifier.tvFocus()) { Text("＋ Reihe aus Serien-Kategorie") }
        }
    }
}

// ---------- Favoritenlisten ----------
@Composable
fun FavPickDialog(vm: AppVM) {
    val item = vm.favPick ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(item.id) { delay(200); runCatching { fr.requestFocus() } }
    val tick = vm.favTick
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(460.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(24.dp)) {
            Text("IN LISTE MERKEN", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            val all = listOf(FavList("", "Favoriten")) + vm.favLists
            all.forEachIndexed { i, l ->
                val inL = tick >= 0 && vm.inList(l.id, item)
                OutlinedButton(onClick = { vm.toggleInList(l.id, item) },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        .then(if (i == 0) Modifier.focusRequester(fr) else Modifier).tvFocus()) {
                    Text((if (inL) "★  " else "☆  ") + l.name)
                }
            }
            OutlinedButton(onClick = { val n = vm.createFavList(); vm.toggleInList(n.id, item) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).tvFocus()) { Text("＋ Neue Liste anlegen und hinzufügen") }
            Button(onClick = { vm.favPick = null }, modifier = Modifier.padding(top = 14.dp).tvFocus()) { Text("Fertig") }
        }
    }
}

@Composable
fun FavListsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    var renaming by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf<String?>(null) }
    val tf = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    LaunchedEffect(renaming) { if (renaming != null) { delay(150); runCatching { tf.requestFocus() } } }
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("FAVORITENLISTEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Text("Sender in mehrere Listen sortieren, zum Beispiel Kinder, Sport oder Abends. Beim Favorisieren (OK lange drücken) fragt die App, in welche Liste.",
            fontSize = 13.sp, color = gray, modifier = Modifier.padding(vertical = 10.dp))
        val all = listOf(FavList("", "Favoriten")) + vm.favLists
        all.forEachIndexed { i, l ->
            androidx.compose.runtime.key(l.id) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(14.dp).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (renaming == l.id) {
                        OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true,
                            modifier = Modifier.weight(1f).focusRequester(tf))
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { vm.renameFavList(l.id, text); renaming = null }, modifier = Modifier.tvFocus()) { Text("OK") }
                    } else {
                        Column(Modifier.weight(1f).padding(start = 8.dp)) {
                            Text((if (l.id.isEmpty()) "★ " else "") + l.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Text(vm.listItems(l.id).size.toString() + " Sender", fontSize = 12.sp, color = gray)
                        }
                        Button(onClick = { vm.push(Screen.FavListEdit(l.id)) },
                            modifier = (if (i == 0) Modifier.focusRequester(fr) else Modifier).tvFocus()) { Text("Sender ›") }
                        if (l.id.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { text = l.name; renaming = l.id }, modifier = Modifier.tvFocus()) { Text("✎") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { vm.moveFavList(l.id, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { vm.moveFavList(l.id, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = {
                                if (confirmDel == l.id) { vm.deleteFavList(l.id); confirmDel = null } else confirmDel = l.id
                            }, modifier = Modifier.tvFocus()) { Text(if (confirmDel == l.id) "Wirklich?" else "🗑") }
                        }
                    }
                }
            }
        }
        Button(onClick = { val n = vm.createFavList(); text = n.name; renaming = n.id },
            modifier = Modifier.padding(top = 14.dp).tvFocus()) { Text("＋ Neue Liste") }
    }
}

@Composable
fun FavListEditScreen(vm: AppVM, id: String) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    val list = remember(vm.favTick, id) { vm.listItems(id) }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(vm.listName(id).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("Reihenfolge der Sender in dieser Liste", fontSize = 13.sp, color = gray)
                }
                OutlinedButton(onClick = { vm.sortListAz(id) }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("A–Z sortieren") }
            }
            if (list.isEmpty()) Text("Noch keine Sender. Favorisiere Sender mit OK lange drücken.", color = gray)
        }
        itemsIndexed(list, key = { _, c -> c.id }) { idx, c ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(12.dp).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text((idx + 1).toString(), fontSize = 13.sp, color = gray, modifier = Modifier.width(34.dp))
                AsyncImage(model = c.logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(12.dp))
                Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { vm.moveInList(id, c, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { vm.moveInList(id, c, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { vm.removeFromList(id, c) }, modifier = Modifier.tvFocus()) { Text("✕") }
            }
        }
    }
}

@Composable
fun Tile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(170.dp).tvFocus(1.08f).clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3A0F18), Color(0xFF14080B))))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 46.sp)
        Spacer(Modifier.height(10.dp))
        Text(label.uppercase(), fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BrowseScreen(vm: AppVM, type: String) {
    DisposableEffect(Unit) { onDispose { vm.stopPreview() } }
    Row(Modifier.fillMaxSize()) {
        CategoryPane(vm, type)
        Column(Modifier.weight(1f).fillMaxHeight().onFocusChanged { if (it.hasFocus) vm.leftFocus = null }) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.queryText,
                    onValueChange = { vm.queryText = it; if (type == "itv") vm.search(it) },
                    label = { Text("Suche") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(vm.queryText) }),
                    modifier = Modifier.weight(1f).tvFocus()
                )
                if (type == "itv") {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.push(Screen.Guide) }, modifier = Modifier.tvFocus()) { Text("Programm") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.openEditChannels() }, modifier = Modifier.tvFocus()) { Text("Kanäle") }
                }
                Spacer(Modifier.width(8.dp))
                if (type != "itv") {
                    OutlinedButton(onClick = { vm.toggleEditMode() }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.editMode) "Fertig" else "Ausblenden")
                    }
                    Spacer(Modifier.width(8.dp))
                }
                OutlinedButton(onClick = { vm.push(Screen.EditCats) }, modifier = Modifier.tvFocus()) { Text("Kategorien") }
            }
            Text(if (vm.editMode && type != "itv") "AUSBLENDEN-MODUS: OK blendet einen Eintrag aus oder wieder ein. Beenden mit Fertig."
                else "OK lange drücken oder Menü-Taste = Favorit", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            if (type != "itv" && vm.selCat?.endsWith(":resume") != true) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.cycleSort() }, modifier = Modifier.tvFocus()) {
                        Text("Sortierung: " + vm.sortLabel() + " ⟳", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { vm.cycleQual() }, modifier = Modifier.tvFocus()) {
                        Text("Qualität: " + vm.qualLabel() + " ⟳", fontSize = 12.sp)
                    }
                    if (type == "vod") {
                        OutlinedButton(onClick = { vm.toggleHideSeen() }, modifier = Modifier.tvFocus()) {
                            Text("Gesehene ausblenden: " + (if (vm.hideSeen) "an" else "aus") + " ⟳", fontSize = 12.sp)
                        }
                    }
                }
            }
            if (type == "itv" && vm.previewOn && !vm.perfMode && LocalConfiguration.current.screenHeightDp >= 480) PreviewCard(vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (type != "itv" && vm.selCat?.endsWith(":resume") == true) {
                    ResumeListView(vm)
                } else if (type == "itv") {
                    LazyColumn(state = vm.listState, modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(vm.items) { ch -> ChannelRow(vm, ch) }
                    }
                } else {
                    val last by remember { derivedStateOf { vm.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 } }
                    val shown = vm.shownItems()
                    LaunchedEffect(last, shown.size, vm.hasMore) {
                        if (vm.hasMore && last >= shown.size - 6) vm.loadMore()
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), state = vm.gridState,
                        modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(shown) { entry -> PosterCard(vm, entry) }
                    }
                    if (vm.busyList) Text("Lade …", Modifier.align(Alignment.BottomCenter).padding(8.dp))
                }
                if (vm.items.isEmpty() && !vm.busyList && !vm.loading && vm.selCat?.endsWith(":resume") != true) Text("Keine Einträge", Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun ChannelRow(vm: AppVM, ch: Item) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).tvFocus(1.02f).onFocusChanged { if (it.hasFocus) vm.requestPreview(ch) }
        .glass(12.dp).favKey { vm.toggleFav(ch) }
        .combinedClickable(onClick = { vm.openItem(ch) }, onLongClick = { vm.toggleFav(ch) }).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(6.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text((if (vm.isFavAny(ch)) "★ " else "") + ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 13.sp, color = LocalMuted.current,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                vm.epgProgress(now)?.let { p ->
                    LinearProgressIndicator(progress = { p },
                        modifier = Modifier.padding(top = 5.dp).fillMaxWidth().height(3.dp))
                }
            }
        }
    }
}

@Composable
fun PosterCard(vm: AppVM, entry: Item) {
    val hidden = vm.editMode && entry.id in vm.hiddenItems
    Box(Modifier.padding(6.dp)) {
        Box(Modifier.alpha(if (hidden) 0.35f else 1f).tvFocus(1.06f)
            .onFocusChanged { if (it.hasFocus) vm.focusAmbient(entry.logo ?: entry.backdrop) }
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF222A33)).favKey { vm.toggleFav(entry) }
            .combinedClickable(onClick = { vm.openItem(entry) }, onLongClick = { vm.toggleFav(entry) })) {
            val pctx = LocalContext.current
            val pperf = LocalPerf.current
            val req = remember(entry.logo, pperf) {
                coil.request.ImageRequest.Builder(pctx).data(entry.logo).crossfade(if (pperf) 0 else 120).build()
            }
            AsyncImage(model = req, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            QualityBadges(entry.name, Modifier.align(Alignment.TopEnd).padding(6.dp))
            if (vm.browseType == "vod" && ("mv|" + entry.cmd) in vm.seenKeys) {
                Text("✓", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                        .background(Color(0xCC1E9E5A), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
            }
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                .padding(start = 10.dp, end = 10.dp, top = 30.dp, bottom = 10.dp)) {
                Text((if (hidden) "✗ " else if (vm.isFav(entry)) "★ " else "") + entry.name,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val mac = vm.portal?.mac ?: ""
    val ds = remember {
        SmartHttpFactory().setCompat(vm.compat && vm.isLive).setUserAgent(vm.streamUserAgent()).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (vm.isLive) 6_000 else if (NetState.weak) 14_000 else 10_000)
            .setReadTimeoutMs(if (vm.isLive) 8_000 else if (NetState.weak) 22_000 else 15_000)
            .setDefaultRequestProperties(vm.streamHeaders())
    }
    val exo = remember {
        val selector = DefaultTrackSelector(ctx)
        val maxQ = vm.qualityMode != "auto"
        val forceHigh = vm.qualityMode == "max"
        if (maxQ) {
            // Immer die höchste Bild- und Tonqualität nehmen, die das Gerät kann (nicht an die Bildschirmgröße gebunden).
            selector.setParameters(
                selector.buildUponParameters()
                    .setForceHighestSupportedBitrate(forceHigh)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setConstrainAudioChannelCountToDeviceCapabilities(false)
                    .build()
            )
        }
        if (vm.fourKHelp) {
            // Tunneling gibt es nur über den Track-Selector (DefaultTrackSelector.Parameters)
            selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(true).build())
        }
        if (vm.audioMode == "stereo") {
            selector.setParameters(selector.buildUponParameters()
                .setMaxAudioChannelCount(2).setConstrainAudioChannelCountToDeviceCapabilities(true).build())
        }
        val rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        if (vm.decoderMode == "sw") {
            rf.setMediaCodecSelector(MediaCodecSelector { mime, secure, tunneling ->
                MediaCodecUtil.getDecoderInfos(mime, secure, tunneling).sortedBy { it.hardwareAccelerated }
            })
        }
        if (vm.fourKHelp) rf.forceEnableMediaCodecAsynchronousQueueing()
        ExoPlayer.Builder(ctx, rf)
            .setTrackSelector(selector)
            // Größerer Puffer: ruhigeres Bild bei 4K und schwankendem Netz
            .setLoadControl(if (!vm.isLive) buildVodLoadControl() else if (vm.compat) DefaultLoadControl.Builder().build() else buildLoadControl(vm.isLive, if (NetState.weak && vm.bufferMode == "fast") "balanced" else if (NetState.weak && !vm.isLive) "stable" else if (NetState.weak) "balanced" else vm.bufferMode))
            // Richtiger Audio-Modus für Filme (Surround, Lautstärke, Fokus)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(
                    ds,
                    // Schnellerer Start und ruhigeres Bild bei MPEG-TS-Sendern
                    if (vm.compat || !vm.isLive) DefaultExtractorsFactory() else DefaultExtractorsFactory().setTsExtractorFlags(
                        DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                ).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(if (NetState.weak) 10 else 6))
            ).build().apply {
                playWhenReady = true
                // Tonspur: Deutsch bevorzugen, sonst Standard des Senders
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguages(*(if (vm.prefAudioLang.isNotEmpty()) arrayOf(vm.prefAudioLang) else arrayOf("de", "deu", "ger")))
                    .apply {
                        if (vm.prefTextLang == "off") setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        else if (vm.prefTextLang.isNotEmpty()) setPreferredTextLanguage(vm.prefTextLang)
                    }
                    .build()
                if (maxQ) {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                        .setMaxVideoBitrate(Int.MAX_VALUE)
                        .setMaxAudioBitrate(Int.MAX_VALUE)
                        .setMaxAudioChannelCount(Int.MAX_VALUE)
                        .clearViewportSizeConstraints()
                        .build()
                }
            }
    }
    var retries by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf(false) }
    var audioMenu by remember { mutableStateOf(false) }
    var xray by remember { mutableStateOf(false) }
    fun closeXray() { xray = false; exo.playWhenReady = true }
    var infoOn by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var qualityText by remember { mutableStateOf("") }
    var skipped by remember(vm.playUrl) { mutableStateOf(false) }
    var controls by remember { mutableStateOf(false) }
    var liveBar by remember { mutableStateOf(false) }
    var epgSel by remember { mutableIntStateOf(0) }
    val barFr = remember { FocusRequester() }
    var ctrlTick by remember { mutableIntStateOf(0) }
    val ctrlFr = remember { FocusRequester() }
    // Schnelleres Spulen: 10 s, bei wiederholtem Drücken 30 s, dann 60 s
    val seekState = remember { longArrayOf(0L, 0L) }
    // Live pausieren / zurückspulen
    var liveBehind by remember { mutableLongStateOf(0L) }
    var livePaused by remember { mutableStateOf(false) }
    var audioSess by remember { mutableIntStateOf(exo.audioSessionId) }
    val enh = remember { arrayOfNulls<android.media.audiofx.LoudnessEnhancer>(1) }
    fun goLive() {
        if (exo.isCurrentMediaItemSeekable && exo.isCurrentMediaItemLive) {
            exo.seekToDefaultPosition()
            exo.playWhenReady = true
            liveBehind = 0L
        } else vm.reload()
    }
    fun liveSeek(dir: Int) {
        if (!exo.isCurrentMediaItemSeekable) {
            vm.showNotice("Zurückspulen geht bei diesem Sender nicht, nur Pause")
            return
        }
        if (dir > 0 && liveBehind <= 10_000L) { goLive(); return }
        exo.seekTo((exo.currentPosition + dir * 10_000L).coerceAtLeast(0L))
        liveBehind = (liveBehind - dir * 10_000L).coerceAtLeast(0L)
    }
    fun stepSeek(dir: Int) {
        val now = System.currentTimeMillis()
        seekState[1] = if (now - seekState[0] < 1200) seekState[1] + 1 else 0L
        seekState[0] = now
        val sec = when {
            seekState[1] < 2 -> 10
            seekState[1] < 5 -> 30
            else -> 60
        }
        val dur = exo.duration
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + dir * sec * 1000L).coerceIn(0L, max))
        vm.showNotice((if (dir < 0) "⏪ " else "") + sec + " s" + (if (dir > 0) " ⏩" else ""))
    }
    val showSkip by remember {
        derivedStateOf {
            val end = if (vm.isEpisode) vm.introEndMs() else 0L
            vm.isEpisode && !skipped && !vm.noIntro() && posMs >= 3_000L && posMs <= (if (end > 0L) end - 2_000L else 240_000L)
        }
    }
    var hintOn by remember(vm.playUrl) { mutableStateOf(false) }
    LaunchedEffect(showSkip) {
        if (showSkip) { hintOn = true; delay(10_000); hintOn = false } else hintOn = false
    }
    val nextLbl = if (vm.isEpisode) vm.nextLabel() else null
    val creditsNow = nextLbl != null && durMs > 300_000L && posMs >= durMs - 90_000L
    val nextFr = remember { FocusRequester() }
    val fr = remember { FocusRequester() }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                AppLog.add("Wiedergabefehler (" + vm.playTitle + "): " + error.errorCodeName)
                if (error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES) {
                    if (!vm.isLive) vm.savePosition(exo.currentPosition, exo.duration)
                }
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                    return
                }
                val http = error.cause as? HttpDataSource.InvalidResponseCodeException
                if (http != null) AppLog.add("HTTP " + http.responseCode + " von " + (http.dataSpec.uri.host ?: "?"))
                // Server lehnt ab: erst andere Kennungen probieren, jeweils mit frischem Link
                if (error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS && vm.nextHeaderMode()) {
                    AppLog.add("Neuer Versuch mit anderer Anfrage-Kennung (Stufe " + vm.headerStage() + ")")
                    vm.reload()
                    return
                }
                if (vm.isLive) {
                    when {
                        retries < 2 -> { retries++; vm.reload() }
                        vm.tryAlternate() -> retries = 0
                        retries < 5 -> { retries++; vm.reload() }
                        else -> vm.error = playErrorText(error)
                    }
                } else vm.error = playErrorText(error)
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { audioSess = audioSessionId }
            private var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING && last == Player.STATE_READY) {
                    AppLog.add("Puffert nach: " + vm.playTitle)
                    vm.reportStall()
                }
                last = state
                if (state == Player.STATE_READY) {
                    retries = 0
                }
                if (state == Player.STATE_ENDED && !vm.isLive) vm.onEnded()
            }
        }
        exo.addListener(l)
        val netAl = object : AnalyticsListener {
            override fun onBandwidthEstimate(
                eventTime: AnalyticsListener.EventTime, totalLoadTimeMs: Int, totalBytesLoaded: Long, bitrateEstimate: Long
            ) { vm.reportBandwidth(bitrateEstimate) }

            override fun onVideoInputFormatChanged(
                eventTime: AnalyticsListener.EventTime, format: Format, decoderReuseEvaluation: DecoderReuseEvaluation?
            ) {
                if (vm.hdrOut == "auto") {
                    val ci = format.colorInfo
                    val hdr = ci != null && (ci.colorTransfer == C.COLOR_TRANSFER_ST2084 || ci.colorTransfer == C.COLOR_TRANSFER_HLG)
                    setWindowHdr(ctx, hdr)
                }
                if (vm.afrMode == "off" || (vm.isLive && vm.afrMode != "all")) return
                if (format.frameRate > 0f) matchRefreshRate(ctx, format.frameRate)
            }
        }
        exo.addAnalyticsListener(netAl)
        if (vm.hdrOut == "on") setWindowHdr(ctx, true)
        onDispose {
            exo.removeAnalyticsListener(netAl)
            resetRefreshRate(ctx)
            setWindowHdr(ctx, false)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
            exo.removeListener(l)
            exo.playWhenReady = false
            // Freigeben erst nach dem nächsten Bild: die Startseite erscheint sofort
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ runCatching { exo.release() } }, 300)
        }
    }

    // Netz-Anpassung: bei schwachem Netz Bildgröße und Datenrate deckeln, bei gutem Netz wieder freigeben
    val weakNow = vm.effectiveWeak()
    var weakApplied by remember { mutableStateOf(false) }
    var weakBanner by remember { mutableStateOf(false) }
    LaunchedEffect(weakNow, vm.netMode) {
        if (weakNow && vm.netMode == "auto") { weakBanner = true; delay(6000); weakBanner = false } else weakBanner = false
    }
    LaunchedEffect(weakNow, exo) {
        val sel = exo.trackSelector as? DefaultTrackSelector ?: return@LaunchedEffect
        if (weakNow) {
            sel.setParameters(sel.buildUponParameters()
                .setMaxVideoSize(1280, 720).setMaxVideoBitrate(4_000_000)
                .setForceHighestSupportedBitrate(false).setExceedVideoConstraintsIfNecessary(true).build())
            weakApplied = true
        } else if (weakApplied) {
            sel.setParameters(sel.buildUponParameters()
                .clearVideoSizeConstraints().setMaxVideoBitrate(Int.MAX_VALUE)
                .setForceHighestSupportedBitrate(vm.qualityMode == "max").build())
            weakApplied = false
        }
    }

    LaunchedEffect(vm.playUrl, vm.playNonce) {
        vm.playUrl?.let { u ->
            ds.setUserAgent(vm.streamUserAgent())
            ds.setDefaultRequestProperties(vm.streamHeaders())
            val pos = if (vm.isLive) 0L else vm.resumePos()
            if (pos > 0) {
                exo.setMediaItem(MediaItem.fromUri(u), pos)
                vm.showNotice("Weiter bei ${fmtTime(pos)}")
            } else exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare(); exo.play()
        }
    }
    LaunchedEffect(Unit) { fr.requestFocus() }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration
            if (vm.isEpisode && durMs > 60_000L && posMs >= durMs - 1_500L && exo.playbackState != Player.STATE_BUFFERING) vm.onEnded()
            qualityText = qualityLabel(exo)
            livePaused = vm.isLive && !exo.playWhenReady
            if (livePaused) liveBehind += 1000L
            delay(1000)
        }
    }
    BackHandler(enabled = audioMenu) { audioMenu = false }
    BackHandler(enabled = xray) { closeXray() }
    BackHandler(enabled = controls) { controls = false }
    BackHandler(enabled = liveBar) { liveBar = false }
    BackHandler(enabled = detail && vm.isLive) { detail = false }
    LaunchedEffect(detail, vm.playChId) {
        epgSel = 0
        if (detail && vm.isLive) vm.loadEpg(vm.playChId, 8)
    }
    LaunchedEffect(liveBar) {
        if (liveBar) {
            delay(150)
            runCatching { barFr.requestFocus() }
        } else {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(liveBar, ctrlTick) {
        if (liveBar) {
            delay(8_000)
            liveBar = false
        }
    }
    LaunchedEffect(vm.playChId, vm.playNonce) { liveBehind = 0L }
    // Lautstärke-Boost über den Audio-Effekt des Systems
    LaunchedEffect(audioSess, vm.boostDb) {
        runCatching { enh[0]?.release() }
        enh[0] = null
        if (vm.boostDb > 0 && audioSess != C.AUDIO_SESSION_ID_UNSET && audioSess != 0) {
            runCatching {
                val e = android.media.audiofx.LoudnessEnhancer(audioSess)
                e.setTargetGain(vm.boostDb * 100)
                e.setEnabled(true)
                enh[0] = e
            }
        }
    }
    DisposableEffect(Unit) { onDispose { runCatching { enh[0]?.release() } } }
    LaunchedEffect(controls) {
        if (controls) {
            delay(150)
            runCatching { if (creditsNow) nextFr.requestFocus() else ctrlFr.requestFocus() }
        } else {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    // Leiste blendet sich nach 7 Sekunden ohne Bedienung aus
    LaunchedEffect(controls, ctrlTick) {
        if (controls) {
            delay(7_000)
            controls = false
        }
    }
    LaunchedEffect(vm.playUrl) {
        if (vm.autoSkipIntro && vm.isEpisode && !vm.noIntro() && vm.playUrl != null && vm.resumePos() == 0L) {
            var waited = 0
            while (exo.playbackState != Player.STATE_READY && waited < 15_000) {
                delay(250)
                waited += 250
            }
            delay(1200)
            if (exo.currentPosition < 120_000) {
                exo.seekTo(vm.skipTarget(exo.currentPosition))
                skipped = true
            }
        }
    }
    LaunchedEffect(audioMenu) {
        if (!audioMenu) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.chanPanel) {
        if (!vm.chanPanel) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.playChId, vm.isLive) {
        while (vm.isLive) { vm.loadEpg(vm.playChId); delay(60_000) }
    }
    // Läuft ein Sender 40 Sekunden stabil, zählt das als gute Quelle
    LaunchedEffect(vm.playChId, vm.playNonce) {
        if (vm.isLive) {
            delay(40_000)
            if (exo.isPlaying) vm.markGood(vm.playChId)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
        }
    }
    LaunchedEffect(tick, vm.playTitle) { info = true; delay(vm.infoSeconds * 1000L); if (!detail) info = false }

    // Wächter: Bei Hängern im Live-TV neuen Link holen. Erkennt
    //  - Puffern oder Standbild der Position (> 8 s)
    //  - Stream-Ende (Server trennt, Token abgelaufen)
    //  - eingefrorenes Bild bei weiterlaufendem Ton (Decoder hängt, > 10 s)
    LaunchedEffect(Unit) {
        var stuck = 0
        var stalls = 0
        var lastPos = -1L
        var frozen = 0
        var lastFrames = -1
        while (true) {
            delay(2000)
            if (!vm.isLive || vm.loading) { stuck = 0; frozen = 0; lastFrames = -1; continue }
            val pos = exo.currentPosition
            val st = exo.playbackState
            val bad = exo.playWhenReady &&
                (st == Player.STATE_BUFFERING || st == Player.STATE_ENDED ||
                    (st == Player.STATE_READY && pos == lastPos))
            lastPos = pos
            // Bild eingefroren, Ton läuft weiter
            var videoFrozen = false
            if (!vm.fourKHelp && exo.isPlaying && exo.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) {
                val frames = exo.videoDecoderCounters?.let { it.ensureUpdated(); it.renderedOutputBufferCount } ?: -1
                if (frames >= 0 && frames == lastFrames) frozen++ else frozen = 0
                lastFrames = frames
                videoFrozen = frozen >= 5
            } else { frozen = 0; lastFrames = -1 }
            if (exo.isPlaying && !videoFrozen) stalls = 0
            if (bad) stuck++ else stuck = 0
            if (stuck >= 3 && vm.memoryTight()) {
                AppLog.add("Speicher knapp: Zwischenspeicher geleert")
                vm.trimMemory()
            }
            if (stuck >= 4 || videoFrozen) {
                AppLog.add(if (videoFrozen) "Bild eingefroren (Ton läuft): Decoder wird neu gestartet" else "Live-Stream hängt (" + st + "): neuer Link")
                stuck = 0; frozen = 0; lastFrames = -1
                stalls++
                // Decoder und Verbindung komplett freigeben, dann mit frischem Link neu starten
                // Nur bei eingefrorenem Bild den Decoder hart freigeben. Sonst bleibt das letzte Bild stehen, bis der neue Link läuft.
                runCatching { exo.stop(); exo.clearMediaItems() }
                vm.markBad(vm.playChId)
                if (stalls >= 6 && vm.tryAlternate()) stalls = 0 else vm.reload()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
        // Zurück lange halten = direkt zur Startseite
        if (e.key == Key.Back && e.nativeKeyEvent.repeatCount > 0) {
            vm.swallowBackAt = System.currentTimeMillis()
            if (vm.stack.size > 1) vm.goTo("home")
            return@onKeyEvent true
        }
        if (vm.chanPanel || audioMenu || controls || liveBar || xray) return@onKeyEvent false
        tick++
        val dg = digitOf(e.key)
        if (vm.isLive && dg >= 0) {
            vm.digit(dg)
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_LAST_CHANNEL) ||
                e.key == Key(android.view.KeyEvent.KEYCODE_PROG_RED))) {
            vm.toggleLast()
            return@onKeyEvent true
        }
        if (e.key == Key.MediaPlay) { exo.playWhenReady = true; return@onKeyEvent true }
        if (e.key == Key.MediaPause) { exo.playWhenReady = false; return@onKeyEvent true }
        if (vm.isLive && e.key == Key.MediaRewind) { liveSeek(-1); return@onKeyEvent true }
        if (vm.isLive && e.key == Key.MediaFastForward) { liveSeek(1); return@onKeyEvent true }
        // Farbtasten der Strong-Fernbedienung: Grün = Ton/Untertitel, Gelb/Info = Infos bzw. Bedienleiste, Blau/Guide = Senderliste
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_GREEN)) { audioMenu = true; return@onKeyEvent true }
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_YELLOW) || e.key == Key(android.view.KeyEvent.KEYCODE_INFO)) {
            if (vm.isLive) detail = !detail else controls = true
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_BLUE) || e.key == Key(android.view.KeyEvent.KEYCODE_GUIDE))) {
            vm.openChannelPanel()
            return@onKeyEvent true
        }
        // Mini-EPG: bei geöffneter Detail-Ansicht mit Links/Rechts Sendungen wählen, OK = Erinnerung
        if (vm.isLive && detail) {
            val up = vm.upcomingEpg(vm.playChId)
            when (e.key) {
                Key.DirectionLeft -> { epgSel = (epgSel - 1).coerceAtLeast(0); return@onKeyEvent true }
                Key.DirectionRight -> { epgSel = (epgSel + 1).coerceAtMost((up.size - 1).coerceAtLeast(0)); return@onKeyEvent true }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                    val prog = up.getOrNull(epgSel)
                    val ch = vm.currentChannel()
                    if (prog != null && ch != null && prog.startTs > System.currentTimeMillis() / 1000) vm.toggleReminder(ch, prog)
                    else detail = false
                    return@onKeyEvent true
                }
                else -> { }
            }
        }
        if (vm.numberBuffer.isNotEmpty() && (e.key == Key.DirectionCenter || e.key == Key.Enter)) {
            vm.commitNumber()
            return@onKeyEvent true
        }
        when (e.key) {
            Key.DirectionUp, Key.ChannelUp -> if (vm.isLive) { detail = false; vm.zap(1); true } else false
            Key.DirectionDown, Key.ChannelDown -> if (vm.isLive) { detail = false; vm.zap(-1); true } else false
            Key.DirectionLeft, Key.MediaRewind ->
                if (!vm.isLive) { stepSeek(-1); true } else { vm.openChannelPanel(); true }
            Key.DirectionRight, Key.MediaFastForward ->
                if (!vm.isLive) { stepSeek(1); true } else { audioMenu = true; true }
            Key.Menu -> if (vm.isLive) { vm.openChannelPanel(); true } else { audioMenu = true; true }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                if (vm.isLive) {
                    if (e.key == Key.MediaPlayPause) exo.playWhenReady = !exo.playWhenReady
                    else if (!exo.playWhenReady) exo.playWhenReady = true
                    else if (liveBehind > 2_000L) goLive()
                    else liveBar = true
                }
                else if (e.key == Key.MediaPlayPause) exo.playWhenReady = !exo.playWhenReady
                else controls = true
                true
            }
            else -> false
        }
    }) {
        AndroidView(factory = { c ->
            PlayerView(c).apply {
                useController = false
                isFocusable = false
                isFocusableInTouchMode = false
                keepScreenOn = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = exo
            }
        }, modifier = Modifier.fillMaxSize(), update = { v ->
            v.resizeMode = when (vm.picMode) {
                1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        })
        if (vm.isLive && (livePaused || liveBehind > 2_000L) && !vm.chanPanel && !audioMenu) {
            Text(
                if (livePaused) "⏸  Live pausiert  (+" + liveBehind / 1000 + " s)  ·  OK = weiter"
                else "⏪  " + liveBehind / 1000 + " s hinter Live  ·  OK = zurück zu Live",
                fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 28.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 10.dp))
        }
        if ((info || detail) && !vm.chanPanel && !controls) InfoPanel(vm, detail, posMs, durMs, qualityText, Modifier.align(Alignment.BottomCenter), epgSel)
        if (liveBar && vm.isLive && !vm.chanPanel && !audioMenu) {
            LiveBar(vm, exo, barFr, Modifier.align(Alignment.BottomCenter),
                onTick = { ctrlTick++ },
                onAudio = { liveBar = false; audioMenu = true },
                onInfo = { liveBar = false; detail = true })
        }
        if (controls && !vm.isLive && !vm.chanPanel && !audioMenu) {
            PlayerControls(exo, posMs, durMs, showSkip, ctrlFr, Modifier.align(Alignment.BottomCenter), nextLbl, nextFr, { vm.playNext() },
                onTick = { ctrlTick++ },
                onSkipIntro = {
                    exo.seekTo(vm.skipTarget(exo.currentPosition))
                    skipped = true
                    controls = false
                },
                onNoIntro = { vm.setNoIntro(); controls = false },
                onXray = { exo.playWhenReady = false; xray = true; controls = false })
        }
        if (xray && !vm.isLive) XRayPanel(vm, Modifier.align(Alignment.BottomCenter)) { closeXray() }
        if (vm.chanPanel) ChannelPanel(vm, Modifier.align(Alignment.CenterStart))
        if (audioMenu) AudioMenu(exo, vm, infoOn, { infoOn = !infoOn }) { audioMenu = false }
        if (infoOn) StreamInfo(vm, exo, qualityText, Modifier.align(Alignment.TopStart))
        if (weakNow && vm.netMode == "auto") {
            if (weakBanner) {
                Text("📶 Schwaches Netz – sparsamer Modus", fontSize = 13.sp, color = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(24.dp)
                        .background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 6.dp))
            } else {
                Text("📶", fontSize = 14.sp, modifier = Modifier.align(Alignment.TopEnd).padding(24.dp).alpha(0.7f))
            }
        }
        if (vm.numberBuffer.isNotEmpty()) {
            Text(vm.numberBuffer, fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(32.dp)
                    .background(Color(0x99000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 8.dp))
        }
        vm.upNext?.let { nxt ->
            Text("Nächste Folge in 5 s:  $nxt     (Zurück = abbrechen)", fontSize = 16.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
        if (creditsNow && !vm.chanPanel && !audioMenu && !controls && vm.upNext == null) {
            Text("⏭  Nächste Folge:  $nextLbl   (OK drücken)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 48.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
        if (showSkip && hintOn && !vm.chanPanel && !audioMenu && !controls && vm.upNext == null) {
            Text("⏭  Intro überspringen  (OK drücken, dann Intro)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 120.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
    }
}

/** Schnell-Leiste im Live-TV: erscheint mit OK, alles per Pfeiltasten und OK bedienbar. */
@Composable
fun LiveBar(
    vm: AppVM, exo: ExoPlayer, firstFr: FocusRequester, modifier: Modifier,
    onTick: () -> Unit, onAudio: () -> Unit, onInfo: () -> Unit
) {
    val gray = LocalMuted.current
    var paused by remember { mutableStateOf(!exo.playWhenReady) }
    Column(modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(18.dp)
        .onPreviewKeyEvent { if (it.type == KeyEventType.KeyDown) onTick(); false }) {
        Text(vm.playTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.toggleCurrentFav(); onTick() }, modifier = Modifier.focusRequester(firstFr).tvFocus()) {
                Text(if (vm.isCurrentFav()) "★ Favorit" else "☆ Favorit")
            }
            OutlinedButton(onClick = onAudio, modifier = Modifier.tvFocus()) { Text("🔊 Ton & Untertitel") }
            OutlinedButton(onClick = {
                exo.playWhenReady = !exo.playWhenReady
                paused = !exo.playWhenReady
                onTick()
            }, modifier = Modifier.tvFocus()) { Text(if (paused) "▶ Weiter" else "⏸ Pause") }
            OutlinedButton(onClick = { vm.toggleLast() }, modifier = Modifier.tvFocus()) { Text("↩ Letzter Sender") }
            OutlinedButton(onClick = onInfo, modifier = Modifier.tvFocus()) { Text("ℹ Info") }
            OutlinedButton(onClick = { vm.cyclePic(); onTick() }, modifier = Modifier.tvFocus()) { Text("🖼 " + vm.picLabel().substringBefore(" (")) }
            OutlinedButton(onClick = { vm.cycleSleep(); onTick() }, modifier = Modifier.tvFocus()) {
                Text("⏾ " + (if (vm.sleepMinutes == 0) "Sleep aus" else vm.sleepMinutes.toString() + " Min."))
            }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
        Text("Zurück schließt die Leiste.", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
    }
}

/** X-Ray: zeigt beim angehaltenen Film die Besetzung (aus TMDB). */
@Composable
fun XRayPanel(vm: AppVM, modifier: Modifier, onClose: () -> Unit) {
    val gray = LocalMuted.current
    val target = remember { vm.xrayTarget() }
    val fr = remember { FocusRequester() }
    val cast by produceState<List<Tmdb.Person>?>(null, target.first) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            if (vm.tmdbKey.isBlank()) emptyList()
            else {
                val info = Tmdb.lookup(vm.tmdbKey, target.first, "", target.second)
                if (info == null || info.id <= 0) emptyList()
                else Tmdb.extras(vm.tmdbKey, info.id, target.second)?.cast ?: emptyList()
            }
        }
    }
    LaunchedEffect(cast) { if (!cast.isNullOrEmpty()) { delay(150); runCatching { fr.requestFocus() } } }
    Column(modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("X-RAY", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(target.first, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("Zurück = weiter ansehen", fontSize = 12.sp, color = gray)
        }
        val l = cast
        when {
            l == null -> Text("Besetzung wird geladen …", color = gray, modifier = Modifier.padding(vertical = 14.dp))
            l.isEmpty() -> Text(if (vm.tmdbKey.isBlank()) "Kein TMDB-Schlüssel eingetragen." else "Zu diesem Titel gibt es keine Besetzungsdaten.",
                color = gray, modifier = Modifier.padding(vertical = 14.dp))
            else -> LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(l) { i, p -> CastChip(p, if (i == 0) Modifier.focusRequester(fr) else Modifier) }
            }
        }
    }
}

/** Bedienleiste für Filme und Serien: erscheint mit OK. */
@Composable
fun PlayerControls(
    exo: ExoPlayer, pos: Long, dur: Long, canSkip: Boolean, playFr: FocusRequester, modifier: Modifier,
    nextLabel: String?, nextFr: FocusRequester, onNext: () -> Unit,
    onTick: () -> Unit, onSkipIntro: () -> Unit, onXray: (() -> Unit)? = null, onNoIntro: (() -> Unit)? = null
) {
    var playing by remember { mutableStateOf(exo.playWhenReady) }
    LaunchedEffect(Unit) {
        while (true) {
            playing = exo.playWhenReady
            delay(300)
        }
    }
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    fun seekBy(delta: Long) {
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, max))
        onTick()
    }
    Column(modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(20.dp)
        .onPreviewKeyEvent { if (it.type == KeyEventType.KeyDown) onTick(); false }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(pos), fontSize = 14.sp, color = Color.White)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
            }
            Spacer(Modifier.width(12.dp))
            Text(if (dur > 0) fmtTime(dur) else "--:--", fontSize = 14.sp, color = gray)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { seekBy(-60_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 60 s") }
            OutlinedButton(onClick = { seekBy(-10_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 10 s") }
            Button(onClick = {
                exo.playWhenReady = !exo.playWhenReady
                playing = exo.playWhenReady
                onTick()
            }, modifier = Modifier.focusRequester(playFr).tvFocus()) {
                Text(if (playing) "⏸  Pause" else "▶  Weiter", fontSize = 18.sp)
            }
            OutlinedButton(onClick = { seekBy(10_000) }, modifier = Modifier.tvFocus()) { Text("10 s ⏩") }
            OutlinedButton(onClick = { seekBy(60_000) }, modifier = Modifier.tvFocus()) { Text("60 s ⏩") }
            if (nextLabel != null) {
                Button(onClick = onNext, modifier = Modifier.focusRequester(nextFr).tvFocus()) { Text("⏭ Nächste Folge") }
            }
            if (canSkip) {
                OutlinedButton(onClick = onSkipIntro, modifier = Modifier.tvFocus()) { Text("⏭ Intro") }
                if (onNoIntro != null) {
                    OutlinedButton(onClick = onNoIntro, modifier = Modifier.tvFocus()) { Text("🚫 Kein Intro") }
                }
            }
            if (onXray != null) {
                OutlinedButton(onClick = onXray, modifier = Modifier.tvFocus()) { Text("🎭 X-Ray") }
            }
        }
        Text("Zurück schließt die Leiste.", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun InfoPanel(vm: AppVM, detail: Boolean, pos: Long, dur: Long, quality: String, modifier: Modifier, sel: Int = 0) {
    val gray = Color(0xFFB0BAC4)
    val list = vm.epgList(vm.playChId)
    val now = if (vm.isLive) vm.currentEpg(vm.playChId) else null
    Box(modifier.fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
        .padding(start = 32.dp, end = 32.dp, top = 56.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            vm.playLogo?.let { logo ->
                AsyncImage(model = logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(10.dp))
                Spacer(Modifier.width(18.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(vm.playTitle, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (quality.isNotEmpty()) {
                    Text(quality, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
                if (vm.isLive) {
                    if (now != null) {
                        Text("${now.start}–${now.end}  ${now.title}", fontSize = 18.sp, color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        vm.epgProgress(now)?.let { p ->
                            LinearProgressIndicator(progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                        }
                        if (detail) {
                            val up = vm.upcomingEpg(vm.playChId)
                            val s = sel.coerceIn(0, (up.size - 1).coerceAtLeast(0))
                            up.forEachIndexed { i, e ->
                                val bell = if (vm.isReminder(vm.playChId, e.startTs)) "🔔 " else ""
                                Text((if (i == s) "▶ " else "    ") + bell + e.start + (if (i == 0) "  jetzt  " else "  ") + e.title,
                                    fontSize = 15.sp, color = if (i == s) Color.White else gray,
                                    fontWeight = if (i == s) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            up.getOrNull(s)?.descr?.takeIf { it.isNotBlank() }?.let { d ->
                                Text(d, fontSize = 14.sp, color = gray, maxLines = 4, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 6.dp))
                            }
                        } else {
                            list.dropWhile { it != now }.drop(1).take(1).forEach { n ->
                                Text("${n.start}  ${n.title}", fontSize = 15.sp, color = gray, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        Text("Keine Programminfo", fontSize = 14.sp, color = gray)
                    }
                    Text(if (detail) "◀ ▶ Sendung wählen   ·   OK = Erinnerung   ·   Zurück = schließen"
                        else "▲▼ Sender   ·   ◀ Senderliste   ·   ▶ Ton & Untertitel   ·   OK Schnell-Menü",
                        fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                } else if (dur > 0) {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                    Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 14.sp, color = gray)
                }
            }
        }
    }
}

@Composable
fun GuideScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val hours = 6
    val dpPerMin = 4
    val nameW = 150.dp
    val totalW = nameW + (hours * 60 * dpPerMin).dp
    val hScroll = rememberScrollState()
    val startSec = remember { (System.currentTimeMillis() / 1000 / 1800) * 1800 - 1800 }
    val timeFmt = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("EPG  ·  PROGRAMMÜBERSICHT   (OK auf kommende Sendung = 🔔 Erinnerung)", fontSize = 14.sp, letterSpacing = 3.sp, color = accent,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
        Box(Modifier.weight(1f).fillMaxWidth().glass(18.dp)) {
            Column(Modifier.fillMaxHeight().horizontalScroll(hScroll)) {
                Box(Modifier.width(totalW).height(30.dp)) {
                    for (i in 0..(hours * 2)) {
                        Text(timeFmt.format(java.util.Date((startSec + i * 1800L) * 1000)), fontSize = 11.sp, color = gray,
                            modifier = Modifier.offset(x = nameW + (i * 30 * dpPerMin).dp, y = 8.dp))
                    }
                }
                LazyColumn(Modifier.width(totalW).weight(1f)) {
                    items(vm.items, key = { it.id }) { ch -> GuideRow(vm, ch, startSec, hours, dpPerMin, nameW, hScroll) }
                }
            }
        }
    }
}

@Composable
fun GuideRow(vm: AppVM, ch: Item, startSec: Long, hours: Int, dpPerMin: Int, nameW: Dp, hScroll: ScrollState) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id, 12) }
    val list = vm.epgList(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val light = LocalLight.current
    val nowSec = System.currentTimeMillis() / 1000
    val endSec = startSec + hours * 3600L
    Box(Modifier.width(nameW + (hours * 60 * dpPerMin).dp).height(64.dp).padding(vertical = 3.dp)) {
        for (e in list) {
            if (e.startTs <= 0 || e.stopTs <= e.startTs) continue
            val s0 = maxOf(e.startTs, startSec)
            val s1 = minOf(e.stopTs, endSec)
            if (s1 <= s0) continue
            val left = nameW + (((s0 - startSec) / 60f) * dpPerMin).dp
            val w = maxOf((((s1 - s0) / 60f) * dpPerMin).dp - 3.dp, 10.dp)
            val isNow = nowSec in e.startTs until e.stopTs
            Text((if (vm.isReminder(ch.id, e.startTs)) "🔔 " else "") + e.start + "  " + e.title, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.offset(x = left).width(w).fillMaxHeight().tvFocus(1.02f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isNow) accent.copy(alpha = 0.35f) else if (light) Color(0x14000000) else Color(0x1FFFFFFF))
                    .clickable {
                        if (e.startTs > System.currentTimeMillis() / 1000) vm.toggleReminder(ch, e) else vm.openItem(ch)
                    }.padding(8.dp))
        }
        if (list.isEmpty()) {
            Text("Keine Programminfo", fontSize = 12.sp, color = gray,
                modifier = Modifier.align(Alignment.CenterStart).offset(x = nameW + 8.dp))
        }
        // Sendername bleibt beim seitlichen Scrollen links stehen
        Row(Modifier.offset { IntOffset(hScroll.value, 0) }.width(nameW).fillMaxHeight()
            .background(if (light) Color(0xFFEAECF2) else Color(0xFF101018))
            .tvFocus(1.02f).clickable { vm.openItem(ch) }.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
            Spacer(Modifier.width(8.dp))
            Text(ch.name, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun EditCatsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var kw by remember { mutableStateOf("DE, German, Deutsch") }
    val groups = vm.portalGroups
    var byPortal by remember { mutableStateOf(groups.size > 1) }
    var openG by remember { mutableStateOf(setOf<String>()) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kategorien auswählen", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.allCats.count { it.id !in vm.hiddenCats }} von ${vm.allCats.size} sichtbar",
            fontSize = 13.sp, color = gray)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = kw, onValueChange = { kw = it }, singleLine = true,
                label = { Text("Suchbegriffe, z. B. DE, German") }, modifier = Modifier.weight(1f).tvFocus())
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.showOnlyMatching(kw) }, modifier = Modifier.tvFocus()) { Text("Nur passende") }
        }
        val countries = vm.countryGroups()
        if (countries.isNotEmpty()) {
            Text("LÄNDER (erkannt am Anfang des Namens, OK = ein/aus)", fontSize = 11.sp, letterSpacing = 2.sp, color = gray)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                countries.forEach { (code, n) ->
                    val st = vm.countryState(code)
                    OutlinedButton(onClick = { vm.toggleCountry(code) }, modifier = Modifier.tvFocus()) {
                        Text((if (st == 2) "✓ " else if (st == 0) "✗ " else "◐ ") + code + " (" + n + ")")
                    }
                }
            }
        }
        Row(Modifier.padding(bottom = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (groups.size > 1) {
                OutlinedButton(onClick = { byPortal = !byPortal }, modifier = Modifier.tvFocus()) {
                    Text(if (byPortal) "Ansicht: nach Portal  ⟳" else "Ansicht: eine Liste  ⟳")
                }
            }
            OutlinedButton(onClick = { vm.setAllCats(true) }, modifier = Modifier.tvFocus()) { Text("Alle anzeigen") }
            OutlinedButton(onClick = { vm.setAllCats(false) }, modifier = Modifier.tvFocus()) { Text("Alle ausblenden") }
            OutlinedButton(onClick = { vm.sortCats("de") }, modifier = Modifier.tvFocus()) { Text("DE/AT/CH zuerst") }
            OutlinedButton(onClick = { vm.sortCats("az") }, modifier = Modifier.tvFocus()) { Text("A–Z") }
            OutlinedButton(onClick = { vm.sortCats("provider") }, modifier = Modifier.tvFocus()) { Text("Reihenfolge des Anbieters") }
        }
        if (!(byPortal && groups.size > 1)) {
            LazyColumn(Modifier.weight(1f)) {
                items(vm.orderCats(vm.allCats), key = { it.id }) { c ->
                    val on = c.id !in vm.hiddenCats
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text((if (on) "✓  " else "✗  ") + c.title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                            modifier = Modifier.weight(1f).tvFocus().clickable { vm.toggleCat(c.id) }.padding(12.dp))
                        OutlinedButton(onClick = { vm.moveCat(c.id, -1) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("▲") }
                        OutlinedButton(onClick = { vm.moveCat(c.id, 1) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("▼") }
                    }
                }
            }
        } else {
            Text("Gleichnamige Kategorien gelten für alle Portale. OK klappt ein Portal auf oder zu.",
                fontSize = 11.sp, color = gray, modifier = Modifier.padding(bottom = 4.dp))
            LazyColumn(Modifier.weight(1f)) {
                for (g in groups) {
                    val isOpen = g.pfx in openG
                    val vis = g.cats.count { it.id !in vm.hiddenCats }
                    item(key = "g:" + g.pfx) {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((if (isOpen) "▾  " else "▸  ") + g.name + "   (" + vis + " von " + g.cats.size + " sichtbar)",
                                fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f).tvFocus().clickable {
                                    openG = if (isOpen) openG - g.pfx else openG + g.pfx
                                }.padding(12.dp))
                            OutlinedButton(onClick = { vm.setCats(g.cats.map { it.id }, true) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("Alle ein") }
                            OutlinedButton(onClick = { vm.setCats(g.cats.map { it.id }, false) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("Alle aus") }
                        }
                    }
                    if (isOpen) {
                        items(vm.orderCats(g.cats), key = { g.pfx + ":" + it.id }) { c ->
                            val on = c.id !in vm.hiddenCats
                            Text((if (on) "✓  " else "✗  ") + c.title, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                                modifier = Modifier.fillMaxWidth().padding(start = 22.dp).tvFocus().clickable { vm.toggleCat(c.id) }.padding(10.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditChansScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var filter by remember { mutableStateOf("") }
    val shown = vm.editChans.filter { filter.isBlank() || it.name.contains(filter.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kanäle ein-/ausblenden", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.editChans.count { it.id !in vm.hiddenChans }} von ${vm.editChans.size} sichtbar",
            fontSize = 13.sp, color = gray)
        OutlinedTextField(value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Filter nach Name") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).tvFocus())
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, true) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte ausblenden")
            }
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, false) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte einblenden")
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { ch ->
                val on = ch.id !in vm.hiddenChans
                Text((if (on) "✓  " else "✗  ") + ch.name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleChan(ch.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, item: Item) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    val isSeries = vm.browseType == "series"
    LaunchedEffect(item.id) { vm.loadSimilar(item) }
    val res = remember(item) { vm.resumeFor(item) }
    val tm by produceState<Tmdb.Info?>(null, item.id, vm.tmdbKey) {
        value = if (vm.tmdbKey.isBlank()) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Tmdb.lookup(vm.tmdbKey, item.name, item.year, isSeries) }
    }
    val ctx = LocalContext.current
    val tmId = tm?.id ?: 0
    val ex by produceState<Tmdb.Extras?>(null, tmId) {
        value = if (tmId <= 0) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Tmdb.extras(vm.tmdbKey, tmId, isSeries) }
    }
    val posterUrl = item.logo?.takeIf { it.isNotBlank() } ?: tm?.poster
    val backUrl = item.backdrop ?: tm?.backdrop
    LaunchedEffect(posterUrl) { vm.focusAmbient(posterUrl) }
    val descrText = if (item.descr.isNotBlank()) item.descr else (tm?.overview ?: "")
    val ratingText = if (tm != null && tm!!.rating.isNotBlank() && !item.meta.contains("Bewertung")) "Bewertung: " + tm!!.rating else ""
    Box(Modifier.fillMaxSize()) {
        AsyncImage(model = backUrl ?: posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (backUrl != null) 0.4f else 0.22f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0A0A0F), Color(0xCC0A0A0F), Color(0x330A0A0F)))))
        Row(Modifier.fillMaxSize().padding(40.dp)) {
            AsyncImage(model = posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(240.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(16.dp)))
            Spacer(Modifier.width(32.dp))
            Column(Modifier.weight(1f).fillMaxHeight().glass(24.dp).verticalScroll(rememberScrollState()).padding(24.dp)) {
                Text(if (isSeries) "SERIE" else "FILM", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                Text(item.name, fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (item.year.isNotBlank()) Text(item.year, fontSize = 16.sp, color = gray)
                    QualityBadges(item.name, Modifier)
                }
                Box(Modifier.padding(top = 12.dp).width(64.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.height(16.dp))
                Text(if (descrText.isNotBlank()) descrText else "Keine Beschreibung vorhanden.", fontSize = 16.sp,
                    color = if (descrText.isNotBlank()) MaterialTheme.colorScheme.onSurface else gray)
                val metaText = listOf(item.meta, ratingText).filter { it.isNotBlank() }.joinToString("\n")
                if (metaText.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(metaText, fontSize = 14.sp, color = gray)
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (res != null) {
                        Button(onClick = { vm.playResume(res) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("▶ Weiter bei " + fmtTime(res.pos) +
                                (if (isSeries) "  ·  " + res.title.substringAfter(" – ") else ""), fontSize = 18.sp)
                        }
                    }
                    Button(onClick = { if (res != null && !isSeries) vm.startFresh(item) else vm.startItem(item) },
                        modifier = (if (res == null) Modifier.focusRequester(fr) else Modifier).tvFocus()) {
                        Text(if (isSeries) "Staffeln ansehen" else if (res != null) "↺ Von vorne" else "▶ Abspielen", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleFav(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isFav(item)) "★ Favorit entfernen" else "☆ Zu Favoriten", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatch(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isWatch(item)) "✓ In Merkliste" else "＋ Merkliste", fontSize = 18.sp)
                    }
                }
                if (!isSeries) {
                    OutlinedButton(onClick = { vm.toggleMovieSeen(item) }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                        Text(if (vm.isMovieSeen(item)) "✓ Gesehen (antippen zum Entfernen)" else "○ Als gesehen markieren", fontSize = 16.sp)
                    }
                }
                if (vm.tmdbKey.isBlank()) {
                    Text("Besetzung: TMDB-Schlüssel in den Einstellungen eintragen.", fontSize = 12.sp, color = gray,
                        modifier = Modifier.padding(top = 10.dp))
                } else if (tm == null) {
                    Text("Besetzung: kein TMDB-Treffer für diesen Titel.", fontSize = 12.sp, color = gray,
                        modifier = Modifier.padding(top = 10.dp))
                }
                ex?.cast?.takeIf { it.isNotEmpty() }?.let { cast ->
                    Spacer(Modifier.height(24.dp))
                    Text("BESETZUNG", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                    LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(cast) { p -> CastChip(p) }
                    }
                }
                if (vm.similar.isNotEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("ÄHNLICHE TITEL", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                    LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(vm.similar) { m -> MiniPoster(m) { vm.openHomeItem(m, vm.browseType) } }
                    }
                }
            }
        }
    }
}

/** Kurzer Vorspann: Logo blendet ein, Goldlinie zieht auf. Beliebige Taste oder Tippen überspringt ihn. */
@Composable
fun ClassicIntro(sound: Boolean, onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    val ctx = LocalContext.current
    val mp = remember { arrayOfNulls<android.media.MediaPlayer>(1) }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    // Startton: kurzer, weicher Klang zum Einblenden des Logos
    LaunchedEffect(Unit) {
        if (sound) {
            runCatching {
                val p = android.media.MediaPlayer.create(ctx, R.raw.intro_boom)
                p?.setOnCompletionListener { it.release() }
                p?.start()
                mp[0] = p
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose { runCatching { mp[0]?.release() }; mp[0] = null }
    }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(900))
        line.animateTo(1f, tween(700))
        delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { onDone(); true } else false }
            .clickable { onDone() },
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(fade.value).graphicsLayer { scaleX = 0.92f + 0.08f * fade.value; scaleY = 0.92f + 0.08f * fade.value },
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎬", fontSize = 56.sp)
            Spacer(Modifier.height(12.dp))
            Text("TOM’S TV", fontSize = 48.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                letterSpacing = 10.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.width((240 * line.value).dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 13.sp, letterSpacing = 5.sp, color = LocalMuted.current)
        }
    }
}

/** Vorspann: Premium mit Kino-Boom, sonst klassisch. */
@Composable
fun IntroScreen(premium: Boolean, sound: Boolean, simple: Boolean, onDone: () -> Unit) {
    if (simple) ClassicIntro(sound, onDone)
    else PremiumIntro(sound, if (premium) Palette.CINEMA_RED else MaterialTheme.colorScheme.primary, onDone)
}

/** Kino-Intro: Sternenflug in den Titel – die Sterne bremsen ab, das Logo fliegt aus der Tiefe heran und glüht. */
@Composable
fun PremiumIntro(sound: Boolean, tint: Color, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val clock = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    var finished by remember { mutableStateOf(false) }
    val finish = { if (!finished) { finished = true; onDone() } }
    val mp = remember { arrayOfNulls<android.media.MediaPlayer>(1) }
    DisposableEffect(Unit) { onDispose { runCatching { mp[0]?.release() }; mp[0] = null } }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    // Der Schlag im Sound sitzt etwa 0,3 s nach dem Start: so landet er genau beim Aufblitzen des Logos
    LaunchedEffect(Unit) {
        if (sound) {
            delay(1230)
            runCatching {
                val p = android.media.MediaPlayer.create(ctx, R.raw.intro_boom)
                p?.setOnCompletionListener { it.release() }
                p?.start()
                mp[0] = p
            }
        }
    }
    LaunchedEffect(Unit) {
        clock.animateTo(3f, tween(3000, easing = androidx.compose.animation.core.LinearEasing))
        finish()
    }
    // Sterne: Winkel, Abstand, Tiefe, Farbwahl (einmal erzeugt)
    val stars = remember {
        val r = java.util.Random(11)
        List(150) { floatArrayOf(r.nextFloat() * 6.2832f, 0.05f + r.nextFloat() * 1.1f, r.nextFloat(), r.nextFloat()) }
    }
    val t = clock.value
    fun cl(x: Float) = x.coerceIn(0f, 1f)
    fun eo(x: Float): Float { val u = 1f - cl(x); return 1f - u * u * u }
    fun prog(tt: Float): Float { val u = cl(tt / 1.7f); return 3.4f * (1f - Math.pow((1f - u).toDouble(), 2.2).toFloat()) }
    val out = 1f - cl((t - 2.6f) / 0.4f)
    val la = eo((t - 1.0f) / 0.7f)
    val sweep = -0.25f + 1.5f * cl((t - 1.5f) / 0.9f)
    val flash = cl(1f - kotlin.math.abs(t - 1.55f) / 0.1f) * 0.35f
    Box(
        Modifier.fillMaxSize().background(Color(0xFF04040A)).focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { finish(); true } else false }
            .clickable { finish() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val k = w / 1280f
            drawRect(Brush.radialGradient(listOf(Color(0xFF4628A0).copy(alpha = 0.35f * cl(t / 1.2f)), Color.Transparent),
                center = Offset(cx, cy), radius = w * 0.5f))
            drawRect(Brush.radialGradient(listOf(tint.copy(alpha = 0.22f * cl((t - 1f) / 0.6f)), Color.Transparent),
                center = Offset(cx, cy * 1.1f), radius = w * 0.3f))
            val p1 = prog(t); val p0 = prog(t - 0.04f)
            for (st in stars) {
                val z1 = (((st[2] - p1) % 1f) + 1f) % 1f + 0.02f
                val z0 = (((st[2] - p0) % 1f) + 1f) % 1f + 0.02f
                val rr = st[1] * 900f * k
                val ca = kotlin.math.cos(st[0]); val sa = kotlin.math.sin(st[0])
                val x1 = cx + ca * rr / (z1 * 3f); val y1 = cy + sa * rr / (z1 * 3f)
                val wrapped = kotlin.math.abs(z1 - z0) > 0.3f
                val x0 = if (wrapped) x1 else cx + ca * rr / (z0 * 3f)
                val y0 = if (wrapped) y1 else cy + sa * rr / (z0 * 3f)
                val al = (cl(1.1f - z1) * out * (0.35f + 0.65f * st[3])).coerceIn(0f, 1f)
                val col = when {
                    st[3] > 0.6f -> Color(0xFF78DCFF)
                    st[3] > 0.3f -> Color(0xFFBE96FF)
                    else -> Color.White
                }
                drawLine(col.copy(alpha = al), Offset(x0, y0), Offset(x1, y1), strokeWidth = (0.8f + 1.6f * (1f - z1)) * k.coerceAtLeast(1f))
            }
        }
        Column(
            Modifier.graphicsLayer {
                val sc = 0.56f + 0.44f * la
                scaleX = sc; scaleY = sc; alpha = la * out
            },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val red = tint
            val light = Color(0xFFFFD6D6)
            val stops = arrayOf(0f to red, cl(sweep - 0.15f) to red, cl(sweep) to light, cl(sweep + 0.15f) to red, 1f to red)
            Text("TOM’S TV", fontSize = 64.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.SansSerif,
                letterSpacing = (26f - 22f * la).sp,
                style = androidx.compose.ui.text.TextStyle(
                    brush = Brush.horizontalGradient(*stops, startX = 0f, endX = 700f),
                    shadow = androidx.compose.ui.graphics.Shadow(tint.copy(alpha = 0.8f * la), Offset.Zero, 12f + 40f * la)))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.width((340 * eo((t - 1.6f) / 0.6f)).dp).height(3.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFF22D3EE), Color.White, Color(0xFFA855F7), Color.Transparent))))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 12.sp, letterSpacing = 6.sp, color = Color(0xFFB4BCCD),
                modifier = Modifier.alpha(eo((t - 1.9f) / 0.4f)))
        }
        if (flash > 0.01f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flash)))
    }
}

@Composable
fun Clock() {
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        while (true) {
            time = f.format(java.util.Date())
            delay(20_000)
        }
    }
    Text(time, fontSize = 14.sp, color = LocalMuted.current)
}

/** Merkt sich den Fokus in den linken Seiten und stellt ihn nach dem Zurückkehren wieder her. */
fun Modifier.leftFocus(vm: AppVM, key: String): Modifier = composed {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (vm.leftFocus == key) { delay(150); runCatching { fr.requestFocus() } }
    }
    this.focusRequester(fr).onFocusChanged { if (it.hasFocus) vm.leftFocus = key }
}

@Composable
fun Shell(vm: AppVM, current: String, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Sidebar(vm, current)
        Box(Modifier.weight(1f).fillMaxHeight()) { content() }
    }
}

@Composable
fun Sidebar(vm: AppVM, current: String) {
    val neon = LocalNeon.current
    val amb = LocalAmbient.current
    val accent = if (neon) amb else MaterialTheme.colorScheme.primary
    val compact = when (vm.sidebarMode) {
        "compact" -> true
        "normal" -> false
        else -> LocalConfiguration.current.screenHeightDp < 480
    }
    val widthAnim by animateDpAsState(if (compact) 76.dp else 224.dp, label = "sidebarWidth")
    val width = if (LocalPerf.current) (if (compact) 76.dp else 224.dp) else widthAnim
    val menu = listOf(
        Triple("home", "home", "Startseite"), Triple("itv", "tv", "Live TV"), Triple("vod", "film", "Filme"),
        Triple("series", "popcorn", "Serien"), Triple("resume", "resume", "Weiterschauen"), Triple("watch", "bookmark", "Merkliste"),
        Triple("epg", "calendar", "EPG"), Triple("portals", "ticket", "Portale"), Triple("settings", "gear", "Einstellungen")
    )
    val premium = LocalPremium.current
    Column(Modifier.width(width).fillMaxHeight()
        .then(if (premium) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF000000), Color(0xE6050505))))
                .padding(horizontal = 8.dp, vertical = 16.dp)
              else Modifier.padding(10.dp).glass(22.dp).padding(horizontal = 8.dp, vertical = 10.dp))) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start) {
            if (!compact) {
                Text("TOM’S TV", fontSize = if (premium) 20.sp else 17.sp,
                    fontWeight = if (premium) FontWeight.Black else FontWeight.Bold, fontFamily = titleFont,
                    color = if (premium) Palette.CINEMA_RED else Color.Unspecified,
                    letterSpacing = if (premium) 2.sp else 3.sp, modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (compact) "▶" else "◀", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.setSidebar(if (compact) "normal" else "compact") }
                    .padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(vm.navScroll)) {
            menu.forEach { (id, emoji, label) ->
                val sel = id == current
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).leftFocus(vm, "nav:" + id).tvFocus(1.02f).clip(RoundedCornerShape(14.dp))
                    .then(if (sel && premium) Modifier.background(Color(0x22FFFFFF)).drawBehind {
                              drawRect(accent, size = androidx.compose.ui.geometry.Size(4.dp.toPx(), size.height))
                          }
                          else if (sel && neon) Modifier.background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.85f), shiftHue(accent, 45f).copy(alpha = 0.45f))))
                              .border(1.dp, Color(0x59FFFFFF), RoundedCornerShape(14.dp))
                          else if (sel) Modifier.background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.55f))))
                          else Modifier)
                    .clickable { vm.goTo(id) }
                    .padding(horizontal = if (compact) 0.dp else 12.dp, vertical = if (compact) 11.dp else 10.dp),
                    horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(emoji, if (compact) 30.dp else 26.dp)
                    if (!compact) {
                        Spacer(Modifier.width(10.dp))
                        Text(label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel && premium) Color.White else if (sel && neon) Color.White else if (sel) MaterialTheme.colorScheme.onPrimary
                                    else if (premium) Color(0xFFB3B3B3) else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 22.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (!LocalPremium.current) {
            Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(accent))
            Spacer(Modifier.width(10.dp))
        }
        Text(title, fontSize = if (LocalPremium.current) 20.sp else 18.sp,
            fontWeight = if (LocalPremium.current) FontWeight.ExtraBold else FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text("$action  ›", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.tvFocus(1.05f).clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction)
                    .padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

/** Wer schaut? – Auswahl beim Start (nur bei mehreren Profilen). */
@Composable
fun ProfilePicker(vm: AppVM) {
    val fr = remember { FocusRequester() }
    BackHandler { vm.profilePicked = true }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Wer schaut?", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, fontFamily = titleFont)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
            vm.profiles.forEach { p ->
                val cur = p.id == vm.profileId
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.then(if (cur) Modifier.focusRequester(fr) else Modifier)
                        .tvFocus(1.08f).clip(CircleShape)
                        .clickable { vm.switchProfile(p.id); vm.profilePicked = true }.padding(6.dp)) {
                        Avatar(p.avatar, 110.dp, initialOf(p.name))
                    }
                    Text(p.name, fontSize = 18.sp, fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(top = 8.dp), maxLines = 1)
                }
            }
        }
    }
}

/** Große Kacheln mit Farbverlauf für die Hauptbereiche (Blau-Design). */
@Composable
fun BrandTiles(vm: AppVM) {
    val tiles = listOf(
        Triple("Live TV", "tv", listOf(Color(0xFF1E3FB5), Color(0xFF0B1A5E))) to "itv",
        Triple("Filme", "film", listOf(Color(0xFF7B2FBE), Color(0xFF2A0F5E))) to "vod",
        Triple("Serien", "popcorn", listOf(Color(0xFF0E8FA8), Color(0xFF07325A))) to "series",
        Triple("Merkliste", "bookmark", listOf(Color(0xFFC2336B), Color(0xFF521233))) to "watch",
        Triple("EPG", "calendar", listOf(Color(0xFF1E8E5A), Color(0xFF0A3A2C))) to "epg"
    )
    val perf = LocalPerf.current
    val src = vm.homeNew.ifEmpty { vm.homeCached }
    val imgs = listOf(vm.recentChans.firstOrNull()?.logo, src.getOrNull(0)?.let { it.backdrop ?: it.logo },
        src.getOrNull(1)?.let { it.backdrop ?: it.logo }, src.getOrNull(2)?.let { it.backdrop ?: it.logo }, null)
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(tiles) { ti, (t, target) ->
            Box(Modifier.width(190.dp).height(104.dp).tvFocus(1.05f)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(t.third))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                .clickable { vm.goTo(target) }) {
                imgs.getOrNull(ti)?.let { u ->
                    if (!perf) {
                        AsyncImage(model = u, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().alpha(0.32f))
                        Box(Modifier.fillMaxSize().background(
                            Brush.horizontalGradient(listOf(t.third[1].copy(alpha = 0.85f), Color.Transparent))))
                    }
                }
                Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp)) {
                    GlowIcon(t.second, 44.dp)
                    Text(t.first, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun HeroBanner(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    if (LocalPremium.current) PremiumHero(vm, item, index, count, fr) else ClassicHero(vm, item, index, count, fr)
}

@Composable
fun ClassicHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val accent = MaterialTheme.colorScheme.primary
    val blue = LocalBlue.current
    val gray = if (blue) Color(0xFFB4BBC9) else Color(0xFFC3CAD1)
    val shade = if (blue) Color(0xFF040714) else Color(0xFF07070B)
    Box(Modifier.fillMaxWidth().height(300.dp).padding(horizontal = 16.dp, vertical = 4.dp)
        .clip(RoundedCornerShape(if (blue) 28.dp else 24.dp))) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (item.backdrop != null) 0.7f else 0.45f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(shade, shade.copy(alpha = 0.9f), shade.copy(alpha = 0.25f)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            if (blue) listOf(Color.Transparent, Color.Transparent, shade.copy(alpha = 0.55f), shade)
            else listOf(Color.Transparent, Color(0xCC07070B)))))
        Row(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(accent).padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text("NEU", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                            color = MaterialTheme.colorScheme.onPrimary)
                    }
                    if (item.year.isNotBlank()) {
                        Spacer(Modifier.width(10.dp))
                        Text(item.year, fontSize = 14.sp, color = gray)
                    }
                }
                Text(item.name, fontSize = 30.sp, fontWeight = if (blue) FontWeight.ExtraBold else FontWeight.Bold,
                    fontFamily = titleFont, color = if (blue) Color.White else Color.Unspecified,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                Text(item.descr, fontSize = 14.sp, color = gray, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp, end = 24.dp))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                        Text("▶  Jetzt ansehen", fontSize = 16.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatchOf(item, "vod") }, modifier = Modifier.tvFocus()) {
                        Text("＋ Merkliste", fontSize = 16.sp)
                    }
                }
            }
            AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(160.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)))
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(if (i == index) 18.dp else 7.dp, 7.dp).clip(CircleShape)
                    .background(if (i == index) accent else Color(0x66FFFFFF)))
            }
        }
    }
}

/** Premium-Banner: randlos, groß, Bild läuft nach links und unten ins Schwarz aus. */
@Composable
fun PremiumHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val gray = Color(0xFFD0D0D0)
    val red = MaterialTheme.colorScheme.primary
    Box(Modifier.fillMaxWidth().height(360.dp)) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (item.backdrop != null) 0.95f else 0.5f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(0f to Color.Black, 0.38f to Color(0xD9000000), 0.75f to Color(0x14000000), 1f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(0f to Color(0x66000000), 0.25f to Color.Transparent, 0.7f to Color.Transparent, 1f to Color.Black)))
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = 32.dp, top = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("T", fontSize = 22.sp, fontWeight = FontWeight.Black, color = red)
                Spacer(Modifier.width(8.dp))
                Text("NEU IM ANGEBOT", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = gray)
            }
            Text(item.name, fontSize = 44.sp, lineHeight = 46.sp, fontWeight = FontWeight.Black, color = Color.White,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Neu", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF46D369))
                if (item.year.isNotBlank()) {
                    Spacer(Modifier.width(12.dp))
                    Text(item.year, fontSize = 14.sp, color = gray)
                }
            }
            Text(item.descr, fontSize = 15.sp, lineHeight = 21.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).tvFocus(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text("▶  Abspielen", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Button(onClick = { vm.toggleWatchOf(item, "vod") }, modifier = Modifier.tvFocus(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xB36D6D6E), contentColor = Color.White)) {
                    Text("＋  Merkliste", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(if (i == index) 22.dp else 12.dp, 3.dp)
                    .background(if (i == index) Color.White else Color(0x55FFFFFF)))
            }
        }
    }
}

@Composable
fun MiniPoster(entry: Item, onClick: () -> Unit) {
    val premium = LocalPremium.current
    val r = if (premium) 6.dp else 14.dp
    Box(Modifier.width(if (premium) 142.dp else 132.dp)) {
        val sink = LocalAmbientSink.current
        Box(Modifier.tvFocus(1.06f).onFocusChanged { if (it.hasFocus) sink(entry.logo ?: entry.backdrop) }
            .clip(RoundedCornerShape(r)).background(if (premium) Color(0xFF1A1A1A) else Color(0xFF222A33))
            .border(if (premium) 0.dp else 1.dp, if (premium) Color.Transparent else Color(0x22FFFFFF), RoundedCornerShape(r))
            .clickable(onClick = onClick)) {
            val pctx = LocalContext.current
            val pperf = LocalPerf.current
            val req = remember(entry.logo, pperf) {
                coil.request.ImageRequest.Builder(pctx).data(entry.logo).crossfade(if (pperf) 0 else 120).build()
            }
            AsyncImage(model = req, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            QualityBadges(entry.name, Modifier.align(Alignment.TopEnd).padding(4.dp))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .padding(start = 8.dp, end = 8.dp, top = 28.dp, bottom = 8.dp)) {
                Text(entry.name, fontSize = 12.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun ChannelTile(ch: Item, onClick: () -> Unit) {
    Column(Modifier.width(124.dp).tvFocus(1.06f).glass(14.dp).clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.height(48.dp).fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(ch.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FavsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember(vm.favTick, vm.favLists) {
        listOf(Triple("itv", "Live TV – Favoriten", vm.favsFor("itv"))) +
            vm.favLists.map { Triple("itv:" + it.id, "Live TV – " + it.name, vm.listItems(it.id)) } +
            listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.favsFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Row(Modifier.padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("FAVORITEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { vm.push(Screen.FavLists) }, modifier = Modifier.tvFocus()) { Text("Listen verwalten ›") }
        }
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch keine Favoriten. Halte OK gedrückt oder nutze die Menü-Taste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { f ->
                        if (type == "itv") ChannelTile(f) { vm.openFavorite(type, f) }
                        else if (type.startsWith("itv:")) ChannelTile(f) { vm.openFavoriteList(type.removePrefix("itv:"), f) }
                        else MiniPoster(f) { vm.openFavorite(type, f) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val tabs = listOf("Portale & Sender", "Startseite & Design", "Player", "Bild & Ton", "Profile", "System")
    val fr = remember { FocusRequester() }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(vm.settingsTab) {
        if (first) first = false else vm.settingsScroll.scrollTo(0)
    }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Row(Modifier.fillMaxSize().padding(28.dp)) {
        Column(Modifier.width(280.dp).fillMaxHeight().padding(end = 20.dp)) {
            Text("EINSTELLUNGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(4.dp))
            Box(Modifier.width(60.dp).height(2.dp).background(accent))
            Spacer(Modifier.height(16.dp))
            tabs.forEachIndexed { i, label ->
                val sel = vm.settingsTab == i
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    .then(if (i == vm.settingsTab) Modifier.focusRequester(fr) else Modifier)
                    .onFocusChanged { if (it.isFocused) vm.settingsTab = i }
                    .tvFocus(1.03f).clip(RoundedCornerShape(14.dp))
                    .then(if (sel) Modifier.glass(14.dp) else Modifier)
                    .clickable { vm.settingsTab = i }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(3.dp).height(20.dp).background(if (sel) accent else Color.Transparent))
                    Spacer(Modifier.width(12.dp))
                    Text(label, fontSize = 17.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        color = if (sel) accent else Color.Unspecified, maxLines = 1)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(vm.settingsScroll)) {
            Text(tabs[vm.settingsTab].uppercase(), fontSize = 14.sp, letterSpacing = 4.sp, color = gray)
            Column(Modifier.padding(top = 10.dp).glass(22.dp).padding(20.dp)) { SettingsBlock(vm, vm.settingsTab) }
        }
    }
}

@Composable
fun SettingsBlock(vm: AppVM, sec: Int) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.padding(top = 10.dp)) {
        if (sec == 0) {
            OutlinedButton(onClick = { vm.push(Screen.Portals) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Portale verwalten  ›")
            }
        }
        if (sec == 5) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { vm.checkUpdate() }, modifier = Modifier.tvFocus()) { Text("Nach Updates suchen") }
                if (vm.updateInfo != null) {
                    Button(onClick = { vm.installUpdate() }, modifier = Modifier.tvFocus()) { Text("Jetzt installieren") }
                }
            }
            vm.updateMsg?.let { Text(it, fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 6.dp)) }
            if (vm.updateProgress >= 0) {
                LinearProgressIndicator(progress = { vm.updateProgress / 100f },
                    modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(top = 6.dp))
            }
        }
        if (sec == 4) {
            Text("PROFIL", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            var profText by remember { mutableStateOf("") }
            var profDel by remember { mutableStateOf(false) }
            OutlinedButton(onClick = { vm.nextProfile() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Aktives Profil: " + vm.profileName() + (if (vm.profiles.size > 1) "  ⟳" else ""))
            }
            Box(Modifier.widthIn(max = 420.dp).padding(top = 6.dp)) { Field("Profilname", profText) { profText = it } }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.addProfile(profText); profText = "" }, modifier = Modifier.tvFocus()) { Text("＋ Neues Profil") }
                OutlinedButton(onClick = { vm.renameProfile(profText); profText = "" }, modifier = Modifier.tvFocus()) { Text("Umbenennen") }
                if (vm.profileId.isNotEmpty()) {
                    OutlinedButton(onClick = { if (profDel) { vm.deleteProfile(); profDel = false } else profDel = true },
                        modifier = Modifier.tvFocus()) { Text(if (profDel) "Wirklich löschen?" else "Profil löschen") }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AVATARS.forEach { k ->
                    Box(Modifier.tvFocus(1.1f).clip(CircleShape).clickable { vm.setAvatar(k) }
                        .border(if (vm.profileAvatar() == k) 3.dp else 0.dp, Color.White, CircleShape).padding(4.dp)) {
                        Avatar(k, 56.dp, initialOf(vm.profileName()))
                    }
                }
            }
            if (vm.profiles.size > 1) {
                OutlinedButton(onClick = { vm.toggleAskProfile() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                    Text("Profilwahl beim Start: " + (if (vm.askProfile) "an" else "aus"))
                }
            }
            Text("Jedes Profil hat eigene Favoriten, Merkliste, Weiterschauen und Zuletzt gesehen.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 1) {
            Text("SCHRIFTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Palette.textOptions.forEach { (name, c) ->
                    OutlinedButton(onClick = { vm.setTextColor(name) }, modifier = Modifier.tvFocus()) {
                        Text((if (vm.textColorName == name) "● " else "") + name, color = c)
                    }
                }
            }
            Text("AKZENTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Palette.accentOptions.forEach { (name, c) ->
                    OutlinedButton(onClick = { vm.setAccent(name) }, modifier = Modifier.tvFocus()) {
                        Text((if (vm.accentName == name) "● " else "") + name, color = c)
                    }
                }
            }
            Text("SEITENLEISTE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleSidebar() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text((when (vm.sidebarMode) {
                    "compact" -> "Kompakt (nur Symbole)"
                    "normal" -> "Normal (mit Namen)"
                    else -> "Automatisch"
                }) + "  ⟳")
            }
        }
        if (sec == 5) {
            Text("SICHERUNG & AUTOSTART", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    vm.showNotice(if (vm.createBackup()) "Sicherung erstellt" else "Sicherung fehlgeschlagen")
                }, modifier = Modifier.tvFocus()) { Text("💾 Sicherung erstellen") }
                OutlinedButton(onClick = { vm.restoreBackup() }, modifier = Modifier.tvFocus()) { Text("♻ Sicherung laden") }
            }
            Text(vm.lastBackupText + "  ·  automatisch jede Woche  ·  " + vm.backupFile().absolutePath,
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            Text("Die Sicherung bleibt bei App-Updates erhalten, wird aber beim Deinstallieren der App mit gelöscht.",
                fontSize = 12.sp, color = gray)
            val ctxA = LocalContext.current
            OutlinedButton(onClick = {
                vm.toggleAutostart()
                if (vm.autostart && android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(ctxA)) {
                    try {
                        ctxA.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + ctxA.packageName)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) { vm.showNotice("Diese Box bietet die nötige Freigabe nicht an") }
                }
            }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Autostart mit der Box: " + (if (vm.autostart) "an" else "aus"))
            }
            Text("Braucht die Freigabe „Über anderen Apps einblenden“. Nicht jede Box erlaubt das.",
                fontSize = 12.sp, color = gray)
        }
        if (sec == 1) {
            Text("DESIGN", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleGlow() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Glow & Rand: " + vm.glowLabel() + "  ⟳")
            }
            OutlinedButton(onClick = { vm.push(Screen.DesignScale) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Größe: " + vm.uiSizeLabel() + "  ›")
            }
            OutlinedButton(onClick = { vm.push(Screen.HomeLayout) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Startseite einrichten  ›")
            }
        }
        if (sec == 0) {
            OutlinedButton(onClick = { vm.push(Screen.FavLists) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Favoritenlisten verwalten  ›")
            }
        }
        if (sec == 1) {
            OutlinedButton(onClick = { vm.toggleHomeGerman() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Startseite nur deutsche Titel: " + (if (vm.homeGerman) "an" else "aus") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleBadges() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Qualitäts-Abzeichen (4K, HDR …): " + (if (vm.badges) "an" else "aus") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleDesign() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(when (vm.designMode) {
                    "premium" -> "Streaming Premium  ⟳"
                    "oled" -> "OLED-Schwarz  ⟳"
                    "night" -> "Tiefblau-Magie (Streaming-Stil)  ⟳"
                    "neon" -> "Neon-Glas (Glas, Farbverläufe, Neon-Glow)  ⟳"
                    else -> "Cinema (dunkel)  ⟳"
                })
            }
        }
        if (sec == 2) {
            OutlinedButton(onClick = { vm.togglePreview() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.previewOn) "Live-Vorschau in der Senderliste: an  ⟳" else "Live-Vorschau in der Senderliste: aus  ⟳")
            }
            Text("Manche Anbieter erlauben nur einen Stream gleichzeitig. Dann die Vorschau ausschalten.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 1) {
            Text("LEISTUNG", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.togglePerf() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(if (vm.perfMode) "Leistungsmodus: an  ⟳" else "Leistungsmodus: aus  ⟳")
            }
            Text("An: keine Animationen, keine Vorschau, kein Banner-Wechsel. Gut für ältere Boxen.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 2) {
            Text("KOMFORT", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleInfoSeconds() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Sender-Info im Live-Bild: " + vm.infoSeconds + " Sekunden  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleSleep() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min.") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleResumeLast() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.resumeLastOnStart) "Beim Start letzten Sender fortsetzen: an  ⟳"
                    else "Beim Start letzten Sender fortsetzen: aus  ⟳")
            }
        }
        if (sec == 2) {
            Text("SERIEN", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.toggleAutoNext() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(if (vm.autoNext) "Nächste Folge automatisch: an  ⟳" else "Nächste Folge automatisch: aus  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Intro überspringen: " + vm.introSeconds + " Sekunden  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleAutoIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.autoSkipIntro) "Intro automatisch überspringen: an  ⟳" else "Intro automatisch überspringen: aus  ⟳")
            }
            Text("Tipp: Am Ende des Vorspanns im Player Menü öffnen und „Intro-Ende hier merken“ wählen. Das gilt dann für alle Folgen dieser Serie. Sonst springt die App die eingestellte Zeit vor.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 2) {
            Text("ZUSATZINFOS (OPTIONAL)", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            Box(Modifier.padding(top = 4.dp)) { Field("TMDB-Schlüssel (kostenlos auf themoviedb.org)", vm.tmdbKey) { vm.updateTmdbKey(it) } }
            Text("Mit Schlüssel ergänzt die App fehlende Poster, Beschreibungen und Bewertungen bei Filmen und Serien.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 1) {
            OutlinedButton(onClick = { vm.toggleIntroSound() }, modifier = Modifier.padding(top = 14.dp).tvFocus()) {
                Text(if (vm.introSound) "Start-Sound: an  ⟳" else "Start-Sound: aus  ⟳")
            }
        }
        if (sec == 5) {
            Text("SPEICHER", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            LaunchedEffect(Unit) { vm.refreshCacheSize() }
            OutlinedButton(onClick = { vm.clearCache() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("🗑  Cache leeren" + (if (vm.cacheSizeText.isNotEmpty()) "  (jetzt " + vm.cacheSizeText + ")" else ""))
            }
            OutlinedButton(onClick = { vm.cycleCacheLimit() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Automatisch leeren ab: " + (if (vm.cacheLimitMb == 0) "aus" else vm.cacheLimitMb.toString() + " MB") + "  ⟳")
            }
            Text("Leert Bilder und Update-Dateien. Beim Leeren per Knopf werden auch die gespeicherten Senderlisten gelöscht, der nächste Start dauert dann etwas länger.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 5) {
            Text("SICHERUNG & HILFE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("📱 Backup und Wiederherstellung (per Handy)")
            }
            OutlinedButton(onClick = { vm.push(Screen.LogView) }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("🧾 Fehlerprotokoll ansehen")
            }
        }
        if (sec == 3) {
            Text("BILD & TON", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleQuality() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(when (vm.qualityMode) {
                    "max" -> "Maximale Qualität (immer die höchste)  ⟳"
                    "adaptive" -> "Beste Qualität, passt sich der Leitung an  ⟳"
                    else -> "Automatisch (an Bildschirm angepasst)  ⟳"
                })
            }
            Text("Gilt ab dem nächsten gestarteten Stream. Bild und Ton werden nicht umgerechnet.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleHdr() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("HDR-Ausgabe: " + vm.hdrLabel() + "  ⟳")
            }
            Text("Fordert bei HDR-Filmen den HDR-Farbraum an, damit der Fernseher auf HDR umschaltet.", fontSize = 12.sp, color = gray)
            OutlinedButton(onClick = { vm.cycleAfr() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Bildwiederholrate anpassen: " + vm.afrLabel() + "  ⟳")
            }
            Text("Stellt den Fernseher auf den Takt des Films (z. B. 24 oder 25 Bilder/s) um. Der Bildschirm kann dabei kurz flackern.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleAudio() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Ton: " + vm.audioLabel() + "  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleDecoder() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Decoder: " + vm.decoderLabel() + "  ⟳")
            }
            Text("Ton und Decoder gelten ab dem nächsten gestarteten Stream.", fontSize = 12.sp, color = gray,
                modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleNetMode() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Netz-Anpassung: " + vm.netLabel() + "  ⟳")
            }
            Text("Bei schwachem Netz: Bild höchstens 720p, größerer Puffer, längere Wartezeiten. Der Puffer gilt ab dem nächsten gestarteten Sender.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleBuffer() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(when (vm.bufferMode) {
                    "fast" -> "Pufferung: schnell (kurz)  ⟳"
                    "stable" -> "Pufferung: stabil (groß, für 4K)  ⟳"
                    else -> "Pufferung: ausgewogen  ⟳"
                })
            }
            OutlinedButton(onClick = { vm.toggleCompat() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.compat) "Kompatibilitätsmodus: an  ⟳" else "Kompatibilitätsmodus: aus  ⟳")
            }
            Text("Auf Fire TV und schwachen Geräten von Anfang an an. Standard-Verbindung, Standard-Puffer und einfaches Auslesen der Sender. Gilt ab dem nächsten gestarteten Stream.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.toggle4kHelp() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.fourKHelp) "4K-Hilfe (Tunneling): an  ⟳" else "4K-Hilfe (Tunneling): aus  ⟳")
            }
            Text("Bei Rucklern in 4K: Pufferung auf stabil stellen, danach die 4K-Hilfe testen. Ein Netzwerkkabel hilft am meisten.",
                fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 0) {
            OutlinedButton(onClick = { vm.toggleDedupe() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.dedupe) "Gleichnamige Sender: zusammenfassen  ⟳"
                    else "Gleichnamige Sender: alle zeigen  ⟳")
            }
        }
        if (sec == 5) {
            Text("Version ${BuildConfig.VERSION_NAME}", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
fun PhoneAddScreen(vm: AppVM) {
    val gray = LocalMuted.current
    DisposableEffect(Unit) {
        vm.startPhoneAdd()
        onDispose { vm.stopPhoneAdd() }
    }
    val url = vm.qrUrl
    val bmp = remember(url) { url?.let { qrBitmap(it).asImageBitmap() } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Row(Modifier.fillMaxSize().padding(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 32.dp)) {
            Text("PORTAL PER HANDY HINZUFÜGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(80.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(20.dp))
            Text("1.  Das Handy muss im selben WLAN sein wie diese Box.", fontSize = 16.sp)
            Text("2.  Kamera-App öffnen und den QR-Code scannen.", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
            Text("3.  Formular ausfüllen und auf Portal hinzufügen tippen.", fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp))
            Text("Das Portal erscheint sofort in deiner Liste. Du kannst mehrere nacheinander eintragen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
            Text("Auf derselben Seite: Backup herunterladen und wiederherstellen, Fehlerprotokoll ansehen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
            if (url != null) {
                Text("Oder im Handy-Browser öffnen:", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
                Text(url, fontSize = 13.sp, color = gray)
            }
            Text("Portale gesamt: ${vm.portals.size}", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 12.dp))
            Spacer(Modifier.height(20.dp))
            Button(onClick = { vm.back() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Fertig") }
        }
        Box(Modifier.size(320.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(14.dp),
            contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(bitmap = bmp, contentDescription = "QR-Code", modifier = Modifier.fillMaxSize())
            } else {
                Text("…", color = Color.Black, fontSize = 24.sp)
            }
        }
    }
}

@Composable
fun ChannelPanel(vm: AppVM, modifier: Modifier) {
    val cats = remember(vm.chanPanel) { vm.panelCategories() }
    var catsOpen by remember { mutableStateOf(true) }
    val rows = remember(vm.panelGroups, vm.panelExpanded, vm.chanPanel) {
        val out = ArrayList<PaneRow>()
        if (vm.panelGroups.isNotEmpty()) {
            for (g in vm.panelGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.panelExpanded) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in vm.panelVisibleCats(g)) out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                }
            }
        } else {
            for (c in cats) out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    val catState = rememberLazyListState(initialFirstVisibleItemIndex = rows.indexOfFirst { it.id == vm.panelCat }.coerceAtLeast(0))
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Row(modifier.fillMaxHeight().width(740.dp)
        .background(Brush.horizontalGradient(listOf(Color(0xF2000000), Color(0xE6000000), Color(0x00000000))))
        .padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 70.dp)) {
        Column(Modifier.width(if (catsOpen) 220.dp else 48.dp).fillMaxHeight()) {
            Text(if (catsOpen) "◀  Kategorien" else "▶", fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().tvFocus(1.05f).clip(RoundedCornerShape(8.dp))
                    .clickable { catsOpen = !catsOpen }.padding(8.dp))
            if (catsOpen) {
                LazyColumn(state = catState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(rows, key = { it.id }) { r ->
                        if (r.kind == 0) {
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).glass(10.dp)
                                .clickable { vm.togglePanelGroup(r.pfx) }.padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(if (r.pfx in vm.panelExpanded) "▾" else "▸", fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(r.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            ListRow((if (r.pfx.isNotEmpty()) "   " else "") + r.title, r.id == vm.panelCat) { vm.panelCat = r.id }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        key(vm.panelCat) {
            val list = remember { vm.panelList() }
            val cur = list.indexOfFirst { it.id == vm.playChId }
            val state = rememberLazyListState(initialFirstVisibleItemIndex = cur.coerceAtLeast(0))
            if (list.isEmpty()) {
                Text("Keine Sender", color = Color(0xFFB0BAC4), modifier = Modifier.weight(1f).padding(12.dp))
            } else {
                LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    items(list) { ch ->
                        val isCur = ch.id == vm.playChId
                        val anchor = isCur || (cur < 0 && ch.id == list.first().id)
                        PanelRow(vm, ch, isCur, if (anchor) Modifier.focusRequester(fr) else Modifier) {
                            vm.playFromPanel(ch, list)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PanelRow(vm: AppVM, ch: Item, current: Boolean, modifier: Modifier, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    Row(modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(10.dp))
        .background(if (current) accent.copy(alpha = 0.3f) else Color(0x22FFFFFF))
        .clickable(onClick = onClick).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text((if (current) "▶ " else "") + ch.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal)
            if (now != null) {
                Text("${now.start}  ${now.title}", fontSize = 11.sp, color = Color(0xFFB0BAC4), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun WatchScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember {
        listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.watchFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Text("MERKLISTE", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch nichts gemerkt. Öffne einen Film oder eine Serie und wähle ＋ Merkliste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { w -> MiniPoster(w) { vm.openWatch(type, w) } }
                }
            }
        }
    }
}

/** Zeigt die tatsächlich ankommende Qualität, zum Beispiel "4K 3840×2160 · 50 fps · HEVC | Dolby Digital Plus 5.1". */
fun qualityLabel(p: ExoPlayer): String {
    val parts = ArrayList<String>()
    val v = p.videoFormat
    if (v != null && v.height > 0) {
        val res = when {
            v.height >= 2000 -> "4K"
            v.height >= 1000 -> "FHD"
            v.height >= 700 -> "HD"
            else -> "SD"
        }
        val fps = if (v.frameRate > 0f) " · " + Math.round(v.frameRate) + " fps" else ""
        val codec = when (v.sampleMimeType) {
            "video/hevc" -> " · HEVC"
            "video/avc" -> " · H.264"
            "video/av01" -> " · AV1"
            "video/x-vnd.on2.vp9" -> " · VP9"
            "video/mpeg2" -> " · MPEG-2"
            else -> ""
        }
        parts.add(res + " " + v.width + "×" + v.height + fps + codec)
    }
    val a = p.audioFormat
    if (a != null) {
        val codec = when (a.sampleMimeType) {
            "audio/ac3" -> "Dolby Digital"
            "audio/eac3" -> "Dolby Digital Plus"
            "audio/eac3-joc" -> "Dolby Atmos"
            "audio/true-hd" -> "Dolby TrueHD"
            "audio/vnd.dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MPEG-Audio"
            "audio/mpeg-L2" -> "MPEG-Audio"
            else -> "Audio"
        }
        val ch = when (a.channelCount) {
            1 -> "Mono"
            2 -> "Stereo"
            6 -> "5.1"
            8 -> "7.1"
            else -> if (a.channelCount > 0) a.channelCount.toString() + " Kanäle" else ""
        }
        parts.add((codec + " " + ch).trim())
    }
    return parts.joinToString("   |   ")
}

class PaneRow(val kind: Int, val id: String, val title: String, val pfx: String)

@Composable
fun CategoryPane(vm: AppVM, type: String) {
    val open = vm.catPaneOpen
    val accent = MaterialTheme.colorScheme.primary
    val widthAnim by animateDpAsState(if (open) 280.dp else 56.dp, label = "catPaneWidth")
    val width = if (LocalPerf.current) (if (open) 280.dp else 56.dp) else widthAnim
    val rows = remember(vm.portalGroups, vm.expandedPortals, vm.hiddenCats, vm.categories, type, vm.orderTick, vm.favLists) {
        val out = ArrayList<PaneRow>()
        if (vm.portalGroups.isNotEmpty()) {
            if (type == "itv") for (l in vm.favLists) out.add(PaneRow(1, "fl:" + l.id, "★ " + l.name, ""))
            for (g in vm.portalGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.expandedPortals) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    if (type != "itv") out.add(PaneRow(1, "p:" + g.pfx + ":resume", "⏯ Weiterschauen", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in vm.orderCats(g.cats.filter { it.id !in vm.hiddenCats }, type)) {
                        out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                    }
                }
            }
        } else {
            out.add(PaneRow(1, "fav", "★ Favoriten", ""))
            for (c in vm.categories) if (c.id != "fav") out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    Column(Modifier.width(width).fillMaxHeight().padding(start = 4.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)
        .glass(20.dp).padding(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (open) Arrangement.Start else Arrangement.Center) {
            if (open) {
                Text("PORTALE", fontSize = 11.sp, letterSpacing = 3.sp, color = accent,
                    modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (open) "◀" else "▶", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.toggleCatPane() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (open) {
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = vm.catListState) {
                items(rows, key = { it.id }) { r ->
                    if (r.kind == 0) {
                        val expanded = r.pfx in vm.expandedPortals
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).leftFocus(vm, "cat:" + r.id).tvFocus(1.02f).glass(12.dp)
                            .clickable { vm.toggleGroup(r.pfx) }
                            .padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (expanded) "▾" else "▸", fontSize = 14.sp, color = accent)
                            Spacer(Modifier.width(10.dp))
                            Text(r.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    } else {
                        Box(Modifier.leftFocus(vm, "cat:" + r.id)) {
                            ListRowK(r.title, r.id == vm.selCat, catKind(r.title)) { vm.selectCategory(r.id) }
                        }
                    }
                }
            }
        }
    }
}

/** Auswahl der Tonspur (Sprache, Format, Kanäle) während der Wiedergabe. */
@Composable
fun AudioMenu(exo: ExoPlayer, vm: AppVM, infoOn: Boolean, onToggleInfo: () -> Unit, onClose: () -> Unit) {
    val groups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO } }
    val tgroups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(560.dp).heightIn(max = 440.dp).glass(22.dp).background(Color(0xEE0A0A0F))
            .verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text("TON", fontSize = 14.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            if (groups.isEmpty()) {
                Text("Keine auswählbaren Tonspuren gefunden.", color = LocalMuted.current)
            }
            var first = true
            for (g in groups) {
                for (ti in 0 until g.length) {
                    val selected = g.isTrackSelected(ti)
                    val label = (if (selected) "●  " else "○  ") + audioLabel(g.getTrackFormat(ti))
                    val rowMod = if (first) Modifier.focusRequester(fr) else Modifier
                    first = false
                    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = rowMod.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti))
                                    .build()
                                g.getTrackFormat(ti).language?.takeIf { it.isNotEmpty() && it != "und" }?.let { vm.setAudioLang(it) }
                                onClose()
                            }
                            .padding(12.dp))
                }
            }
            if (tgroups.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("UNTERTITEL", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                val off = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
                MenuRow((if (off) "●  " else "○  ") + "Aus", off) {
                    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    vm.setTextLang("off")
                    onClose()
                }
                for (g in tgroups) {
                    for (ti in 0 until g.length) {
                        val sel = g.isTrackSelected(ti) && !off
                        val lang = g.getTrackFormat(ti).language
                        val nm = if (lang.isNullOrEmpty() || lang == "und") "Untertitel"
                        else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
                        MenuRow((if (sel) "●  " else "○  ") + nm, sel) {
                            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
                            vm.setTextLang(if (lang.isNullOrEmpty() || lang == "und") "" else lang)
                            onClose()
                        }
                    }
                }
            }
            if (vm.isLive) {
                val alts = vm.alternativesFor(vm.playChId)
                if (alts.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    Text("QUELLE (PORTAL)", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                    for ((pname, ch) in alts) {
                        val cur = ch.id == vm.playChId
                        MenuRow((if (cur) "●  " else "○  ") + pname, cur) {
                            vm.chooseSource(ch)
                            onClose()
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("OPTIONEN", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            if (vm.isLive) {
                MenuRow(if (exo.playWhenReady) "⏸  Live pausieren" else "▶  Live weiter", false) {
                    exo.playWhenReady = !exo.playWhenReady
                    onClose()
                }
            }
            MenuRow("🖼  Bild: " + vm.picLabel(), false) { vm.cyclePic() }
            MenuRow("🔊  Lautstärke-Boost: " + (if (vm.boostDb == 0) "aus" else "+" + vm.boostDb + " dB"), false) { vm.cycleBoost() }
            if (vm.isEpisode) {
                MenuRow("⏭  Intro-Ende hier merken (" + fmtTime(exo.currentPosition) + ")", false) {
                    vm.saveIntroEnd(exo.currentPosition)
                    onClose()
                }
            }
            MenuRow("⏾  Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min."), false) { vm.cycleSleep() }
            MenuRow((if (infoOn) "☑" else "☐") + "  Stream-Diagnose anzeigen", false) {
                onToggleInfo()
                onClose()
            }
            Text("Zurück schließt das Menü.", fontSize = 12.sp, color = LocalMuted.current,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}

fun audioLabel(f: androidx.media3.common.Format): String {
    val lang = f.language
    val langName = if (lang.isNullOrEmpty() || lang == "und") "Tonspur"
    else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
    val codec = when (f.sampleMimeType) {
        "audio/ac3" -> "Dolby Digital"
        "audio/eac3" -> "Dolby Digital Plus"
        "audio/eac3-joc" -> "Dolby Atmos"
        "audio/true-hd" -> "Dolby TrueHD"
        "audio/vnd.dts" -> "DTS"
        "audio/vnd.dts.hd" -> "DTS-HD"
        "audio/mp4a-latm" -> "AAC"
        "audio/mpeg" -> "MPEG-Audio"
        "audio/mpeg-L2" -> "MPEG-Audio"
        else -> "Audio"
    }
    val ch = when (f.channelCount) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> if (f.channelCount > 0) f.channelCount.toString() + " Kanäle" else ""
    }
    return (langName + "  ·  " + codec + " " + ch).trim()
}

/** Kleines Live-Bild (ohne Ton) des markierten Senders, ersetzt die Vorschau-Zeile in der Senderliste. */
@Composable
fun PreviewCard(vm: AppVM) {
    val ctx = LocalContext.current
    val gray = LocalMuted.current
    val exo = remember {
        val ds = SmartHttpFactory().setUserAgent(UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8_000).setReadTimeoutMs(10_000)
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply { volume = 0f }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    val url = vm.previewUrl
    LaunchedEffect(url) {
        if (url == null) {
            exo.stop()
            exo.clearMediaItems()
        } else {
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.play()
        }
    }
    val ch = vm.previewChannel
    val now = if (ch != null) vm.currentEpg(ch.id) else null
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(260.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            AndroidView(factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = exo
                }
            }, modifier = Modifier.fillMaxSize())
            if (url == null) {
                Text(if (ch == null) "Sender wählen" else "Vorschau lädt …", fontSize = 12.sp, color = Color(0xFFB0B7BF))
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(ch?.name ?: "", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (now.descr.isNotBlank()) {
                    Text(now.descr, fontSize = 12.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
            Text("Vorschau ohne Ton", fontSize = 11.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/** Angefangene Filme und Serien eines Portals, mit Weiter-Knopf und Löschen. */
@Composable
fun ResumeListView(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    LaunchedEffect(Unit) { vm.refreshResumeShown() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("WEITERSCHAUEN", fontSize = 13.sp, letterSpacing = 3.sp, color = accent, modifier = Modifier.weight(1f))
            if (vm.resumeEntries.isNotEmpty()) {
                OutlinedButton(onClick = { vm.clearResumeShown() }, modifier = Modifier.tvFocus()) { Text("🗑 Alle löschen") }
            }
        }
        if (vm.resumeEntries.isEmpty()) {
            Text("Nichts angefangen. Filme und Serien, die du ansiehst, erscheinen hier.", color = gray,
                modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp)) {
            items(vm.resumeEntries, key = { it.key }) { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(16.dp).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.width(54.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222A33)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fmtTime(r.pos) + (if (r.dur > 0) " / " + fmtTime(r.dur) else ""), fontSize = 12.sp, color = gray)
                        if (r.dur > 0) {
                            LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { vm.playResume(r) }, modifier = Modifier.tvFocus()) { Text("▶ Weiter") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.removeResume(r) }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
                }
            }
        }
    }
}

fun digitOf(k: Key): Int = when (k) {
    Key.Zero, Key.NumPad0 -> 0
    Key.One, Key.NumPad1 -> 1
    Key.Two, Key.NumPad2 -> 2
    Key.Three, Key.NumPad3 -> 3
    Key.Four, Key.NumPad4 -> 4
    Key.Five, Key.NumPad5 -> 5
    Key.Six, Key.NumPad6 -> 6
    Key.Seven, Key.NumPad7 -> 7
    Key.Eight, Key.NumPad8 -> 8
    Key.Nine, Key.NumPad9 -> 9
    else -> -1
}

@Composable
fun MenuRow(label: String, bold: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(12.dp))
}

/** Kleines Fenster mit Puffer, Bildrate und Quelle zum Prüfen von Rucklern. */
@Composable
fun StreamInfo(vm: AppVM, exo: ExoPlayer, quality: String, modifier: Modifier) {
    var buf by remember { mutableStateOf(0L) }
    var rate by remember { mutableStateOf(0) }
    var state by remember { mutableStateOf("") }
    var fps by remember { mutableStateOf(0f) }
    var codec by remember { mutableStateOf("") }
    var audio by remember { mutableStateOf("") }
    var dropped by remember { mutableIntStateOf(0) }
    var stalls by remember { mutableIntStateOf(0) }
    var bw by remember { mutableLongStateOf(0L) }
    DisposableEffect(exo) {
        val al = object : AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                dropped += droppedFrames
            }
            override fun onBandwidthEstimate(
                eventTime: AnalyticsListener.EventTime, totalLoadTimeMs: Int, totalBytesLoaded: Long, bitrateEstimate: Long
            ) { bw = bitrateEstimate }
        }
        val pl = object : Player.Listener {
            private var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_BUFFERING && last == Player.STATE_READY) stalls++
                last = playbackState
            }
        }
        exo.addAnalyticsListener(al)
        exo.addListener(pl)
        onDispose { exo.removeAnalyticsListener(al); exo.removeListener(pl) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            buf = exo.totalBufferedDuration
            rate = exo.videoFormat?.bitrate ?: 0
            fps = exo.videoFormat?.frameRate ?: 0f
            codec = when (exo.videoFormat?.sampleMimeType) {
                "video/avc" -> "H.264"
                "video/hevc" -> "H.265"
                "video/mpeg2" -> "MPEG-2"
                "video/av01" -> "AV1"
                null -> ""
                else -> "Video"
            }
            audio = exo.audioFormat?.let { audioLabel(it) } ?: ""
            state = when (exo.playbackState) {
                Player.STATE_BUFFERING -> "Puffert"
                Player.STATE_READY -> if (exo.isPlaying) "Läuft" else "Pause"
                Player.STATE_ENDED -> "Ende"
                else -> "Leerlauf"
            }
            delay(1000)
        }
    }
    val verdict = when {
        stalls >= 3 -> "⚠ Netz oder Quelle instabil: mehrfach gepuffert. LAN-Kabel, Pufferung „stabil“ oder andere Quelle probieren."
        dropped > 30 -> "⚠ Die Box kommt beim Dekodieren nicht mit: Qualität auf „adaptiv“ stellen oder 4K-Hilfe testen."
        bw > 0 && rate > 0 && bw < rate * 13L / 10L -> "⚠ Verbindung ist für diese Videorate knapp."
        else -> "✓ Alles im grünen Bereich"
    }
    Column(modifier.padding(16.dp).widthIn(max = 420.dp).glass(14.dp).padding(12.dp)) {
        Text("STREAM-DIAGNOSE", fontSize = 10.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary)
        Text(state + "  ·  Puffer " + (buf / 1000) + " s", fontSize = 12.sp, color = Color.White)
        if (quality.isNotEmpty()) Text(quality, fontSize = 12.sp, color = Color.White)
        if (codec.isNotEmpty()) Text(codec + (if (fps > 0) "  ·  " + fps.toInt() + " Bilder/s" else ""), fontSize = 12.sp, color = Color.White)
        if (rate > 0) Text("Videorate " + (rate / 1000) + " kbit/s", fontSize = 12.sp, color = Color.White)
        if (bw > 0) Text("Netz ca. " + (bw / 1_000_000) + " Mbit/s", fontSize = 12.sp, color = Color.White)
        if (audio.isNotEmpty()) Text(audio, fontSize = 12.sp, color = Color.White)
        Text("Ausgelassene Bilder: $dropped  ·  Aussetzer: $stalls", fontSize = 12.sp, color = Color.White)
        Text("Quelle: " + vm.sourceName(), fontSize = 12.sp, color = Color.White)
        Text(verdict, fontSize = 12.sp, color = Color.White, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Fehlerprotokoll: letzte Meldungen und Abstürze. */
@Composable
fun LogScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var lines by remember { mutableStateOf(AppLog.all()) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("FEHLERPROTOKOLL", fontSize = 18.sp, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("⟳ Neu laden") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { AppLog.clear(); lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
        }
        if (lines.isEmpty()) {
            Text("Keine Einträge.", color = gray, modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp).glass(16.dp).padding(12.dp)) {
            items(lines) { l ->
                Text(l, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

/** Hinweisfenster beim App-Start, wenn eine neuere Version bereitsteht. */
@Composable
fun UpdateDialog(vm: AppVM) {
    val info = vm.updatePrompt ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(info) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("UPDATE VERFÜGBAR", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text("Eine neue Version von Tom’s TV ist bereit (${info.tag}).", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = Color.White)
            Text("Die Installation dauert nur einen Moment. Deine Daten bleiben erhalten.", fontSize = 14.sp,
                color = Color(0xFFB0B7BF), modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.updatePrompt = null; vm.installUpdate() },
                    modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt installieren") }
                OutlinedButton(onClick = { vm.updatePrompt = null }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

@Composable
fun ReminderDialog(vm: AppVM) {
    LaunchedEffect(Unit) {
        while (true) {
            vm.checkReminders()
            delay(15_000)
        }
    }
    val r = vm.dueReminder ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(r) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("🔔  ERINNERUNG", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(r.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("beginnt gleich auf " + r.chName, fontSize = 14.sp, color = Color(0xFFB0B7BF),
                modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.acceptReminder() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt umschalten") }
                OutlinedButton(onClick = { vm.dismissReminder() }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

/** Puffergrößen für Live-TV und Filme. */
/** Sucht zum Film-Takt (z. B. 24 oder 25 Bilder/s) eine passende Bildwiederholrate des Fernsehers. */
fun matchRefreshRate(ctx: android.content.Context, fps: Float) {
    if (android.os.Build.VERSION.SDK_INT < 23) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        @Suppress("DEPRECATION")
        val d = act.windowManager.defaultDisplay
        val cur = d.mode
        val cands = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .filter { m ->
                val mult = m.refreshRate / fps
                val n = Math.round(mult)
                n >= 1 && Math.abs(m.refreshRate - fps * n) < 0.15f
            }
            .sortedBy { it.refreshRate }
        val best = cands.firstOrNull() ?: return
        if (best.modeId == cur.modeId) return
        val lp = act.window.attributes
        lp.preferredDisplayModeId = best.modeId
        act.window.attributes = lp
        AppLog.add("Bildwiederholrate angepasst: " + best.refreshRate + " Hz für " + fps + " Bilder/s")
    } catch (e: Exception) { }
}

/** Fordert für das Fenster den HDR-Farbraum an (oder gibt ihn wieder frei). Ab Android 8. */
fun setWindowHdr(ctx: android.content.Context, on: Boolean) {
    if (android.os.Build.VERSION.SDK_INT < 26) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        val want = if (on) android.content.pm.ActivityInfo.COLOR_MODE_HDR else android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT
        if (act.window.colorMode != want) {
            act.window.colorMode = want
            AppLog.add("HDR-Farbraum: " + (if (on) "angefordert" else "zurückgesetzt"))
        }
    } catch (e: Exception) { }
}

fun resetRefreshRate(ctx: android.content.Context) {
    if (android.os.Build.VERSION.SDK_INT < 23) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        val lp = act.window.attributes
        if (lp.preferredDisplayModeId != 0) { lp.preferredDisplayModeId = 0; act.window.attributes = lp }
    } catch (e: Exception) { }
}

/** Filme und Serien: großer Puffer, und nach einem Aussetzer erst wieder starten, wenn genug vorgeladen ist. */
fun buildVodLoadControl(): DefaultLoadControl {
    val cap = (Runtime.getRuntime().maxMemory() / 4).toInt().coerceIn(32 * 1024 * 1024, 96 * 1024 * 1024)
    return DefaultLoadControl.Builder()
        .setBufferDurationsMs(60_000, 240_000, 4_000, 15_000)
        .setTargetBufferBytes(cap)
        .setPrioritizeTimeOverSizeThresholds(false)
        .build()
}

fun buildLoadControl(live: Boolean, mode: String): DefaultLoadControl {
    val b = DefaultLoadControl.Builder()
    // Puffer-Bytes nie größer als ein Achtel des Java-Heaps (sonst OutOfMemory -> Dauer-Buffering)
    val cap = (Runtime.getRuntime().maxMemory() / 8).toInt().coerceIn(16 * 1024 * 1024, 64 * 1024 * 1024)
    when (mode) {
        "fast" -> b.setBufferDurationsMs(12_000, 40_000, 1_000, 2_500)
        "stable" -> {
            b.setBufferDurationsMs(40_000, 120_000, 2_500, 8_000)
            b.setTargetBufferBytes(minOf(cap, 48 * 1024 * 1024))
        }
        else -> if (live) {
            // Größerer Live-Puffer: macht „Live pausieren“ und Zurückspulen länger möglich
            b.setBufferDurationsMs(25_000, 120_000, 1_500, 4_000)
            b.setTargetBufferBytes(minOf(cap, 32 * 1024 * 1024))
        } else b.setBufferDurationsMs(30_000, 90_000, 2_500, 6_000)
    }
    return b.build()
}

/** Verständliche Fehlermeldung statt "error code bad http status". */
fun playErrorText(e: PlaybackException): String {
    val h = e.cause as? HttpDataSource.InvalidResponseCodeException
    if (h != null) {
        return when (h.responseCode) {
            401, 403 -> "Das Portal lehnt den Stream ab (HTTP " + h.responseCode + "). Abo und Gerät (MAC) beim Anbieter prüfen."
            404 -> "Stream nicht gefunden (HTTP 404). Der Sender ist beim Anbieter vielleicht offline."
            in 500..599 -> "Fehler beim Anbieter-Server (HTTP " + h.responseCode + "). Später erneut versuchen."
            else -> "Der Server antwortet mit HTTP " + h.responseCode + "."
        }
    }
    return "Wiedergabefehler: " + e.errorCodeName
}

// ---------- Qualitäts-Abzeichen ----------
private val reBadge4k = Regex("(^|[^A-Z0-9])(4K|UHD|2160P?)([^A-Z0-9]|$)")
private val reBadgeFhd = Regex("(^|[^A-Z0-9])(FHD|FULL ?HD|1080[PI]?)([^A-Z0-9]|$)")
private val reBadgeHd = Regex("(^|[^A-Z0-9])(HD|720P?)([^A-Z0-9]|$)")
private val reBadgeHdr = Regex("(^|[^A-Z0-9])(HDR10\\+?|HDR|DOLBY ?VISION)([^A-Z0-9]|$)")
private val reBadgeBd = Regex("(^|[^A-Z0-9])(BLU-?RAY|BDRIP|BD)([^A-Z0-9]|$)")

/** Liest Qualitätsangaben aus dem Titel (nur was wirklich dort steht). */
fun qualityBadges(name: String): List<String> {
    val n = name.uppercase()
    val out = ArrayList<String>(2)
    when {
        reBadge4k.containsMatchIn(n) -> out.add("4K")
        reBadgeFhd.containsMatchIn(n) -> out.add("FHD")
        reBadgeHd.containsMatchIn(n) -> out.add("HD")
    }
    if (reBadgeHdr.containsMatchIn(n)) out.add("HDR")
    else if (reBadgeBd.containsMatchIn(n)) out.add("BD")
    return out
}

@Composable
fun QualityBadges(name: String, modifier: Modifier = Modifier) {
    if (!LocalBadges.current) return
    val list = remember(name) { qualityBadges(name) }
    if (list.isEmpty()) return
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        list.forEach { b ->
            val gold = b == "4K" || b == "HDR"
            Text(b, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp,
                color = if (gold) Color(0xFF1A1200) else Color.White,
                modifier = Modifier.clip(RoundedCornerShape(4.dp))
                    .background(if (gold) Color(0xFFFFC857) else Color(0xCC000000))
                    .padding(horizontal = 5.dp, vertical = 2.dp))
        }
    }
}

// ---------- Besetzung und Trailer ----------
@Composable
fun CastChip(p: Tmdb.Person, modifier: Modifier = Modifier) {
    Column(modifier.width(96.dp).tvFocus(1.06f).focusable().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Color(0xFF222A33)), contentAlignment = Alignment.Center) {
            Text(p.name.take(1), fontSize = 26.sp, color = Color(0x88FFFFFF))
            if (p.photo != null) AsyncImage(model = p.photo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize())
        }
        Text(p.name, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp))
        if (p.role.isNotBlank()) Text(p.role, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, color = LocalMuted.current)
    }
}

// ---------- Design & Skalierung ----------
@Composable
fun StepRow(label: String, value: Int, min: Int, max: Int, step: Int, fr: FocusRequester?, onChange: (Int) -> Unit) {
    val gray = LocalMuted.current
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)
        .then(if (fr != null) Modifier.focusRequester(fr) else Modifier)
        .tvFocus(1.02f).glass(14.dp)
        .onKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) false
            else when (e.key) {
                Key.DirectionLeft -> { onChange((value - step).coerceIn(min, max)); true }
                Key.DirectionRight -> { onChange((value + step).coerceIn(min, max)); true }
                else -> false
            }
        }
        .focusable().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("◀  " + value + " %  ▶", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
        }
        LinearProgressIndicator(progress = { (value - min).toFloat() / (max - min) },
            modifier = Modifier.padding(top = 10.dp).fillMaxWidth().height(4.dp))
        Text("Links / Rechts auf der Fernbedienung", fontSize = 11.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun DesignScaleScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    Row(Modifier.fillMaxSize().padding(28.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text("DESIGN & SKALIERUNG", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(4.dp))
            Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(12.dp))
            StepRow("Kachel- und Layoutgröße", vm.uiPct, 60, 110, 2, fr) { vm.changeUiPct(it) }
            StepRow("Schriftgröße (zusätzlich)", vm.fontPct, 80, 140, 5, null) { vm.changeFontPct(it) }
            Text("Schnellauswahl", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.changeUiPct(72); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Kompakt") }
                OutlinedButton(onClick = { vm.changeUiPct(86); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Standard") }
                OutlinedButton(onClick = { vm.changeUiPct(100); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Groß") }
            }
            OutlinedButton(onClick = { vm.resetScale() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("↺ Zurücksetzen (86 % / 100 %)")
            }
        }
        Spacer(Modifier.width(28.dp))
        Column(Modifier.width(220.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("VORSCHAU", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.width(150.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF222A33))) {
                Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(
                    Brush.verticalGradient(listOf(Color(0xFF2F4B8F), Color(0xFF111827)))))
                QualityBadges("Beispielfilm 4K HDR", Modifier.align(Alignment.TopEnd).padding(6.dp))
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .padding(start = 10.dp, end = 10.dp, top = 30.dp, bottom = 10.dp)) {
                    Text("Beispielfilm", fontSize = 13.sp, color = Color.White)
                }
            }
            Text("Beispieltext in dieser Größe", fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
            Text("Kleiner Zusatztext", fontSize = 12.sp, color = gray)
        }
    }
}

/** Alle angefangenen Filme und Serien des Portals (Eintrag „Weiterschauen“ in der linken Spalte). */
@Composable
fun ResumeAllView(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val first = remember { FocusRequester() }
    LaunchedEffect(vm.resumeList.isNotEmpty()) { if (vm.resumeList.isNotEmpty()) runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("WEITERSCHAUEN", fontSize = 13.sp, letterSpacing = 3.sp, color = accent, modifier = Modifier.weight(1f))
            if (vm.resumeList.isNotEmpty()) {
                OutlinedButton(onClick = { vm.clearAllResumes() }, modifier = Modifier.tvFocus()) { Text("🗑 Alle löschen") }
            }
        }
        if (vm.resumeList.isEmpty()) {
            Text("Nichts angefangen. Filme und Serien, die du ansiehst, erscheinen hier.", color = gray,
                modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 4.dp)) {
            itemsIndexed(vm.resumeList, key = { _, r -> r.key }) { idx, r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(16.dp).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.width(54.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222A33)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text((if (r.type == "series") "Serie" else "Film") + "  ·  " + fmtTime(r.pos) +
                            (if (r.dur > 0) " / " + fmtTime(r.dur) else ""), fontSize = 12.sp, color = gray)
                        if (r.dur > 0) {
                            LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { vm.playResume(r) },
                        modifier = (if (idx == 0) Modifier.focusRequester(first) else Modifier).tvFocus()) { Text("▶ Weiter") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.removeResume(r) }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
                }
            }
        }
    }
}
