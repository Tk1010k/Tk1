@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.ui.ExperimentalComposeUiApi::class)

package com.example.portaltv

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.Coil
import coil.ImageLoader
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

val LocalLight = compositionLocalOf { false }
val LocalMuted = compositionLocalOf { Color(0xFFB0B7BF) }
val LocalPerf = compositionLocalOf { false }
val LocalGlow = compositionLocalOf { 1f }
val LocalBadges = compositionLocalOf { true }

/** Streaming-Premium-Design aktiv (schwarz, Kino-Rot, große Kacheln). */
val LocalPremium = compositionLocalOf { false }
val LocalBlue = compositionLocalOf { false }
val LocalNeon = compositionLocalOf { false }
val LocalShield = compositionLocalOf { false }
val LocalMid = compositionLocalOf { false }
/** Apple-TV-Design: Tab-Leiste oben, großes Titelbild, weißer Fokus. */
val LocalAtv = compositionLocalOf { false }
/** Kino-Design: wählbare Akzentfarbe (Standard Eisblau). */
object Kino {
    val labels = listOf("Eisblau", "Gold", "Smaragd", "Rubin", "Violett")
    private val c1 = listOf(0xFF4FC3E8, 0xFFD9B26B, 0xFF2FD1A0, 0xFFE0525E, 0xFF9B7BFF)
    private val c2 = listOf(0xFFB5ECFF, 0xFFF3DDA8, 0xFFA9F5DC, 0xFFFFB3B8, 0xFFD3C4FF)
    var idx by mutableStateOf(0)
    val a: Color get() = Color(c1[idx.coerceIn(0, 4)])
    val a2: Color get() = Color(c2[idx.coerceIn(0, 4)])
}
val LocalKino = compositionLocalOf { false }

/** Akzent der Shield-/Mitternacht-Designs (Pink bzw. Magenta). */
val sPink: Color
    @Composable get() = if (LocalKino.current) Kino.a else if (LocalAtv.current) Color(0xFFF2F2F7) else if (LocalMid.current) Color(0xFFC2358F) else Color(0xFFF801A3)
/** Markenfarbe von „Tom’s TV“ im aktuellen Design (Mitternacht: Blau). */
val brandTint: Color
    @Composable get() = if (LocalKino.current) Kino.a else if (LocalMid.current || LocalAtv.current) Color(0xFF3D7BFF) else if (LocalShield.current) Color(0xFFF801A3) else MaterialTheme.colorScheme.primary
/** Flat-Design: Premium-Look mit Linien-Symbolen und farbiger Menü-Auswahl. */
val LocalFlat = compositionLocalOf { false }
val LocalAmbientSink = androidx.compose.runtime.staticCompositionLocalOf<(String?) -> Unit> { { } }
val LocalAmbient = compositionLocalOf { Color(0xFF5B6BFF) }

/** Farbton verschieben (für den zweiten Farbverlauf im Neon-Glas-Design). */
fun shiftHue(c: Color, deg: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt()), hsv)
    hsv[0] = (hsv[0] + deg + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Im Shield-Design bleibt Schrift weiß, auch wo sonst die Akzentfarbe genutzt würde. */
@Composable
fun tcol(c: Color): Color = if (LocalShield.current || (LocalPremium.current && !LocalFlat.current)) Color.White else c

/** Farbe für kleine Überschriften: in den dunklen Premium-Designs hellgrau statt Akzent (besserer Kontrast aus der Ferne). */
@Composable
fun hdrCol(): Color = if (LocalShield.current || (LocalPremium.current && !LocalFlat.current)) Color(0xFFE8ECF2) else MaterialTheme.colorScheme.primary

/** Outline-Knopf: im Shield-Design weiße Schrift und feiner heller Rand statt Akzentfarbe. */
@Composable
fun OutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
                   contentPadding: PaddingValues = ButtonDefaults.ContentPadding, content: @Composable RowScope.() -> Unit) {
    if (LocalShield.current || (LocalPremium.current && !LocalFlat.current)) androidx.compose.material3.OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x80FFFFFF)), contentPadding = contentPadding, content = content)
    else androidx.compose.material3.OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled,
        contentPadding = contentPadding, content = content)
}

/** Titel-Schrift: im Premium-Design moderne, kräftige Sans-Schrift, sonst Serif. */
val titleFont: FontFamily
    @Composable get() = FontFamily.SansSerif

class MainActivity : ComponentActivity() {
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            runCatching { coil.Coil.imageLoader(this).memoryCache?.clear() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.crash(e)
            oldHandler?.uncaughtException(t, e)
        }
        Coil.setImageLoader(ImageLoader.Builder(this).crossfade(120).respectCacheHeaders(false)
            .allowRgb565(true)
            .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.12).build() }
            .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("img_cache")).maxSizeBytes(150L * 1024 * 1024).build() }
            .build())
        setContent {
            val vm: AppVM = viewModel()
            val light = false
            val ac = if (vm.designMode == "kino") Kino.a else if (vm.designMode == "atv") Color.White else if (vm.designMode == "shield") Color(0xFFF801A3) else if (vm.designMode == "midnight") Color(0xFFC2358F) else if (vm.designMode == "premium") Color(0xFFA771EE) else Palette.accent(vm.accentName)
            val tc = if (light) Color(0xFF14161B) else if (vm.designMode == "shield" || vm.designMode == "midnight" || vm.designMode == "atv" || vm.designMode == "kino" || vm.designMode == "premium") Color.White else Palette.text(vm.textColorName)
            val premium = vm.designMode == "premium" || vm.designMode == "flat"
            val bg = when (vm.designMode) {
                "premium" -> Color(0xFF020105)
                "flat" -> Color(0xFF0C0A15)
                "oled" -> Color(0xFF000000)
                "night" -> Color(0xFF040714)
                "neon" -> Color(0xFF07070D)
                "shield" -> Color(0xFF010103)
                "midnight" -> Color(0xFF030818)
                "atv" -> Color(0xFF0A0A0C)
                "kino" -> Color(0xFF060810)
                else -> Color(0xFF0A0A0F)
            }
            val ambAnim by androidx.compose.animation.animateColorAsState(vm.ambient, tween(700), label = "ambient")
            val ambSink = remember(vm) { { u: String? -> vm.focusAmbient(u) } }
            val onAc = if (ac.luminance() > 0.5f) Color(0xFF0A0A0F) else Color.White
            val scheme = if (light) {
                lightColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc,
                    onSurfaceVariant = tc, background = bg, surface = bg)
            } else {
                darkColorScheme(primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc, onSurfaceVariant = tc)
            }
            val muted = if (light) Color(0xFF5B6270) else if (vm.designMode == "premium") Color(0xFF9D9AA8) else if (premium) Color(0xFFA8A8A8) else Color(0xFFB0B7BF)
            val baseDensity = LocalDensity.current
            val scaled = Density(baseDensity.density * vm.uiScale(), baseDensity.fontScale * vm.fontPct / 100f / vm.uiScale())
            CompositionLocalProvider(LocalLight provides light, LocalMuted provides muted, LocalPerf provides vm.perfMode,
                LocalPremium provides premium, LocalFlat provides (vm.designMode == "flat"), LocalBlue provides (vm.designMode == "night" || vm.designMode == "neon" || vm.designMode == "shield" || (vm.designMode == "midnight" || vm.designMode == "kino") || vm.designMode == "atv"), LocalNeon provides (vm.designMode == "neon" || vm.designMode == "shield" || (vm.designMode == "midnight" || vm.designMode == "kino") || vm.designMode == "atv"), LocalShield provides (vm.designMode == "shield" || (vm.designMode == "midnight" || vm.designMode == "kino") || vm.designMode == "atv"), LocalMid provides ((vm.designMode == "midnight" || vm.designMode == "kino")), LocalKino provides (vm.designMode == "kino"), LocalAtv provides (vm.designMode == "atv"), LocalAmbient provides (if (vm.designMode == "kino") Kino.a else if (vm.designMode == "atv") Color(0xFFE8E8ED) else if (vm.designMode == "shield") Color(0xFFF801A3) else if ((vm.designMode == "midnight" || vm.designMode == "kino")) Color(0xFFC2358F) else ambAnim), LocalAmbientSink provides ambSink, LocalGlow provides vm.glowFactor(), LocalBadges provides vm.badges, LocalDensity provides scaled) {
                MaterialTheme(colorScheme = scheme) {
                    Surface(Modifier.fillMaxSize(), color = bg, contentColor = tc) {
                        Box(Modifier.fillMaxSize()) {
                            App(vm)
                        }
                    }
                }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Menü-Taste der Fernbedienung = Favorit umschalten. */
fun Modifier.favKey(onFav: () -> Unit): Modifier = onKeyEvent { e ->
    if (e.type == KeyEventType.KeyDown && e.key == Key.Menu) { onFav(); true } else false
}

/** Kontextmenü per Fernbedienung: Menü/Info/Stern-Taste oder OK lange halten (Shield sendet bei langem OK nur Wiederholungen). */
fun Modifier.ctxKey(onMenu: () -> Unit): Modifier = composed {
    var longDone by remember { mutableStateOf(false) }
    onPreviewKeyEvent { e ->
        val ok = e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter
        when {
            e.type == KeyEventType.KeyDown && (e.key == Key.Menu || e.nativeKeyEvent.keyCode == 165 || e.nativeKeyEvent.keyCode == 176) -> { onMenu(); true }
            ok && e.type == KeyEventType.KeyDown && e.nativeKeyEvent.repeatCount >= 1 -> { if (!longDone) { longDone = true; onMenu() }; true }
            ok && e.type == KeyEventType.KeyUp && longDone -> { longDone = false; true }
            else -> false
        }
    }
}

/** Brücke vom YouTube-Player (JavaScript) zur App. */
class YtBridge(val onFail: (Int) -> Unit, val onEnd: () -> Unit, val onPlay: () -> Unit) {
    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    @android.webkit.JavascriptInterface fun fail(code: Int) { h.post { onFail(code) } }
    @android.webkit.JavascriptInterface fun ended() { h.post { onEnd() } }
    @android.webkit.JavascriptInterface fun playing() { h.post { onPlay() } }
    @android.webkit.JavascriptInterface fun log(m: String) { AppLog.add("YT: " + m) }
}

private const val YT_HTML = """<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;padding:0;background:#000;width:100%;height:100%;overflow:hidden}#p,iframe{position:fixed;left:0;top:0;width:100vw;height:100vh;border:0}</style></head>
<body><div id="p"></div>
<script>window.onerror=function(m){Android.log("JS-Fehler "+m);};</script>
<script src="https://www.youtube.com/iframe_api" onerror="Android.log('iframe_api nicht ladbar')"></script>
<script>
var pl;
function fit(t){
  try{ t.setSize(window.innerWidth, window.innerHeight); }catch(x){}
  var f=null; try{ f=t.getIframe(); }catch(x){}
  if(f){ f.style.position='fixed'; f.style.left='0'; f.style.top='0'; f.style.width=window.innerWidth+'px'; f.style.height=window.innerHeight+'px'; f.style.border='0'; }
  Android.log('Fenster '+window.innerWidth+'x'+window.innerHeight+', Player '+(f?f.offsetWidth+'x'+f.offsetHeight:'?'));
}
function onYouTubeIframeAPIReady(){
  pl=new YT.Player('p',{width:String(window.innerWidth),height:String(window.innerHeight),videoId:'@KEY@',
    playerVars:{autoplay:1,controls:@CTRL@,disablekb:@DKB@,rel:0,modestbranding:1,playsinline:1,fs:0,hl:'de',cc_lang_pref:'de',mute:@MUTE@,origin:'@ORIGIN@',widget_referrer:'@ORIGIN@'},
    events:{
      onReady:function(e){ Android.log('bereit'); fit(e.target); if(@MUTE@==1){e.target.mute();} e.target.playVideo(); },
      onError:function(e){ Android.fail(e.data); },
      onStateChange:function(e){ Android.log('Status '+e.data); if(e.data==1){fit(e.target); Android.playing();} if(e.data==0){Android.ended();} }
    }});
}
</script></body></html>"""

/** Eingebetteter YouTube-Player (WebView). interactive = Fernbedienung steuert den Player, sonst nur Vorschau. */
@Composable
fun YtEmbed(key: String, muted: Boolean, interactive: Boolean, modifier: Modifier,
            onFail: (Int) -> Unit, onEnd: () -> Unit, onPlaying: () -> Unit) {
    val failS by rememberUpdatedState(onFail)
    val endS by rememberUpdatedState(onEnd)
    val playS by rememberUpdatedState(onPlaying)
    AndroidView(modifier = modifier, factory = { c ->
        val wv = android.webkit.WebView(c)
        wv.setBackgroundColor(android.graphics.Color.BLACK)
        val st = wv.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.mediaPlaybackRequiresUserGesture = false
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) AppLog.add("YT-Konsole: " + m.message())
                return true
            }
        }
        wv.webViewClient = object : android.webkit.WebViewClient() {
            override fun onReceivedError(v: android.webkit.WebView?, r: android.webkit.WebResourceRequest?, e: android.webkit.WebResourceError?) {
                if (r != null && r.isForMainFrame) AppLog.add("YT-Seite Fehler: " + (e?.description ?: "?"))
            }
        }
        var logged = false
        try { AppLog.add("YT-Player in Version " + c.packageManager.getPackageInfo(c.packageName, 0).versionName) } catch (e: Exception) { }
        wv.addJavascriptInterface(YtBridge({ code ->
            AppLog.add("Trailer: YouTube-Player Fehler " + code + (if (code == 101 || code == 150 || code == 152 || code == 153) " (Einbetten nicht erlaubt)" else ""))
            failS(code)
        }, { endS() }, {
            if (!logged) { logged = true; AppLog.add("Trailer: läuft") }
            playS()
        }), "Android")
        wv.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        wv.isFocusable = interactive
        wv.isFocusableInTouchMode = interactive
        val html = YT_HTML.replace("@KEY@", key).replace("@CTRL@", if (interactive) "1" else "0")
            .replace("@DKB@", if (interactive) "0" else "1").replace("@MUTE@", if (muted) "1" else "0")
            .replace("@ORIGIN@", "https://" + c.packageName)
        // YouTube will wissen, welche App einbettet: App-Kennung als Herkunft statt youtube.com
        wv.loadDataWithBaseURL("https://" + c.packageName, html, "text/html", "utf-8", null)
        if (interactive) wv.post { wv.requestFocus() }
        bindWebPause(wv, c, true)
        wv
    }, onRelease = { w -> unbindWebPause(w); w.stopLoading(); w.destroy() })
}

/** WebView anhalten, sobald die App im Hintergrund ist (sonst laufen Trailer, Ton und Datenverkehr weiter). */
fun bindWebPause(wv: android.webkit.WebView, c: android.content.Context, isEmbed: Boolean) {
    val lo = c as? androidx.lifecycle.LifecycleOwner ?: return
    val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
        if (e == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
            if (isEmbed) wv.evaluateJavascript("try{pl.pauseVideo();}catch(x){}", null)
            wv.onPause(); wv.pauseTimers()
        } else if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
            wv.resumeTimers(); wv.onResume()
        }
    }
    lo.lifecycle.addObserver(obs)
    wv.tag = obs
}

fun unbindWebPause(w: android.webkit.WebView) {
    val obs = w.tag as? androidx.lifecycle.LifecycleEventObserver ?: return
    (w.context as? androidx.lifecycle.LifecycleOwner)?.lifecycle?.removeObserver(obs)
}

/** YouTube-Seite des Trailers in der App (wenn der Rechteinhaber das Einbetten sperrt). Läuft in der WebView, keine zweite App. */
@Composable
fun YtWatch(key: String, modifier: Modifier) {
    AndroidView(modifier = modifier, factory = { c ->
        val wv = android.webkit.WebView(c)
        wv.setBackgroundColor(android.graphics.Color.BLACK)
        val st = wv.settings
        st.javaScriptEnabled = true
        st.domStorageEnabled = true
        st.mediaPlaybackRequiresUserGesture = false
        android.webkit.CookieManager.getInstance().setAcceptCookie(true)
        wv.webChromeClient = android.webkit.WebChromeClient()
        wv.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldOverrideUrlLoading(v: android.webkit.WebView?, r: android.webkit.WebResourceRequest?): Boolean {
                val u = r?.url?.toString().orEmpty()
                return !(u.startsWith("http://") || u.startsWith("https://"))
            }
            override fun onPageFinished(v: android.webkit.WebView?, url: String?) {
                val w = v ?: return
                AppLog.add("YT-Seite geladen")
                val js = "(function(){var v=document.querySelector('video'); if(v){v.muted=false; v.play();}})();"
                w.evaluateJavascript(js, null)
                w.postDelayed({ w.evaluateJavascript(js, null) }, 1500)
                w.postDelayed({ w.evaluateJavascript(js, null) }, 4000)
            }
            override fun onReceivedError(v: android.webkit.WebView?, r: android.webkit.WebResourceRequest?, e: android.webkit.WebResourceError?) {
                if (r != null && r.isForMainFrame) AppLog.add("YT-Seite Fehler: " + (e?.description ?: "?"))
            }
        }
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true
        wv.loadUrl("https://m.youtube.com/watch?v=" + key)
        wv.post { wv.requestFocus() }
        bindWebPause(wv, c, false)
        wv
    }, onRelease = { w -> unbindWebPause(w); w.stopLoading(); w.destroy() })
}

/** Spielt den ersten einbettbaren Clip aus der Liste (bei „Einbetten nicht erlaubt" kommt der nächste). */
@Composable
fun YtTrailer(keys: List<String>, muted: Boolean, interactive: Boolean, modifier: Modifier,
              onFail: () -> Unit, onEnd: () -> Unit, onPlaying: () -> Unit) {
    var ki by remember(keys) { mutableIntStateOf(0) }
    var web by remember(keys) { mutableStateOf(false) }
    if (web) {
        val first = keys.firstOrNull() ?: return
        YtWatch(first, modifier)
        return
    }
    val k = keys.getOrNull(ki) ?: return
    var started by remember(k) { mutableStateOf(false) }
    // Nächster Clip; nach dem letzten wird die YouTube-Seite in der App geöffnet (nur mit Bedienung), sonst Aufgabe
    fun next() {
        if (ki + 1 < keys.size) {
            AppLog.add("Trailer: nächster Clip (" + (ki + 2) + "/" + keys.size + ")")
            ki++
        } else if (interactive) {
            AppLog.add("Trailer: Einbetten klappt nicht, YouTube-Seite in der App")
            web = true
        } else onFail()
    }
    if (interactive) LaunchedEffect(k) {
        delay(10000)
        if (!started) { AppLog.add("Trailer: Clip startet nicht (10 s)"); next() }
    }
    androidx.compose.runtime.key(k) {
        YtEmbed(k, muted, interactive, modifier, onFail = { code ->
            if (code == 101 || code == 150 || code == 152) next() else onFail()
        }, onEnd = onEnd, onPlaying = { started = true; onPlaying() })
    }
}

/** Stummer Trailer im Banner (nur wenn eingeschaltet und nicht im Sparmodus). */
@Composable
fun HeroTrailer(vm: AppVM, item: Item, modifier: Modifier) {
    if (!vm.heroTrailerOn || vm.perfMode || vm.allLoading || vm.trailerReq != null) return
    var done by remember(item.id) { mutableStateOf(false) }
    var playing by remember(item.id) { mutableStateOf(false) }
    val tk by produceState<List<String>?>(null, item.id, vm.tmdbKey) {
        value = null
        if (vm.tmdbKey.isNotBlank()) {
            kotlinx.coroutines.delay(2500)
            val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val tm = Tmdb.lookup(vm.tmdbKey, item.name, item.year, false)
                if (tm == null || tm.id <= 0) null else Tmdb.extras(vm.tmdbKey, tm.id, false)?.trailers?.takeIf { it.isNotEmpty() }
            }
            AppLog.add("Banner-Trailer: " + (if (r == null) "kein Trailer für \"" else "gefunden für \"") + item.name + "\"")
            value = r
        }
    }
    val k = tk
    val active = k != null && !done
    LaunchedEffect(active) { vm.heroVideoOn = active }
    DisposableEffect(Unit) { onDispose { vm.heroVideoOn = false } }
    LaunchedEffect(k) {
        if (k != null) {
            delay(12000)
            if (!playing) { AppLog.add("Banner-Trailer: startet nicht (12 s), Bild bleibt"); done = true }
            else { delay(33000); done = true }
        }
    }
    if (k != null && !done) {
        val a by animateFloatAsState(if (playing) 1f else 0f, tween(700), label = "heroTrailer")
        BoxWithConstraints(modifier.clipToBounds().alpha(a)) {
            val w = maxWidth
            YtTrailer(k, true, false, Modifier.align(Alignment.Center).requiredSize(w, w * 9f / 16f),
                onFail = { done = true }, onEnd = { done = true }, onPlaying = { playing = true })
            if (a < 1f) AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize().alpha(1f - a))
        }
    }
}

/** Vollbild-Trailer (Banner und Detailansicht): sucht den Trailer bei TMDB und spielt ihn im YouTube-Player ab.
 *  Liegt direkt im App-Fenster (kein Dialog-Fenster), damit das Video sichtbar bleibt. */
@Composable
fun TrailerDialog(vm: AppVM) {
    val req = vm.trailerReq ?: return
    var tk by remember(req.id) { mutableStateOf<List<String>?>(null) }
    var playing by remember(req.id) { mutableStateOf(false) }
    BackHandler(enabled = true) { vm.trailerReq = null }
    LaunchedEffect(req.id) {
        val k = if (vm.tmdbKey.isBlank()) null else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val tm = Tmdb.lookup(vm.tmdbKey, req.name, req.year, vm.trailerSeries)
            if (tm == null || tm.id <= 0) null else Tmdb.extras(vm.tmdbKey, tm.id, vm.trailerSeries)?.trailers?.takeIf { it.isNotEmpty() }
        }
        if (k == null) {
            AppLog.add("Trailer: kein TMDB-Trailer für \"" + req.name + "\"")
            vm.trailerReq = null
            vm.showNotice("Kein Trailer gefunden")
        } else tk = k
    }
    val k = tk
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (k != null) {
            YtTrailer(k, false, true, Modifier.fillMaxSize(),
                onFail = { vm.trailerReq = null; vm.showNotice("Trailer nicht abspielbar") },
                onEnd = { vm.trailerReq = null }, onPlaying = { playing = true })
        }
        if (!playing) Text(if (k == null) "Trailer wird gesucht …" else "Trailer wird geladen …", fontSize = 18.sp,
            color = Color(0xCCFFFFFF), modifier = Modifier.align(Alignment.Center))
        Text("Zurück = Trailer schließen", fontSize = 13.sp, color = Color(0x99FFFFFF),
            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp))
    }
}

/** Milchglas-Fläche: sanft durchscheinend mit feiner Kante. */
fun Modifier.glass(radius: Dp = 16.dp): Modifier = composed {
    val light = LocalLight.current
    if (LocalPerf.current) {
        return@composed this.clip(RoundedCornerShape(radius.coerceAtMost(12.dp))).background(Color(0x22FFFFFF))
    }
    if (LocalPremium.current) {
        // Premium: flache, dunkle Fläche statt Milchglas
        return@composed this.clip(RoundedCornerShape(radius.coerceAtMost(10.dp))).background(Color(0x17FFFFFF))
    }
    val shape = RoundedCornerShape(radius)
    if (LocalShield.current) {
        return@composed this.clip(shape).background(if (LocalMid.current) Color(0xA00A1236) else Color(0xB0000000)).background(Color(0x12FFFFFF))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x55FFFFFF), Color(0x14FFFFFF))), shape)
    }
    if (LocalNeon.current && !light) {
        val amb = LocalAmbient.current
        return@composed this.clip(shape)
            .background(Brush.linearGradient(listOf(Color(0x2EFFFFFF), amb.copy(alpha = 0.06f), Color(0x08FFFFFF))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x99FFFFFF), amb.copy(alpha = 0.40f), Color(0x12FFFFFF))), shape)
    }
    this.clip(shape)
        .background(Brush.linearGradient(
            if (light) listOf(Color(0xEEFFFFFF), Color(0x99FFFFFF)) else listOf(Color(0x30FFFFFF), Color(0x0AFFFFFF))))
        .border(1.dp, Brush.linearGradient(
            if (light) listOf(Color(0x33000000), Color(0x0F000000)) else listOf(Color(0x66FFFFFF), Color(0x10FFFFFF))), shape)
}

/** Seitenrand der Startseite: im Apple-TV-Design breiter (44 dp), sonst 20 dp. */
@Composable
fun homePad(): androidx.compose.ui.unit.Dp = if (LocalAtv.current) 44.dp else 20.dp

/** Fokus für die Fernbedienung: Zoom, Leuchten und Rahmen in der Akzentfarbe. */
fun Modifier.tvFocus(zoom: Float = 1.03f): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val perf = LocalPerf.current
    if (perf) {
        // Leicht-Modus: nur ein Rahmen, kein Zoom, kein Schatten, keine Animation (Premium: Magenta)
        val focusColor = if (LocalPremium.current && !LocalFlat.current) Color(0xFFDECDF8) else Color.White
        return@composed this.onFocusChanged { f = it.hasFocus }
            .border(if (f) 4.dp else 0.dp, if (f) focusColor else Color.Transparent, RoundedCornerShape(10.dp))
    }
    if (LocalAtv.current) {
        // Apple-TV: Kachel hebt sich leicht, weißer Rahmen
        val za = minOf(1f + (zoom - 1f) * 2.2f, 1.09f)
        val scA by animateFloatAsState(if (f) za else 1f, tween(160), label = "atvZoom")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scA; scaleY = scA }
            .shadow(if (f) 24.dp else 0.dp, RoundedCornerShape(14.dp), clip = false, ambientColor = Color.Black, spotColor = Color.Black)
            .border(if (f) 4.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(14.dp))
    }
    if (LocalPremium.current) {
        // Flat: Kachel wächst deutlich, weißer Rahmen. Premium: Magenta-Rahmen mit leichtem Glow.
        val pure = !LocalFlat.current
        val premiumFocus = if (pure) Color(0xFFDECDF8) else Color.White
        val z = 1f + (zoom - 1f) * (if (pure) 1.45f else 1.6f)
        val scaleP by animateFloatAsState(if (f && !perf) z else 1f, tween(if (pure) 150 else 180), label = "focusZoomP")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scaleP; scaleY = scaleP }
            .shadow(if (pure && f && !perf) 16.dp else 0.dp, RoundedCornerShape(10.dp), clip = false,
                ambientColor = premiumFocus.copy(alpha = 0.75f), spotColor = premiumFocus)
            .border(if (f) 4.dp else 0.dp, if (f) premiumFocus else Color.Transparent, RoundedCornerShape(if (pure) 10.dp else 8.dp))
    }
    val glowK = LocalGlow.current
    if (LocalBlue.current) {
        val neon = LocalNeon.current
        val tint = if (neon) LocalAmbient.current else Color(0xFF7FA6FF)
        val zb = 1f + (zoom - 1f) * 1.8f
        val scaleB by animateFloatAsState(if (f && !perf) zb else 1f, tween(160), label = "focusZoomB")
        return@composed this.onFocusChanged { f = it.hasFocus }
            .zIndex(if (f) 1f else 0f)
            .graphicsLayer { scaleX = scaleB; scaleY = scaleB }
            .shadow(if (f && !perf) ((if (neon) 32f else 22f) * glowK).dp else 0.dp, RoundedCornerShape(14.dp), clip = false,
                ambientColor = tint, spotColor = tint)
            .border(if (f) 4.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(14.dp))
    }
    val scale by animateFloatAsState(if (f && !perf) zoom else 1f, animationSpec = tween(100), label = "focusZoom")
    val accent = MaterialTheme.colorScheme.primary
    this.onFocusChanged { f = it.hasFocus }
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .shadow(if (f && !perf) (18f * glowK).dp else 0.dp, RoundedCornerShape(14.dp), clip = false, ambientColor = accent, spotColor = accent)
        .border(if (f) 4.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(14.dp))
}

@Composable
fun App(vm: AppVM = viewModel()) {
    val activity = LocalContext.current as? Activity
    val lastBack = remember { longArrayOf(0L) }
    BackHandler {
        if (System.currentTimeMillis() - vm.swallowBackAt < 3500) { vm.swallowBackAt = 0L; return@BackHandler }
        if (vm.backToNav()) return@BackHandler
        if (!vm.back()) {
            val now = System.currentTimeMillis()
            if (now - lastBack[0] < 2500) activity?.finish()
            else {
                lastBack[0] = now
                vm.showNotice("Nochmal Zurück zum Beenden")
            }
        }
    }
    val mode = vm.designMode
    val perfFast = vm.perfMode
    val glow = MaterialTheme.colorScheme.primary
    val LocalGlowValue = LocalGlow.current
    val amb = LocalAmbient.current
    val glowA = when (mode) { "oled" -> 0.10f; "premium" -> 0.05f; "flat" -> 0.07f; "night" -> 0.08f; "neon" -> 0f; "shield" -> 0f; "midnight" -> 0f; "kino" -> 0f; "atv" -> 0f; else -> 0.26f }
    val blueA = when (mode) {
        "night" -> 0.55f
        "oled", "premium", "neon", "shield", "midnight", "atv", "kino" -> 0.0f
        else -> 0.16f
    }
    Box(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(
            when (mode) {
                "premium" -> listOf(Color(0xFF07050F), Color(0xFF020105), Color.Black)
                "oled" -> listOf(Color.Black, Color.Black)
                "night" -> listOf(Color(0xFF16277A), Color(0xFF0A1238), Color(0xFF040714))
                "neon" -> listOf(Color(0xFF0A0A14), Color(0xFF07070D))
                "shield" -> listOf(Color(0xFF03010F), Color(0xFF010103))
                "midnight" -> listOf(Color(0xFF070E2C), Color(0xFF040818), Color(0xFF02040C))
                "atv" -> listOf(Color(0xFF131318), Color(0xFF09090C), Color(0xFF040405))
                "kino" -> listOf(Color(0xFF0B1020), Color(0xFF070910), Color(0xFF04050A))
                else -> listOf(Color(0xFF0C0C13), Color(0xFF07070B))
            }))
        .drawBehind {
            if (!perfFast) {
                val gk = LocalGlowValue
                drawRect(Brush.radialGradient(listOf(glow.copy(alpha = glowA * gk), Color.Transparent),
                    center = Offset(size.width * 0.12f, 0f), radius = size.maxDimension * 0.6f))
                drawRect(Brush.radialGradient(listOf(Color(0xFF3B5BDB).copy(alpha = blueA * gk), Color.Transparent),
                    center = Offset(size.width, size.height), radius = size.maxDimension * 0.55f))
                if (mode == "midnight") {
                    val w = size.width; val h = size.height
                    drawRect(Brush.radialGradient(listOf(Color(0xFF2547B8).copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(w * 0.55f, 0f), radius = w * 0.6f))
                    drawRect(Brush.radialGradient(listOf(Color(0xFF6D28D9).copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(w, h * 0.55f), radius = w * 0.4f))
                    drawRect(Brush.radialGradient(listOf(Color(0xFFC2358F).copy(alpha = 0.30f), Color.Transparent),
                        center = Offset(0f, h), radius = w * 0.36f))
                    fun mcurve(x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, col: Color, a: Float, n: Int, sp: Float) {
                        for (i in 0 until n) {
                            val m = (n - 1) / 2f
                            val d = (i - m) * sp
                            val k = 1f - kotlin.math.abs(i - m) / n
                            val p = androidx.compose.ui.graphics.Path().apply {
                                moveTo(w * x0, h * (y0 + d)); cubicTo(w * x1, h * (y1 + d * 1.6f), w * x2, h * (y2 + d * 0.6f), w * x3, h * (y3 + d))
                            }
                            drawPath(p, col.copy(alpha = a * k), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.6f))
                        }
                    }
                    mcurve(0f, 0.86f, 0.05f, 0.80f, 0.10f, 0.95f, 0.20f, 1.03f, Color(0xFFD23C9E), 0.65f, 10, 0.010f)
                    mcurve(0f, 0.78f, 0.06f, 0.72f, 0.12f, 0.88f, 0.22f, 1.02f, Color(0xFF7B4DE0), 0.50f, 8, 0.010f)
                }
                if (mode == "kino") {
                    val w = size.width; val h = size.height
                    drawRect(Brush.radialGradient(listOf(Color(0xFF2A3560).copy(alpha = 0.35f), Color.Transparent), center = Offset(w * 0.72f, 0f), radius = w * 0.7f))
                    drawRect(Brush.radialGradient(listOf(Kino.a.copy(alpha = 0.20f), Color.Transparent), center = Offset(0f, h), radius = w * 0.34f))
                }
                if (mode == "shield") {
                    // Feste Violett-/Pink-Lichtverläufe wie im Entwurf
                    drawRect(Brush.radialGradient(listOf(Color(0xFFF801A3).copy(alpha = 0.07f), Color.Transparent),
                        center = Offset(size.width * 1.0f, size.height * 0.0f), radius = size.maxDimension * 0.42f))
                    drawRect(Brush.radialGradient(listOf(Color(0xFFB5127A).copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.0f, size.height * 1.0f), radius = size.maxDimension * 0.40f))
                    drawRect(Brush.radialGradient(listOf(Color(0xFFF801A3).copy(alpha = 0.07f), Color.Transparent),
                        center = Offset(size.width * 0.6f, size.height * 1.05f), radius = size.maxDimension * 0.35f))
                    // Seidige Lichtbänder: viele feine, sehr transparente Linien, links und unten links gebündelt
                    val w = size.width; val h = size.height
                    drawRect(Brush.horizontalGradient(listOf(Color(0xFF2C0127).copy(alpha = 0.55f), Color.Transparent), startX = 0f, endX = w * 0.22f))
                    val pink = Color(0xFFF801A3); val vio = Color(0xFFB50171)
                    fun silk(x0: Float, y0: Float, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, col: Color, a: Float, n: Int, sp: Float) {
                        for (i in 0 until n) {
                            val m = (n - 1) / 2f
                            val d = (i - m) * sp
                            val k = 1f - kotlin.math.abs(i - m) / n
                            val p = androidx.compose.ui.graphics.Path().apply {
                                moveTo(w * x0, h * (y0 + d)); cubicTo(w * x1, h * (y1 + d * 1.6f), w * x2, h * (y2 + d * 0.6f), w * x3, h * (y3 + d))
                            }
                            drawPath(p, col.copy(alpha = a * k), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.6f))
                        }
                    }
                    silk(0f, 0.80f, 0.08f, 0.72f, 0.16f, 0.96f, 0.30f, 1.03f, pink, 0.40f, 12, 0.012f)
                    silk(0f, 0.62f, 0.07f, 0.55f, 0.12f, 0.80f, 0.24f, 0.98f, vio, 0.30f, 10, 0.010f)
                    silk(0f, 0.20f, 0.06f, 0.05f, 0.12f, 0.12f, 0.20f, -0.02f, pink, 0.30f, 8, 0.010f)
                    silk(0.72f, -0.02f, 0.82f, 0.06f, 0.92f, 0.02f, 1f, 0.16f, vio, 0.20f, 8, 0.010f)
                }
                if (mode == "neon") {
                    // Weiche Farbwolken in der Farbe des fokussierten Posters
                    val k = 0.35f + 0.65f * gk
                    drawRect(Brush.radialGradient(listOf(amb.copy(alpha = 0.50f * k), Color.Transparent),
                        center = Offset(size.width * 0.80f, size.height * 0.16f), radius = size.maxDimension * 0.55f))
                    drawRect(Brush.radialGradient(listOf(shiftHue(amb, 45f).copy(alpha = 0.38f * k), Color.Transparent),
                        center = Offset(size.width * 0.96f, size.height * 0.82f), radius = size.maxDimension * 0.50f))
                    drawRect(Brush.radialGradient(listOf(shiftHue(amb, -60f).copy(alpha = 0.20f * k), Color.Transparent),
                        center = Offset(size.width * 0.22f, size.height * 1.02f), radius = size.maxDimension * 0.42f))
                }
            }
        }) {
        if (!vm.introDone) {
            IntroScreen(vm.designMode == "premium" || vm.designMode == "flat", vm.introSound, false) { vm.introDone = true }
        } else if (!vm.profilePicked) {
            ProfilePicker(vm)
        } else AnimatedContent(
            targetState = vm.stack.last(),
            transitionSpec = {
                // Beim Verlassen und Betreten des Players ohne Überblendung: fühlt sich schneller an
                if (perfFast || initialState is Screen.Play || targetState is Screen.Play)
                    (EnterTransition.None togetherWith ExitTransition.None)
                else (fadeIn(tween(120)) togetherWith fadeOut(tween(80)))
            },
            label = "screen"
        ) { s -> when (s) {
            Screen.Portals -> Shell(vm, "portals") { PortalsScreen(vm) }
            is Screen.Form -> FormScreen(vm, s.edit)
            Screen.Home -> Shell(vm, "home") { HomeScreen(vm) }
            is Screen.Browse -> Shell(vm, s.type) { BrowseScreen(vm, s.type) }
            is Screen.Seasons -> {
                val rows: List<Pair<String, () -> Unit>> = vm.seasons.map { se -> se.name to { vm.openSeason(se) } }
                SimpleList(s.title, rows)
            }
            is Screen.Episodes -> {
                val se = s.season
                val rows: List<Pair<String, () -> Unit>> = se.episodes.map { n ->
                    (if (vm.isSeen(se, n)) "✓  " else "") + "Episode $n" to { vm.playEpisode(se, n) }
                }
                SimpleList(se.name, rows)
            }
            Screen.ResumeList -> {
                val rows: List<Pair<String, () -> Unit>> = vm.resumeList.map { r ->
                    "${r.title}  ·  ${fmtTime(r.pos)}" to { vm.playResume(r) }
                }
                val empty: List<Pair<String, () -> Unit>> = listOf("Noch nichts angefangen" to { })
                SimpleList("Weiterschauen", if (rows.isEmpty()) empty else rows)
            }
            Screen.Guide -> Shell(vm, "epg") { GuideScreen(vm) }
            Screen.Favs -> Shell(vm, "fav") { FavsScreen(vm) }
            Screen.Watch -> Shell(vm, "watch") { WatchScreen(vm) }
            Screen.GlobalSearch -> Shell(vm, "search") { GlobalSearchScreen(vm) }
            Screen.Settings -> Shell(vm, "settings") { SettingsScreen(vm) }
            Screen.AppSettings -> SettingsScreen(vm)
            Screen.LogView -> LogScreen(vm)
            is Screen.Detail -> DetailScreen(vm, s.item)
            Screen.EditCats -> EditCatsScreen(vm)
            Screen.EditChans -> EditChansScreen(vm)
            Screen.DesignScale -> DesignScaleScreen(vm)
            Screen.ResumeAll -> Shell(vm, "resume") { ResumeAllView(vm) }
            Screen.HomeLayout -> HomeLayoutScreen(vm)
            is Screen.HomeAddRow -> {
                val rows: List<Pair<String, () -> Unit>> = vm.homeCatChoices.map { c -> c.title to { vm.addHomeCustom(s.type, c) } }
                val wait: List<Pair<String, () -> Unit>> = listOf("Lade Kategorien …" to { })
                SimpleList(if (s.type == "series") "Serien-Kategorie als Reihe wählen" else "Film-Kategorie als Reihe wählen",
                    if (rows.isEmpty()) wait else rows)
            }
            Screen.FavLists -> FavListsScreen(vm)
            is Screen.FavListEdit -> FavListEditScreen(vm, s.id)
            Screen.PhoneAdd -> PhoneAddScreen(vm)
            Screen.RemoteAccess -> RemoteAccessScreen(vm)
            Screen.Play -> PlayerScreen(vm)
        } }
        if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
        if (vm.introDone) {
            UpdateDialog(vm)
            ReminderDialog(vm)
            FavPickDialog(vm)
            ItemMenuDialog(vm)
            TrailerDialog(vm)
        }
        vm.notice?.let {
            Text(it, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
                    .background(Color(0xDD0D47A1), RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 8.dp))
        }
        vm.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(12.dp))
        }
    }
}

@Composable
fun ListRow(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(
        text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(12.dp)
    )
}

/** Listenzeile mit kleinem Symbol vor dem Text (z. B. Kategorien). */
@Composable
fun ListRowK(text: String, selected: Boolean, kind: String?, onClick: () -> Unit) {
    if (kind == null) { ListRow(text, selected, onClick); return }
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
        .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
        .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        GlowIcon(kind, 26.dp)
        Spacer(Modifier.width(10.dp))
        Text(text.trim(), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun SimpleList(title: String, rows: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(rows) { (label, act) -> ListRow(label, false, act) } }
    }
}

@Composable
fun PortalsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TOM’S TV", fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
            letterSpacing = 6.sp)
        Box(Modifier.padding(vertical = 6.dp).width(120.dp).height(2.dp).background(accent))
        Text("PORTALE · ALLE SIND AKTIV", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent),
            modifier = Modifier.align(Alignment.Start).padding(top = 6.dp, bottom = 6.dp))
        if (vm.portals.isEmpty()) {
            Text("Noch kein Portal eingetragen. Füge unten dein erstes Portal hinzu.", color = gray,
                modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).widthIn(max = 900.dp).fillMaxWidth()) {
            items(vm.portals, key = { it.id }) { p ->
                PortalRow(vm, p, if (p.id == vm.portals.first().id) Modifier.focusRequester(fr) else Modifier)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.tvFocus()) { Text("+ Portal") }
            Button(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) { Text("📱 Per Handy") }
            OutlinedButton(onClick = { vm.refreshAllPortals(true) }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
    }
}

@Composable
fun PortalRow(vm: AppVM, p: Portal, modifier: Modifier = Modifier) {
    var confirm by remember { mutableStateOf(false) }
    val host = remember(p.url) { runCatching { java.net.URL(p.url).host }.getOrDefault(p.url) }
    val st = vm.status[p.id]
    val statusText = when {
        st == null || st == "loading" -> "⏳ lädt …"
        st == "ok" -> "● aktiv"
        else -> "⚠ nicht erreichbar"
    }
    val statusColor = when {
        st == null || st == "loading" -> LocalMuted.current
        st == "ok" -> Color(0xFF69F0AE)
        else -> Color(0xFFFF8A80)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(modifier.weight(1f).tvFocus(1.02f).clip(RoundedCornerShape(16.dp))
            .glass(16.dp)
            .clickable { vm.push(Screen.Form(p)) }.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            GlowIcon("ticket", 40.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(host, fontSize = 13.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(statusText, fontSize = 13.sp, color = statusColor, maxLines = 1)
                val line = vm.portalLine(p)
                if (line.isNotBlank()) {
                    line.split("  ·  ").forEach { part ->
                        val isExp = part.startsWith("läuft") || part.startsWith("Abo abgelaufen")
                        Text(part, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            color = if (isExp && vm.portalWarn(p)) Color(0xFFFFB74D) else LocalMuted.current)
                    }
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        val pos = vm.portals.indexOfFirst { it.id == p.id }
        OutlinedButton(onClick = { vm.movePortal(p, -1) }, enabled = pos > 0,
            contentPadding = PaddingValues(horizontal = 14.dp), modifier = Modifier.tvFocus()) { Text("▲") }
        Spacer(Modifier.width(6.dp))
        OutlinedButton(onClick = { vm.movePortal(p, 1) }, enabled = pos in 0 until vm.portals.size - 1,
            contentPadding = PaddingValues(horizontal = 14.dp), modifier = Modifier.tvFocus()) { Text("▼") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.refreshSingle(p) }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
        Spacer(Modifier.width(6.dp))
        OutlinedButton(onClick = { vm.refreshEpg(p) }, contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.tvFocus()) { Text("EPG ⟳") }
        Spacer(Modifier.width(6.dp))
        OutlinedButton(onClick = { vm.toggleEpg(p) }, contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.tvFocus()) {
            Text(if (vm.epgEnabled(p)) "EPG an" else "EPG aus", color = if (vm.epgEnabled(p)) Color.Unspecified else Color(0xFFFF8A80))
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.push(Screen.Form(p)) }, modifier = Modifier.tvFocus()) { Text("Bearbeiten") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = {
            if (confirm) { vm.pendingFocus = neighborKey(vm.portals, pos) { "p:" + it.id }; vm.deletePortal(p) } else confirm = true
        }, modifier = Modifier.delFocus(vm, "p:" + p.id).tvFocus()) {
            Text(if (confirm) "Wirklich löschen?" else "Löschen")
        }
    }
}

/** Zeigt eine MAC-Adresse mit Doppelpunkten und Großbuchstaben an, ohne den getippten Text zu verändern (so lässt sich einzeln löschen). */
val MacVisual = VisualTransformation { t ->
    val raw = t.text
    val sb = StringBuilder()
    raw.forEachIndexed { i, c -> if (i > 0 && i % 2 == 0) sb.append(':'); sb.append(c.uppercaseChar()) }
    val map = object : OffsetMapping {
        override fun originalToTransformed(offset: Int): Int = if (offset <= 0) 0 else offset + (offset - 1) / 2
        override fun transformedToOriginal(offset: Int): Int = (offset - offset / 3).coerceIn(0, raw.length)
    }
    TransformedText(AnnotatedString(sb.toString()), map)
}

@Composable
fun Field(label: String, value: String, vt: VisualTransformation = VisualTransformation.None, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label, fontSize = 16.sp) }, singleLine = true, visualTransformation = vt,
        textStyle = LocalTextStyle.current.copy(fontSize = 18.sp),
        colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0x66FFFFFF)),
        modifier = Modifier.fillMaxWidth().tvFocus())
}

@Composable
fun FormScreen(vm: AppVM, edit: Portal?) {
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var url by remember { mutableStateOf(edit?.url ?: "http://") }
    var mac by remember { mutableStateOf((edit?.mac ?: "").filter { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }.take(12)) }
    var login by remember { mutableStateOf(edit?.login ?: "") }
    var pw by remember { mutableStateOf(edit?.password ?: "") }
    val fbs = remember {
        mutableStateListOf<Pair<String, String>>().also { l ->
            edit?.fallbacks?.forEach { f -> l.add(f.url to f.mac.filter { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }.take(12)) }
        }
    }
    var err by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.testResult = null }
    Column(Modifier.fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (edit == null) "Portal hinzufügen" else "Portal bearbeiten", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (edit != null) {
            val info = vm.portalLine(edit)
            if (info.isNotBlank()) Text(info, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                color = if (vm.portalWarn(edit)) Color(0xFFFFB74D) else LocalMuted.current)
        }
        Field("Name", name) { name = it }
        Field("Portal-URL (z. B. http://host/c/)", url) { url = it }
        Field("MAC-Adresse (z. B. 001A79XXXXXX, Doppelpunkte setzt die App)", mac, MacVisual) { v -> mac = v.filter { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }.take(12) }
        Field("Login (optional)", login) { login = it }
        Field("Passwort (optional)", pw) { pw = it }
        fbs.forEachIndexed { i, fb ->
            Text("Fallback " + (i + 1) + "  (leer = wie Hauptzugang)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = LocalMuted.current, modifier = Modifier.padding(top = 8.dp))
            Field("Fallback-URL " + (i + 1), fb.first) { v -> fbs[i] = v to fbs[i].second }
            Field("Fallback-MAC " + (i + 1) + " (001A79XXXXXX)", fb.second, MacVisual) { v ->
                fbs[i] = fbs[i].first to v.filter { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }.take(12)
            }
            OutlinedButton(modifier = Modifier.tvFocus(), onClick = { fbs.removeAt(i) }) { Text("Fallback " + (i + 1) + " entfernen") }
        }
        OutlinedButton(modifier = Modifier.tvFocus(), onClick = { fbs.add("http://" to "") }) { Text("＋ Fallback (URL + MAC) hinzufügen") }
        err?.let { Text(it, fontSize = 17.sp, color = Color(0xFFFF8A80)) }
        if (vm.testing) Text("⏳  Portal wird getestet … (kann bis zu einer Minute dauern)", color = LocalMuted.current)
        vm.testResult?.let {
            Text(it, fontSize = 17.sp, color = if (it.startsWith("✓")) Color(0xFF69F0AE) else Color(0xFFFF8A80))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(modifier = Modifier.tvFocus(), onClick = {
                val m = normMac(mac)
                val u = url.trim()
                when {
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        val fr = parseFallbacks(fbs.toList(), u, m)
                        if (fr.second != null) err = fr.second else {
                            err = null
                            vm.testPortal(Portal("test", name.trim().ifBlank { "Test" }, u, m, login.trim(), pw, fr.first))
                        }
                    }
                }
            }) { Text("🔍 Testen") }
            Button(modifier = Modifier.tvFocus(), onClick = {
                val m = normMac(mac)
                val u = url.trim()
                when {
                    name.isBlank() -> err = "Name fehlt"
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        val fr = parseFallbacks(fbs.toList(), u, m)
                        if (fr.second != null) err = fr.second else {
                            vm.savePortal(Portal(edit?.id ?: UUID.randomUUID().toString(), name.trim(), u, m, login.trim(), pw, fr.first))
                            vm.back()
                        }
                    }
                }
            }) { Text("Speichern") }
            OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Abbrechen") }
        }
    }
}

/** Hinweis auf der Startseite, wenn ein Abo in weniger als 14 Tagen abläuft oder abgelaufen ist. */
@Composable
fun ExpiryWarn(vm: AppVM) {
    val warn = vm.portals.filter { vm.portalWarn(it) }
    if (warn.isEmpty()) return
    Text("⚠ Abo läuft ab: " + warn.joinToString("   ·   ") { it.name + vm.portalShort(it) },
        fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFFFB74D),
        modifier = Modifier.padding(horizontal = homePad(), vertical = 6.dp))
}

@Composable
fun HomeHeaderTexts(vm: AppVM, greeting: String, gray: Color) {
    Text(if (vm.profiles.size > 1) greeting + ", " + vm.profileName() else greeting,
        fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont)
    Text("${vm.status.values.count { it == "ok" }} VON ${vm.portals.size} PORTALEN AKTIV", fontSize = 13.sp,
        letterSpacing = 3.sp, color = gray)
    if (vm.portals.isNotEmpty()) {
        Text(vm.portals.joinToString("    ") { p ->
            val st = vm.status[p.id]
            (if (st == "ok") "●" else if (st != null && st.startsWith("err")) "⚠" else "…") + " " + p.name + vm.portalShort(p)
        }, fontSize = 13.sp, color = gray, maxLines = 2, modifier = Modifier.padding(top = 2.dp))
    }
}

fun markText(st: Int, text: String): androidx.compose.ui.text.AnnotatedString =
    androidx.compose.ui.text.buildAnnotatedString {
        pushStyle(androidx.compose.ui.text.SpanStyle(
            color = if (st == 2) Color(0xFF4ADE80) else if (st == 1) Color(0xFFFFC857) else Color(0xFFD0605E),
            fontWeight = FontWeight.ExtraBold))
        append(if (st == 2) "✓  " else if (st == 1) "◐  " else "✗  ")
        pop()
        append(text)
    }

@Composable
fun HomeScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 5 -> "Gute Nacht"
        hour < 11 -> "Guten Morgen"
        hour < 18 -> "Guten Tag"
        else -> "Guten Abend"
    }
    val newList = vm.homeNew.ifEmpty { vm.homeCached }
    val hero = newList.take(5)
    var idx by remember { mutableIntStateOf(0) }
    var heroFocus by remember { mutableStateOf(false) }
    val hfm = androidx.compose.ui.platform.LocalFocusManager.current
    LaunchedEffect(hero.size) {
        while (hero.size > 1 && !vm.perfMode) {
            delay(8000)
            // Solange der Fokus auf dem Banner liegt, bleibt es stehen (zum Lesen)
            if (!heroFocus && !vm.heroVideoOn) idx = (idx + 1) % hero.size
        }
    }
    var heroShown by remember { mutableStateOf(true) }
    LaunchedEffect(idx) { heroShown = false; delay(30); heroShown = true }
    val heroAlpha by animateFloatAsState(if (heroShown || vm.perfMode) 1f else 0f, tween(450), label = "heroFade")
    val fr = remember { FocusRequester() }
    LaunchedEffect(hero.isNotEmpty()) {
        if (hero.isNotEmpty()) {
            delay(150)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.heroFocusReq) {
        if (vm.heroFocusReq > 0 && hero.isNotEmpty()) {
            runCatching { vm.rowState("home").scrollToItem(0) }
            delay(80)
            runCatching { fr.requestFocus() }
        }
    }
    val secs0 = vm.homeSections().filter { it !in vm.homeOff }.distinct()
    // Shield-Design: Live-TV-Reihe direkt unter dem Banner
    val secs = if (LocalShield.current && !LocalAtv.current && "pop" in secs0) listOf("pop") + (secs0 - "pop") else secs0
    val atvHome = LocalAtv.current
    val kinoHome = LocalKino.current
    LazyColumn(Modifier.fillMaxSize(), state = vm.rowState("home")) {
        if (!atvHome) item(key = "head") {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { HomeHeaderTexts(vm, greeting, gray) }
            if (vm.profiles.size > 1) {
                OutlinedButton(onClick = { vm.nextProfile() }, modifier = Modifier.padding(end = 12.dp).tvFocus()) {
                    Avatar(vm.profileAvatar(), 28.dp, initialOf(vm.profileName()))
                    Spacer(Modifier.width(8.dp))
                    Text(vm.profileName())
                }
            }
            Clock()
        }
        }
        item(key = "hero") {
        if (hero.isNotEmpty()) {
            Box(Modifier.alpha(heroAlpha).onFocusChanged { heroFocus = it.hasFocus }.onPreviewKeyEvent { e ->
                // Pfeile links/rechts wechseln zuerst zwischen den Knöpfen (Ansehen, Trailer, Merkliste);
                // erst vom äußersten Knopf aus wird das Banner gewechselt. CH+/CH-, Seite hoch/runter und Vor-/Zurückspulen wechseln immer.
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val n = hero.size
                when (e.key) {
                    Key.DirectionRight -> {
                        if (vm.heroBtn in 0..1) { hfm.moveFocus(androidx.compose.ui.focus.FocusDirection.Right); true }
                        else if (n > 1) { idx = (idx + 1) % n; true } else false
                    }
                    Key.DirectionLeft -> {
                        if (vm.heroBtn >= 1) { hfm.moveFocus(androidx.compose.ui.focus.FocusDirection.Left); true }
                        else if (n > 1 && idx > 0) { idx -= 1; true } else false
                    }
                    Key.ChannelDown, Key.PageDown, Key.MediaFastForward, Key.MediaNext -> if (n > 1) { idx = (idx + 1) % n; true } else false
                    Key.ChannelUp, Key.PageUp, Key.MediaRewind, Key.MediaPrevious -> if (n > 1) { idx = (idx - 1 + n) % n; true } else false
                    Key.Menu -> { vm.toggleWatchOf(hero[idx % n], "vod"); true }
                    else -> false
                }
            }) { HeroBanner(vm, hero[idx % hero.size], idx % hero.size, hero.size, fr) }
        } else {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (vm.portals.isEmpty()) {
                    Text("Noch kein Portal eingetragen.", color = gray)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("+ Portal hinzufügen")
                        }
                        OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) {
                            Text("📱 Per Handy")
                        }
                    }
                } else {
                    Text(
                        if (vm.allLoading) "Portale werden verbunden …"
                        else "Keine Inhalte gefunden. Prüfe unter Portale, ob die Portale erreichbar sind.",
                        color = gray
                    )
                    if (!vm.allLoading) {
                        vm.portals.filter { (vm.status[it.id] ?: "").startsWith("err") }.forEach { p ->
                            Text("⚠ " + p.name + ": " + (vm.status[p.id] ?: "").removePrefix("err:"), fontSize = 13.sp,
                                color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 4.dp))
                        }
                        Button(onClick = { vm.refreshAllPortals(true) }, modifier = Modifier.padding(top = 10.dp).tvFocus()) {
                            Text("⟳ Erneut versuchen")
                        }
                    }
                }
            }
        }
        }
        if (kinoHome) item(key = "ktiles") { KinoTiles(vm) }
        item(key = "expwarn") { ExpiryWarn(vm) }
        item(key = "brand") { if (LocalBlue.current && !LocalShield.current) BrandTiles(vm) }
        items(secs, key = { it }) { sid ->
            run {
                when {
                    sid == "eps" -> {
                        if (vm.newEpisodes.isNotEmpty()) {
                            SectionHeader("Neue Folgen bei deinen Serien")
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.newEpisodes) { pr -> MiniPoster(pr.first) { vm.openHomeItem(pr.first, "series") } }
                            }
                        }
                    }
                    sid == "new" -> {
                        if (newList.isNotEmpty()) {
                            SectionHeader("Neu im Angebot", "Alle anzeigen") { vm.goTo("vod") }
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(newList) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
                            }
                        }
                    }
                    sid == "byportal" -> {
                        if (vm.homeNewByPortal.size > 1) {
                            val shownIds = vm.homeNew.map { it.id }.toSet()
                            for ((pname, plist0) in vm.homeNewByPortal) {
                                // Nur zeigen, was nicht schon oben unter „Neu im Angebot“ steht
                                val plist = plist0.filter { it.id !in shownIds }
                                if (plist.size < 3) continue
                                SectionHeader("Neu bei " + pname)
                                LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(plist) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
                                }
                            }
                        }
                    }
                    sid == "watch" -> {
                        val watch = remember(vm.profileId) { vm.watchFor("vod") + vm.watchFor("series") }
                        if (watch.isNotEmpty()) {
                            SectionHeader("Meine Merkliste", "Alle anzeigen") { vm.goTo("watch") }
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(watch) { w -> MiniPoster(w) { vm.openHomeItem(w, vm.watchType(w)) } }
                            }
                        }
                    }
                    sid == "recent" -> {
                        if (vm.recentChans.isNotEmpty()) {
                            SectionHeader("Zuletzt gesehen")
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.recentChans) { c -> ChannelTile(c) { vm.openRecent(c) } }
                            }
                        }
                    }
                    sid == "live" || sid.startsWith("live:") -> LiveNowRow(vm, sid)
                    sid == "pop" && LocalMid.current -> { MidLiveRow(vm); MidTopRow(vm); EveningRow(vm) }
                    sid == "pop" -> {
                        if (vm.homeChannels.isNotEmpty()) {
                            SectionHeader("Live TV – Beliebte Sender", "Alle anzeigen") { vm.goTo("itv") }
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.homeChannels) { c ->
                                    if ((LocalFlat.current || LocalShield.current) && !LocalPerf.current) LiveTile(vm, c) { vm.openHomeItem(c, "itv") }
                                    else ChannelTile(c) { vm.openHomeItem(c, "itv") }
                                }
                            }
                        }
                                            if (LocalAtv.current) EveningRow(vm)
                    }
                    sid == "resume" -> {
                        if (vm.resumeList.isNotEmpty()) {
                            SectionHeader("Weiterschauen", if (LocalAtv.current) "Alle anzeigen" else null) { vm.goTo("resume") }
                            LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(vm.resumeList) { r ->
                                    if (LocalAtv.current) { AtvResumeCard(vm, r); return@items }
                                    Column(Modifier.width(190.dp).tvFocus(1.05f).clip(RoundedCornerShape(12.dp))
                                        .background(Color(0x22FFFFFF)).clickable { vm.playResume(r) }.padding(12.dp)) {
                                        Text("⏯  ${fmtTime(r.pos)}", fontSize = if (LocalPremium.current) 15.sp else 13.sp, color = gray)
                                        Text(cleanTitle(r.title), fontSize = if (LocalPremium.current) 17.sp else 14.sp, fontWeight = FontWeight.Medium, maxLines = 2,
                                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                    sid.startsWith("c:") -> CustomHomeRow(vm, sid)
                }
            }
        }
        item(key = "end") { Spacer(Modifier.height(24.dp)) }
    }
}

// ---------- Startseite einrichten und Jetzt live ----------
/** Design „Mitternacht“: Live-TV als Kategorie-Kacheln (Alle Sender, Sport, Film, Musik …). */
@Composable
fun MidLiveRow(vm: AppVM) {
    val cats = vm.homeCats
    if (vm.homeChannels.isEmpty() && cats.isEmpty()) return
    SectionHeader("Live TV", "Alle anzeigen") { vm.goTo("itv") }
    LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        item(key = "all") { CatTile("Alle Sender", "tv", 0) { vm.goTo("itv") } }
        itemsIndexed(cats, key = { _, c -> c.id }) { i, c -> CatTile(tileName(c.title), tileKind(c.title), i + 1) { vm.openLiveCat(c) } }
    }
}

/** Kürzt Präfixe wie „DE |“ vom Kategorienamen. */
private val reTilePfx = Regex("^[A-Za-z]{2,3}\\s*[|:]\\s*")
fun tileName(t: String): String = t.replace(reTilePfx, "").trim().ifEmpty { t }

/** Anzeigetitel für Filme/Serien: ohne Sprachkürzel („DE - “, „(DE)“) und mit „Titel (2026)“ statt „Titel - 2026“. Der Originalname bleibt unverändert. */
private val reLangPfx = Regex("^(DE|EN|GER|AT|CH)\\s*[-–|:]\\s+")
private val reLangPar = Regex("\\s*\\((DE|EN|GER|AT|CH)\\)")
private val reLangMid = Regex("\\s+(DE|EN)(?=\\s+[-–]\\s)")
private val reDashYear = Regex("\\s+[-–]\\s+((19|20)\\d{2})$")
fun cleanTitle(t: String): String {
    var x = t.trim().replace(reLangPfx, "").replace(reLangPar, "").replace(reLangMid, "")
    x = x.replace(reDashYear) { " (" + it.groupValues[1] + ")" }
    return x.trim().ifEmpty { t }
}

/** Datum 2026-11-18 → 18.11.2026 (andere Texte bleiben unverändert). */
private val reIsoDate = Regex("^(\\d{4})-(\\d{2})-(\\d{2})$")
fun niceDate(s: String): String = reIsoDate.find(s.trim())?.let { it.groupValues[3] + "." + it.groupValues[2] + "." + it.groupValues[1] } ?: s

/** Symbol für eine Live-Kategorie nach Stichwörtern im Namen. */
fun tileKind(title: String): String {
    val t = title.lowercase()
    catKind(title)?.let { return it }
    return when {
        listOf("catchup", "replay", "mediathek", "archiv", "timeshift").any { it in t } -> "resume"
        listOf("regional", "lokal", "local", "international", "world", "welt").any { it in t } -> "ticket"
        listOf("doku", "docu", "wissen", "history").any { it in t } -> "news"
        listOf("premium", "vip", "favorit").any { it in t } -> "star"
        else -> "tv"
    }
}

@Composable
fun CatTile(title: String, kind: String, idx: Int, onClick: () -> Unit) {
    val pal = listOf(0xFF2A0F4AL to 0xFF8A2A9EL, 0xFF06154AL to 0xFF2A5AD0L, 0xFF0A1A4AL to 0xFF1E3E9AL,
        0xFF3A0F4AL to 0xFFC2358FL, 0xFF0B2A5AL to 0xFF4A8AE0L, 0xFF3A0F5AL to 0xFF9A3AD0L)
    val (c0, c1) = pal[idx % pal.size]
    val kino = LocalKino.current
    val kb = Color(0xFF0E1630)
    val kEnd = androidx.compose.ui.graphics.lerp(kb, Kino.a, 0.30f + 0.08f * (idx % 3))
    Box(Modifier.width(176.dp).height(88.dp).tvFocus(1.05f).clip(RoundedCornerShape(14.dp))
        .background(Brush.linearGradient(if (kino) listOf(kb, kEnd) else listOf(Color(c0), Color(c1))))
        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
        .clickable(onClick = onClick)) {
        androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
            val p = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, size.height * 0.75f)
                cubicTo(size.width * 0.3f, size.height * 0.4f, size.width * 0.6f, size.height * 1.1f, size.width, size.height * 0.55f)
            }
            drawPath(p, Color.White.copy(alpha = 0.18f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
        }
        Column(Modifier.align(Alignment.Center).padding(bottom = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            FlatIcon(kind, 34.dp, Color.White.copy(alpha = 0.92f))
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp, start = 8.dp, end = 8.dp))
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(sPink))
            Spacer(Modifier.width(4.dp))
            Text("Live", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LiveNowRow(vm: AppVM, sid: String) {
    val list = remember(sid, vm.favTick, vm.homeTick, vm.homeChannels) { vm.liveItems(sid) }
    if (list.isEmpty()) return
    SectionHeader(if (sid == "live") "Jetzt live" else "Jetzt live – " + vm.listName(sid.removePrefix("live:")))
    LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.id }) { ch -> LiveTile(vm, ch) { vm.openLiveFrom(sid, list, ch) } }
    }
}

@Composable
fun LiveTile(vm: AppVM, ch: Item, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    if (LocalAtv.current) {
        Column(Modifier.width(250.dp).tvFocus(1.05f).glass(18.dp).clickable(onClick = onClick).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(ch.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(now?.title ?: "…", fontSize = 13.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("● LIVE", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF5A5F), maxLines = 1)
            }
            val prA = now?.let { vm.epgProgress(it) }
            if (prA != null) LinearProgressIndicator(progress = { prA }, modifier = Modifier.padding(top = 10.dp).fillMaxWidth().height(3.dp),
                color = Color.White, trackColor = Color(0x33FFFFFF))
            else Spacer(Modifier.height(13.dp))
        }
        return
    }
    if (LocalShield.current) {
        Column(Modifier.width(176.dp).tvFocus(1.05f).glass(14.dp).clickable(onClick = onClick).padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.height(54.dp).fillMaxWidth())
            Text(ch.name, fontSize = if (LocalPremium.current) 16.sp else 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp))
            Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(now?.title ?: "", fontSize = 13.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f))
                Text("● Live", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (LocalAtv.current) Color(0xFFFF5A5F) else sPink, maxLines = 1)
            }
            val pr0 = now?.let { vm.epgProgress(it) }
            if (pr0 != null) LinearProgressIndicator(progress = { pr0 }, modifier = Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp))
            else Spacer(Modifier.height(3.dp))
        }
        return
    }
    Column(Modifier.width(210.dp).tvFocus(1.05f).glass(14.dp).clickable(onClick = onClick).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(8.dp))
            Text(ch.name, fontSize = if (LocalPremium.current) 16.sp else 13.sp, fontWeight = FontWeight.SemiBold, maxLines = if (LocalPremium.current) 2 else 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false))
            if (LocalShield.current) {
                Spacer(Modifier.width(6.dp))
                Text("● Live", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF4D6D), maxLines = 1)
            }
        }
        Text(now?.title ?: "…", fontSize = if (LocalPremium.current) 15.sp else 13.sp, color = LocalMuted.current, maxLines = 2,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp).height(34.dp))
        val pr = now?.let { vm.epgProgress(it) }
        if (pr != null) {
            LinearProgressIndicator(progress = { pr }, modifier = Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp))
        } else Spacer(Modifier.height(3.dp))
    }
}

@Composable
fun CustomHomeRow(vm: AppVM, sid: String) {
    val hc = vm.homeCustom.firstOrNull { it.id == sid } ?: return
    LaunchedEffect(sid, vm.homeTick) { vm.loadCustom(sid) }
    val l = vm.customItems[sid] ?: return
    if (l.isEmpty()) return
    SectionHeader(hc.title)
    LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(l) { m -> MiniPoster(m) { vm.openHomeItem(m, hc.type) } }
    }
}

@Composable
fun HomeLayoutScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val sections = vm.homeSections()
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("STARTSEITE EINRICHTEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Text("Reihen ein- oder ausschalten und mit ▲ ▼ verschieben. Eigene Reihen kommen aus Film- oder Serien-Kategorien.",
            fontSize = 13.sp, color = gray, modifier = Modifier.padding(vertical = 10.dp))
        sections.forEachIndexed { i, id ->
            androidx.compose.runtime.key(id) {
                val on = id !in vm.homeOff
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(14.dp).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { vm.toggleHomeSection(id) },
                        modifier = Modifier.delFocus(vm, "h:" + id, if (i == 0) fr else null).tvFocus()) { Text(if (on) "✓" else "✗", fontWeight = FontWeight.ExtraBold, color = if (on) Color(0xFF4ADE80) else Color(0xFFD0605E)) }
                    Spacer(Modifier.width(12.dp))
                    Text(vm.homeLabel(id), fontSize = 16.sp, color = if (on) Color.Unspecified else gray,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.moveHomeSection(id, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = { vm.moveHomeSection(id, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                    if (id.startsWith("c:")) {
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = {
                            vm.pendingFocus = neighborKey(sections, i) { "h:" + it }
                            vm.removeHomeCustom(id)
                        }, modifier = Modifier.tvFocus()) { Text("🗑") }
                    }
                }
            }
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { vm.openHomeAdd("vod") }, modifier = Modifier.tvFocus()) { Text("＋ Reihe aus Filme-Kategorie") }
            Button(onClick = { vm.openHomeAdd("series") }, modifier = Modifier.tvFocus()) { Text("＋ Reihe aus Serien-Kategorie") }
        }
    }
}

// ---------- Favoritenlisten ----------
@Composable
fun FavPickDialog(vm: AppVM) {
    val item = vm.favPick ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(item.id) { delay(200); runCatching { fr.requestFocus() } }
    val tick = vm.favTick
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(460.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(24.dp)) {
            Text("IN LISTE MERKEN", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            val all = listOf(FavList("", "Favoriten")) + vm.favLists
            all.forEachIndexed { i, l ->
                val inL = tick >= 0 && vm.inList(l.id, item)
                OutlinedButton(onClick = { vm.toggleInList(l.id, item) },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        .then(if (i == 0) Modifier.focusRequester(fr) else Modifier).tvFocus()) {
                    Text((if (inL) "★  " else "☆  ") + l.name)
                }
            }
            OutlinedButton(onClick = { val n = vm.createFavList(); vm.toggleInList(n.id, item) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).tvFocus()) { Text("＋ Neue Liste anlegen und hinzufügen") }
            Button(onClick = { vm.favPick = null }, modifier = Modifier.padding(top = 14.dp).tvFocus()) { Text("Fertig") }
        }
    }
}

/** Kontextmenü zu einem Film oder einer Serie (langer OK-Druck oder Menü-Taste in der Titelliste). */
@Composable
fun ItemMenuDialog(vm: AppVM) {
    val item = vm.ctxItem ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(item.id) { delay(200); runCatching { fr.requestFocus() } }
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(460.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(24.dp)) {
            Text("MENÜ", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Text(item.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
            OutlinedButton(onClick = { vm.toggleFav(item) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).focusRequester(fr).tvFocus()) {
                Text(if (vm.isFav(item)) "★  Favorit entfernen" else "☆  Zu Favoriten", fontSize = 17.sp)
            }
            OutlinedButton(onClick = { vm.toggleWatch(item) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp).tvFocus()) {
                Text(if (vm.isWatch(item)) "✓  Aus Merkliste entfernen" else "＋  Merkliste", fontSize = 17.sp)
            }
            if (vm.browseType == "vod") {
                OutlinedButton(onClick = { vm.toggleMovieSeen(item) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp).tvFocus()) {
                    Text(if (vm.isMovieSeen(item)) "✓  Gesehen (zum Entfernen drücken)" else "○  Als gesehen markieren", fontSize = 17.sp)
                }
            }
            OutlinedButton(onClick = { vm.ctxItem = null; vm.push(Screen.Detail(item)) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).tvFocus()) { Text("Details öffnen", fontSize = 17.sp) }
            Button(onClick = { vm.ctxItem = null }, modifier = Modifier.padding(top = 14.dp).tvFocus()) { Text("Schließen") }
        }
    }
}

@Composable
fun FavListsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    var renaming by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf<String?>(null) }
    val tf = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    LaunchedEffect(renaming) { if (renaming != null) { delay(150); runCatching { tf.requestFocus() } } }
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("FAVORITENLISTEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Text("Sender in mehrere Listen sortieren, zum Beispiel Kinder, Sport oder Abends. Beim Favorisieren (OK lange drücken) fragt die App, in welche Liste.",
            fontSize = 13.sp, color = gray, modifier = Modifier.padding(vertical = 10.dp))
        val all = listOf(FavList("", "Favoriten")) + vm.favLists
        all.forEachIndexed { i, l ->
            androidx.compose.runtime.key(l.id) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(14.dp).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (renaming == l.id) {
                        OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true,
                            modifier = Modifier.weight(1f).focusRequester(tf))
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { vm.renameFavList(l.id, text); renaming = null }, modifier = Modifier.tvFocus()) { Text("OK") }
                    } else {
                        Column(Modifier.weight(1f).padding(start = 8.dp)) {
                            Text((if (l.id.isEmpty()) "★ " else "") + l.name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Text(vm.listItems(l.id).size.toString() + " Sender", fontSize = 13.sp, color = gray)
                        }
                        Button(onClick = { vm.push(Screen.FavListEdit(l.id)) },
                            modifier = Modifier.delFocus(vm, "fl:" + l.id, if (i == 0) fr else null).tvFocus()) { Text("Sender ›") }
                        if (l.id.isNotEmpty()) {
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { text = l.name; renaming = l.id }, modifier = Modifier.tvFocus()) { Text("✎") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { vm.moveFavList(l.id, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = { vm.moveFavList(l.id, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                            Spacer(Modifier.width(6.dp))
                            OutlinedButton(onClick = {
                                if (confirmDel == l.id) {
                                    vm.pendingFocus = neighborKey(all, i) { "fl:" + it.id }
                                    vm.deleteFavList(l.id); confirmDel = null
                                } else confirmDel = l.id
                            }, modifier = Modifier.tvFocus()) { Text(if (confirmDel == l.id) "Wirklich?" else "🗑") }
                        }
                    }
                }
            }
        }
        Button(onClick = { val n = vm.createFavList(); text = n.name; renaming = n.id },
            modifier = Modifier.padding(top = 14.dp).tvFocus()) { Text("＋ Neue Liste") }
    }
}

@Composable
fun FavListEditScreen(vm: AppVM, id: String) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    val list = remember(vm.favTick, id) { vm.listItems(id) }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(vm.listName(id).uppercase(), fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("Reihenfolge der Sender in dieser Liste", fontSize = 13.sp, color = gray)
                }
                OutlinedButton(onClick = { vm.sortListAz(id) }, modifier = Modifier.delFocus(vm, "f:top", fr).tvFocus()) { Text("A–Z sortieren") }
            }
            if (list.isEmpty()) Text("Noch keine Sender. Favorisiere Sender mit OK lange drücken.", color = gray)
        }
        itemsIndexed(list, key = { _, c -> c.id }) { idx, c ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).glass(12.dp).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text((idx + 1).toString(), fontSize = 13.sp, color = gray, modifier = Modifier.width(34.dp))
                AsyncImage(model = c.logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(12.dp))
                Text(c.name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { vm.moveInList(id, c, -1) }, modifier = Modifier.tvFocus()) { Text("▲") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { vm.moveInList(id, c, 1) }, modifier = Modifier.tvFocus()) { Text("▼") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = {
                    vm.pendingFocus = neighborKey(list, idx) { "f:" + it.id } ?: "f:top"
                    vm.removeFromList(id, c)
                }, modifier = Modifier.delFocus(vm, "f:" + c.id).tvFocus()) { Text("✕") }
            }
        }
    }
}

@Composable
fun Tile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(170.dp).tvFocus(1.08f).clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3A0F18), Color(0xFF14080B))))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 46.sp)
        Spacer(Modifier.height(10.dp))
        Text(label.uppercase(), fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun GlobalSearchScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(200); runCatching { fr.requestFocus() } }
    LazyColumn(Modifier.fillMaxSize().inContent(vm, "search"), state = vm.rowState("search")) {
        item(key = "q") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                if (LocalAtv.current) {
                    // Apple-TV-Stil: ruhiges, abgerundetes Feld, nur Ring bei Fokus, keine Vergrößerung
                    var ff by remember { mutableStateOf(false) }
                    Box(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(14.dp))
                        .background(Color(if (ff) 0x30FFFFFF else 0x1CFFFFFF))
                        .border(if (ff) 2.dp else 1.dp, if (ff) Color.White else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 18.dp), contentAlignment = Alignment.CenterStart) {
                        if (vm.gsQuery.isEmpty()) Text("Suche in allen Portalen: Sender, Filme, Serien", fontSize = 16.sp, color = gray, maxLines = 1)
                        androidx.compose.foundation.text.BasicTextField(
                            value = vm.gsQuery, onValueChange = { vm.gsQuery = it }, singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 20.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { vm.globalSearch(vm.gsQuery) }),
                            modifier = Modifier.fillMaxWidth().focusRequester(fr).onFocusChanged { ff = it.isFocused })
                    }
                    Spacer(Modifier.width(12.dp))
                    Button(onClick = { vm.globalSearch(vm.gsQuery) }, modifier = Modifier.height(54.dp).tvFocus(), shape = RoundedCornerShape(14.dp)) { Text("Suchen", fontSize = 16.sp) }
                } else {
                OutlinedTextField(
                    value = vm.gsQuery, onValueChange = { vm.gsQuery = it },
                    label = { Text("Suche in allen Portalen: Sender, Filme, Serien") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.globalSearch(vm.gsQuery) }),
                    modifier = Modifier.weight(1f).focusRequester(fr).tvFocus()
                )
                Spacer(Modifier.width(10.dp))
                Button(onClick = { vm.globalSearch(vm.gsQuery) }, modifier = Modifier.tvFocus()) { Text("Suchen") }
                }
            }
        }
        if (vm.searchHist.isNotEmpty() && !vm.gsBusy) item(key = "hist") {
            LazyRow(contentPadding = PaddingValues(horizontal = 24.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                item { Text("ZULETZT", fontSize = 13.sp, letterSpacing = 3.sp, color = gray, modifier = Modifier.padding(end = 4.dp)) }
                items(vm.searchHist) { h ->
                    OutlinedButton(onClick = { vm.gsQuery = h; vm.globalSearch(h) }, modifier = Modifier.tvFocus(),
                        shape = RoundedCornerShape(50), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                        Text(h, fontSize = 13.sp, maxLines = 1)
                    }
                }
                item { TextButton(onClick = { vm.clearSearchHist() }, modifier = Modifier.tvFocus()) { Text("✕ Leeren", fontSize = 13.sp, color = gray) } }
            }
        }
        item(key = "state") {
            if (vm.gsBusy) Text("Suche läuft …", color = gray, modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
            else if (vm.gsDone && vm.gsChannels.isEmpty() && vm.gsMovies.isEmpty() && vm.gsSeries.isEmpty())
                Text("Nichts gefunden.", color = gray, modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
        }
        if (vm.gsChannels.isNotEmpty()) item(key = "chs") {
            Column {
                SectionHeader("Sender (" + vm.gsChannels.size + ")")
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.gsChannels) { c -> ChannelTile(c) { vm.openSearchChannel(c) } }
                }
            }
        }
        if (vm.gsMovies.isNotEmpty()) item(key = "mov") {
            Column {
                SectionHeader("Filme (" + vm.gsMovies.size + ")")
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.gsMovies) { it0 -> MiniPoster(it0) { vm.openHomeItem(it0, "vod") } }
                }
            }
        }
        if (vm.gsSeries.isNotEmpty()) item(key = "ser") {
            Column {
                SectionHeader("Serien (" + vm.gsSeries.size + ")")
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.gsSeries) { it0 -> MiniPoster(it0) { vm.openHomeItem(it0, "series") } }
                }
            }
        }
        item(key = "end") { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun BrowseScreen(vm: AppVM, type: String) {
    DisposableEffect(Unit) { onDispose { vm.stopPreview() } }
    val pageFm = androidx.compose.ui.platform.LocalFocusManager.current
    Row(Modifier.fillMaxSize()) {
        CategoryPane(vm, type)
        Column(Modifier.weight(1f).fillMaxHeight().onFocusChanged { if (it.hasFocus) vm.leftFocus = null }) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.queryText,
                    onValueChange = { vm.queryText = it; if (type == "itv") vm.search(it) },
                    label = { Text("Suche") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(vm.queryText) }),
                    modifier = Modifier.weight(1f).tvFocus()
                )
                if (type == "itv") {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.guideDirect = false; vm.push(Screen.Guide) }, modifier = Modifier.tvFocus()) { Text("Programm") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.openEditChannels() }, modifier = Modifier.tvFocus()) { Text("Kanäle") }
                }
                Spacer(Modifier.width(8.dp))
                if (type != "itv") {
                    OutlinedButton(onClick = { vm.toggleEditMode() }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.editMode) "Fertig" else "Ausblenden")
                    }
                    Spacer(Modifier.width(8.dp))
                }
                OutlinedButton(onClick = { vm.push(Screen.EditCats) }, modifier = Modifier.tvFocus()) { Text("Kategorien") }
            }
            if (vm.editMode && type != "itv") Text("AUSBLENDEN-MODUS: OK blendet einen Eintrag aus oder wieder ein. Beenden mit Fertig.",
                fontSize = 13.sp, color = LocalMuted.current, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            if (type != "itv" && vm.selCat?.endsWith(":resume") != true) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val l = vm.shownItems()
                        if (vm.editMode) vm.showNotice("Erst „Fertig“ drücken")
                        else if (l.isEmpty()) vm.showNotice("Noch keine Titel geladen")
                        else vm.openItem(l.random())
                    }, modifier = Modifier.tvFocus()) {
                        Text("Überrasch mich", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { vm.cycleSort() }, modifier = Modifier.tvFocus()) {
                        Text("Sortierung: " + vm.sortLabel() + " ⟳", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { vm.cycleQual() }, modifier = Modifier.tvFocus()) {
                        Text("Qualität: " + vm.qualLabel() + " ⟳", fontSize = 13.sp)
                    }
                    if (type == "vod") {
                        OutlinedButton(onClick = { vm.toggleHideSeen() }, modifier = Modifier.tvFocus()) {
                            Text("Gesehene ausblenden: " + (if (vm.hideSeen) "an" else "aus") + " ⟳", fontSize = 13.sp)
                        }
                    }
                }
            }
            // CH+/CH- (oder Seite hoch/runter) springen seitenweise: im Raster 4 Reihen, in der Senderliste 8 Zeilen
            // ▶ aus den Kategorien kehrt zum zuletzt benutzten Sender bzw. Film zurück
            val contentMem = remember { FocusMemory() }
            CompositionLocalProvider(LocalFocusMemory provides contentMem) {
            Box(Modifier.weight(1f).fillMaxWidth().enterAt(contentMem) { vm.itemFocus }.onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val dir = when (e.key) {
                    Key.ChannelDown, Key.PageDown -> androidx.compose.ui.focus.FocusDirection.Down
                    Key.ChannelUp, Key.PageUp -> androidx.compose.ui.focus.FocusDirection.Up
                    else -> null
                }
                if (dir == null) false else { repeat(if (type == "itv") 8 else 4) { pageFm.moveFocus(dir) }; true }
            }) {
                if (type != "itv" && vm.selCat?.endsWith(":resume") == true) {
                    ResumeListView(vm)
                } else if (type == "itv") {
                    // Fester Schlüssel je Sender: Der Fokus bleibt beim Nachladen und bei EPG-Updates auf seinem Sender
                    val chItems = vm.items
                    val chKeys = remember(chItems, chItems.size) {
                        val seen = HashMap<String, Int>()
                        chItems.map { e -> val n = seen[e.id] ?: 0; seen[e.id] = n + 1; if (n == 0) e.id else e.id + "#" + n }
                    }
                    LazyColumn(state = vm.listState, modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        itemsIndexed(chItems, key = { i, e -> chKeys.getOrElse(i) { e.id + "@" + i } }) { _, ch -> ChannelRow(vm, ch) }
                    }
                } else {
                    val last by remember { derivedStateOf { vm.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 } }
                    val shown = vm.shownItems()
                    LaunchedEffect(last, shown.size, vm.hasMore) {
                        if (vm.hasMore && last >= shown.size - 18) vm.loadMore()
                    }
                    // Feste Schlüssel je Film: Beim Nachladen oder Neusortieren bleibt der Cursor auf seinem Film
                    val gridKeys = remember(shown) {
                        val seen = HashMap<String, Int>()
                        shown.map { e -> val n = seen[e.id] ?: 0; seen[e.id] = n + 1; if (n == 0) e.id else e.id + "#" + n }
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), state = vm.gridState,
                        modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        itemsIndexed(shown, key = { i, _ -> gridKeys[i] }) { _, entry -> PosterCard(vm, entry) }
                    }
                    if (vm.busyList) Text("Lade …", Modifier.align(Alignment.BottomCenter).padding(8.dp))
                }
                if (vm.items.isEmpty() && !vm.busyList && !vm.loading && vm.selCat?.endsWith(":resume") != true) Text("Keine Einträge", Modifier.align(Alignment.Center))
            }
            }
        }
    }
}

@Composable
fun ChannelRow(vm: AppVM, ch: Item) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).itemFocus(vm, "b:" + ch.id).tvFocus(1.02f)
        .glass(12.dp).favKey { vm.toggleFav(ch) }
        .combinedClickable(onClick = { vm.openItem(ch) }, onLongClick = { vm.toggleFav(ch) }).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(6.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text((if (vm.isFavAny(ch)) "★ " else "") + ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 13.sp, color = LocalMuted.current,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                vm.epgProgress(now)?.let { p ->
                    LinearProgressIndicator(progress = { p },
                        modifier = Modifier.padding(top = 5.dp).fillMaxWidth().height(3.dp))
                }
            }
        }
    }
}

@Composable
fun PosterCard(vm: AppVM, entry: Item) {
    val hidden = vm.editMode && entry.id in vm.hiddenItems
    var pcFocus by remember { mutableStateOf(false) }
    Box(Modifier.padding(6.dp)) {
        Box(Modifier.alpha(if (hidden) 0.35f else 1f).itemFocus(vm, "b:" + entry.id).tvFocus(1.06f)
            .onFocusChanged { pcFocus = it.hasFocus; if (it.hasFocus) vm.focusAmbient(entry.logo ?: entry.backdrop) }
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF222A33)).ctxKey { vm.ctxItem = entry }
            .combinedClickable(onClick = { vm.openItem(entry) }, onLongClick = { vm.ctxItem = entry })) {
            val pctx = LocalContext.current
            val pperf = LocalPerf.current
            val req = remember(entry.logo, pperf) {
                coil.request.ImageRequest.Builder(pctx).data(entry.logo).size(300, 450).crossfade(if (pperf) 0 else 120).allowRgb565(pperf).build()
            }
            AsyncImage(model = req, contentDescription = entry.name, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            QualityBadges(entry.name, Modifier.align(Alignment.TopEnd).padding(6.dp))
            if (vm.browseType == "vod" && ("mv|" + entry.cmd) in vm.seenKeys) {
                Text("✓", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
                        .background(Color(0xCC1E9E5A), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
            }
            if (pcFocus || hidden || vm.isFav(entry) || entry.logo.isNullOrBlank()) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
                .padding(start = 10.dp, end = 10.dp, top = 46.dp, bottom = 10.dp)) {
                Text((if (hidden) "✗ " else if (vm.isFav(entry)) "★ " else "") + cleanTitle(entry.name),
                    maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = if (LocalPremium.current) 17.sp else 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val mac = vm.portal?.mac ?: ""
    val ds = remember {
        SmartHttpFactory().setCompat(vm.compat && vm.isLive).setUserAgent(vm.streamUserAgent()).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(if (vm.isLive) 6_000 else if (NetState.weak) 14_000 else 10_000)
            .setReadTimeoutMs(if (vm.isLive) 8_000 else if (NetState.weak) 22_000 else 15_000)
            .setDefaultRequestProperties(vm.streamHeaders())
    }
    // Streams mit Containerfehlern: einmal mit TS-Erkennung (wie bei Live) neu versuchen
    val tsFlags = remember { booleanArrayOf(false) }
    var vodRetries by remember { mutableIntStateOf(0) }
    var archiveMenu by remember { mutableStateOf(false) }
    val exo = remember {
        val selector = DefaultTrackSelector(ctx)
        val maxQ = vm.qualityMode != "auto"
        val forceHigh = vm.qualityMode == "max"
        if (maxQ) {
            // Immer die höchste Bild- und Tonqualität nehmen, die das Gerät kann (nicht an die Bildschirmgröße gebunden).
            selector.setParameters(
                selector.buildUponParameters()
                    .setForceHighestSupportedBitrate(forceHigh)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setConstrainAudioChannelCountToDeviceCapabilities(false)
                    .build()
            )
        }
        if (vm.fourKHelp) {
            // Tunneling gibt es nur über den Track-Selector (DefaultTrackSelector.Parameters)
            selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(true).build())
        }
        if (vm.audioMode == "stereo") {
            selector.setParameters(selector.buildUponParameters()
                .setMaxAudioChannelCount(2).setConstrainAudioChannelCountToDeviceCapabilities(true).build())
        }
        val rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        if (vm.decoderMode == "sw") {
            rf.setMediaCodecSelector(MediaCodecSelector { mime, secure, tunneling ->
                MediaCodecUtil.getDecoderInfos(mime, secure, tunneling).sortedBy { it.hardwareAccelerated }
            })
        }
        if (vm.fourKHelp) rf.forceEnableMediaCodecAsynchronousQueueing()
        ExoPlayer.Builder(ctx, rf)
            .setTrackSelector(selector)
            // Größerer Puffer: ruhigeres Bild bei 4K und schwankendem Netz
            .setLoadControl(if (!vm.isLive) buildVodLoadControl() else if (vm.compat) DefaultLoadControl.Builder().build() else buildLoadControl(vm.isLive, if (NetState.weak && vm.bufferMode == "fast") "balanced" else if (NetState.weak && !vm.isLive) "stable" else if (NetState.weak) "balanced" else vm.bufferMode))
            // Richtiger Audio-Modus für Filme (Surround, Lautstärke, Fokus)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(
                DefaultMediaSourceFactory(
                    ds,
                    // Schnellerer Start und ruhigeres Bild bei MPEG-TS-Sendern
                    object : androidx.media3.extractor.ExtractorsFactory {
                        private fun f(): DefaultExtractorsFactory =
                            if ((vm.compat || !vm.isLive) && !tsFlags[0]) DefaultExtractorsFactory()
                            else DefaultExtractorsFactory().setTsExtractorFlags(
                                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                        override fun createExtractors(): Array<androidx.media3.extractor.Extractor> = f().createExtractors()
                        override fun createExtractors(uri: android.net.Uri, responseHeaders: Map<String, List<String>>): Array<androidx.media3.extractor.Extractor> =
                            f().createExtractors(uri, responseHeaders)
                    }
                ).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(if (NetState.weak) 10 else 6))
            ).build().apply {
                playWhenReady = true
                // Tonspur: Deutsch bevorzugen, sonst Standard des Senders
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setPreferredAudioLanguages(*(if (vm.audioLangNow().isNotEmpty()) arrayOf(vm.audioLangNow()) else arrayOf("de", "deu", "ger")))
                    .apply {
                        if (vm.textLangNow() == "off") setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                        else if (vm.textLangNow().isNotEmpty()) setPreferredTextLanguage(vm.textLangNow())
                    }
                    .build()
                if (maxQ) {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                        .setMaxVideoBitrate(Int.MAX_VALUE)
                        .setMaxAudioBitrate(Int.MAX_VALUE)
                        .setMaxAudioChannelCount(Int.MAX_VALUE)
                        .clearViewportSizeConstraints()
                        .build()
                }
            }
    }
    var retries by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf(false) }
    var audioMenu by remember { mutableStateOf(false) }
    var xray by remember { mutableStateOf(false) }
    fun closeXray() { xray = false; exo.playWhenReady = true }
    var infoOn by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var qualityText by remember { mutableStateOf("") }
    var skipped by remember(vm.playUrl) { mutableStateOf(false) }
    var controls by remember { mutableStateOf(false) }
    var liveBar by remember { mutableStateOf(false) }
    var epgSel by remember { mutableIntStateOf(0) }
    val barFr = remember { FocusRequester() }
    var ctrlTick by remember { mutableIntStateOf(0) }
    val ctrlFr = remember { FocusRequester() }
    // Schnelleres Spulen: 10 s, bei wiederholtem Drücken 30 s, dann 60 s
    val seekState = remember { longArrayOf(0L, 0L) }
    // Live pausieren / zurückspulen
    var liveBehind by remember { mutableLongStateOf(0L) }
    var livePaused by remember { mutableStateOf(false) }
    var audioSess by remember { mutableIntStateOf(exo.audioSessionId) }
    val enh = remember { arrayOfNulls<android.media.audiofx.LoudnessEnhancer>(1) }
    fun goLive() {
        if (exo.isCurrentMediaItemSeekable && exo.isCurrentMediaItemLive) {
            exo.seekToDefaultPosition()
            exo.playWhenReady = true
            liveBehind = 0L
        } else vm.reload()
    }
    fun liveSeek(dir: Int) {
        if (!exo.isCurrentMediaItemSeekable) {
            vm.showNotice("Zurückspulen geht bei diesem Sender nicht, nur Pause")
            return
        }
        if (dir > 0 && liveBehind <= 10_000L) { goLive(); return }
        exo.seekTo((exo.currentPosition + dir * 10_000L).coerceAtLeast(0L))
        liveBehind = (liveBehind - dir * 10_000L).coerceAtLeast(0L)
    }
    fun stepSeek(dir: Int) {
        val now = System.currentTimeMillis()
        seekState[1] = if (now - seekState[0] < 1200) seekState[1] + 1 else 0L
        seekState[0] = now
        val sec = when {
            seekState[1] < 2 -> 10
            seekState[1] < 5 -> 30
            else -> 60
        }
        val dur = exo.duration
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + dir * sec * 1000L).coerceIn(0L, max))
        vm.showNotice((if (dir < 0) "⏪ " else "") + sec + " s" + (if (dir > 0) " ⏩" else ""))
    }
    val showSkip by remember {
        derivedStateOf {
            val end = if (vm.isEpisode) vm.introEndMs() else 0L
            vm.isEpisode && !skipped && !vm.noIntro() && posMs >= 3_000L && posMs <= (if (end > 0L) end - 2_000L else 240_000L)
        }
    }
    var hintOn by remember(vm.playUrl) { mutableStateOf(false) }
    LaunchedEffect(showSkip) {
        if (showSkip) { hintOn = true; delay(10_000); hintOn = false } else hintOn = false
    }
    val nextLbl = if (vm.isEpisode) vm.nextLabel() else null
    val creditsNow = nextLbl != null && durMs > 300_000L && posMs >= durMs - 90_000L
    val nextFr = remember { FocusRequester() }
    val fr = remember { FocusRequester() }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                AppLog.add("Wiedergabefehler (" + vm.playTitle + "): " + error.errorCodeName)
                if (error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES) {
                    if (!vm.isLive) vm.savePosition(exo.currentPosition, exo.duration)
                }
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    exo.seekToDefaultPosition()
                    exo.prepare()
                    return
                }
                val http = error.cause as? HttpDataSource.InvalidResponseCodeException
                if (http != null) AppLog.add("HTTP " + http.responseCode + " von " + (http.dataSpec.uri.host ?: "?"))
                // Server lehnt ab: erst andere Kennungen probieren, jeweils mit frischem Link
                if (error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS && vm.nextHeaderMode()) {
                    AppLog.add("Neuer Versuch mit anderer Anfrage-Kennung (Stufe " + vm.headerStage() + ")")
                    vm.reload()
                    return
                }
                if (vm.isLive) {
                    // Gesperrt (z. B. 461): nicht lange wiederholen. Erst andere Variante im selben Portal, dann nächster Zugang (Fallback)
                    val sessHttp = (http?.responseCode ?: vm.lastHttpErr) in intArrayOf(401, 403, 429, 451, 461)
                    when {
                        sessHttp && vm.tryAlternate(true) -> retries = 0
                        sessHttp && vm.canSwitchAccount() -> {
                            vm.tryNextAccountAsync { ok -> if (ok) { retries = 0 } else { if (!vm.tryAlternate()) vm.reload() } }
                        }
                        retries < 2 -> {
                            retries++
                            if (retries == 2 && http != null) vm.showNotice(playErrorText(error, vm.connHintFor(vm.playChId)), 7000L)
                            vm.reload()
                        }
                        vm.tryAlternate() -> retries = 0
                        retries < 5 -> { retries++; vm.reload() }
                        else -> vm.error = playErrorText(error, vm.connHintFor(vm.playChId))
                    }
                } else {
                    val parseErr = error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
                    val netErr = http != null || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED
                    when {
                        parseErr && !tsFlags[0] -> {
                            tsFlags[0] = true
                            AppLog.add("Neuer Versuch mit TS-Erkennung")
                            vm.savePosition(exo.currentPosition, exo.duration)
                            vm.reload()
                        }
                        netErr && vodRetries < 2 -> {
                            vodRetries++
                            AppLog.add("Neuer Versuch mit frischem Link (" + vodRetries + "/2)")
                            vm.showNotice("Verbindung unterbrochen, neuer Versuch …")
                            vm.savePosition(exo.currentPosition, exo.duration)
                            vm.reload()
                        }
                        else -> vm.error = playErrorText(error, vm.connHintFor(vm.playChId))
                    }
                }
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { audioSess = audioSessionId }
            private var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING && last == Player.STATE_READY) {
                    AppLog.add("Puffert nach: " + vm.playTitle)
                    vm.reportStall()
                }
                last = state
                if (state == Player.STATE_READY) {
                    retries = 0
                    vodRetries = 0
                }
                if (state == Player.STATE_ENDED && !vm.isLive) vm.onEnded()
            }
        }
        exo.addListener(l)
        val netAl = object : AnalyticsListener {
            // Was der Player beim Laden wirklich vom Server bekommt (sonst unter stillen Wiederholungen versteckt)
            override fun onLoadError(
                eventTime: AnalyticsListener.EventTime, loadEventInfo: androidx.media3.exoplayer.source.LoadEventInfo,
                mediaLoadData: androidx.media3.exoplayer.source.MediaLoadData, error: java.io.IOException, wasCanceled: Boolean
            ) {
                if (!vm.isLive) return
                val code = (error as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                if (code != null) vm.lastHttpErr = code
                if (!vm.loadErrLogOk()) return
                AppLog.add("Player-Ladefehler: " + error.javaClass.simpleName + (if (code != null) " HTTP $code" else "") +
                    " " + (error.message ?: "").take(50) + " · " + loadEventInfo.uri.host + " · " + loadEventInfo.loadDurationMs +
                    " ms, " + loadEventInfo.bytesLoaded + " B")
            }

            override fun onBandwidthEstimate(
                eventTime: AnalyticsListener.EventTime, totalLoadTimeMs: Int, totalBytesLoaded: Long, bitrateEstimate: Long
            ) { vm.reportBandwidth(bitrateEstimate) }

            override fun onVideoInputFormatChanged(
                eventTime: AnalyticsListener.EventTime, format: Format, decoderReuseEvaluation: DecoderReuseEvaluation?
            ) {
                if (vm.hdrOut == "auto") {
                    val ci = format.colorInfo
                    val hdr = ci != null && (ci.colorTransfer == C.COLOR_TRANSFER_ST2084 || ci.colorTransfer == C.COLOR_TRANSFER_HLG)
                    setWindowHdr(ctx, hdr)
                }
                if (vm.afrMode == "off" || (vm.isLive && vm.afrMode != "all")) return
                if (format.frameRate > 0f) matchRefreshRate(ctx, format.frameRate)
            }
        }
        exo.addAnalyticsListener(netAl)
        if (vm.hdrOut == "on") setWindowHdr(ctx, true)
        onDispose {
            exo.removeAnalyticsListener(netAl)
            resetRefreshRate(ctx)
            setWindowHdr(ctx, false)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
            exo.removeListener(l)
            exo.playWhenReady = false
            // Freigeben erst nach dem nächsten Bild: die Startseite erscheint sofort
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ runCatching { exo.release() } }, 300)
        }
    }

    // Netz-Anpassung: bei schwachem Netz Bildgröße und Datenrate deckeln, bei gutem Netz wieder freigeben
    val weakNow = vm.effectiveWeak()
    var weakApplied by remember { mutableStateOf(false) }
    var weakBanner by remember { mutableStateOf(false) }
    LaunchedEffect(weakNow, vm.netMode) {
        if (weakNow && vm.netMode == "auto") { weakBanner = true; delay(6000); weakBanner = false } else weakBanner = false
    }
    LaunchedEffect(weakNow, exo) {
        val sel = exo.trackSelector as? DefaultTrackSelector ?: return@LaunchedEffect
        if (weakNow) {
            sel.setParameters(sel.buildUponParameters()
                .setMaxVideoSize(1280, 720).setMaxVideoBitrate(4_000_000)
                .setForceHighestSupportedBitrate(false).setExceedVideoConstraintsIfNecessary(true).build())
            weakApplied = true
        } else if (weakApplied) {
            sel.setParameters(sel.buildUponParameters()
                .clearVideoSizeConstraints().setMaxVideoBitrate(Int.MAX_VALUE)
                .setForceHighestSupportedBitrate(vm.qualityMode == "max").build())
            weakApplied = false
        }
    }

    LaunchedEffect(vm.playUrl, vm.playNonce) {
        vm.playUrl?.let { u ->
            ds.setUserAgent(vm.streamUserAgent())
            ds.setDefaultRequestProperties(vm.streamHeaders())
            val pos = if (vm.isLive) 0L else vm.resumePos()
            if (pos > 0) {
                exo.setMediaItem(MediaItem.fromUri(u), pos)
                vm.showNotice("Weiter bei ${fmtTime(pos)}")
            } else exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare(); exo.play()
        }
    }
    LaunchedEffect(Unit) { fr.requestFocus() }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration
            if (vm.isEpisode && durMs > 60_000L && posMs >= durMs - 1_500L && exo.playbackState != Player.STATE_BUFFERING) vm.onEnded()
            qualityText = qualityLabel(exo)
            livePaused = vm.isLive && !exo.playWhenReady
            if (livePaused) liveBehind += 1000L
            delay(1000)
        }
    }
    BackHandler(enabled = audioMenu) { audioMenu = false }
    LaunchedEffect(archiveMenu) {
        if (!archiveMenu) { delay(150); runCatching { fr.requestFocus() } }
    }
    BackHandler(enabled = xray) { closeXray() }
    BackHandler(enabled = controls) { controls = false }
    BackHandler(enabled = liveBar) { liveBar = false }
    BackHandler(enabled = detail && vm.isLive) { detail = false }
    LaunchedEffect(detail, vm.playChId) {
        epgSel = 0
        if (detail && vm.isLive) vm.loadEpg(vm.playChId, 8)
    }
    LaunchedEffect(liveBar) {
        if (liveBar) {
            delay(150)
            runCatching { barFr.requestFocus() }
        } else {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(liveBar, ctrlTick) {
        if (liveBar) {
            delay(8_000)
            liveBar = false
        }
    }
    LaunchedEffect(vm.playChId, vm.playNonce) { liveBehind = 0L }
    // Lautstärke-Boost über den Audio-Effekt des Systems
    LaunchedEffect(audioSess, vm.boostDb) {
        runCatching { enh[0]?.release() }
        enh[0] = null
        if (vm.boostDb > 0 && audioSess != C.AUDIO_SESSION_ID_UNSET && audioSess != 0) {
            runCatching {
                val e = android.media.audiofx.LoudnessEnhancer(audioSess)
                e.setTargetGain(vm.boostDb * 100)
                e.setEnabled(true)
                enh[0] = e
            }
        }
    }
    DisposableEffect(Unit) { onDispose { runCatching { enh[0]?.release() } } }
    LaunchedEffect(controls) {
        if (controls) {
            delay(150)
            runCatching { if (creditsNow) nextFr.requestFocus() else ctrlFr.requestFocus() }
        } else {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    // Leiste blendet sich nach 7 Sekunden ohne Bedienung aus
    LaunchedEffect(controls, ctrlTick) {
        if (controls) {
            delay(7_000)
            controls = false
        }
    }
    LaunchedEffect(vm.playUrl) {
        if (vm.autoSkipIntro && vm.isEpisode && !vm.noIntro() && vm.playUrl != null && vm.resumePos() == 0L) {
            var waited = 0
            while (exo.playbackState != Player.STATE_READY && waited < 15_000) {
                delay(250)
                waited += 250
            }
            delay(1200)
            if (exo.currentPosition < 120_000) {
                exo.seekTo(vm.skipTarget(exo.currentPosition))
                skipped = true
            }
        }
    }
    LaunchedEffect(audioMenu) {
        if (!audioMenu) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.chanPanel) {
        if (!vm.chanPanel) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.playChId, vm.isLive) {
        while (vm.isLive) { vm.loadEpg(vm.playChId); delay(60_000) }
    }
    // Läuft ein Sender 40 Sekunden stabil, zählt das als gute Quelle
    LaunchedEffect(vm.playChId, vm.playNonce) {
        if (vm.isLive) {
            delay(40_000)
            if (exo.isPlaying) vm.markGood(vm.playChId)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
        }
    }
    // Neu starten, sobald sich Taste/Titel/Detail ändert: wird die Detail-Ansicht geschlossen, läuft die Ausblend-Zeit erneut
    LaunchedEffect(tick, vm.playTitle, detail, controls, liveBar, audioMenu, vm.chanPanel) {
        info = true
        if (detail) return@LaunchedEffect
        delay(vm.infoSeconds * 1000L)
        info = false
    }

    // Wächter: Bei Hängern im Live-TV neuen Link holen. Erkennt
    //  - Puffern oder Standbild der Position (> 8 s)
    //  - Stream-Ende (Server trennt, Token abgelaufen)
    //  - eingefrorenes Bild bei weiterlaufendem Ton (Decoder hängt, > 10 s)
    LaunchedEffect(Unit) {
        var stuck = 0
        var stalls = 0
        var lastPos = -1L
        var frozen = 0
        var lastFrames = -1
        var fails = 0
        var lastCh = ""
        while (true) {
            delay(2000)
            if (!vm.isLive || vm.loading) { stuck = 0; frozen = 0; lastFrames = -1; continue }
            if (vm.playChId != lastCh) { lastCh = vm.playChId; fails = 0 }
            val pos = exo.currentPosition
            val st = exo.playbackState
            val bad = exo.playWhenReady &&
                (st == Player.STATE_BUFFERING || st == Player.STATE_ENDED ||
                    (st == Player.STATE_READY && pos == lastPos))
            lastPos = pos
            // Bild eingefroren, Ton läuft weiter
            var videoFrozen = false
            if (!vm.fourKHelp && exo.isPlaying && exo.currentTracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) {
                val frames = exo.videoDecoderCounters?.let { it.ensureUpdated(); it.renderedOutputBufferCount } ?: -1
                if (frames >= 0 && frames == lastFrames) frozen++ else frozen = 0
                lastFrames = frames
                videoFrozen = frozen >= 5
            } else { frozen = 0; lastFrames = -1 }
            if (exo.isPlaying && !videoFrozen) { stalls = 0; fails = 0; vm.lastHttpErr = 0; vm.noteHdrOk(); vm.noteAcctOk() }
            if (bad) stuck++ else stuck = 0
            // Server hat den Stream beendet: nicht lange warten, sofort neuen Link holen
            val ended = exo.playWhenReady && st == Player.STATE_ENDED
            if (stuck >= 3 && vm.memoryTight()) {
                AppLog.add("Speicher knapp: Zwischenspeicher geleert")
                vm.trimMemory()
            }
            // Server nimmt die Verbindung an, liefert aber nichts: erst andere Anfrage-Kennungen probieren (wie andere Apps)
            if (stuck >= 4 && !ended && !videoFrozen && st == Player.STATE_BUFFERING && vm.nextHeaderMode()) {
                AppLog.add("Stream liefert keine Daten: andere Anfrage-Kennung (Stufe " + vm.headerStage() + ")")
                stuck = 0; frozen = 0; lastFrames = -1
                runCatching { exo.stop(); exo.clearMediaItems() }
                vm.reload()
                continue
            }
            if (stuck >= 4 || ended || videoFrozen) {
                AppLog.add(if (videoFrozen) "Bild eingefroren (Ton läuft): Decoder wird neu gestartet" else if (ended) "Stream vom Anbieter beendet: sofort neuer Link" else "Live-Stream hängt (" + st + "): neuer Link")
                if (!videoFrozen) vm.noteDrop(vm.playChId)
                stuck = 0; frozen = 0; lastFrames = -1
                stalls++
                // Decoder und Verbindung komplett freigeben, dann mit frischem Link neu starten
                // Nur bei eingefrorenem Bild den Decoder hart freigeben. Sonst bleibt das letzte Bild stehen, bis der neue Link läuft.
                runCatching { exo.stop(); exo.clearMediaItems() }
                vm.markBad(vm.playChId)
                val altLimit = if (vm.lastHttpErr in intArrayOf(401, 403, 429, 451, 461)) 2 else 6
                // Reihenfolge: andere Variante im selben Portal, dann nächster Zugang (Fallback), dann anderes Portal
                if (stalls >= altLimit && (vm.tryAlternate(true) || vm.tryNextAccount() || vm.tryAlternate())) stalls = 0 else {
                    vm.reload()
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
        // Zurück lange halten = direkt zur Startseite
        if (e.key == Key.Back && e.nativeKeyEvent.repeatCount > 0) {
            vm.swallowBackAt = System.currentTimeMillis()
            if (vm.stack.size > 1) vm.goTo("home")
            return@onKeyEvent true
        }
        if (vm.chanPanel || audioMenu || controls || liveBar || xray || archiveMenu) return@onKeyEvent false
        tick++
        val dg = digitOf(e.key)
        if (vm.isLive && dg >= 0) {
            vm.digit(dg)
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_LAST_CHANNEL) ||
                e.key == Key(android.view.KeyEvent.KEYCODE_PROG_RED))) {
            vm.toggleLast()
            return@onKeyEvent true
        }
        if (e.key == Key.MediaPlay) { exo.playWhenReady = true; return@onKeyEvent true }
        if (e.key == Key.MediaPause) { exo.playWhenReady = false; return@onKeyEvent true }
        if (vm.isLive && e.key == Key.MediaRewind) { liveSeek(-1); return@onKeyEvent true }
        if (vm.isLive && e.key == Key.MediaFastForward) { liveSeek(1); return@onKeyEvent true }
        // Bild-/Zoom-Taste der Fernbedienung: Bildformat umschalten (Original, Zoom, Gestreckt)
        val picKey = e.nativeKeyEvent.keyCode
        if (picKey == android.view.KeyEvent.KEYCODE_ZOOM_IN || picKey == android.view.KeyEvent.KEYCODE_ZOOM_OUT ||
            picKey == android.view.KeyEvent.KEYCODE_PICTSYMBOLS || picKey == 255) {
            vm.cyclePic()
            vm.showNotice("Bild: " + vm.picLabel())
            return@onKeyEvent true
        }
        // Farbtasten der Strong-Fernbedienung: Grün = Ton/Untertitel, Gelb/Info = Infos bzw. Bedienleiste, Blau/Guide = Senderliste
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_GREEN)) { audioMenu = true; return@onKeyEvent true }
        if (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_YELLOW) || e.key == Key(android.view.KeyEvent.KEYCODE_INFO)) {
            if (vm.isLive) detail = !detail else controls = true
            return@onKeyEvent true
        }
        if (vm.isLive && (e.key == Key(android.view.KeyEvent.KEYCODE_PROG_BLUE) || e.key == Key(android.view.KeyEvent.KEYCODE_GUIDE))) {
            vm.openChannelPanel()
            return@onKeyEvent true
        }
        // Mini-EPG: bei geöffneter Detail-Ansicht mit Links/Rechts Sendungen wählen, OK = Erinnerung
        if (vm.isLive && detail) {
            val up = vm.upcomingEpg(vm.playChId)
            when (e.key) {
                Key.DirectionLeft -> { epgSel = (epgSel - 1).coerceAtLeast(0); return@onKeyEvent true }
                Key.DirectionRight -> { epgSel = (epgSel + 1).coerceAtMost((up.size - 1).coerceAtLeast(0)); return@onKeyEvent true }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                    val prog = up.getOrNull(epgSel)
                    val ch = vm.currentChannel()
                    if (prog != null && ch != null && prog.startTs > System.currentTimeMillis() / 1000) vm.toggleReminder(ch, prog)
                    else detail = false
                    return@onKeyEvent true
                }
                else -> { }
            }
        }
        if (vm.numberBuffer.isNotEmpty() && (e.key == Key.DirectionCenter || e.key == Key.Enter)) {
            vm.commitNumber()
            return@onKeyEvent true
        }
        when (e.key) {
            Key.DirectionUp, Key.ChannelUp -> if (vm.isLive) { detail = false; vm.zap(1); true } else false
            Key.DirectionDown, Key.ChannelDown -> if (vm.isLive) { detail = false; vm.zap(-1); true } else false
            Key.DirectionLeft, Key.MediaRewind ->
                if (!vm.isLive) { stepSeek(-1); true } else { vm.openChannelPanel(); true }
            Key.DirectionRight, Key.MediaFastForward ->
                if (!vm.isLive) { stepSeek(1); true } else { audioMenu = true; true }
            Key.Menu -> if (vm.isLive) { vm.openChannelPanel(); true } else { audioMenu = true; true }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                if (vm.isLive) {
                    if (e.key == Key.MediaPlayPause) exo.playWhenReady = !exo.playWhenReady
                    else if (!exo.playWhenReady) exo.playWhenReady = true
                    else if (liveBehind > 2_000L) goLive()
                    else liveBar = true
                }
                else if (e.key == Key.MediaPlayPause) exo.playWhenReady = !exo.playWhenReady
                else controls = true
                true
            }
            else -> {
                // Unbekannte Tasten im Fehlerprotokoll festhalten, damit sie später belegt werden können
                val kcode = e.nativeKeyEvent.keyCode
                if (e.nativeKeyEvent.repeatCount == 0 && kcode !in intArrayOf(4, 19, 20, 21, 22, 23, 66, 82))
                    AppLog.add("Taste im Player: Code " + kcode + " (" + android.view.KeyEvent.keyCodeToString(kcode) + ")")
                false
            }
        }
    }) {
        AndroidView(factory = { c ->
            PlayerView(c).apply {
                useController = false
                isFocusable = false
                isFocusableInTouchMode = false
                keepScreenOn = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = exo
            }
        }, modifier = Modifier.fillMaxSize(), update = { v ->
            v.resizeMode = when (vm.picMode) {
                1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        })
        if (vm.isLive && (livePaused || liveBehind > 2_000L) && !vm.chanPanel && !audioMenu) {
            Text(
                if (livePaused) "⏸  Live pausiert  (+" + liveBehind / 1000 + " s)  ·  OK = weiter"
                else "⏪  " + liveBehind / 1000 + " s hinter Live  ·  OK = zurück zu Live",
                fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 28.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 10.dp))
        }
        if ((info || detail) && !vm.chanPanel && !controls) InfoPanel(vm, detail, posMs, durMs, qualityText, Modifier.align(Alignment.BottomCenter), epgSel)
        if (liveBar && vm.isLive && !vm.chanPanel && !audioMenu) {
            LiveBar(vm, exo, barFr, Modifier.align(Alignment.BottomCenter),
                onTick = { ctrlTick++ },
                onAudio = { liveBar = false; audioMenu = true },
                onInfo = { liveBar = false; detail = true },
                onArchive = if ((vm.currentChannel()?.arch ?: 0) > 0) ({ liveBar = false; archiveMenu = true }) else null)
        }
        if (controls && !vm.isLive && !vm.chanPanel && !audioMenu) {
            PlayerControls(exo, posMs, durMs, showSkip, ctrlFr, Modifier.align(Alignment.BottomCenter), nextLbl, nextFr, { vm.playNext() },
                onTick = { ctrlTick++ },
                onSkipIntro = {
                    exo.seekTo(vm.skipTarget(exo.currentPosition))
                    skipped = true
                    controls = false
                },
                onNoIntro = { vm.setNoIntro(); controls = false },
                onAudio = { controls = false; audioMenu = true },
                onXray = { exo.playWhenReady = false; xray = true; controls = false })
        }
        if (xray && !vm.isLive) XRayPanel(vm, Modifier.align(Alignment.BottomCenter)) { closeXray() }
        if (vm.chanPanel) ChannelPanel(vm, Modifier.align(Alignment.CenterStart))
        if (audioMenu) AudioMenu(exo, vm, infoOn, { infoOn = !infoOn }) { audioMenu = false }
        if (archiveMenu) vm.currentChannel()?.let { ach ->
            ArchiveMenu(vm, ach, { archiveMenu = false }) { e ->
                archiveMenu = false
                vodRetries = 0
                vm.playArchive(ach, e)
            }
        }
        if (infoOn) StreamInfo(vm, exo, qualityText, Modifier.align(Alignment.TopStart))
        if (weakNow && vm.netMode == "auto") {
            if (weakBanner) {
                Text("📶 Schwaches Netz – sparsamer Modus", fontSize = 13.sp, color = Color.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(24.dp)
                        .background(Color(0x99000000), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 6.dp))
            } else {
                Text("📶", fontSize = 14.sp, modifier = Modifier.align(Alignment.TopEnd).padding(24.dp).alpha(0.7f))
            }
        }
        if (vm.numberBuffer.isNotEmpty()) {
            Text(vm.numberBuffer, fontSize = 64.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(32.dp)
                    .background(Color(0x99000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 8.dp))
        }
        vm.upNext?.let { nxt ->
            Text("Nächste Folge in 5 s:  $nxt     (Zurück = abbrechen)", fontSize = 16.sp, color = Color.White,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
        if (creditsNow && !vm.chanPanel && !audioMenu && !controls && vm.upNext == null) {
            Text("⏭  Nächste Folge:  $nextLbl   (OK drücken)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 48.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
        if (showSkip && hintOn && !vm.chanPanel && !audioMenu && !controls && vm.upNext == null) {
            Text("⏭  Intro überspringen  (OK drücken, dann Intro)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 32.dp, bottom = 120.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(12.dp)).padding(horizontal = 20.dp, vertical = 12.dp))
        }
    }
}

/** Schnell-Leiste im Live-TV: erscheint mit OK, alles per Pfeiltasten und OK bedienbar. */
@Composable
fun LiveBar(
    vm: AppVM, exo: ExoPlayer, firstFr: FocusRequester, modifier: Modifier,
    onTick: () -> Unit, onAudio: () -> Unit, onInfo: () -> Unit, onArchive: (() -> Unit)? = null
) {
    val gray = LocalMuted.current
    var paused by remember { mutableStateOf(!exo.playWhenReady) }
    Column(modifier.fillMaxWidth().padding(horizontal = 40.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(18.dp)
        .onPreviewKeyEvent { if (it.type == KeyEventType.KeyDown) onTick(); false }) {
        Text(vm.playTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.toggleCurrentFav(); onTick() }, modifier = Modifier.focusRequester(firstFr).tvFocus()) {
                Text(if (vm.isCurrentFav()) "★ Favorit" else "☆ Favorit")
            }
            OutlinedButton(onClick = onAudio, modifier = Modifier.tvFocus()) { Text("🔊 Ton & Untertitel") }
            OutlinedButton(onClick = {
                exo.playWhenReady = !exo.playWhenReady
                paused = !exo.playWhenReady
                onTick()
            }, modifier = Modifier.tvFocus()) { Text(if (paused) "▶ Weiter" else "⏸ Pause") }
            OutlinedButton(onClick = { vm.toggleLast() }, modifier = Modifier.tvFocus()) { Text("↩ Letzter Sender") }
            OutlinedButton(onClick = onInfo, modifier = Modifier.tvFocus()) { Text("ℹ Info") }
            if (onArchive != null) OutlinedButton(onClick = onArchive, modifier = Modifier.tvFocus()) { Text("⏪ Archiv") }
            OutlinedButton(onClick = { vm.cyclePic(); onTick() }, modifier = Modifier.tvFocus()) { Text("🖼 " + vm.picLabel().substringBefore(" (")) }
            OutlinedButton(onClick = { vm.cycleSleep(); onTick() }, modifier = Modifier.tvFocus()) {
                Text("⏾ " + (if (vm.sleepMinutes == 0) "Sleep aus" else vm.sleepMinutes.toString() + " Min."))
            }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
        Text("Zurück schließt die Leiste.", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
    }
}

/** Archiv (Catch-up): vergangene Sendungen des Senders, nach Tagen sortiert. */
@Composable
fun ArchiveMenu(vm: AppVM, ch: Item, onClose: () -> Unit, onPlay: (Epg) -> Unit) {
    val gray = LocalMuted.current
    var day by remember { mutableIntStateOf(0) }
    val days = ((ch.arch + 23) / 24).coerceIn(1, 4)
    val fmtD = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US) }
    val fmtL = remember { java.text.SimpleDateFormat("EEE d.M.", java.util.Locale.GERMANY) }
    val now = System.currentTimeMillis()
    val list by produceState<List<Epg>?>(null, day) {
        value = null
        value = vm.archiveDay(ch.id, fmtD.format(java.util.Date(now - day * 86_400_000L)))
    }
    val fr = remember { FocusRequester() }
    BackHandler { onClose() }
    LaunchedEffect(list) { if (list?.isNotEmpty() == true) { delay(120); runCatching { fr.requestFocus() } } }
    val nowSec = now / 1000
    val past = list?.filter { it.stopTs <= 0L || (it.stopTs <= nowSec && it.stopTs >= nowSec - ch.arch * 3600L) }
    Column(Modifier.fillMaxSize().background(Color(0xF2050509)).padding(horizontal = 48.dp, vertical = 32.dp)) {
        Text("ARCHIV  ·  " + ch.name, fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (d in 0 until days) {
                OutlinedButton(onClick = { day = d }, modifier = Modifier.tvFocus()) {
                    Text((if (d == 0) "Heute" else if (d == 1) "Gestern" else fmtL.format(java.util.Date(now - d * 86_400_000L))) +
                        (if (d == day) "  ●" else ""))
                }
            }
        }
        when {
            past == null -> Text("Lade …", color = gray, modifier = Modifier.padding(top = 20.dp))
            past.isEmpty() -> Text("Für diesen Tag liefert das Portal keine Sendungen im Archiv.", color = gray,
                modifier = Modifier.padding(top = 20.dp))
            else -> LazyColumn(Modifier.padding(top = 14.dp)) {
                itemsIndexed(past.asReversed()) { i, e ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        .then(if (i == 0) Modifier.focusRequester(fr) else Modifier)
                        .tvFocus(1.02f).glass(12.dp).clickable { onPlay(e) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(e.start + "–" + e.end, fontSize = 14.sp, color = gray, modifier = Modifier.width(120.dp))
                        Text(e.title, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Text("OK = abspielen   ·   Zurück = schließen", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

/** X-Ray: zeigt beim angehaltenen Film die Besetzung (aus TMDB). */
@Composable
fun XRayPanel(vm: AppVM, modifier: Modifier, onClose: () -> Unit) {
    val gray = LocalMuted.current
    val target = remember { vm.xrayTarget() }
    val fr = remember { FocusRequester() }
    val cast by produceState<List<Tmdb.Person>?>(null, target.first) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            if (vm.tmdbKey.isBlank()) emptyList()
            else {
                val info = Tmdb.lookup(vm.tmdbKey, target.first, "", target.second)
                if (info == null || info.id <= 0) emptyList()
                else Tmdb.extras(vm.tmdbKey, info.id, target.second)?.cast ?: emptyList()
            }
        }
    }
    LaunchedEffect(cast) { if (!cast.isNullOrEmpty()) { delay(150); runCatching { fr.requestFocus() } } }
    Column(modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("X-RAY", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Spacer(Modifier.width(12.dp))
            Text(target.first, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("Zurück = weiter ansehen", fontSize = 13.sp, color = gray)
        }
        val l = cast
        when {
            l == null -> Text("Besetzung wird geladen …", color = gray, modifier = Modifier.padding(vertical = 14.dp))
            l.isEmpty() -> Text(if (vm.tmdbKey.isBlank()) "Kein TMDB-Schlüssel eingetragen." else "Zu diesem Titel gibt es keine Besetzungsdaten.",
                color = gray, modifier = Modifier.padding(vertical = 14.dp))
            else -> LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(l) { i, p -> CastChip(p, if (i == 0) Modifier.focusRequester(fr) else Modifier) }
            }
        }
    }
}

/** Bedienleiste für Filme und Serien: erscheint mit OK. */
@Composable
fun PlayerControls(
    exo: ExoPlayer, pos: Long, dur: Long, canSkip: Boolean, playFr: FocusRequester, modifier: Modifier,
    nextLabel: String?, nextFr: FocusRequester, onNext: () -> Unit,
    onTick: () -> Unit, onSkipIntro: () -> Unit, onXray: (() -> Unit)? = null, onNoIntro: (() -> Unit)? = null,
    onAudio: (() -> Unit)? = null
) {
    var playing by remember { mutableStateOf(exo.playWhenReady) }
    LaunchedEffect(Unit) {
        while (true) {
            playing = exo.playWhenReady
            delay(300)
        }
    }
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    fun seekBy(delta: Long) {
        val max = if (dur > 0) dur else Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, max))
        onTick()
    }
    Column(modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 28.dp).glass(22.dp)
        .background(Color(0xEE0A0A0F)).padding(20.dp)
        .onPreviewKeyEvent { if (it.type == KeyEventType.KeyDown) onTick(); false }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(pos), fontSize = 14.sp, color = Color.White)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(accent))
            }
            Spacer(Modifier.width(12.dp))
            Text(if (dur > 0) fmtTime(dur) else "--:--", fontSize = 14.sp, color = gray)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { seekBy(-60_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 60 s") }
            OutlinedButton(onClick = { seekBy(-10_000) }, modifier = Modifier.tvFocus()) { Text("⏪ 10 s") }
            Button(onClick = {
                exo.playWhenReady = !exo.playWhenReady
                playing = exo.playWhenReady
                onTick()
            }, modifier = Modifier.focusRequester(playFr).tvFocus()) {
                Text(if (playing) "⏸  Pause" else "▶  Weiter", fontSize = 18.sp)
            }
            OutlinedButton(onClick = { seekBy(10_000) }, modifier = Modifier.tvFocus()) { Text("10 s ⏩") }
            OutlinedButton(onClick = { seekBy(60_000) }, modifier = Modifier.tvFocus()) { Text("60 s ⏩") }
            if (nextLabel != null) {
                Button(onClick = onNext, modifier = Modifier.focusRequester(nextFr).tvFocus()) { Text("⏭ Nächste Folge") }
            }
        }
        // Zweite Reihe: Ton/Sprache, Intro, X-Ray (passt so auch auf kleine Bildschirme)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically) {
            if (onAudio != null) OutlinedButton(onClick = onAudio, modifier = Modifier.tvFocus()) { Text("🔊 Ton & Untertitel") }
            if (canSkip) {
                OutlinedButton(onClick = onSkipIntro, modifier = Modifier.tvFocus()) { Text("⏭ Intro") }
                if (onNoIntro != null) {
                    OutlinedButton(onClick = onNoIntro, modifier = Modifier.tvFocus()) { Text("🚫 Kein Intro") }
                }
            }
            if (onXray != null) {
                OutlinedButton(onClick = onXray, modifier = Modifier.tvFocus()) { Text("🎭 X-Ray") }
            }
        }
        Text("Zurück schließt die Leiste.", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun InfoPanel(vm: AppVM, detail: Boolean, pos: Long, dur: Long, quality: String, modifier: Modifier, sel: Int = 0) {
    val gray = Color(0xFFB0BAC4)
    val list = vm.epgList(vm.playChId)
    val now = if (vm.isLive) vm.currentEpg(vm.playChId) else null
    Box(modifier.fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
        .padding(start = 32.dp, end = 32.dp, top = 56.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            vm.playLogo?.let { logo ->
                AsyncImage(model = logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(10.dp))
                Spacer(Modifier.width(18.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(vm.playTitle, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (quality.isNotEmpty()) {
                    Text(quality, fontSize = 13.sp, color = tcol(MaterialTheme.colorScheme.primary), maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
                if (vm.isLive) {
                    if (now != null) {
                        Text("${now.start}–${now.end}  ${now.title}", fontSize = 18.sp, color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        vm.epgProgress(now)?.let { p ->
                            LinearProgressIndicator(progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                        }
                        if (detail) {
                            val up = vm.upcomingEpg(vm.playChId)
                            val s = sel.coerceIn(0, (up.size - 1).coerceAtLeast(0))
                            up.forEachIndexed { i, e ->
                                val bell = if (vm.isReminder(vm.playChId, e.startTs)) "🔔 " else ""
                                Text((if (i == s) "▶ " else "    ") + bell + e.start + (if (i == 0) "  jetzt  " else "  ") + e.title,
                                    fontSize = 15.sp, color = if (i == s) Color.White else gray,
                                    fontWeight = if (i == s) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            up.getOrNull(s)?.descr?.takeIf { it.isNotBlank() }?.let { d ->
                                Text(d, fontSize = 14.sp, color = gray, maxLines = 4, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 6.dp))
                            }
                        } else {
                            list.dropWhile { it != now }.drop(1).take(1).forEach { n ->
                                Text("${n.start}  ${n.title}", fontSize = 15.sp, color = gray, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        }
                    } else {
                        Text("Keine Programminfo", fontSize = 14.sp, color = gray)
                    }
                    Text(if (detail) "◀ ▶ Sendung wählen   ·   OK = Erinnerung   ·   Zurück = schließen"
                        else "▲▼ Sender   ·   ◀ Senderliste   ·   ▶ Ton & Untertitel   ·   OK Schnell-Menü",
                        fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                } else if (dur > 0) {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                    Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 14.sp, color = gray)
                }
            }
        }
    }
}

@Composable
fun GuideScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val hours = 6
    val dpPerMin = 4
    val nameW = 180.dp
    var archCh by remember { mutableStateOf<Item?>(null) }
    val totalW = nameW + (hours * 60 * dpPerMin).dp
    val hScroll = vm.pageScroll("guideH")
    val startSec = remember { (System.currentTimeMillis() / 1000 / 1800) * 1800 - 1800 }
    val timeFmt = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()) }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("EPG  ·  PROGRAMMÜBERSICHT   (OK auf kommende Sendung = 🔔 Erinnerung, ⏪ = Archiv)", fontSize = 14.sp, letterSpacing = 3.sp, color = tcol(accent),
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
        Box(Modifier.weight(1f).fillMaxWidth().glass(18.dp)) {
            Column(Modifier.fillMaxHeight().horizontalScroll(hScroll)) {
                Box(Modifier.width(totalW).height(30.dp)) {
                    for (i in 0..(hours * 2)) {
                        Text(timeFmt.format(java.util.Date((startSec + i * 1800L) * 1000)), fontSize = 13.sp, color = gray,
                            modifier = Modifier.offset(x = nameW + (i * 30 * dpPerMin).dp, y = 8.dp))
                    }
                }
                LazyColumn(Modifier.width(totalW).weight(1f), state = vm.rowState("guide")) {
                    items(vm.items, key = { it.id }) { ch -> GuideRow(vm, ch, startSec, hours, dpPerMin, nameW, hScroll) { archCh = it } }
                }
            }
        }
    }
    archCh?.let { c ->
        ArchiveMenu(vm, c, onClose = { archCh = null }) { e -> archCh = null; vm.playArchive(c, e) }
    }
    }
}

@Composable
fun GuideRow(vm: AppVM, ch: Item, startSec: Long, hours: Int, dpPerMin: Int, nameW: Dp, hScroll: ScrollState, onArchive: (Item) -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id, 12) }
    val list = vm.epgList(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    val gray = LocalMuted.current
    val light = LocalLight.current
    val nowSec = System.currentTimeMillis() / 1000
    val endSec = startSec + hours * 3600L
    Box(Modifier.width(nameW + (hours * 60 * dpPerMin).dp).height(64.dp).padding(vertical = 3.dp)) {
        // Manche Anbieter liefern überlappende Sendungen: nach Start sortieren und jede am Beginn der nächsten kürzen
        val sorted = list.filter { it.startTs > 0 && it.stopTs > it.startTs }.sortedBy { it.startTs }.distinctBy { it.startTs }
        for ((ei, e) in sorted.withIndex()) {
            val stopTs = minOf(e.stopTs, sorted.getOrNull(ei + 1)?.startTs ?: e.stopTs)
            if (stopTs <= e.startTs) continue
            val s0 = maxOf(e.startTs, startSec)
            val s1 = minOf(stopTs, endSec)
            if (s1 <= s0) continue
            val left = nameW + (((s0 - startSec) / 60f) * dpPerMin).dp
            val w = maxOf((((s1 - s0) / 60f) * dpPerMin).dp - 3.dp, 10.dp)
            val isNow = nowSec in e.startTs until stopTs
            Text((if (vm.isReminder(ch.id, e.startTs)) "🔔 " else "") + e.start + "  " + e.title, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.offset(x = left).width(w).fillMaxHeight().itemFocus(vm, "g:" + ch.id + ":" + e.startTs).tvFocus(1.02f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isNow) accent.copy(alpha = 0.35f) else if (light) Color(0x14000000) else Color(0x1FFFFFFF))
                    .clickable {
                        if (e.startTs > System.currentTimeMillis() / 1000) vm.toggleReminder(ch, e) else vm.openItem(ch)
                    }.padding(8.dp))
        }
        if (list.isEmpty()) {
            Text("Keine Programminfo", fontSize = 13.sp, color = gray,
                modifier = Modifier.align(Alignment.CenterStart).offset(x = nameW + 8.dp))
        }
        // Sendername bleibt beim seitlichen Scrollen links stehen
        Row(Modifier.offset { IntOffset(hScroll.value, 0) }.width(nameW).fillMaxHeight()
            .background(if (light) Color(0xFFEAECF2) else Color(0xFF101018)),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).fillMaxHeight().itemFocus(vm, "g:" + ch.id).tvFocus(1.02f).clickable { vm.openItem(ch) }.padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
                Spacer(Modifier.width(8.dp))
                Text(ch.name, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (ch.arch > 0) {
                Text("⏪", fontSize = 18.sp, modifier = Modifier.fillMaxHeight().tvFocus(1.05f)
                    .clickable { onArchive(ch) }.padding(horizontal = 8.dp).wrapContentHeight(Alignment.CenterVertically))
            }
        }
    }
}

@Composable
fun EditCatsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var kw by remember { mutableStateOf("DE, German, Deutsch") }
    val groups = vm.portalGroups
    var byPortal by remember { mutableStateOf(groups.size > 1) }
    var openG by remember { mutableStateOf(setOf<String>()) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kategorien auswählen", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.allCats.count { it.id !in vm.hiddenCats }} von ${vm.allCats.size} sichtbar",
            fontSize = 13.sp, color = gray)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = kw, onValueChange = { kw = it }, singleLine = true,
                label = { Text("Suchbegriffe, z. B. DE, German") }, modifier = Modifier.weight(1f).tvFocus())
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.showOnlyMatching(kw) }, modifier = Modifier.tvFocus()) { Text("Nur passende") }
        }
        val countries = vm.countryGroups()
        if (countries.isNotEmpty()) {
            Text("LÄNDER (erkannt am Anfang des Namens, OK = ein/aus)", fontSize = 13.sp, letterSpacing = 2.sp, color = gray)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                countries.forEach { (code, n) ->
                    val st = vm.countryState(code)
                    OutlinedButton(onClick = { vm.toggleCountry(code) }, modifier = Modifier.tvFocus()) {
                        Text(markText(st, code + " (" + n + ")"))
                    }
                }
            }
        }
        Row(Modifier.padding(bottom = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (groups.size > 1) {
                OutlinedButton(onClick = { byPortal = !byPortal }, modifier = Modifier.tvFocus()) {
                    Text(if (byPortal) "Ansicht: nach Portal  ⟳" else "Ansicht: eine Liste  ⟳")
                }
            }
            OutlinedButton(onClick = { vm.setAllCats(true) }, modifier = Modifier.tvFocus()) { Text("Alle anzeigen") }
            OutlinedButton(onClick = { vm.setAllCats(false) }, modifier = Modifier.tvFocus()) { Text("Alle ausblenden") }
            Button(onClick = { vm.germanOnlyNow() }, modifier = Modifier.tvFocus()) { Text("Nur Deutsch") }
            OutlinedButton(onClick = { vm.sortCats("de") }, modifier = Modifier.tvFocus()) { Text("DE/AT/CH zuerst") }
            OutlinedButton(onClick = { vm.sortCats("az") }, modifier = Modifier.tvFocus()) { Text("A–Z") }
            OutlinedButton(onClick = { vm.sortCats("provider") }, modifier = Modifier.tvFocus()) { Text("Reihenfolge des Anbieters") }
        }
        if (!(byPortal && groups.size > 1)) {
            LazyColumn(Modifier.weight(1f)) {
                items(vm.orderCats(vm.allCats), key = { it.id }) { c ->
                    val on = c.id !in vm.hiddenCats
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(markText(if (on) 2 else 0, c.title), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                            modifier = Modifier.weight(1f).tvFocus().clickable { vm.toggleCat(c.id) }.padding(12.dp))
                        OutlinedButton(onClick = { vm.moveCat(c.id, -1) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("▲") }
                        OutlinedButton(onClick = { vm.moveCat(c.id, 1) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("▼") }
                    }
                }
            }
        } else {
            Text("Gleichnamige Kategorien gelten für alle Portale. OK klappt ein Portal auf oder zu.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(bottom = 4.dp))
            LazyColumn(Modifier.weight(1f)) {
                for (g in groups) {
                    val isOpen = g.pfx in openG
                    val vis = g.cats.count { it.id !in vm.hiddenCats }
                    item(key = "g:" + g.pfx) {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((if (isOpen) "▾  " else "▸  ") + g.name + "   (" + vis + " von " + g.cats.size + " sichtbar)",
                                fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = tcol(MaterialTheme.colorScheme.primary),
                                modifier = Modifier.weight(1f).tvFocus().clickable {
                                    openG = if (isOpen) openG - g.pfx else openG + g.pfx
                                }.padding(12.dp))
                            OutlinedButton(onClick = { vm.setCats(g.cats.map { it.id }, true) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("Alle ein") }
                            OutlinedButton(onClick = { vm.setCats(g.cats.map { it.id }, false) }, modifier = Modifier.padding(start = 6.dp).tvFocus()) { Text("Alle aus") }
                        }
                    }
                    if (isOpen) {
                        items(vm.orderCats(g.cats), key = { g.pfx + ":" + it.id }) { c ->
                            val on = c.id !in vm.hiddenCats
                            Text(markText(if (on) 2 else 0, c.title), fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                                modifier = Modifier.fillMaxWidth().padding(start = 22.dp).tvFocus().clickable { vm.toggleCat(c.id) }.padding(10.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditChansScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var filter by remember { mutableStateOf("") }
    val shown = vm.editChans.filter { filter.isBlank() || it.name.contains(filter.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kanäle ein-/ausblenden", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.editChans.count { it.id !in vm.hiddenChans }} von ${vm.editChans.size} sichtbar",
            fontSize = 13.sp, color = gray)
        OutlinedTextField(value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Filter nach Name") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).tvFocus())
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, true) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte ausblenden")
            }
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, false) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte einblenden")
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { ch ->
                val on = ch.id !in vm.hiddenChans
                Text(markText(if (on) 2 else 0, ch.name), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleChan(ch.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, item: Item) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    val isSeries = vm.browseType == "series"
    LaunchedEffect(item.id) { vm.loadSimilar(item) }
    val res = remember(item) { vm.resumeFor(item) }
    val tm by produceState<Tmdb.Info?>(null, item.id, vm.tmdbKey) {
        value = if (vm.tmdbKey.isBlank()) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Tmdb.lookup(vm.tmdbKey, item.name, item.year, isSeries) }
    }
    val ctx = LocalContext.current
    val tmId = tm?.id ?: 0
    val ex by produceState<Tmdb.Extras?>(null, tmId) {
        value = if (tmId <= 0) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Tmdb.extras(vm.tmdbKey, tmId, isSeries) }
    }
    val posterUrl = item.logo?.takeIf { it.isNotBlank() } ?: tm?.poster
    val backUrl = item.backdrop ?: tm?.backdrop
    LaunchedEffect(posterUrl) { vm.focusAmbient(posterUrl) }
    val descrText = if (item.descr.isNotBlank()) item.descr else (tm?.overview ?: "")
    val ratingText = if (tm != null && tm!!.rating.isNotBlank() && !item.meta.contains("Bewertung")) "Bewertung: " + tm!!.rating else ""
    Box(Modifier.fillMaxSize()) {
        AsyncImage(model = backUrl ?: posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (backUrl != null) 0.4f else 0.22f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0A0A0F), Color(0xCC0A0A0F), Color(0x330A0A0F)))))
        Row(Modifier.fillMaxSize().padding(40.dp)) {
            AsyncImage(model = posterUrl, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(240.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(16.dp)))
            Spacer(Modifier.width(32.dp))
            Column(Modifier.weight(1f).fillMaxHeight().glass(24.dp).verticalScroll(rememberScrollState()).padding(24.dp)) {
                Text(if (isSeries) "SERIE" else "FILM", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
                Text(cleanTitle(item.name), fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                    modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (item.year.isNotBlank()) Text(niceDate(item.year), fontSize = 16.sp, color = gray)
                    QualityBadges(item.name, Modifier)
                }
                Box(Modifier.padding(top = 12.dp).width(64.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (res != null) {
                        Button(onClick = { vm.playResume(res) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("▶ Weiter bei " + fmtTime(res.pos) +
                                (if (isSeries) "  ·  " + res.title.substringAfter(" – ") else ""), fontSize = 18.sp,
                                maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 420.dp))
                        }
                    }
                    Button(onClick = { if (res != null && !isSeries) vm.startFresh(item) else vm.startItem(item) },
                        modifier = (if (res == null) Modifier.focusRequester(fr) else Modifier).tvFocus()) {
                        Text(if (isSeries) "Staffeln ansehen" else if (res != null) "↺ Von vorne" else "▶ Abspielen", fontSize = 18.sp)
                    }
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { vm.toggleFav(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isFav(item)) "★ Favorit entfernen" else "☆ Zu Favoriten", fontSize = 18.sp, maxLines = 1, softWrap = false)
                    }
                    OutlinedButton(onClick = { vm.toggleWatch(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isWatch(item)) "✓ Aus Merkliste entfernen" else "＋ Merkliste", fontSize = 18.sp, maxLines = 1, softWrap = false)
                    }
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { vm.trailerSeries = isSeries; vm.trailerReq = item }, modifier = Modifier.tvFocus()) {
                        Text("🎬  Trailer ansehen", fontSize = 18.sp, maxLines = 1, softWrap = false)
                    }
                    if (!isSeries) {
                        OutlinedButton(onClick = { vm.toggleMovieSeen(item) }, modifier = Modifier.tvFocus()) {
                            Text(if (vm.isMovieSeen(item)) "✓ Gesehen" else "○ Als gesehen markieren", fontSize = 18.sp, maxLines = 1, softWrap = false)
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text(if (descrText.isNotBlank()) descrText else "Keine Beschreibung vorhanden.", fontSize = 16.sp,
                    color = if (descrText.isNotBlank()) MaterialTheme.colorScheme.onSurface else gray)
                val metaText = listOf(item.meta, ratingText).filter { it.isNotBlank() }.joinToString("\n")
                if (metaText.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(metaText, fontSize = 14.sp, color = gray)
                }
                if (vm.tmdbKey.isBlank()) {
                    Text("Besetzung: TMDB-Schlüssel in den Einstellungen eintragen.", fontSize = 13.sp, color = gray,
                        modifier = Modifier.padding(top = 10.dp))
                } else if (tm == null) {
                    Text("Besetzung: kein TMDB-Treffer für diesen Titel.", fontSize = 13.sp, color = gray,
                        modifier = Modifier.padding(top = 10.dp))
                }
                ex?.cast?.takeIf { it.isNotEmpty() }?.let { cast ->
                    Spacer(Modifier.height(24.dp))
                    Text("BESETZUNG", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
                    LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(cast) { p -> CastChip(p) }
                    }
                }
                if (vm.similar.isNotEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("ÄHNLICHE TITEL", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
                    LazyRow(contentPadding = PaddingValues(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(vm.similar) { m -> MiniPoster(m) { vm.openHomeItem(m, vm.browseType) } }
                    }
                }
            }
        }
    }
}

/** Kurzer Vorspann: Logo blendet ein, Goldlinie zieht auf. Beliebige Taste oder Tippen überspringt ihn. */
@Composable
fun ClassicIntro(sound: Boolean, onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    val ctx = LocalContext.current
    val mp = remember { arrayOfNulls<android.media.MediaPlayer>(1) }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    // Startton: kurzer, weicher Klang zum Einblenden des Logos
    LaunchedEffect(Unit) {
        if (sound) {
            runCatching {
                val p = android.media.MediaPlayer.create(ctx, R.raw.intro_boom)
                p?.setOnCompletionListener { it.release() }
                p?.start()
                mp[0] = p
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose { runCatching { mp[0]?.release() }; mp[0] = null }
    }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(900))
        line.animateTo(1f, tween(700))
        delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { onDone(); true } else false }
            .clickable { onDone() },
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(fade.value).graphicsLayer { scaleX = 0.92f + 0.08f * fade.value; scaleY = 0.92f + 0.08f * fade.value },
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎬", fontSize = 56.sp)
            Spacer(Modifier.height(12.dp))
            Text("TOM’S TV", fontSize = 48.sp, fontWeight = FontWeight.Bold, fontFamily = titleFont,
                letterSpacing = 10.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.width((240 * line.value).dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 13.sp, letterSpacing = 5.sp, color = LocalMuted.current)
        }
    }
}

/** Vorspann: Premium mit Kino-Boom, sonst klassisch. */
@Composable
fun IntroScreen(premium: Boolean, sound: Boolean, simple: Boolean, onDone: () -> Unit) {
    if (simple) ClassicIntro(sound, onDone)
    else PremiumIntro(sound, brandTint, onDone)
}

/** Kino-Intro „Lichtstrahl“: ein Lichtpunkt zieht sich zum blauen Kinostreifen auseinander, ein Lichtkamm schreibt das Logo, Boom mit Druckwelle, Cinemascope-Balken öffnen sich. */
@Composable
fun PremiumIntro(sound: Boolean, tint: Color, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val clock = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    var finished by remember { mutableStateOf(false) }
    val finish = { if (!finished) { finished = true; onDone() } }
    val mp = remember { arrayOfNulls<android.media.MediaPlayer>(1) }
    DisposableEffect(Unit) { onDispose { runCatching { mp[0]?.release() }; mp[0] = null } }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    // Der Schlag im Sound sitzt etwa 0,3 s nach dem Start: so landet er genau beim Boom (2,4 s)
    LaunchedEffect(Unit) {
        if (sound) {
            delay(2100)
            runCatching {
                val p = android.media.MediaPlayer.create(ctx, R.raw.intro_boom)
                p?.setOnCompletionListener { it.release() }
                p?.start()
                mp[0] = p
            }
        }
    }
    LaunchedEffect(Unit) {
        clock.animateTo(4.5f, tween(4500, easing = androidx.compose.animation.core.LinearEasing))
        finish()
    }
    // Staubkörner im Strahl: x, y, Tiefe, Phase, Tempo (einmal erzeugt)
    val dust = remember {
        val r = java.util.Random(7)
        List(90) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.3f + r.nextFloat() * 0.7f, r.nextFloat() * 6.28f, 0.4f + r.nextFloat()) }
    }
    val t = clock.value
    fun cl(x: Float) = x.coerceIn(0f, 1f)
    fun eo(x: Float): Float { val u = 1f - cl(x); return 1f - u * u * u }
    fun eio(x: Float): Float { val u = cl(x); return if (u < 0.5f) 4f * u * u * u else 1f - Math.pow((-2.0 * u + 2.0), 3.0).toFloat() / 2f }
    val rv = -0.10f + 1.2f * eio((t - 1.2f) / 1.2f)
    val bars = 0.126f * (1f - eio((t - 3.5f) / 0.9f))
    val outAll = 1f - cl((t - 3.9f) / 0.6f)
    val tagA = eo((t - 2.7f) / 0.5f) * (1f - cl((t - 3.6f) / 0.3f))
    val flash = cl(1f - kotlin.math.abs(t - 2.4f) / 0.1f) * 0.3f
    val blue = Color(0xFF5B8CFF)
    Box(
        Modifier.fillMaxSize().graphicsLayer { alpha = outAll }.background(Color(0xFF020309)).focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { finish(); true } else false }
            .clickable { finish() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val cx = w / 2f; val cy = h / 2f
            val k = w / 1280f
            // Lichtpunkt und Kinostreifen
            val ig = eo(t / 0.5f)
            val sw = eo((t - 0.35f) / 0.9f)
            val fadeS = 1f - 0.6f * cl((t - 2.6f) / 0.8f) - 0.4f * cl((t - 3.4f) / 0.4f)
            val sh = (2f + 5f * ig) * k * (1f + 1.2f * cl(1f - kotlin.math.abs(t - 2.4f) / 0.25f))
            val halfW = w * 0.46f * sw + 6f * k
            if (ig > 0f && fadeS > 0f) {
                withTransform({ scale(1f, 0.38f, Offset(cx, cy)) }) {
                    drawRect(Brush.radialGradient(listOf(Color(0xFF3C64E6).copy(alpha = 0.28f * ig * fadeS), Color.Transparent),
                        center = Offset(cx, cy), radius = w * 0.4f),
                        topLeft = Offset(0f, cy - h * 3f), size = androidx.compose.ui.geometry.Size(w, h * 6f))
                }
                val streak = Brush.horizontalGradient(
                    0f to Color(0x005B8CFF), 0.25f to Color(0xD95B8CFF), 0.5f to Color.White, 0.75f to Color(0xD95B8CFF), 1f to Color(0x005B8CFF),
                    startX = cx - halfW, endX = cx + halfW)
                for (j in 4 downTo 1) {
                    val gh = sh * (1f + j * 2.5f)
                    drawRect(streak, topLeft = Offset(cx - halfW, cy - gh / 2f), size = androidx.compose.ui.geometry.Size(halfW * 2f, gh), alpha = 0.22f / j * fadeS)
                }
                drawRect(streak, topLeft = Offset(cx - halfW, cy - sh / 2f), size = androidx.compose.ui.geometry.Size(halfW * 2f, sh), alpha = fadeS.coerceIn(0f, 1f))
            }
            // Lichtkamm beim Schreiben des Logos
            val rt = cl((t - 1.2f) / 1.2f)
            if (rt > 0f && rt < 1f) {
                val lx = w * 0.19f + w * 0.62f * eio((t - 1.2f) / 1.2f)
                val hh = h * 0.24f
                val comb = Brush.verticalGradient(0f to Color.Transparent, 0.5f to Color.White, 1f to Color.Transparent, startY = cy - hh, endY = cy + hh)
                drawRect(comb, topLeft = Offset(lx - 7f * k, cy - hh), size = androidx.compose.ui.geometry.Size(14f * k, hh * 2f), alpha = 0.25f)
                drawRect(comb, topLeft = Offset(lx - 1.5f * k, cy - hh), size = androidx.compose.ui.geometry.Size(3f * k, hh * 2f))
            }
            // Druckwelle
            val ring = cl((t - 2.4f) / 0.9f)
            if (ring > 0f && ring < 1f) {
                withTransform({ scale(1f, 0.55f, Offset(cx, cy)) }) {
                    drawCircle(Color(0xFF9BBCFF).copy(alpha = 0.55f * (1f - ring)), radius = w * 0.05f + w * 0.5f * eo(ring), center = Offset(cx, cy),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(2.5f * k))
                }
            }
            // Staub im Strahl
            val da = cl((t - 0.8f) / 0.6f) * (1f - cl((t - 3.5f) / 0.6f))
            if (da > 0f) {
                for (d in dust) {
                    val x = ((d[0] + t * 0.012f * d[2]) % 1f) * w
                    val y = cy + (d[1] - 0.5f) * h * 0.55f + kotlin.math.sin(t * d[4] + d[3]) * 6f * k
                    val a = (da * d[2] * (0.25f + 0.55f * kotlin.math.abs(kotlin.math.sin(t * 1.7f * d[4] + d[3])))).coerceIn(0f, 1f)
                    drawCircle(Color(0xFFD7E2FF).copy(alpha = a), radius = (0.6f + 1.4f * d[2]) * k, center = Offset(x, y))
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier
                .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    val a = cl(rv); val b = cl(rv + 0.06f)
                    drawRect(Brush.horizontalGradient(0f to Color.Black, a to Color.Black, b to Color.Transparent, 1f to Color.Transparent),
                        blendMode = androidx.compose.ui.graphics.BlendMode.DstIn)
                }) {
                Text("Tom’s TV", fontSize = 130.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.SansSerif,
                    style = androidx.compose.ui.text.TextStyle(color = Color(0xFFB5CCFF),
                        shadow = androidx.compose.ui.graphics.Shadow(blue.copy(alpha = 0.55f), Offset.Zero, 28f)))
            }
            Spacer(Modifier.height(18.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 16.sp, letterSpacing = 8.sp, color = Color(0xFFE8D2A0), modifier = Modifier.alpha(tagA))
        }
        // Cinemascope-Balken oben und unten, öffnen sich am Ende
        Canvas(Modifier.fillMaxSize()) {
            val bh = size.height * bars
            if (bh > 0.5f) {
                drawRect(Color.Black, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(size.width, bh))
                drawRect(Color.Black, topLeft = Offset(0f, size.height - bh), size = androidx.compose.ui.geometry.Size(size.width, bh))
            }
        }
        if (flash > 0.01f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flash)))
    }
}

@Composable
fun Clock() {
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        while (true) {
            time = f.format(java.util.Date())
            delay(20_000)
        }
    }
    if (LocalShield.current) {
        val date = remember(time) { java.text.SimpleDateFormat("EEE, d. MMM yyyy", java.util.Locale.GERMANY).format(java.util.Date()) }
        Column(horizontalAlignment = Alignment.End) {
            Text(time, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(date, fontSize = 13.sp, color = LocalMuted.current)
        }
    } else Text(time, fontSize = 14.sp, color = LocalMuted.current)
}

/** Merkt sich den Fokus in den linken Seiten und stellt ihn nach dem Zurückkehren wieder her. */
fun Modifier.leftFocus(vm: AppVM, key: String): Modifier = composed {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (vm.leftFocus == key) { delay(150); runCatching { fr.requestFocus() } }
    }
    LaunchedEffect(vm.navFocusReq) {
        if (vm.navFocusReq == key) { runCatching { fr.requestFocus() }; vm.navFocusReq = null }
    }
    this.focusRequester(fr).onFocusChanged { if (it.hasFocus) { vm.leftFocus = key; vm.contentFocus = null } }
}

/** Nach dem Löschen bekommt der Nachbar-Eintrag mit diesem Schlüssel den Fokus, damit der Cursor in der Liste bleibt. */
fun Modifier.delFocus(vm: AppVM, key: String, req: FocusRequester? = null): Modifier = composed {
    val fr = req ?: remember { FocusRequester() }
    LaunchedEffect(vm.pendingFocus) {
        if (vm.pendingFocus == key) { delay(80); runCatching { fr.requestFocus() }; vm.pendingFocus = null }
    }
    this.focusRequester(fr)
}

/** Schlüssel des nächsten Eintrags (sonst des vorigen) einer Liste, null wenn die Liste danach leer ist. */
fun <T> neighborKey(list: List<T>, idx: Int, key: (T) -> String): String? =
    list.getOrNull(idx + 1)?.let(key) ?: list.getOrNull(idx - 1)?.let(key)

/** Merkt sich den fokussierten Eintrag im Inhalt und gibt ihm nach dem Zurückkehren wieder den Fokus. */
fun Modifier.itemFocus(vm: AppVM, key: String): Modifier = composed {
    val fr = remember { FocusRequester() }
    val mem = LocalFocusMemory.current
    if (mem != null) DisposableEffect(key) { mem.map[key] = fr; onDispose { if (mem.map[key] === fr) mem.map.remove(key) } }
    LaunchedEffect(Unit) {
        if (vm.itemFocus == key) { delay(200); runCatching { fr.requestFocus() } }
    }
    this.focusRequester(fr).onFocusChanged { if (it.hasFocus) vm.itemFocus = key }.focusGroup()
}

/** Fokus-Ziele einer Liste: Wer von außen hineinspringt, landet auf dem gewählten bzw. zuletzt benutzten Eintrag. */
class FocusMemory { val map = HashMap<String, FocusRequester>() }

val LocalFocusMemory = staticCompositionLocalOf<FocusMemory?> { null }

/**
 * Macht den Bereich zu einer Fokus-Gruppe. Kommt der Fokus mit ◀ ▶ (bzw. ▲ ▼ bei vertical) von außen,
 * springt er auf den Eintrag mit dem Schlüssel aus [key] statt auf den räumlich nächsten.
 */
fun Modifier.enterAt(mem: FocusMemory, vertical: Boolean = false, key: () -> String?): Modifier =
    this.focusProperties {
        enter = { d ->
            val ok = if (vertical) d == FocusDirection.Up || d == FocusDirection.Down
                     else d == FocusDirection.Left || d == FocusDirection.Right
            (if (ok) key()?.let { mem.map[it] } else null) ?: FocusRequester.Default
        }
    }.focusGroup()

/** Meldet einen Eintrag unter [key] bei [mem] an, damit [enterAt] ihn ansteuern kann. */
fun Modifier.enterKey(mem: FocusMemory, key: String): Modifier = composed {
    val fr = remember { FocusRequester() }
    DisposableEffect(key) { mem.map[key] = fr; onDispose { if (mem.map[key] === fr) mem.map.remove(key) } }
    this.focusRequester(fr)
}

/** Markiert einen Bereich als Inhalt (nicht Seitenleiste), damit Zurück zuerst zur Seitenleiste springt. */
fun Modifier.inContent(vm: AppVM, id: String): Modifier =
    this.onFocusChanged { if (it.hasFocus) { vm.contentFocus = id; vm.leftFocus = null } }

@Composable
fun Shell(vm: AppVM, current: String, content: @Composable () -> Unit) {
    if (LocalAtv.current) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().padding(top = if (current == "home") 0.dp else 60.dp)
                .then(if (current == "epg" || current == "settings") Modifier.inContent(vm, current) else Modifier)) { content() }
            AtvTopBar(vm, current)
        }
        return
    }
    Row(Modifier.fillMaxSize()) {
        Sidebar(vm, current)
        Column(Modifier.weight(1f).fillMaxHeight()
            .then(if (current == "epg" || current == "settings") Modifier.inContent(vm, current) else Modifier)) {
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
            if (LocalShield.current && current == "home") HintBar()
        }
    }
}

/** Apple-TV-Design: schwebende Tab-Leiste oben statt Seitenleiste. */
@Composable
fun AtvTopBar(vm: AppVM, current: String) {
    val homeState = vm.rowState("home")
    val scrolled by remember(homeState) { derivedStateOf { current == "home" && (homeState.firstVisibleItemIndex > 0 || homeState.firstVisibleItemScrollOffset > 60) } }
    // Weiterschauen: Reihe auf der Startseite ("Alle anzeigen"); Portale: Einstellungen > Portale verwalten
    val menu = listOf("home" to "Startseite", "itv" to "Live TV", "vod" to "Filme", "series" to "Serien",
        "watch" to "Merkliste", "epg" to "EPG", "search" to "", "settings" to "")
    Box(Modifier.fillMaxWidth()
        .then(if (scrolled) Modifier.background(Brush.verticalGradient(0f to Color(0xF50A0A0C), 0.7f to Color(0xEB0A0A0C), 1f to Color(0x000A0A0C))) else Modifier)
        .padding(horizontal = 44.dp, vertical = 10.dp)) {
        if (!scrolled) Row(Modifier.align(Alignment.CenterStart), verticalAlignment = Alignment.CenterVertically) {
            Text("Tom’s ", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("TV", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color(0xFF3D7BFF))
        }
        val navMem = remember { FocusMemory() }
        Row(Modifier.align(Alignment.Center).enterAt(navMem, vertical = true) { "nav:" + current }.clip(RoundedCornerShape(50)).background(Color(0x40303036))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(50)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            menu.forEach { (id, label) ->
                var f by remember { mutableStateOf(false) }
                val sel = id == current
                val sc by animateFloatAsState(if (f) 1.06f else 1f, tween(140), label = "atvTab")
                Box(Modifier.leftFocus(vm, "nav:" + id).enterKey(navMem, "nav:" + id).onFocusChanged { f = it.hasFocus }
                    .onPreviewKeyEvent { e ->
                        if (current == "home" && e.type == KeyEventType.KeyDown && e.key == Key.DirectionDown) { vm.heroFocusReq++; true } else false
                    }
                    .graphicsLayer { scaleX = sc; scaleY = sc }
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) Color.White else if (f) Color(0x66FFFFFF) else Color.Transparent)
                    .border(if (f) 2.dp else 0.dp, if (f) Color.White else Color.Transparent, RoundedCornerShape(50))
                    .clickable { vm.goTo(id) }
                    .padding(horizontal = 14.dp, vertical = 7.dp), contentAlignment = Alignment.Center) {
                    if (id == "settings") FlatIcon("gear", 20.dp, if (sel) Color.Black else Color.White)
                    else if (id == "search") FlatIcon("search", 20.dp, if (sel) Color.Black else Color.White)
                    else Text(label, fontSize = 15.sp, maxLines = 1, softWrap = false,
                        fontWeight = if (sel || f) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (sel) Color.Black else Color.White)
                }
            }
        }
        Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
            val pName = vm.profileName()
            Box(Modifier.leftFocus(vm, "nav:profile").tvFocus(1.05f).clip(CircleShape).clickable {
                if (vm.profiles.size > 1) vm.profilePicked = false else { vm.settingsTab = 4; vm.goTo("settings") }
            }) { Avatar(vm.profileAvatar(), 30.dp, initialOf(pName)) }
            Spacer(Modifier.width(10.dp))
            Clock()
        }
    }
}

/** Apple-TV-Design: Weiterschauen als breite Karte mit Fortschrittsbalken. */
@Composable
fun AtvResumeCard(vm: AppVM, r: Resume) {
    var f by remember { mutableStateOf(false) }
    val left = if (r.dur > r.pos) ((r.dur - r.pos) / 60000L).toInt() else -1
    val rest = if (left < 0) "bei " + fmtTime(r.pos) else if (left >= 60) "noch " + (left / 60) + " Std. " + (left % 60) + " Min." else "noch " + left + " Min."
    Column(Modifier.width(220.dp)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).onFocusChanged { f = it.hasFocus }.tvFocus(1.05f).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1C1C24)).clickable { vm.playResume(r) }) {
            AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xB3000000))))
            if (r.dur > 0) LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                modifier = Modifier.align(Alignment.BottomStart).padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth().height(3.dp),
                color = Color.White, trackColor = Color(0x44FFFFFF))
        }
        Text(cleanTitle(r.title), fontSize = 14.sp, fontWeight = if (f) FontWeight.Bold else FontWeight.Medium, color = if (f) Color.White else Color(0xFFB8B8C2),
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp, start = 4.dp))
        Text(rest, fontSize = 13.sp, color = Color(0xFF9A9AA8), modifier = Modifier.padding(start = 4.dp))
    }
}

/** Bedienhinweise am unteren Rand (nur Shield-Design, Startseite). */
@Composable
fun HintBar() {
    val gray = LocalMuted.current
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 8.dp)
        .drawBehind { drawRect(Color(0x22FFFFFF), size = androidx.compose.ui.geometry.Size(size.width, 1.dp.toPx())) }
        .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        Text("▲ ▼ ◀ ▶  Navigieren", fontSize = 13.sp, color = gray)
        Box(Modifier.width(1.dp).height(14.dp).background(Color(0x33FFFFFF)))
        Text("OK  Auswählen", fontSize = 13.sp, color = gray)
        Box(Modifier.width(1.dp).height(14.dp).background(Color(0x33FFFFFF)))
        Text("Zurück  Zum Menü", fontSize = 13.sp, color = gray)
    }
}

@Composable
fun Sidebar(vm: AppVM, current: String) {
    val neon = LocalNeon.current
    val amb = LocalAmbient.current
    val accent = if (neon) amb else MaterialTheme.colorScheme.primary
    val compact = when (vm.sidebarMode) {
        "compact" -> true
        "normal" -> false
        else -> LocalConfiguration.current.screenHeightDp < 480
    }
    val wide = if (LocalKino.current) 230.dp else if (LocalMid.current) 200.dp else if (LocalShield.current) 260.dp else 224.dp
    val compactW = if (LocalPremium.current && !LocalFlat.current) 88.dp else 76.dp
    val widthAnim by animateDpAsState(if (compact) compactW else wide, label = "sidebarWidth")
    val width = if (LocalPerf.current) (if (compact) compactW else wide) else widthAnim
    val menu = listOf(
        Triple("home", "home", "Startseite"), Triple("itv", "tv", "Live TV"), Triple("vod", "film", "Filme"),
        Triple("series", "popcorn", "Serien"), Triple("resume", "resume", "Weiterschauen"), Triple("watch", "bookmark", "Merkliste"), Triple("search", "search", "Suche"),
        Triple("epg", "calendar", "EPG"), Triple("portals", "ticket", "Portale"), Triple("settings", "gear", "Einstellungen")
    )
    val premium = LocalPremium.current
    val pmOnly = LocalPremium.current && !LocalFlat.current
    val flat = LocalFlat.current
    val flatLook = flat || LocalShield.current
    val shieldNav = LocalShield.current
    Column(Modifier.width(width).fillMaxHeight()
        .then(if (flat) Modifier.background(Color(0xFF110E1C))
                .drawBehind { drawRect(accent.copy(alpha = 0.6f), topLeft = Offset(size.width - 2.dp.toPx(), 0f),
                    size = androidx.compose.ui.geometry.Size(2.dp.toPx(), size.height)) }
                .padding(horizontal = 8.dp, vertical = 16.dp)
              else if (LocalKino.current) Modifier.background(Brush.verticalGradient(0f to Color(0xF00B0D14), 1f to Color(0xF007080C)))
                .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.Transparent, Kino.a.copy(alpha = 0.8f), Color.Transparent)),
                    topLeft = Offset(size.width - 2.dp.toPx(), 0f), size = androidx.compose.ui.geometry.Size(2.dp.toPx(), size.height)) }
                .padding(horizontal = 10.dp, vertical = 16.dp)
              else if (LocalMid.current) Modifier.background(Brush.verticalGradient(0f to Color(0xF0030612), 1f to Color(0xB0060818)))
                .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF4A3AC8), Color(0xFF9A2FA8), Color.Transparent)),
                    topLeft = Offset(size.width - 2.dp.toPx(), 0f), size = androidx.compose.ui.geometry.Size(2.dp.toPx(), size.height)) }
                .padding(horizontal = 10.dp, vertical = 16.dp)
              else if (LocalShield.current) Modifier.background(Brush.verticalGradient(0f to Color(0xE6130116), 0.7f to Color(0xD9140117), 1f to Color(0xCC2A0126)))
                .drawBehind { drawRect(Color(0x33FFFFFF), topLeft = Offset(size.width - 1.dp.toPx(), 0f),
                    size = androidx.compose.ui.geometry.Size(1.dp.toPx(), size.height)) }
                .padding(horizontal = 10.dp, vertical = 16.dp)
              else if (pmOnly) Modifier.background(Color(0xFF020204))
                .padding(horizontal = 8.dp, vertical = 16.dp)
              else if (premium) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF000000), Color(0xE6050505))))
                .padding(horizontal = 8.dp, vertical = 16.dp)
              else Modifier.padding(10.dp).glass(22.dp).then(if (LocalShield.current) Modifier.background(Color(0x7007030F)) else Modifier).padding(horizontal = 8.dp, vertical = 10.dp))) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start) {
            if (!compact && LocalShield.current) {
                Column(Modifier.weight(1f).padding(start = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (!LocalMid.current) Text("▶", fontSize = 20.sp, color = Color.White)
                        Text(if (LocalMid.current) "Tom’s " else " Tom’s ", fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text("TV", fontSize = 20.sp, fontWeight = FontWeight.Black, color = if (LocalKino.current) Kino.a else if (LocalMid.current) Color(0xFF3D7BFF) else Color.White)
                    }
                    if (!LocalMid.current) Text("Dein TV. Deine Wahl.", fontSize = 13.sp, color = LocalMuted.current)
                }
            }
            if (!compact && !LocalShield.current) {
                Text("TOM’S TV", fontSize = if (premium) 20.sp else 17.sp,
                    fontWeight = if (premium) FontWeight.Black else FontWeight.Bold, fontFamily = titleFont,
                    color = if (flat) Color.White else if (premium) Color(0xFFD9C1F3) else Color.Unspecified,
                    letterSpacing = if (premium) 2.sp else 3.sp, modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (compact) "▶" else "◀", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.setSidebar(if (compact) "normal" else "compact") }
                    .padding(horizontal = 10.dp, vertical = 6.dp))
        }
        run {
            // Aktuelles Profil: bei mehreren Profilen Auswahl, sonst Profil-Einstellungen
            val pName = vm.profileName()
            val pAv = vm.profileAvatar()
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).leftFocus(vm, "nav:profile").tvFocus(1.02f)
                .clip(RoundedCornerShape(14.dp)).clickable {
                    if (vm.profiles.size > 1) vm.profilePicked = false else { vm.settingsTab = 4; vm.goTo("settings") }
                }
                .padding(horizontal = if (compact) 0.dp else 8.dp, vertical = 6.dp),
                horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically) {
                Avatar(pAv, if (compact) 40.dp else 42.dp, initialOf(pName))
                if (!compact) {
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(pName, fontSize = if (premium) 17.sp else 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (vm.profiles.size > 1) "Profil wechseln" else "Profil verwalten", fontSize = if (premium) 14.sp else 13.sp, color = if (pmOnly) Color(0xFFD9C1F3) else tcol(accent), maxLines = 1)
                    }
                }
            }
        }
        val navMem = remember { FocusMemory() }
        Column(Modifier.weight(1f).enterAt(navMem) { "nav:" + current }.verticalScroll(vm.navScroll)) {
            menu.forEach { (id, emoji, label) ->
                val sel = id == current
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).leftFocus(vm, "nav:" + id).enterKey(navMem, "nav:" + id).tvFocus(1.02f).clip(RoundedCornerShape(14.dp))
                    .then(if (sel && LocalKino.current) Modifier.background(Brush.horizontalGradient(listOf(Kino.a2, Kino.a)), RoundedCornerShape(14.dp)) else if (sel && flatLook && LocalMid.current) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFFB02A8F), Color(0xFF6A2FA8)))).border(1.dp, Color(0x99E6A0D8), RoundedCornerShape(14.dp))
                          else if (sel && flatLook) Modifier.background(accent)
                          else if (sel && pmOnly) Modifier.background(Color(0xFF1D1330), RoundedCornerShape(14.dp)).border(1.5.dp, Color(0xFFDECDF8), RoundedCornerShape(14.dp))
                          else if (sel && premium) Modifier.background(if (pmOnly) Color(0x1FE040FB) else Color(0x22FFFFFF)).drawBehind {
                              drawRect(if (pmOnly) Color(0xFFE040FB) else accent, size = androidx.compose.ui.geometry.Size(4.dp.toPx(), size.height))
                          }
                          else if (sel && neon) Modifier.background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.85f), shiftHue(accent, 45f).copy(alpha = 0.45f))))
                              .border(1.dp, Color(0x59FFFFFF), RoundedCornerShape(14.dp))
                          else if (sel) Modifier.background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.55f))))
                          else Modifier)
                    .clickable { vm.goTo(id) }
                    .padding(horizontal = if (compact) 0.dp else 12.dp, vertical = if (compact) 11.dp else if (shieldNav) 9.dp else if (premium) 12.dp else 10.dp),
                    horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically) {
                    if (flatLook || pmOnly) FlatIcon(emoji, if (compact) 28.dp else if (shieldNav) 26.dp else 24.dp,
                        if (sel) (if (pmOnly) Color.White else if (LocalKino.current) Color(0xFF06121A) else if (shieldNav) Color.White else MaterialTheme.colorScheme.onPrimary) else (if (pmOnly) Color(0xFF9B98A8) else Color(0xFFC9C6D6)))
                    else GlowIcon(emoji, if (compact) (if (pmOnly) 38.dp else 30.dp) else (if (pmOnly) 30.dp else 26.dp))
                    if (!compact) {
                        Spacer(Modifier.width(10.dp))
                        Text(label, fontSize = if (shieldNav) 16.sp else if (premium) 18.sp else 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel && LocalKino.current) Color(0xFF06121A) else if (sel && flatLook) (if (shieldNav) Color.White else MaterialTheme.colorScheme.onPrimary) else if (sel && premium) Color.White else if (sel && neon) Color.White else if (sel) MaterialTheme.colorScheme.onPrimary
                                    else if (pmOnly) Color(0xFF9B98A8) else if (premium) Color(0xFFB3B3B3) else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
        if (LocalShield.current && !compact) {
            Text((if (LocalMid.current) "Deine Welt. Dein TV.  ·  v" else "Tom’s TV  v") + BuildConfig.VERSION_NAME, fontSize = 13.sp, color = LocalMuted.current,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp))
        }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().padding(start = if (LocalAtv.current) 44.dp else 24.dp, end = if (LocalAtv.current) 44.dp else 24.dp, top = 22.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (!LocalPremium.current && !LocalAtv.current) {
            Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(accent))
            Spacer(Modifier.width(10.dp))
        }
        Text(title, fontSize = if (LocalAtv.current) 22.sp else if (LocalPremium.current) 24.sp else 18.sp,
            fontWeight = if (LocalPremium.current || LocalAtv.current) FontWeight.ExtraBold else FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text("$action  ›", fontSize = if (LocalPremium.current) 16.sp else 13.sp, color = LocalMuted.current,
                modifier = Modifier.tvFocus(1.05f).clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction)
                    .padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

/** Wer schaut? – Auswahl beim Start (nur bei mehreren Profilen). */
@Composable
fun ProfilePicker(vm: AppVM) {
    val fr = remember { FocusRequester() }
    BackHandler { vm.profilePicked = true }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Wer schaut?", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, fontFamily = titleFont)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
            vm.profiles.forEach { p ->
                val cur = p.id == vm.profileId
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.then(if (cur) Modifier.focusRequester(fr) else Modifier)
                        .tvFocus(1.08f).clip(CircleShape)
                        .clickable { vm.switchProfile(p.id); vm.profilePicked = true }.padding(6.dp)) {
                        Avatar(p.avatar, 110.dp, initialOf(p.name))
                    }
                    Text(p.name, fontSize = 18.sp, fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(top = 8.dp), maxLines = 1)
                }
            }
        }
    }
}

/** Große Kacheln mit Farbverlauf für die Hauptbereiche (Blau-Design). */
@Composable
fun BrandTiles(vm: AppVM) {
    val tiles = listOf(
        Triple("Live TV", "tv", listOf(Color(0xFF1E3FB5), Color(0xFF0B1A5E))) to "itv",
        Triple("Filme", "film", listOf(Color(0xFF7B2FBE), Color(0xFF2A0F5E))) to "vod",
        Triple("Serien", "popcorn", listOf(Color(0xFF0E8FA8), Color(0xFF07325A))) to "series",
        Triple("Merkliste", "bookmark", listOf(Color(0xFFC2336B), Color(0xFF521233))) to "watch",
        Triple("EPG", "calendar", listOf(Color(0xFF1E8E5A), Color(0xFF0A3A2C))) to "epg"
    )
    val perf = LocalPerf.current
    val src = vm.homeNew.ifEmpty { vm.homeCached }
    val imgs = listOf(vm.recentChans.firstOrNull()?.logo, src.getOrNull(0)?.let { it.backdrop ?: it.logo },
        src.getOrNull(1)?.let { it.backdrop ?: it.logo }, src.getOrNull(2)?.let { it.backdrop ?: it.logo }, null)
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(tiles) { ti, (t, target) ->
            Box(Modifier.width(190.dp).height(104.dp).tvFocus(1.05f)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(t.third))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                .clickable { vm.goTo(target) }) {
                imgs.getOrNull(ti)?.let { u ->
                    if (!perf) {
                        AsyncImage(model = u, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().alpha(0.32f))
                        Box(Modifier.fillMaxSize().background(
                            Brush.horizontalGradient(listOf(t.third[1].copy(alpha = 0.85f), Color.Transparent))))
                    }
                }
                Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp)) {
                    GlowIcon(t.second, 44.dp)
                    Text(t.first, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
fun HeroBanner(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    if (LocalAtv.current) AtvHero(vm, item, index, count, fr)
    else if (LocalPremium.current || LocalShield.current) PremiumHero(vm, item, index, count, fr) else ClassicHero(vm, item, index, count, fr)
}

@Composable
fun ClassicHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val accent = MaterialTheme.colorScheme.primary
    val blue = LocalBlue.current
    val gray = if (blue) Color(0xFFB4BBC9) else Color(0xFFC3CAD1)
    val shade = if (blue) Color(0xFF040714) else Color(0xFF07070B)
    Box(Modifier.fillMaxWidth().height(300.dp).padding(horizontal = 16.dp, vertical = 4.dp)
        .clip(RoundedCornerShape(if (blue) 28.dp else 24.dp))) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(if (item.backdrop != null) 0.7f else 0.45f))
        HeroTrailer(vm, item, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(shade, shade.copy(alpha = 0.9f), shade.copy(alpha = 0.25f)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            if (blue) listOf(Color.Transparent, Color.Transparent, shade.copy(alpha = 0.55f), shade)
            else listOf(Color.Transparent, Color(0xCC07070B)))))
        Row(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(accent).padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text("NEU", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                            color = MaterialTheme.colorScheme.onPrimary)
                    }
                    if (item.year.isNotBlank()) {
                        Spacer(Modifier.width(10.dp))
                        Text(yearOf(item.year), fontSize = 14.sp, color = gray)
                    }
                }
                Text(item.name, fontSize = 30.sp, fontWeight = if (blue) FontWeight.ExtraBold else FontWeight.Bold,
                    fontFamily = titleFont, color = if (blue) Color.White else Color.Unspecified,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                Text(item.descr, fontSize = 14.sp, color = gray, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp, end = 24.dp))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).onFocusChanged { if (it.hasFocus) vm.heroBtn = 0 }.tvFocus()) {
                        Text("▶  Jetzt ansehen", fontSize = 16.sp)
                    }
                    OutlinedButton(onClick = { vm.trailerSeries = false; vm.trailerReq = item }, modifier = Modifier.onFocusChanged { if (it.hasFocus) vm.heroBtn = 1 }.tvFocus()) {
                        Text("🎬 Trailer", fontSize = 16.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatchOf(item, "vod") }, modifier = Modifier.onFocusChanged { if (it.hasFocus) vm.heroBtn = 2 }.tvFocus()) {
                        Text("＋ Merkliste", fontSize = 16.sp)
                    }
                }
            }
            AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(160.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33)).border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)))
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(if (i == index) 18.dp else 7.dp, 7.dp).clip(CircleShape)
                    .background(if (i == index) accent else Color(0x66FFFFFF)))
            }
        }
    }
}

/** Apple-TV-Banner: Bild über die ganze Breite, großer Titel, weiße Pille „Jetzt ansehen“. */
@Composable
fun AtvHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val base = Color(0xFF0A0A0C)
    var f1 by remember { mutableStateOf(false) }
    var f2 by remember { mutableStateOf(false) }
    var f3 by remember { mutableStateOf(false) }
    val locked = f1 || f2 || f3
    LaunchedEffect(locked) {
        while (locked) {
            val st = vm.rowState("home")
            if (st.firstVisibleItemIndex > 0 || st.firstVisibleItemScrollOffset > 0) runCatching { st.scrollToItem(0) }
            delay(250)
        }
    }
    val kb = remember(index, item.id) { Animatable(0f) }
    LaunchedEffect(index, item.id) { if (!vm.perfMode) kb.animateTo(1f, tween(14000, easing = androidx.compose.animation.core.LinearEasing)) }
    Box(Modifier.fillMaxWidth().height(366.dp).clipToBounds()) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize().alpha(if (item.backdrop != null) 1f else 0.5f)
                .graphicsLayer { val s = 1f + 0.09f * kb.value; scaleX = s; scaleY = s; translationX = -18f * kb.value })
        HeroTrailer(vm, item, Modifier.matchParentSize())
        Box(Modifier.matchParentSize().background(Brush.horizontalGradient(0f to base.copy(alpha = 0.95f), 0.45f to base.copy(alpha = 0.7f), 0.8f to base.copy(alpha = 0.08f), 1f to Color.Transparent)))
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color(0x55000000), 0.3f to Color.Transparent, 0.6f to Color.Transparent, 1f to base)))
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.58f).padding(start = 44.dp, top = 56.dp, bottom = 22.dp)) {
            Text("NEU IM ANGEBOT", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = Color(0xFFB8B8C0))
            Text(item.name, fontSize = if (item.name.length > 24) 30.sp else 40.sp, lineHeight = if (item.name.length > 24) 33.sp else 43.sp, fontWeight = FontWeight.ExtraBold, color = Color.White,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (LocalBadges.current) qualityBadges(item.name).forEach { b ->
                    Text(b, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE6E6EE),
                        modifier = Modifier.border(1.dp, Color(0x99FFFFFF), RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 1.dp))
                }
                if (item.year.isNotBlank()) Text(yearOf(item.year), fontSize = 15.sp, color = Color(0xFFE0E0E6))
                // Genre und Bewertung nur, wenn das Portal sie mitliefert
                val genre = item.meta.lines().firstOrNull { it.startsWith("Genre: ") }?.removePrefix("Genre: ")?.substringBefore(",")?.trim().orEmpty()
                val rate = item.meta.lines().firstOrNull { it.startsWith("Bewertung: ") }?.removePrefix("Bewertung: ")?.trim().orEmpty()
                if (genre.isNotEmpty()) Text("•  " + genre, fontSize = 15.sp, color = Color(0xFFE0E0E6), maxLines = 1)
                if (rate.isNotEmpty()) Text("•  ★ " + rate, fontSize = 15.sp, color = Color(0xFFF5C542), maxLines = 1)
            }
            Text(item.descr, fontSize = 15.sp, lineHeight = 21.sp, color = Color(0xFFE0E0E6), maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                val s1 by animateFloatAsState(if (f1) 1.07f else 1f, tween(140), label = "atvBtn1")
                Button(onClick = { vm.openHomeItem(item, "vod") },
                    modifier = Modifier.focusRequester(fr)
                        .onFocusChanged { f1 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 0 }
                        .graphicsLayer { scaleX = s1; scaleY = s1 }
                        .border(if (f1) 3.dp else 0.dp, if (f1) Color(0xCCB4B8C2) else Color.Transparent, RoundedCornerShape(50)),
                    shape = RoundedCornerShape(50), contentPadding = PaddingValues(horizontal = 26.dp, vertical = 9.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text("▶  Jetzt ansehen", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                val s3 by animateFloatAsState(if (f3) 1.1f else 1f, tween(140), label = "atvBtn3")
                Button(onClick = { vm.trailerSeries = false; vm.trailerReq = item },
                    modifier = Modifier
                        .onFocusChanged { f3 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 1 }
                        .graphicsLayer { scaleX = s3; scaleY = s3 }
                        .border(if (f3) 3.dp else 0.dp, if (f3) Color.White else Color.Transparent, RoundedCornerShape(50)),
                    shape = RoundedCornerShape(50), contentPadding = PaddingValues(horizontal = 22.dp, vertical = 9.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x99505058), contentColor = Color.White)) {
                    Text("🎬  Trailer", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                val s2 by animateFloatAsState(if (f2) 1.1f else 1f, tween(140), label = "atvBtn2")
                Button(onClick = { vm.toggleWatchOf(item, "vod") },
                    modifier = Modifier
                        .onFocusChanged { f2 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 2 }
                        .graphicsLayer { scaleX = s2; scaleY = s2 }
                        .border(if (f2) 3.dp else 0.dp, if (f2) Color.White else Color.Transparent, RoundedCornerShape(50)),
                    shape = RoundedCornerShape(50), contentPadding = PaddingValues(horizontal = 22.dp, vertical = 9.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x99505058), contentColor = Color.White)) {
                    Text("＋  Merkliste", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        val prog = remember(index) { Animatable(0f) }
        LaunchedEffect(index) { if (!vm.perfMode) prog.animateTo(1f, tween(8000, easing = androidx.compose.animation.core.LinearEasing)) }
        Row(Modifier.align(Alignment.BottomEnd).padding(end = 44.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(count) { i ->
                if (i == index) Box(Modifier.size(44.dp, 6.dp).clip(CircleShape).background(Color(0x55FFFFFF))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(if (vm.perfMode) 1f else prog.value).background(Color.White))
                } else Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0x66FFFFFF)))
            }
        }
    }
}

/** Premium-Banner: randlos, groß, Bild läuft nach links und unten ins Schwarz aus. */
@Composable
fun PremiumHero(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val gray = Color(0xFFD0D0D0)
    val pm = LocalPremium.current && !LocalFlat.current
    val red = if (pm) Color(0xFFA771EE) else MaterialTheme.colorScheme.primary
    val shield = LocalShield.current
    val mid = LocalMid.current
    val heroBase = if (mid) Color(0xFF040A1E) else Color.Black
    var g1 by remember { mutableStateOf(false) }
    var g2 by remember { mutableStateOf(false) }
    var g3 by remember { mutableStateOf(false) }
    val heroLocked = g1 || g2 || g3
    LaunchedEffect(heroLocked) {
        while (heroLocked) {
            val st = vm.rowState("home")
            if (st.firstVisibleItemIndex > 0 || st.firstVisibleItemScrollOffset > 0) runCatching { st.scrollToItem(0) }
            delay(250)
        }
    }
    Box(Modifier.fillMaxWidth()
        .then(if (mid) Modifier else if (shield) Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp)).border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(20.dp)) else Modifier)
        .heightIn(min = if (LocalKino.current) 300.dp else if (mid) 250.dp else if (shield) 210.dp else 360.dp)) {
        AsyncImage(model = item.backdrop ?: item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize().alpha(if (item.backdrop != null) 0.95f else 0.5f))
        HeroTrailer(vm, item, Modifier.matchParentSize())
        Box(Modifier.matchParentSize().background(
            Brush.horizontalGradient(0f to heroBase, 0.38f to heroBase.copy(alpha = 0.85f), 0.75f to heroBase.copy(alpha = 0.08f), 1f to Color.Transparent)))
        Box(Modifier.matchParentSize().background(
            Brush.verticalGradient(0f to Color(0x66000000), 0.25f to Color.Transparent, 0.7f to Color.Transparent, 1f to heroBase)))
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = 32.dp, top = if (shield) 12.dp else 24.dp, bottom = if (shield) 16.dp else 40.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (shield) "★" else "T", fontSize = 22.sp, fontWeight = FontWeight.Black, color = if (shield && !mid) Color.White else red)
                Spacer(Modifier.width(8.dp))
                Text("NEU IM ANGEBOT", fontSize = if (shield) 13.sp else 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, color = gray)
            }
            Text(if (pm) cleanTitle(item.name).uppercase() else cleanTitle(item.name), fontSize = if (shield) (if (cleanTitle(item.name).length > 24) 24.sp else 28.sp) else 42.sp, lineHeight = if (shield) (if (cleanTitle(item.name).length > 24) 27.sp else 31.sp) else 46.sp, fontWeight = if (pm) FontWeight.Bold else FontWeight.Black, color = Color.White,
                maxLines = if (shield && !mid) 1 else 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Neu", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF46D369))
                if (mid && LocalBadges.current) qualityBadges(item.name).forEach { b ->
                    Spacer(Modifier.width(10.dp))
                    Text(b, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE6E6EE),
                        modifier = Modifier.border(1.dp, Color(0x99FFFFFF), RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 1.dp))
                }
                if (item.year.isNotBlank()) {
                    Spacer(Modifier.width(12.dp))
                    Text(yearOf(item.year), fontSize = 14.sp, color = gray)
                }
            }
            Text(item.descr, fontSize = if (shield) 13.sp else 17.sp, lineHeight = if (shield) 18.sp else 23.sp, color = gray, maxLines = if (shield) 2 else 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(if (shield) 8.dp else 18.dp))
            Row(Modifier.wrapContentWidth(align = Alignment.Start, unbounded = true), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.openHomeItem(item, "vod") },
                    modifier = Modifier.focusRequester(fr).onFocusChanged { g1 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 0 }.tvFocus()
                        .then(if (pm) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFFD9C1F3), Color(0xFFA771EE))), RoundedCornerShape(6.dp)) else Modifier),
                    shape = RoundedCornerShape(if (mid) 24.dp else 6.dp),
                    border = if (mid && !LocalKino.current) androidx.compose.foundation.BorderStroke(1.5.dp, Color.White) else null,
                    colors = if (LocalKino.current) ButtonDefaults.buttonColors(containerColor = Kino.a, contentColor = Color(0xFF06121A))
                        else if (mid) ButtonDefaults.buttonColors(containerColor = Color(0x33000000), contentColor = Color.White)
                        else if (shield) ButtonDefaults.buttonColors(containerColor = Color(0xFFF801A3), contentColor = Color.White)
                        else if (pm) ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = Color.White)
                        else ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
                    Text(if (shield) "▶  Jetzt ansehen" else "▶  Abspielen", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
                Button(onClick = { vm.trailerSeries = false; vm.trailerReq = item },
                    modifier = Modifier.onFocusChanged { g3 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 1 }.tvFocus(),
                    shape = RoundedCornerShape(if (mid) 24.dp else 6.dp),
                    border = if (shield) androidx.compose.foundation.BorderStroke(1.dp, Color(0x80FFFFFF)) else if (pm) androidx.compose.foundation.BorderStroke(1.dp, Color(0x40FFFFFF)) else null,
                    colors = ButtonDefaults.buttonColors(containerColor = if (shield) Color(0x66000000) else if (pm) Color(0xFF07040F) else Color(0xB36D6D6E), contentColor = Color.White)) {
                    Text("🎬  Trailer", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
                Button(onClick = { vm.toggleWatchOf(item, "vod") },
                    modifier = Modifier.onFocusChanged { g2 = it.hasFocus; if (it.hasFocus) vm.heroBtn = 2 }.tvFocus(),
                    shape = RoundedCornerShape(if (mid) 24.dp else 6.dp),
                    border = if (shield) androidx.compose.foundation.BorderStroke(1.dp, Color(0x80FFFFFF)) else if (pm) androidx.compose.foundation.BorderStroke(1.dp, Color(0x40FFFFFF)) else null,
                    colors = ButtonDefaults.buttonColors(containerColor = if (shield) Color(0x66000000) else if (pm) Color(0xFF07040F) else Color(0xB36D6D6E), contentColor = Color.White)) {
                    Text("＋  Merkliste", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
        }
        Row(Modifier.align(if (mid) Alignment.BottomCenter else Alignment.BottomEnd).padding(end = if (mid) 0.dp else 32.dp, bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(if (shield) 6.dp else 4.dp)) {
            repeat(count) { i ->
                if (shield) Box(Modifier.size(9.dp).clip(CircleShape).background(if (i == index) sPink else Color(0x77FFFFFF)))
                else Box(Modifier.size(if (i == index) 22.dp else 12.dp, 3.dp)
                    .background(if (i == index) (if (pm) Color(0xFFE2CBF7) else Color.White) else (if (pm) Color(0xFF5D595E) else Color(0x55FFFFFF))))
            }
        }
    }
}

/** Mitternacht: Rangliste der neuesten Titel mit großen Umriss-Zahlen. */
@Composable
fun MidTopRow(vm: AppVM) {
    val list = vm.homeNew.ifEmpty { vm.homeCached }.take(10)
    if (list.size < 3) return
    SectionHeader("Top 10 – Neu im Angebot", "Alle anzeigen") { vm.goTo("vod") }
    LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(list) { i, mv ->
            Box(Modifier.width(if (i >= 9) 250.dp else 205.dp)) {
                Text((i + 1).toString(), modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 4.dp),
                    style = androidx.compose.ui.text.TextStyle(fontSize = 120.sp, fontWeight = FontWeight.Black, letterSpacing = (-8).sp,
                        color = Color(0xCCA0AAE6), drawStyle = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)))
                Box(Modifier.align(Alignment.CenterEnd)) {
                    MiniPoster(mv) { vm.openHomeItem(mv, "vod") }
                    if (i < 3) Text("NEU", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = Color.White,
                        modifier = Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(5.dp))
                            .background(if (LocalKino.current) Kino.a else Color(0xFFC2358F)).padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }
        }
    }
}

/** Heute Abend: die nächsten Sendungen der beliebten Sender (Startzeit und Countdown). */
@Composable
fun EveningRow(vm: AppVM) {
    val chs = vm.homeChannels.take(10)
    if (chs.isEmpty()) return
    LaunchedEffect(chs.size) { chs.forEach { vm.loadEpg(it.id, 12) } }
    val nowS = System.currentTimeMillis() / 1000
    val w0 = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 19); set(java.util.Calendar.MINUTE, 30); set(java.util.Calendar.SECOND, 0)
    }.timeInMillis / 1000
    val w1 = w0 + 3 * 3600L + 1800L
    val entries = chs.mapNotNull { ch ->
        vm.epgList(ch.id).firstOrNull { it.startTs >= maxOf(w0, nowS) && it.startTs <= w1 }?.let { ch to it }
    }.sortedBy { it.second.startTs }
    if (entries.isEmpty()) return
    val tf = remember { java.text.SimpleDateFormat("HH:mm", java.util.Locale.GERMANY) }
    SectionHeader("Heute Abend im Fernsehen")
    LazyRow(contentPadding = PaddingValues(horizontal = homePad(), vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(entries) { (ch, e) ->
            val mins = ((e.startTs - nowS) / 60).toInt().coerceAtLeast(0)
            val cd = if (mins >= 60) "in " + (mins / 60) + " Std. " + (mins % 60) + " Min." else "in " + mins + " Min."
            Column(Modifier.width(250.dp).tvFocus(1.05f).glass(16.dp).clickable { vm.openHomeItem(ch, "itv") }.padding(14.dp)) {
                Text(tf.format(java.util.Date(e.startTs * 1000)) + " · " + cd, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9DB0FF), maxLines = 1)
                Text(e.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp).heightIn(min = 44.dp))
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(ch.name, fontSize = 13.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun MiniPoster(entry: Item, onClick: () -> Unit) {
    val premium = LocalPremium.current
    val pmOnly = LocalPremium.current && !LocalFlat.current
    val r = if (premium) 6.dp else 14.dp
    Box(Modifier.width(if (premium) 166.dp else 132.dp)) {
        val sink = LocalAmbientSink.current
        var pfocus by remember { mutableStateOf(false) }
        Box(Modifier.tvFocus(1.06f).onFocusChanged { pfocus = it.hasFocus; if (it.hasFocus) sink(entry.logo ?: entry.backdrop) }
            .clip(RoundedCornerShape(r)).background(if (premium) Color(0xFF1A1A1A) else Color(0xFF222A33))
            .border(if (premium) 0.dp else 1.dp, if (premium) Color.Transparent else Color(0x22FFFFFF), RoundedCornerShape(r))
            .clickable(onClick = onClick)) {
            val pctx = LocalContext.current
            val pperf = LocalPerf.current
            val req = remember(entry.logo, pperf) {
                coil.request.ImageRequest.Builder(pctx).data(entry.logo).size(300, 450).crossfade(if (pperf) 0 else 120).allowRgb565(pperf).build()
            }
            AsyncImage(model = req, contentDescription = entry.name, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            QualityBadges(entry.name, Modifier.align(Alignment.TopEnd).padding(4.dp))
            if (pfocus || entry.logo.isNullOrBlank()) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                .padding(start = 8.dp, end = 8.dp, top = 28.dp, bottom = 8.dp)) {
                // Mit Fokus läuft der Titel als Laufschrift, damit man ihn ganz lesen kann
                if (pfocus) Text(cleanTitle(entry.name), fontSize = if (premium) 16.sp else 13.sp, color = Color.White, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                    modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE, initialDelayMillis = 500, velocity = 40.dp))
                else Text(cleanTitle(entry.name), fontSize = if (premium) 16.sp else 13.sp, color = Color.White, maxLines = if (premium) 2 else 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun ChannelTile(ch: Item, onClick: () -> Unit) {
    var cfocus by remember { mutableStateOf(false) }
    Column(Modifier.width(124.dp).onFocusChanged { cfocus = it.hasFocus }.tvFocus(1.06f).glass(14.dp).clickable(onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.height(48.dp).fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        if (LocalPremium.current) Text(ch.name, fontSize = 15.sp, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        else if (cfocus) Text(ch.name, fontSize = 13.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
            modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE, initialDelayMillis = 500, velocity = 40.dp))
        else Text(ch.name, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FavsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember(vm.favTick, vm.favLists) {
        listOf(Triple("itv", "Live TV – Favoriten", vm.favsFor("itv"))) +
            vm.favLists.map { Triple("itv:" + it.id, "Live TV – " + it.name, vm.listItems(it.id)) } +
            listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.favsFor(t)) }
    }
    Column(Modifier.fillMaxSize().inContent(vm, "fav").verticalScroll(vm.pageScroll("fav")).padding(vertical = 20.dp)) {
        Row(Modifier.padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("FAVORITEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { vm.push(Screen.FavLists) }, modifier = Modifier.tvFocus()) { Text("Listen verwalten ›") }
        }
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch keine Favoriten. Halte OK gedrückt oder nutze die Menü-Taste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(state = vm.rowState("fav:" + type), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { f ->
                        Box(Modifier.itemFocus(vm, "fav:" + type + ":" + f.id)) {
                            if (type == "itv") ChannelTile(f) { vm.openFavorite(type, f) }
                            else if (type.startsWith("itv:")) ChannelTile(f) { vm.openFavoriteList(type.removePrefix("itv:"), f) }
                            else MiniPoster(f) { vm.openFavorite(type, f) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val tabs = listOf("Portale & Sender", "Startseite & Design", "Player", "Bild & Ton", "Profile", "System")
    val fr = remember { FocusRequester() }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(vm.settingsTab) {
        if (first) first = false else vm.settingsScroll.scrollTo(0)
    }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val tabMem = remember { FocusMemory() }
    Row(Modifier.fillMaxSize().padding(28.dp)) {
        Column(Modifier.width(280.dp).fillMaxHeight().padding(end = 20.dp).enterAt(tabMem) { "st:" + vm.settingsTab }) {
            Text("EINSTELLUNGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(4.dp))
            Box(Modifier.width(60.dp).height(2.dp).background(accent))
            Spacer(Modifier.height(16.dp))
            tabs.forEachIndexed { i, label ->
                val sel = vm.settingsTab == i
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).enterKey(tabMem, "st:" + i)
                    .then(if (i == vm.settingsTab) Modifier.focusRequester(fr) else Modifier)
                    .onFocusChanged { if (it.isFocused && !vm.designFocusReq) vm.settingsTab = i }
                    .tvFocus(1.03f).clip(RoundedCornerShape(14.dp))
                    .then(if (sel) Modifier.glass(14.dp) else Modifier)
                    .clickable { vm.settingsTab = i }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(3.dp).height(20.dp).background(if (sel) accent else Color.Transparent))
                    Spacer(Modifier.width(12.dp))
                    Text(label, fontSize = 17.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        color = if (sel) tcol(accent) else Color.Unspecified, maxLines = 1)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(vm.settingsScroll)) {
            Text(tabs[vm.settingsTab].uppercase(), fontSize = 14.sp, letterSpacing = 4.sp, color = gray)
            Column(Modifier.padding(top = 10.dp).glass(22.dp).padding(20.dp)) { SettingsBlock(vm, vm.settingsTab) }
        }
    }
}

@Composable
fun SettingsBlock(vm: AppVM, sec: Int) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.padding(top = 10.dp)) {
        if (sec == 0) {
            OutlinedButton(onClick = { vm.push(Screen.Portals) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Portale verwalten  ›")
            }
            OutlinedButton(onClick = { vm.runProviderCheck() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.checking) "Prüfe …" else "Anbieter-Check starten")
            }
            vm.checkRows.forEach { Text(it, fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp)) }
            Text("Misst die Antwortzeit deines Internets und jedes Portals und zählt die Stream-Abbrüche seit App-Start. " +
                "So siehst du, ob der Anbieter oder dein Netz das Problem ist.", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
        }
        if (sec == 5) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { vm.checkUpdate() }, modifier = Modifier.tvFocus()) { Text("Nach Updates suchen") }
                if (vm.updateInfo != null) {
                    Button(onClick = { vm.installUpdate() }, modifier = Modifier.tvFocus()) { Text("Jetzt installieren") }
                }
            }
            vm.updateMsg?.let { Text(it, fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 6.dp)) }
            if (vm.updateProgress >= 0) {
                LinearProgressIndicator(progress = { vm.updateProgress / 100f },
                    modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(top = 6.dp))
            }
            Text("GERÄTEPROFIL", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleProfile() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Profil: " + vm.profileName(vm.deviceProfile) + "  ⟳")
            }
            Text("Auto erkennt das Gerät selbst. Stark: Shield. Mittel: Fire TV, Cube. Schwach: Strong Box. " +
                "Das Profil stellt Leistungsmodus und Kompatibilitätsmodus passend ein. Einzeln änderbar, dann steht hier „Angepasst“.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            if (vm.deviceProfile == "auto") Text("Erkannt: " + vm.profileName(vm.detectProfile()),
                fontSize = 13.sp, color = gray)
            Text("Gerät: " + vm.deviceSummary(), fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 2.dp))
        }
        if (sec == 4) {
            Text("PROFIL", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            var profText by remember { mutableStateOf("") }
            var profDel by remember { mutableStateOf(false) }
            OutlinedButton(onClick = { vm.nextProfile() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Aktives Profil: " + vm.profileName() + (if (vm.profiles.size > 1) "  ⟳" else ""))
            }
            Box(Modifier.widthIn(max = 420.dp).padding(top = 6.dp)) { Field("Profilname", profText) { profText = it } }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.addProfile(profText); profText = "" }, modifier = Modifier.delFocus(vm, "prof:add").tvFocus()) { Text("＋ Neues Profil") }
                OutlinedButton(onClick = { vm.renameProfile(profText); profText = "" }, modifier = Modifier.tvFocus()) { Text("Umbenennen") }
                if (vm.profileId.isNotEmpty()) {
                    OutlinedButton(onClick = { if (profDel) { vm.pendingFocus = "prof:add"; vm.deleteProfile(); profDel = false } else profDel = true },
                        modifier = Modifier.tvFocus()) { Text(if (profDel) "Wirklich löschen?" else "Profil löschen") }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AVATARS.forEach { k ->
                    Box(Modifier.tvFocus(1.1f).clip(CircleShape).clickable { vm.setAvatar(k) }
                        .border(if (vm.profileAvatar() == k) 3.dp else 0.dp, Color.White, CircleShape).padding(4.dp)) {
                        Avatar(k, 56.dp, initialOf(vm.profileName()))
                    }
                }
            }
            if (vm.profiles.size > 1) {
                OutlinedButton(onClick = { vm.toggleAskProfile() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                    Text("Profilwahl beim Start: " + (if (vm.askProfile) "an" else "aus"))
                }
            }
            Text("Jedes Profil hat eigene Favoriten, Merkliste, Weiterschauen und Zuletzt gesehen.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 1) {
            if (LocalShield.current || (LocalPremium.current && !LocalFlat.current)) {
                Text("SCHRIFT- UND AKZENTFARBE", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
                Text(if (LocalKino.current) "Im Kino-Design: weiße Schrift. Die Akzentfarbe wählst du bei „Design“ weiter unten." else "In diesem Design fest vorgegeben: weiße Schrift und fester Akzent. Zum Ändern ein anderes Design wählen.",
                    fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            } else {
            Text("SCHRIFTFARBE", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Palette.textOptions.forEach { (name, c) ->
                    OutlinedButton(onClick = { vm.setTextColor(name) }, modifier = Modifier.tvFocus()) {
                        Text((if (vm.textColorName == name) "● " else "") + name, color = c)
                    }
                }
            }
            Text("AKZENTFARBE", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Palette.accentOptions.forEach { (name, c) ->
                    OutlinedButton(onClick = { vm.setAccent(name) }, modifier = Modifier.tvFocus()) {
                        Text((if (vm.accentName == name) "● " else "") + name, color = c)
                    }
                }
            }
            }
            Text("SEITENLEISTE", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleSidebar() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text((when (vm.sidebarMode) {
                    "compact" -> "Kompakt (nur Symbole)"
                    "normal" -> "Normal (mit Namen)"
                    else -> "Automatisch"
                }) + "  ⟳")
            }
        }
        if (sec == 5) {
            Text("SICHERUNG & AUTOSTART", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    vm.showNotice(if (vm.createBackup()) "Sicherung erstellt" else "Sicherung fehlgeschlagen")
                }, modifier = Modifier.tvFocus()) { Text("💾 Sicherung erstellen") }
                OutlinedButton(onClick = { vm.restoreBackup() }, modifier = Modifier.tvFocus()) { Text("♻ Sicherung laden") }
            }
            Text(vm.lastBackupText + "  ·  automatisch jede Woche  ·  " + vm.backupFile().absolutePath,
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            Text("Die Sicherung bleibt bei App-Updates erhalten, wird aber beim Deinstallieren der App mit gelöscht.",
                fontSize = 13.sp, color = gray)
            val ctxA = LocalContext.current
            OutlinedButton(onClick = {
                vm.toggleAutostart()
                if (vm.autostart && android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(ctxA)) {
                    try {
                        ctxA.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + ctxA.packageName)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) { vm.showNotice("Diese Box bietet die nötige Freigabe nicht an") }
                }
            }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Autostart mit der Box: " + (if (vm.autostart) "an" else "aus"))
            }
            Text("Braucht die Freigabe „Über anderen Apps einblenden“. Nicht jede Box erlaubt das.",
                fontSize = 13.sp, color = gray)
        }
        if (sec == 1) {
            Text("DESIGN", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleGlow() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Glow & Rand: " + vm.glowLabel() + "  ⟳")
            }
            OutlinedButton(onClick = { vm.push(Screen.DesignScale) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Größe: " + vm.uiSizeLabel() + "  ›")
            }
            OutlinedButton(onClick = { vm.push(Screen.HomeLayout) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Startseite einrichten  ›")
            }
        }
        if (sec == 0) {
            OutlinedButton(onClick = { vm.push(Screen.FavLists) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Favoritenlisten verwalten  ›")
            }
        }
        if (sec == 1) {
            OutlinedButton(onClick = { vm.toggleHomeGerman() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Startseite nur deutsche Titel: " + (if (vm.homeGerman) "an" else "aus") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleBadges() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Qualitäts-Abzeichen (4K, HDR …): " + (if (vm.badges) "an" else "aus") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.flipHeroTrailer() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Trailer im Banner (Startseite): " + (if (vm.heroTrailerOn) "an" else "aus") + "  ⟳")
            }
            val dfr = remember { FocusRequester() }
            LaunchedEffect(vm.designFocusReq) {
                if (vm.designFocusReq) { delay(350); runCatching { dfr.requestFocus() }; vm.designFocusReq = false }
            }
            OutlinedButton(onClick = { vm.toggleDesign() }, modifier = Modifier.padding(top = 8.dp).focusRequester(dfr).tvFocus()) {
                Text(when (vm.designMode) {
                    "flat" -> "Flat (flach, Linien-Symbole)  ⟳"
                    "premium" -> "Premium (Schwarz, Violett-Fokus, weiße Schrift)  ⟳"
                    "shield" -> "Shield (Schwarz und Pink, Live-TV-Reihe, Hinweisleiste)  ⟳"
                    "midnight" -> "Mitternacht (Nachtblau, Magenta, Live-Kategorien)  ⟳"
                    "atv" -> "Apple TV (Tab-Leiste oben, großes Titelbild)  ⟳"
                    "kino" -> "Kino (Seitenleiste, Funktionskacheln, wählbare Akzentfarbe)  ⟳"
                    "oled" -> "OLED-Schwarz  ⟳"
                    "neon" -> "Neon-Glas (Glas, Farbverläufe, Neon-Glow)  ⟳"
                    else -> "Mitternacht (Nachtblau, Magenta, Live-Kategorien)  ⟳"
                })
            }
            if (vm.designMode == "kino") OutlinedButton(onClick = { vm.cycleKinoAccent() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Akzentfarbe (Kino): " + Kino.labels[Kino.idx.coerceIn(0, 4)] + "  ⟳")
            }
        }
        if (sec == 1) {
            Text("LEISTUNG", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.togglePerf() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(if (vm.perfMode) "Leistungsmodus: an  ⟳" else "Leistungsmodus: aus  ⟳")
            }
            Text("An: keine Animationen, keine Vorschau, kein Banner-Wechsel. Gut für ältere Boxen.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.toggleStartAnim() }, modifier = Modifier.padding(top = 10.dp).tvFocus()) {
                Text(if (vm.startAnim) "Startanimation: an  ⟳" else "Startanimation: aus  ⟳")
            }
        }
        if (sec == 2) {
            Text("KOMFORT", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleInfoSeconds() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("Sender-Info im Live-Bild: " + vm.infoSeconds + " Sekunden  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleSleep() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min.") + "  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleResumeLast() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.resumeLastOnStart) "Beim Start letzten Sender fortsetzen: an  ⟳"
                    else "Beim Start letzten Sender fortsetzen: aus  ⟳")
            }
        }
        if (sec == 2) {
            Text("SERIEN", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.toggleAutoNext() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(if (vm.autoNext) "Nächste Folge automatisch: an  ⟳" else "Nächste Folge automatisch: aus  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Intro überspringen: " + vm.introSeconds + " Sekunden  ⟳")
            }
            OutlinedButton(onClick = { vm.toggleAutoIntro() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.autoSkipIntro) "Intro automatisch überspringen: an  ⟳" else "Intro automatisch überspringen: aus  ⟳")
            }
            Text("Tipp: Am Ende des Vorspanns im Player Menü öffnen und „Intro-Ende hier merken“ wählen. Das gilt dann für alle Folgen dieser Serie. Sonst springt die App die eingestellte Zeit vor.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 2) {
            Text("ZUSATZINFOS (OPTIONAL)", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            Box(Modifier.padding(top = 4.dp)) { Field("TMDB-Schlüssel (kostenlos auf themoviedb.org)", vm.tmdbKey) { vm.updateTmdbKey(it) } }
            Text("Mit Schlüssel ergänzt die App fehlende Poster, Beschreibungen und Bewertungen bei Filmen und Serien.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 1) {
            OutlinedButton(onClick = { vm.toggleIntroSound() }, modifier = Modifier.padding(top = 14.dp).tvFocus()) {
                Text(if (vm.introSound) "Start-Sound: an  ⟳" else "Start-Sound: aus  ⟳")
            }
        }
        if (sec == 5) {
            Text("SPEICHER", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            LaunchedEffect(Unit) { vm.refreshCacheSize() }
            OutlinedButton(onClick = { vm.clearCache() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("🗑  Cache leeren" + (if (vm.cacheSizeText.isNotEmpty()) "  (jetzt " + vm.cacheSizeText + ")" else ""))
            }
            OutlinedButton(onClick = { vm.cycleCacheLimit() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Automatisch leeren ab: " + (if (vm.cacheLimitMb == 0) "aus" else vm.cacheLimitMb.toString() + " MB") + "  ⟳")
            }
            Text("Leert Bilder und Update-Dateien. Beim Leeren per Knopf werden auch die gespeicherten Senderlisten gelöscht, der nächste Start dauert dann etwas länger.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 5) {
            Text("SICHERUNG & HILFE", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text("📱 Backup und Wiederherstellung (per Handy)")
            }
            OutlinedButton(onClick = { vm.push(Screen.LogView) }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("🧾 Fehlerprotokoll ansehen")
            }
        }
        if (sec == 3) {
            Text("BILD & TON", fontSize = 13.sp, letterSpacing = 4.sp, color = tcol(accent), modifier = Modifier.padding(top = 14.dp))
            OutlinedButton(onClick = { vm.cycleQuality() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
                Text(when (vm.qualityMode) {
                    "max" -> "Maximale Qualität (immer die höchste)  ⟳"
                    "adaptive" -> "Beste Qualität, passt sich der Leitung an  ⟳"
                    else -> "Automatisch (an Bildschirm angepasst)  ⟳"
                })
            }
            Text("Gilt ab dem nächsten gestarteten Stream. Bild und Ton werden nicht umgerechnet.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleHdr() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("HDR-Ausgabe: " + vm.hdrLabel() + "  ⟳")
            }
            Text("Fordert bei HDR-Filmen den HDR-Farbraum an, damit der Fernseher auf HDR umschaltet.", fontSize = 13.sp, color = gray)
            OutlinedButton(onClick = { vm.cycleAfr() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Bildwiederholrate anpassen: " + vm.afrLabel() + "  ⟳")
            }
            Text("Stellt den Fernseher auf den Takt des Films (z. B. 24 oder 25 Bilder/s) um. Der Bildschirm kann dabei kurz flackern.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleAudio() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Ton: " + vm.audioLabel() + "  ⟳")
            }
            OutlinedButton(onClick = { vm.cycleDecoder() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Decoder: " + vm.decoderLabel() + "  ⟳")
            }
            Text("Ton und Decoder gelten ab dem nächsten gestarteten Stream.", fontSize = 13.sp, color = gray,
                modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleNetMode() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("Netz-Anpassung: " + vm.netLabel() + "  ⟳")
            }
            Text("Bei schwachem Netz: Bild höchstens 720p, größerer Puffer, längere Wartezeiten. Der Puffer gilt ab dem nächsten gestarteten Sender.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.cycleBuffer() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(when (vm.bufferMode) {
                    "fast" -> "Pufferung: schnell (kurz)  ⟳"
                    "stable" -> "Pufferung: stabil (groß, für 4K)  ⟳"
                    else -> "Pufferung: ausgewogen  ⟳"
                })
            }
            OutlinedButton(onClick = { vm.toggleCompat() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.compat) "Kompatibilitätsmodus: an  ⟳" else "Kompatibilitätsmodus: aus  ⟳")
            }
            Text("Auf Fire TV und schwachen Geräten von Anfang an an. Standard-Verbindung, Standard-Puffer und einfaches Auslesen der Sender. Gilt ab dem nächsten gestarteten Stream.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
            OutlinedButton(onClick = { vm.toggle4kHelp() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.fourKHelp) "4K-Hilfe (Tunneling): an  ⟳" else "4K-Hilfe (Tunneling): aus  ⟳")
            }
            Text("Bei Rucklern in 4K: Pufferung auf stabil stellen, danach die 4K-Hilfe testen. Ein Netzwerkkabel hilft am meisten.",
                fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
        if (sec == 0) {
            OutlinedButton(onClick = { vm.toggleDedupe() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text(if (vm.dedupe) "Gleichnamige Sender: zusammenfassen  ⟳"
                    else "Gleichnamige Sender: alle zeigen  ⟳")
            }
        }
        if (sec == 5) {
            Text("Version ${BuildConfig.VERSION_NAME}", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

@Composable
fun PhoneAddScreen(vm: AppVM) {
    val gray = LocalMuted.current
    DisposableEffect(Unit) {
        vm.startPhoneAdd()
        onDispose { vm.stopPhoneAdd() }
    }
    val url = vm.qrUrl
    val bmp = remember(url) { url?.let { qrBitmap(it).asImageBitmap() } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Row(Modifier.fillMaxSize().padding(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 32.dp)) {
            Text("PORTAL PER HANDY HINZUFÜGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(80.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(20.dp))
            Text("1.  Das Handy muss im selben WLAN sein wie diese Box.", fontSize = 16.sp)
            Text("2.  Kamera-App öffnen und den QR-Code scannen.", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
            Text("3.  Formular ausfüllen und auf Portal hinzufügen tippen.", fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp))
            Text("Das Portal erscheint sofort in deiner Liste. Du kannst mehrere nacheinander eintragen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
            Text("Auf derselben Seite: Backup herunterladen und wiederherstellen, Fehlerprotokoll ansehen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
            if (url != null) {
                Text("Oder im Handy-Browser öffnen:", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
                Text(url, fontSize = 13.sp, color = gray)
            }
            Text("Portale gesamt: ${vm.portals.size}", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 12.dp))
            Spacer(Modifier.height(20.dp))
            Row {
                Button(onClick = { vm.back() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Fertig") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { vm.push(Screen.RemoteAccess) }, modifier = Modifier.tvFocus()) { Text("🌍 Aus der Ferne (anderes Netzwerk)") }
            }
        }
        Box(Modifier.size(320.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(14.dp),
            contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(bitmap = bmp, contentDescription = "QR-Code", modifier = Modifier.fillMaxSize())
            } else {
                Text("…", color = Color.Black, fontSize = 24.sp)
            }
        }
    }
}

@Composable
fun RemoteAccessScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val repo = BuildConfig.UPDATE_REPO
    val base = if (repo.contains("/")) "https://" + repo.substringBefore("/").lowercase() + ".github.io/" + repo.substringAfter("/") + "/" else ""
    val page = if (vm.remoteOn && vm.remoteCode.isNotEmpty() && base.isNotEmpty()) base + "#" + RemoteRelay.norm(vm.remoteCode) else null
    val bmp = remember(page) { page?.let { qrBitmap(it).asImageBitmap() } }
    Row(Modifier.fillMaxSize().padding(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 32.dp)) {
            Text("FERNZUGRIFF PER HANDY", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(80.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(16.dp))
            Text("Portale hinzufügen oder löschen, auch wenn das Handy in einem anderen Netzwerk ist.", fontSize = 15.sp)
            Text("Die Box muss dafür laufen (Tom’s TV geöffnet) und online sein.", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(14.dp))
            if (vm.remoteOn && vm.remoteCode.isNotEmpty()) {
                Text("Koppel-Code", fontSize = 13.sp, color = gray)
                Text(RemoteRelay.pretty(vm.remoteCode), fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("1.  QR-Code mit dem Handy scannen – oder", fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                Text("2.  " + base + " öffnen und den Code eingeben.", fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                Text(if (vm.remoteSeen > 0L) "Letzter Zugriff: " + java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.GERMANY).format(java.util.Date(vm.remoteSeen)) else "Noch kein Zugriff.",
                    fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 8.dp))
                if (vm.remoteStatus.isNotEmpty()) Text(vm.remoteStatus, fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 2.dp))
            } else {
                Text("Fernzugriff ist ausgeschaltet.", fontSize = 15.sp, color = gray)
            }
            Spacer(Modifier.height(16.dp))
            Row {
                Button(onClick = { vm.remoteSwitch() }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                    Text(if (vm.remoteOn) "Ausschalten" else "Einschalten")
                }
                if (vm.remoteOn) {
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton(onClick = { vm.remoteRenew() }, modifier = Modifier.tvFocus()) { Text("Neuer Code") }
                }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Fertig") }
            }
        }
        Box(Modifier.size(300.dp).clip(RoundedCornerShape(16.dp)).background(if (bmp != null) Color.White else Color(0xFF1A1A1A)).padding(14.dp),
            contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bitmap = bmp, contentDescription = "QR-Code", modifier = Modifier.fillMaxSize())
            else Text("–", color = gray, fontSize = 24.sp)
        }
    }
}

@Composable
fun ChannelPanel(vm: AppVM, modifier: Modifier) {
    val cats = remember(vm.chanPanel) { vm.panelCategories() }
    var catsOpen by remember { mutableStateOf(true) }
    val rows = remember(vm.panelGroups, vm.panelExpanded, vm.chanPanel) {
        val out = ArrayList<PaneRow>()
        if (vm.panelGroups.isNotEmpty()) {
            for (g in vm.panelGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.panelExpanded) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in vm.panelVisibleCats(g)) out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                }
            }
        } else {
            for (c in cats) out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    val catState = rememberLazyListState(initialFirstVisibleItemIndex = rows.indexOfFirst { it.id == vm.panelCat }.coerceAtLeast(0))
    val fr = remember { FocusRequester() }
    // ◀ springt in die gewählte Kategorie, ▶ zurück zum zuletzt markierten Sender
    val pMem = remember { FocusMemory() }
    val lastCh = remember { arrayOf<String?>(null) }
    LaunchedEffect(Unit) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Row(modifier.fillMaxHeight().width(740.dp)
        .background(Brush.horizontalGradient(listOf(Color(0xF2000000), Color(0xE6000000), Color(0x00000000))))
        .padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 70.dp)) {
        Column(Modifier.width(if (catsOpen) 220.dp else 48.dp).fillMaxHeight().enterAt(pMem) { "pc:" + vm.panelCat }) {
            Text(if (catsOpen) "◀  Kategorien" else "▶", fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().tvFocus(1.05f).clip(RoundedCornerShape(8.dp))
                    .clickable { catsOpen = !catsOpen }.padding(8.dp))
            if (catsOpen) {
                LazyColumn(state = catState, modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(rows, key = { it.id }) { r ->
                        if (r.kind == 0) {
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).glass(10.dp)
                                .clickable { vm.togglePanelGroup(r.pfx) }.padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(if (r.pfx in vm.panelExpanded) "▾" else "▸", fontSize = 13.sp,
                                    color = tcol(MaterialTheme.colorScheme.primary))
                                Spacer(Modifier.width(8.dp))
                                Text(r.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            Box(Modifier.enterKey(pMem, "pc:" + r.id)) {
                                ListRow((if (r.pfx.isNotEmpty()) "   " else "") + r.title, r.id == vm.panelCat) { vm.panelCat = r.id }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        key(vm.panelCat) {
            val list = remember { vm.panelList() }
            val cur = list.indexOfFirst { it.id == vm.playChId }
            val state = rememberLazyListState(initialFirstVisibleItemIndex = cur.coerceAtLeast(0))
            if (list.isEmpty()) {
                Text("Keine Sender", color = Color(0xFFB0BAC4), modifier = Modifier.weight(1f).padding(12.dp))
            } else {
                LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxHeight().enterAt(pMem) {
                    val k = "pch:" + lastCh[0]
                    if (pMem.map.containsKey(k)) k else "pch:" + vm.playChId
                }) {
                    items(list) { ch ->
                        val isCur = ch.id == vm.playChId
                        val anchor = isCur || (cur < 0 && ch.id == list.first().id)
                        PanelRow(vm, ch, isCur, (if (anchor) Modifier.focusRequester(fr) else Modifier)
                            .enterKey(pMem, "pch:" + ch.id).onFocusChanged { if (it.hasFocus) lastCh[0] = ch.id }) {
                            vm.playFromPanel(ch, list)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PanelRow(vm: AppVM, ch: Item, current: Boolean, modifier: Modifier, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    Row(modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(10.dp))
        .background(if (current) accent.copy(alpha = 0.3f) else Color(0x22FFFFFF))
        .clickable(onClick = onClick).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text((if (current) "▶ " else "") + ch.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal)
            if (now != null) {
                Text("${now.start}  ${now.title}", fontSize = 13.sp, color = Color(0xFFB0BAC4), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun WatchScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val lists = remember {
        listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.watchFor(t)) }
    }
    Column(Modifier.fillMaxSize().inContent(vm, "watch").verticalScroll(vm.pageScroll("watch")).padding(vertical = 20.dp)) {
        Text("MERKLISTE", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch nichts gemerkt. Öffne einen Film oder eine Serie und wähle ＋ Merkliste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(state = vm.rowState("watch:" + type), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { w -> Box(Modifier.itemFocus(vm, "watch:" + type + ":" + w.id)) { MiniPoster(w) { vm.openWatch(type, w) } } }
                }
            }
        }
    }
}

/** Zeigt die tatsächlich ankommende Qualität, zum Beispiel "4K 3840×2160 · 50 fps · HEVC | Dolby Digital Plus 5.1". */
fun qualityLabel(p: ExoPlayer): String {
    val parts = ArrayList<String>()
    val v = p.videoFormat
    if (v != null && v.height > 0) {
        val res = when {
            v.height >= 2000 -> "4K"
            v.height >= 1000 -> "FHD"
            v.height >= 700 -> "HD"
            else -> "SD"
        }
        val fps = if (v.frameRate > 0f) " · " + Math.round(v.frameRate) + " fps" else ""
        val codec = when (v.sampleMimeType) {
            "video/hevc" -> " · HEVC"
            "video/avc" -> " · H.264"
            "video/av01" -> " · AV1"
            "video/x-vnd.on2.vp9" -> " · VP9"
            "video/mpeg2" -> " · MPEG-2"
            else -> ""
        }
        parts.add(res + " " + v.width + "×" + v.height + fps + codec)
    }
    val a = p.audioFormat
    if (a != null) {
        val codec = when (a.sampleMimeType) {
            "audio/ac3" -> "Dolby Digital"
            "audio/eac3" -> "Dolby Digital Plus"
            "audio/eac3-joc" -> "Dolby Atmos"
            "audio/true-hd" -> "Dolby TrueHD"
            "audio/vnd.dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MPEG-Audio"
            "audio/mpeg-L2" -> "MPEG-Audio"
            else -> "Audio"
        }
        val ch = when (a.channelCount) {
            1 -> "Mono"
            2 -> "Stereo"
            6 -> "5.1"
            8 -> "7.1"
            else -> if (a.channelCount > 0) a.channelCount.toString() + " Kanäle" else ""
        }
        parts.add((codec + " " + ch).trim())
    }
    return parts.joinToString("   |   ")
}

class PaneRow(val kind: Int, val id: String, val title: String, val pfx: String)

@Composable
fun CategoryPane(vm: AppVM, type: String) {
    val open = vm.catPaneOpen
    val accent = MaterialTheme.colorScheme.primary
    val widthAnim by animateDpAsState(if (open) 280.dp else 56.dp, label = "catPaneWidth")
    val width = if (LocalPerf.current) (if (open) 280.dp else 56.dp) else widthAnim
    val rows = remember(vm.portalGroups, vm.expandedPortals, vm.hiddenCats, vm.categories, type, vm.orderTick, vm.favLists) {
        val out = ArrayList<PaneRow>()
        if (vm.portalGroups.isNotEmpty()) {
            if (type == "itv") for (l in vm.favLists) out.add(PaneRow(1, "fl:" + l.id, "★ " + l.name, ""))
            for (g in vm.portalGroups) {
                out.add(PaneRow(0, "g:" + g.pfx, g.name, g.pfx))
                if (g.pfx in vm.expandedPortals) {
                    out.add(PaneRow(1, "p:" + g.pfx + ":fav", "★ Favoriten", g.pfx))
                    if (type != "itv") out.add(PaneRow(1, "p:" + g.pfx + ":resume", "⏯ Weiterschauen", g.pfx))
                    out.add(PaneRow(1, "p:" + g.pfx + ":*", "Alle", g.pfx))
                    for (c in vm.orderCats(g.cats.filter { it.id !in vm.hiddenCats }, type)) {
                        out.add(PaneRow(1, "p:" + g.pfx + ":" + c.id, c.title, g.pfx))
                    }
                }
            }
        } else {
            out.add(PaneRow(1, "fav", "★ Favoriten", ""))
            for (c in vm.categories) if (c.id != "fav") out.add(PaneRow(1, c.id, c.title, ""))
        }
        out
    }
    val catMem = remember { FocusMemory() }
    Column(Modifier.width(width).fillMaxHeight().padding(start = 4.dp, top = 8.dp, bottom = 8.dp, end = 4.dp)
        .enterAt(catMem) { "cat:" + vm.selCat }
        .glass(20.dp).padding(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = if (open) Arrangement.Start else Arrangement.Center) {
            if (open) {
                Text("PORTALE", fontSize = 13.sp, letterSpacing = 3.sp, color = tcol(accent),
                    modifier = Modifier.weight(1f).padding(start = 6.dp))
            }
            Text(if (open) "◀" else "▶", fontSize = 14.sp,
                modifier = Modifier.tvFocus(1.1f).clip(RoundedCornerShape(10.dp))
                    .clickable { vm.toggleCatPane() }.padding(horizontal = 10.dp, vertical = 6.dp))
        }
        if (open) {
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = vm.catListState) {
                items(rows, key = { it.id }) { r ->
                    if (r.kind == 0) {
                        val expanded = r.pfx in vm.expandedPortals
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).leftFocus(vm, "cat:" + r.id).tvFocus(1.02f).glass(12.dp)
                            .clickable { vm.toggleGroup(r.pfx) }
                            .padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (expanded) "▾" else "▸", fontSize = 14.sp, color = tcol(accent))
                            Spacer(Modifier.width(10.dp))
                            Text(r.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    } else {
                        Box(Modifier.leftFocus(vm, "cat:" + r.id).enterKey(catMem, "cat:" + r.id)) {
                            ListRowK(r.title, r.id == vm.selCat, catKind(r.title)) { vm.selectCategory(r.id) }
                        }
                    }
                }
            }
        }
    }
}

/** Auswahl der Tonspur (Sprache, Format, Kanäle) während der Wiedergabe. */
@Composable
fun AudioMenu(exo: ExoPlayer, vm: AppVM, infoOn: Boolean, onToggleInfo: () -> Unit, onClose: () -> Unit) {
    val groups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO } }
    val tgroups = remember { exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(560.dp).heightIn(max = 440.dp).glass(22.dp).background(Color(0xEE0A0A0F))
            .verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text("TON", fontSize = 14.sp, letterSpacing = 4.sp, color = hdrCol())
            Spacer(Modifier.height(10.dp))
            if (groups.isEmpty()) {
                Text("Keine auswählbaren Tonspuren gefunden.", color = LocalMuted.current)
            }
            var first = true
            for (g in groups) {
                for (ti in 0 until g.length) {
                    val selected = g.isTrackSelected(ti)
                    val label = (if (selected) "●  " else "○  ") + audioLabel(g.getTrackFormat(ti))
                    val rowMod = if (first) Modifier.focusRequester(fr) else Modifier
                    first = false
                    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = rowMod.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti))
                                    .build()
                                g.getTrackFormat(ti).language?.takeIf { it.isNotEmpty() && it != "und" }?.let { vm.setAudioLang(it) }
                                onClose()
                            }
                            .padding(12.dp))
                }
            }
            if (tgroups.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("UNTERTITEL", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
                val off = exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
                MenuRow((if (off) "●  " else "○  ") + "Aus", off) {
                    exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    vm.setTextLang("off")
                    onClose()
                }
                for (g in tgroups) {
                    for (ti in 0 until g.length) {
                        val sel = g.isTrackSelected(ti) && !off
                        val lang = g.getTrackFormat(ti).language
                        val nm = if (lang.isNullOrEmpty() || lang == "und") "Untertitel"
                        else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
                        MenuRow((if (sel) "●  " else "○  ") + nm, sel) {
                            exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, ti)).build()
                            vm.setTextLang(if (lang.isNullOrEmpty() || lang == "und") "" else lang)
                            onClose()
                        }
                    }
                }
            }
            if (vm.isLive) {
                val alts = vm.alternativesFor(vm.playChId)
                if (alts.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    Text("QUELLE (PORTAL)", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
                    for ((pname, ch) in alts) {
                        val cur = ch.id == vm.playChId
                        MenuRow((if (cur) "●  " else "○  ") + pname, cur) {
                            vm.chooseSource(ch)
                            onClose()
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("OPTIONEN", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            if (vm.isLive) {
                MenuRow(if (exo.playWhenReady) "⏸  Live pausieren" else "▶  Live weiter", false) {
                    exo.playWhenReady = !exo.playWhenReady
                    onClose()
                }
            }
            MenuRow("🖼  Bild: " + vm.picLabel(), false) { vm.cyclePic() }
            MenuRow("🔊  Lautstärke-Boost: " + (if (vm.boostDb == 0) "aus" else "+" + vm.boostDb + " dB"), false) { vm.cycleBoost() }
            if (vm.isEpisode) {
                MenuRow("⏭  Intro-Ende hier merken (" + fmtTime(exo.currentPosition) + ")", false) {
                    vm.saveIntroEnd(exo.currentPosition)
                    onClose()
                }
            }
            MenuRow("⏾  Sleep-Timer: " + (if (vm.sleepMinutes == 0) "aus" else vm.sleepMinutes.toString() + " Min."), false) { vm.cycleSleep() }
            MenuRow((if (infoOn) "☑" else "☐") + "  Stream-Diagnose anzeigen", false) {
                onToggleInfo()
                onClose()
            }
            Text("Zurück schließt das Menü.", fontSize = 13.sp, color = LocalMuted.current,
                modifier = Modifier.padding(top = 10.dp))
        }
    }
}

fun audioLabel(f: androidx.media3.common.Format): String {
    val lang = f.language
    val langName = if (lang.isNullOrEmpty() || lang == "und") "Tonspur"
    else java.util.Locale(lang).getDisplayLanguage(java.util.Locale.GERMAN).ifEmpty { lang }
    val codec = when (f.sampleMimeType) {
        "audio/ac3" -> "Dolby Digital"
        "audio/eac3" -> "Dolby Digital Plus"
        "audio/eac3-joc" -> "Dolby Atmos"
        "audio/true-hd" -> "Dolby TrueHD"
        "audio/vnd.dts" -> "DTS"
        "audio/vnd.dts.hd" -> "DTS-HD"
        "audio/mp4a-latm" -> "AAC"
        "audio/mpeg" -> "MPEG-Audio"
        "audio/mpeg-L2" -> "MPEG-Audio"
        else -> "Audio"
    }
    val ch = when (f.channelCount) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> if (f.channelCount > 0) f.channelCount.toString() + " Kanäle" else ""
    }
    return (langName + "  ·  " + codec + " " + ch).trim()
}

/** Kleines Live-Bild (ohne Ton) des markierten Senders, ersetzt die Vorschau-Zeile in der Senderliste. */
@Composable
fun PreviewCard(vm: AppVM) {
    val ctx = LocalContext.current
    val gray = LocalMuted.current
    val exo = remember {
        val ds = SmartHttpFactory().setUserAgent(UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8_000).setReadTimeoutMs(10_000)
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply { volume = 0f }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    val url = vm.previewUrl
    LaunchedEffect(url) {
        if (url == null) {
            exo.stop()
            exo.clearMediaItems()
        } else {
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.play()
        }
    }
    val ch = vm.previewChannel
    val now = if (ch != null) vm.currentEpg(ch.id) else null
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(260.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            AndroidView(factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    this.player = exo
                }
            }, modifier = Modifier.fillMaxSize())
            if (url == null) {
                Text(if (ch == null) "Sender wählen" else "Vorschau lädt …", fontSize = 13.sp, color = Color(0xFFB0B7BF))
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(ch?.name ?: "", fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (now.descr.isNotBlank()) {
                    Text(now.descr, fontSize = 13.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
            Text("Vorschau ohne Ton", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/** Angefangene Filme und Serien eines Portals, mit Weiter-Knopf und Löschen. */
@Composable
fun ResumeListView(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    LaunchedEffect(Unit) { vm.refreshResumeShown() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("WEITERSCHAUEN", fontSize = 13.sp, letterSpacing = 3.sp, color = tcol(accent), modifier = Modifier.weight(1f))
            if (vm.resumeEntries.isNotEmpty()) {
                OutlinedButton(onClick = { vm.clearResumeShown() }, modifier = Modifier.tvFocus()) { Text("🗑 Alle löschen") }
            }
        }
        if (vm.resumeEntries.isEmpty()) {
            Text("Nichts angefangen. Filme und Serien, die du ansiehst, erscheinen hier.", color = gray,
                modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp)) {
            itemsIndexed(vm.resumeEntries, key = { _, r -> r.key }) { idx, r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(16.dp).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.width(54.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222A33)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fmtTime(r.pos) + (if (r.dur > 0) " / " + fmtTime(r.dur) else ""), fontSize = 13.sp, color = gray)
                        if (r.dur > 0) {
                            LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { vm.playResume(r) }, modifier = Modifier.tvFocus()) { Text("▶ Weiter") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = {
                        vm.pendingFocus = neighborKey(vm.resumeEntries, idx) { it.key }
                        vm.removeResume(r)
                    }, modifier = Modifier.delFocus(vm, r.key).tvFocus()) { Text("🗑 Löschen") }
                }
            }
        }
    }
}

fun digitOf(k: Key): Int = when (k) {
    Key.Zero, Key.NumPad0 -> 0
    Key.One, Key.NumPad1 -> 1
    Key.Two, Key.NumPad2 -> 2
    Key.Three, Key.NumPad3 -> 3
    Key.Four, Key.NumPad4 -> 4
    Key.Five, Key.NumPad5 -> 5
    Key.Six, Key.NumPad6 -> 6
    Key.Seven, Key.NumPad7 -> 7
    Key.Eight, Key.NumPad8 -> 8
    Key.Nine, Key.NumPad9 -> 9
    else -> -1
}

@Composable
fun MenuRow(label: String, bold: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(12.dp))
}

/** Kleines Fenster mit Puffer, Bildrate und Quelle zum Prüfen von Rucklern. */
@Composable
fun StreamInfo(vm: AppVM, exo: ExoPlayer, quality: String, modifier: Modifier) {
    var buf by remember { mutableStateOf(0L) }
    var rate by remember { mutableStateOf(0) }
    var state by remember { mutableStateOf("") }
    var fps by remember { mutableStateOf(0f) }
    var codec by remember { mutableStateOf("") }
    var audio by remember { mutableStateOf("") }
    var dropped by remember { mutableIntStateOf(0) }
    var stalls by remember { mutableIntStateOf(0) }
    var bw by remember { mutableLongStateOf(0L) }
    DisposableEffect(exo) {
        val al = object : AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                dropped += droppedFrames
            }
            override fun onBandwidthEstimate(
                eventTime: AnalyticsListener.EventTime, totalLoadTimeMs: Int, totalBytesLoaded: Long, bitrateEstimate: Long
            ) { bw = bitrateEstimate }
        }
        val pl = object : Player.Listener {
            private var last = Player.STATE_IDLE
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_BUFFERING && last == Player.STATE_READY) stalls++
                last = playbackState
            }
        }
        exo.addAnalyticsListener(al)
        exo.addListener(pl)
        onDispose { exo.removeAnalyticsListener(al); exo.removeListener(pl) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            buf = exo.totalBufferedDuration
            rate = exo.videoFormat?.bitrate ?: 0
            fps = exo.videoFormat?.frameRate ?: 0f
            codec = when (exo.videoFormat?.sampleMimeType) {
                "video/avc" -> "H.264"
                "video/hevc" -> "H.265"
                "video/mpeg2" -> "MPEG-2"
                "video/av01" -> "AV1"
                null -> ""
                else -> "Video"
            }
            audio = exo.audioFormat?.let { audioLabel(it) } ?: ""
            state = when (exo.playbackState) {
                Player.STATE_BUFFERING -> "Puffert"
                Player.STATE_READY -> if (exo.isPlaying) "Läuft" else "Pause"
                Player.STATE_ENDED -> "Ende"
                else -> "Leerlauf"
            }
            delay(1000)
        }
    }
    val verdict = when {
        stalls >= 3 -> "⚠ Netz oder Quelle instabil: mehrfach gepuffert. LAN-Kabel, Pufferung „stabil“ oder andere Quelle probieren."
        dropped > 30 -> "⚠ Die Box kommt beim Dekodieren nicht mit: Qualität auf „adaptiv“ stellen oder 4K-Hilfe testen."
        bw > 0 && rate > 0 && bw < rate * 13L / 10L -> "⚠ Verbindung ist für diese Videorate knapp."
        else -> "✓ Alles im grünen Bereich"
    }
    Column(modifier.padding(16.dp).widthIn(max = 420.dp).glass(14.dp).padding(12.dp)) {
        Text("STREAM-DIAGNOSE", fontSize = 13.sp, letterSpacing = 3.sp, color = hdrCol())
        Text(state + "  ·  Puffer " + (buf / 1000) + " s", fontSize = 13.sp, color = Color.White)
        if (quality.isNotEmpty()) Text(quality, fontSize = 13.sp, color = Color.White)
        if (codec.isNotEmpty()) Text(codec + (if (fps > 0) "  ·  " + fps.toInt() + " Bilder/s" else ""), fontSize = 13.sp, color = Color.White)
        if (rate > 0) Text("Videorate " + (rate / 1000) + " kbit/s", fontSize = 13.sp, color = Color.White)
        if (bw > 0) Text("Netz ca. " + (bw / 1_000_000) + " Mbit/s", fontSize = 13.sp, color = Color.White)
        if (audio.isNotEmpty()) Text(audio, fontSize = 13.sp, color = Color.White)
        Text("Ausgelassene Bilder: $dropped  ·  Aussetzer: $stalls", fontSize = 13.sp, color = Color.White)
        Text("Quelle: " + vm.sourceName(), fontSize = 13.sp, color = Color.White)
        Text(verdict, fontSize = 13.sp, color = Color.White, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Fehlerprotokoll: letzte Meldungen und Abstürze. */
@Composable
fun LogScreen(vm: AppVM) {
    val gray = LocalMuted.current
    var lines by remember { mutableStateOf(AppLog.all()) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("FEHLERPROTOKOLL", fontSize = 18.sp, letterSpacing = 3.sp, color = hdrCol(),
                modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("⟳ Neu laden") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { AppLog.clear(); lines = AppLog.all() }, modifier = Modifier.tvFocus()) { Text("🗑 Löschen") }
        }
        if (lines.isEmpty()) {
            Text("Keine Einträge.", color = gray, modifier = Modifier.padding(12.dp))
        }
        // Zeilen sind anwählbar, damit Pfeil hoch/runter (auch bei der Strong-Fernbedienung) das Protokoll durchblättert.
        // CH+/CH- (oder Seite hoch/runter) springen um 10 Zeilen.
        val fm = androidx.compose.ui.platform.LocalFocusManager.current
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp).glass(16.dp).padding(12.dp)
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val dir = when (e.key) {
                    Key.ChannelDown, Key.PageDown -> androidx.compose.ui.focus.FocusDirection.Down
                    Key.ChannelUp, Key.PageUp -> androidx.compose.ui.focus.FocusDirection.Up
                    else -> null
                }
                if (dir == null) false else { repeat(10) { fm.moveFocus(dir) }; true }
            }) {
            items(lines) { l ->
                var f by remember { mutableStateOf(false) }
                Text(l, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().onFocusChanged { f = it.isFocused }.focusable()
                        .background(if (f) Color(0x33FFFFFF) else Color.Transparent)
                        .padding(vertical = 2.dp, horizontal = 4.dp))
            }
        }
    }
}

/** Hinweisfenster beim App-Start, wenn eine neuere Version bereitsteht. */
@Composable
fun UpdateDialog(vm: AppVM) {
    val info = vm.updatePrompt ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(info) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("UPDATE VERFÜGBAR", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Spacer(Modifier.height(10.dp))
            Text("Eine neue Version von Tom’s TV ist bereit (${info.tag}).", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = Color.White)
            Text("Die Installation dauert nur einen Moment. Deine Daten bleiben erhalten.", fontSize = 14.sp,
                color = Color(0xFFB0B7BF), modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.updatePrompt = null; vm.installUpdate() },
                    modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt installieren") }
                OutlinedButton(onClick = { vm.updatePrompt = null }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

@Composable
fun ReminderDialog(vm: AppVM) {
    LaunchedEffect(Unit) {
        while (true) {
            vm.checkReminders()
            delay(15_000)
        }
    }
    val r = vm.dueReminder ?: return
    val fr = remember { FocusRequester() }
    LaunchedEffect(r) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.width(520.dp).glass(24.dp).background(Color(0xEE0A0A0F)).padding(26.dp)) {
            Text("🔔  ERINNERUNG", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Spacer(Modifier.height(10.dp))
            Text(r.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("beginnt gleich auf " + r.chName, fontSize = 14.sp, color = Color(0xFFB0B7BF),
                modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { vm.acceptReminder() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Jetzt umschalten") }
                OutlinedButton(onClick = { vm.dismissReminder() }, modifier = Modifier.tvFocus()) { Text("Später") }
            }
        }
    }
}

/** Puffergrößen für Live-TV und Filme. */
/** Sucht zum Film-Takt (z. B. 24 oder 25 Bilder/s) eine passende Bildwiederholrate des Fernsehers. */
fun matchRefreshRate(ctx: android.content.Context, fps: Float) {
    if (android.os.Build.VERSION.SDK_INT < 23) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        @Suppress("DEPRECATION")
        val d = act.windowManager.defaultDisplay
        val cur = d.mode
        val cands = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
            .filter { m ->
                val mult = m.refreshRate / fps
                val n = Math.round(mult)
                n >= 1 && Math.abs(m.refreshRate - fps * n) < 0.15f
            }
            .sortedBy { it.refreshRate }
        val best = cands.firstOrNull() ?: return
        if (best.modeId == cur.modeId) return
        val lp = act.window.attributes
        lp.preferredDisplayModeId = best.modeId
        act.window.attributes = lp
        AppLog.add("Bildwiederholrate angepasst: " + best.refreshRate + " Hz für " + fps + " Bilder/s")
    } catch (e: Exception) { }
}

/** Fordert für das Fenster den HDR-Farbraum an (oder gibt ihn wieder frei). Ab Android 8. */
fun setWindowHdr(ctx: android.content.Context, on: Boolean) {
    if (android.os.Build.VERSION.SDK_INT < 26) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        val want = if (on) android.content.pm.ActivityInfo.COLOR_MODE_HDR else android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT
        if (act.window.colorMode != want) {
            act.window.colorMode = want
            AppLog.add("HDR-Farbraum: " + (if (on) "angefordert" else "zurückgesetzt"))
        }
    } catch (e: Exception) { }
}

fun resetRefreshRate(ctx: android.content.Context) {
    if (android.os.Build.VERSION.SDK_INT < 23) return
    var c: android.content.Context? = ctx
    while (c is android.content.ContextWrapper && c !is Activity) c = c.baseContext
    val act = c as? Activity ?: return
    try {
        val lp = act.window.attributes
        if (lp.preferredDisplayModeId != 0) { lp.preferredDisplayModeId = 0; act.window.attributes = lp }
    } catch (e: Exception) { }
}

/** Filme und Serien: großer Puffer, und nach einem Aussetzer erst wieder starten, wenn genug vorgeladen ist. */
fun buildVodLoadControl(): DefaultLoadControl {
    val cap = (Runtime.getRuntime().maxMemory() / 4).toInt().coerceIn(32 * 1024 * 1024, 96 * 1024 * 1024)
    return DefaultLoadControl.Builder()
        .setBufferDurationsMs(60_000, 240_000, 4_000, 15_000)
        .setTargetBufferBytes(cap)
        .setPrioritizeTimeOverSizeThresholds(false)
        .build()
}

fun buildLoadControl(live: Boolean, mode: String): DefaultLoadControl {
    val b = DefaultLoadControl.Builder()
    // Puffer-Bytes nie größer als ein Achtel des Java-Heaps (sonst OutOfMemory -> Dauer-Buffering)
    val cap = (Runtime.getRuntime().maxMemory() / 8).toInt().coerceIn(16 * 1024 * 1024, 64 * 1024 * 1024)
    when (mode) {
        "fast" -> b.setBufferDurationsMs(12_000, 40_000, 1_000, 2_500)
        "stable" -> {
            b.setBufferDurationsMs(40_000, 120_000, 2_500, 8_000)
            b.setTargetBufferBytes(minOf(cap, 48 * 1024 * 1024))
        }
        else -> if (live) {
            // Größerer Live-Puffer: macht „Live pausieren“ und Zurückspulen länger möglich
            b.setBufferDurationsMs(25_000, 120_000, 1_500, 4_000)
            b.setTargetBufferBytes(minOf(cap, 32 * 1024 * 1024))
        } else b.setBufferDurationsMs(30_000, 90_000, 2_500, 6_000)
    }
    return b.build()
}

/** Verständliche Fehlermeldung statt "error code bad http status". */
fun playErrorText(e: PlaybackException, conn: String = ""): String {
    val h = e.cause as? HttpDataSource.InvalidResponseCodeException
    if (h != null) {
        val c = if (conn.isNotEmpty()) " Verbindungen belegt: " + conn + "." else ""
        return when (h.responseCode) {
            401, 403 -> "Das Portal lehnt den Stream ab (HTTP " + h.responseCode + "). Abo und Gerät (MAC) beim Anbieter prüfen." + c
            404 -> "Stream nicht gefunden (HTTP 404). Der Sender ist beim Anbieter vielleicht offline."
            429, 461 -> "Der Anbieter verweigert den Stream (HTTP " + h.responseCode + "): meist zu viele gleichzeitige Verbindungen oder Abo abgelaufen. Anderes Gerät beenden oder Anbieter fragen." + c
            in 500..599 -> "Fehler beim Anbieter-Server (HTTP " + h.responseCode + "). Später erneut versuchen."
            else -> "Der Server antwortet mit HTTP " + h.responseCode + "." + c
        }
    }
    return "Wiedergabefehler: " + e.errorCodeName
}

// ---------- Qualitäts-Abzeichen ----------
private val reBadge4k = Regex("(^|[^A-Z0-9])(4K|UHD|2160P?)([^A-Z0-9]|$)")
private val reBadgeFhd = Regex("(^|[^A-Z0-9])(FHD|FULL ?HD|1080[PI]?)([^A-Z0-9]|$)")
private val reBadgeHd = Regex("(^|[^A-Z0-9])(HD|720P?)([^A-Z0-9]|$)")
private val reBadgeHdr = Regex("(^|[^A-Z0-9])(HDR10\\+?|HDR|DOLBY ?VISION)([^A-Z0-9]|$)")
private val reBadgeBd = Regex("(^|[^A-Z0-9])(BLU-?RAY|BDRIP|BD)([^A-Z0-9]|$)")

/** Liest Qualitätsangaben aus dem Titel (nur was wirklich dort steht). */
/** Aus „2026-11-11“ oder „11.11.2026“ wird „2026“. */
private val reYear4 = Regex("(19|20)\\d{2}")
fun yearOf(s: String): String = reYear4.find(s)?.value ?: s

fun qualityBadges(name: String): List<String> {
    val n = name.uppercase()
    val out = ArrayList<String>(2)
    when {
        reBadge4k.containsMatchIn(n) -> out.add("4K")
        reBadgeFhd.containsMatchIn(n) -> out.add("FHD")
        reBadgeHd.containsMatchIn(n) -> out.add("HD")
    }
    if (reBadgeHdr.containsMatchIn(n)) out.add("HDR")
    else if (reBadgeBd.containsMatchIn(n)) out.add("BD")
    return out
}

@Composable
fun QualityBadges(name: String, modifier: Modifier = Modifier) {
    if (!LocalBadges.current) return
    val list = remember(name) { qualityBadges(name) }
    if (list.isEmpty()) return
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        list.forEach { b ->
            val gold = b == "4K" || b == "HDR"
            Text(b, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp,
                color = if (gold) Color(0xFF1A1200) else Color.White,
                modifier = Modifier.clip(RoundedCornerShape(4.dp))
                    .background(if (gold) Color(0xFFFFC857) else Color(0xCC000000))
                    .padding(horizontal = 5.dp, vertical = 2.dp))
        }
    }
}

// ---------- Besetzung und Trailer ----------
@Composable
fun CastChip(p: Tmdb.Person, modifier: Modifier = Modifier) {
    Column(modifier.width(96.dp).tvFocus(1.06f).focusable().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Color(0xFF222A33)), contentAlignment = Alignment.Center) {
            Text(p.name.take(1), fontSize = 26.sp, color = Color(0x88FFFFFF))
            if (p.photo != null) AsyncImage(model = p.photo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize())
        }
        Text(p.name, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp))
        if (p.role.isNotBlank()) Text(p.role, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, color = LocalMuted.current)
    }
}

// ---------- Design & Skalierung ----------
@Composable
fun StepRow(label: String, value: Int, min: Int, max: Int, step: Int, fr: FocusRequester?, onChange: (Int) -> Unit) {
    val gray = LocalMuted.current
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)
        .then(if (fr != null) Modifier.focusRequester(fr) else Modifier)
        .tvFocus(1.02f).glass(14.dp)
        .onKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) false
            else when (e.key) {
                Key.DirectionLeft -> { onChange((value - step).coerceIn(min, max)); true }
                Key.DirectionRight -> { onChange((value + step).coerceIn(min, max)); true }
                else -> false
            }
        }
        .focusable().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("◀  " + value + " %  ▶", fontSize = 16.sp, color = tcol(MaterialTheme.colorScheme.primary))
        }
        LinearProgressIndicator(progress = { (value - min).toFloat() / (max - min) },
            modifier = Modifier.padding(top = 10.dp).fillMaxWidth().height(4.dp))
        Text("Links / Rechts auf der Fernbedienung", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun DesignScaleScreen(vm: AppVM) {
    val gray = LocalMuted.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    Row(Modifier.fillMaxSize().padding(28.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Text("DESIGN & SKALIERUNG", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(4.dp))
            Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(12.dp))
            StepRow("Kachel- und Layoutgröße", vm.uiPct, 60, 110, 2, fr) { vm.changeUiPct(it) }
            StepRow("Schriftgröße (zusätzlich)", vm.fontPct, 80, 140, 5, null) { vm.changeFontPct(it) }
            Text("Schnellauswahl", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.changeUiPct(72); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Kompakt") }
                OutlinedButton(onClick = { vm.changeUiPct(86); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Standard") }
                OutlinedButton(onClick = { vm.changeUiPct(100); vm.changeFontPct(100) }, modifier = Modifier.tvFocus()) { Text("Groß") }
            }
            OutlinedButton(onClick = { vm.changeUiPct(100); vm.changeFontPct(115) }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("👓 Gut lesbar (Kacheln 100 %, Schrift 115 %)")
            }
            OutlinedButton(onClick = { vm.resetScale() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
                Text("↺ Zurücksetzen (86 % / 100 %)")
            }
        }
        Spacer(Modifier.width(28.dp))
        Column(Modifier.width(220.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("VORSCHAU", fontSize = 13.sp, letterSpacing = 4.sp, color = hdrCol())
            Spacer(Modifier.height(10.dp))
            Box(Modifier.width(150.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF222A33))) {
                Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(
                    Brush.verticalGradient(listOf(Color(0xFF2F4B8F), Color(0xFF111827)))))
                QualityBadges("Beispielfilm 4K HDR", Modifier.align(Alignment.TopEnd).padding(6.dp))
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .padding(start = 10.dp, end = 10.dp, top = 30.dp, bottom = 10.dp)) {
                    Text("Beispielfilm", fontSize = 13.sp, color = Color.White)
                }
            }
            Text("Beispieltext in dieser Größe", fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
            Text("Kleiner Zusatztext", fontSize = 13.sp, color = gray)
        }
    }
}

/** Alle angefangenen Filme und Serien des Portals (Eintrag „Weiterschauen“ in der linken Spalte). */
@Composable
fun ResumeAllView(vm: AppVM) {
    val gray = LocalMuted.current
    val accent = MaterialTheme.colorScheme.primary
    val first = remember { FocusRequester() }
    LaunchedEffect(vm.resumeList.isNotEmpty()) { if (vm.resumeList.isNotEmpty()) runCatching { first.requestFocus() } }
    Column(Modifier.fillMaxSize().inContent(vm, "resume").padding(horizontal = 12.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("WEITERSCHAUEN", fontSize = 13.sp, letterSpacing = 3.sp, color = tcol(accent), modifier = Modifier.weight(1f))
            if (vm.resumeList.isNotEmpty()) {
                OutlinedButton(onClick = { vm.navFocusReq = "nav:resume"; vm.clearAllResumes() }, modifier = Modifier.tvFocus()) { Text("🗑 Alle löschen") }
            }
        }
        if (vm.resumeList.isEmpty()) {
            Text("Nichts angefangen. Filme und Serien, die du ansiehst, erscheinen hier.", color = gray,
                modifier = Modifier.padding(12.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 4.dp)) {
            itemsIndexed(vm.resumeList, key = { _, r -> r.key }) { idx, r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(16.dp).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = r.logo, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.width(54.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222A33)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text((if (r.type == "series") "Serie" else "Film") + "  ·  " + fmtTime(r.pos) +
                            (if (r.dur > 0) " / " + fmtTime(r.dur) else ""), fontSize = 13.sp, color = gray)
                        if (r.dur > 0) {
                            LinearProgressIndicator(progress = { (r.pos.toFloat() / r.dur).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp))
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Button(onClick = { vm.playResume(r) },
                        modifier = (if (idx == 0) Modifier.focusRequester(first) else Modifier).tvFocus()) { Text("▶ Weiter") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = {
                        val nk = neighborKey(vm.resumeList, idx) { it.key }
                        if (nk == null) vm.navFocusReq = "nav:resume" else vm.pendingFocus = nk
                        vm.removeResume(r)
                    }, modifier = Modifier.delFocus(vm, r.key).tvFocus()) { Text("🗑 Löschen") }
                }
            }
        }
    }
}

/** Kino-Design: sechs Funktionskacheln direkt unter dem Banner. */
@Composable
fun KinoTiles(vm: AppVM) {
    val tiles = listOf(
        Triple("itv", "tv", "Live TV" to "Jetzt live"), Triple("vod", "film", "Filme" to "Blockbuster"),
        Triple("series", "popcorn", "Serien" to "Neue Folgen"), Triple("watch", "bookmark", "Merkliste" to "Deine Liste"),
        Triple("epg", "calendar", "Programm" to "Sendezeiten"), Triple("portals", "ticket", "Portale" to "Anbieter"))
    val movieImg = vm.homeNew.getOrNull(1)?.let { it.backdrop ?: it.logo } ?: vm.homeCached.getOrNull(1)?.let { it.backdrop ?: it.logo }
    val seriesImg = vm.newEpisodes.firstOrNull()?.first?.let { it.backdrop ?: it.logo }
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        tiles.forEach { (id, icon, t) ->
            var f by remember { mutableStateOf(false) }
            val img = when (id) { "vod" -> movieImg; "series" -> seriesImg; else -> null }
            Box(Modifier.weight(1f).height(116.dp).onFocusChanged { f = it.hasFocus }.tvFocus(1.04f).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1A1F38), Color(0xFF0D1020))))
                .border(if (f) 2.dp else 1.dp, if (f) Kino.a2 else Color(0x16FFFFFF), RoundedCornerShape(16.dp))
                .clickable { vm.goTo(id) }) {
                if (img != null) {
                    AsyncImage(model = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize().alpha(0.55f))
                    Box(Modifier.matchParentSize().background(Brush.verticalGradient(0f to Color(0x330D1020), 1f to Color(0xE60D1020))))
                }
                Box(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
                    FlatIcon(icon, 24.dp, Kino.a)
                    Column(Modifier.align(Alignment.BottomStart)) {
                        Text(t.first, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(t.second, fontSize = 13.sp, color = LocalMuted.current, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
