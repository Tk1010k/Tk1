package com.example.portaltv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainTVInterface()
        }
    }
}

@Composable
fun MainTVInterface() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Palette.Background, Color(0xFF08080A))
                )
            )
            .padding(24.dp)
    ) {
        Column {
            // Elegante Kopfzeile
            Text(
                text = "TomsTV Portal",
                color = Palette.Primary,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // TV-Kanal-Raster (Optimiert für Fernbedienungen)
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.focusGroup()
            ) {
                // Beispielhaft 12 Kanäle generieren
                items(12) { index ->
                    ChannelCard(channelNumber = index + 1)
                }
            }
        }
    }
}

@Composable
fun ChannelCard(channelNumber: Int) {
    var isFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isFocused) Palette.Primary else Palette.Surface)
            .clickable { /* Kanal starten Logik */ }
            .padding(3.dp) // Simuliert einen eleganten Fokus-Rahmen
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(10.dp))
                .background(Palette.SurfaceSecondary)
                .padding(16.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            Column {
                Text(
                    text = "Kanal ${String.format("%02d", channelNumber)}",
                    color = Palette.TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Jetzt läuft: Live Programm",
                    color = Palette.TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}