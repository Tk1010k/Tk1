@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.portaltv

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppVM = viewModel()
            val tc = Palette.text(vm.textColorName)
            val ac = Palette.accent(vm.accentName)
            val bg = Color(0xFF0A0A0F)
            val onAc = if (ac.luminance() > 0.5f) bg else Color.White
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = ac, onPrimary = onAc, onSurface = tc, onBackground = tc, onSurfaceVariant = tc
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = bg, contentColor = tc) { App(vm) }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Menü-Taste der Fernbedienung = Favorit umschalten. */
fun Modifier.favKey(onFav: () -> Unit): Modifier = onKeyEvent { e ->
    if (e.type == KeyEventType.KeyDown && e.key == Key.Menu) { onFav(); true } else false
}

/** Fokus für die Fernbedienung: leichter Zoom mit Animation plus Rahmen in der Akzentfarbe. */
fun Modifier.tvFocus(zoom: Float = 1.03f): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (f) zoom else 1f, label = "focusZoom")
    val accent = MaterialTheme.colorScheme.primary
    this.onFocusChanged { f = it.hasFocus }
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .border(if (f) 3.dp else 0.dp, if (f) accent else Color.Transparent, RoundedCornerShape(12.dp))
}

@Composable
fun App(vm: AppVM = viewModel()) {
    val activity = LocalContext.current as? Activity
    BackHandler { if (!vm.back()) activity?.finish() }
    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF1C1410), Color(0xFF0A0A0F), Color(0xFF040406))))) {
        if (!vm.introDone) {
            IntroScreen { vm.introDone = true }
        } else when (val s = vm.stack.last()) {
            Screen.Portals -> Shell(vm, "portals") { PortalsScreen(vm) }
            is Screen.Form -> FormScreen(vm, s.edit)
            Screen.Home -> Shell(vm, "home") { HomeScreen(vm) }
            is Screen.Browse -> Shell(vm, s.type) { BrowseScreen(vm, s.type) }
            is Screen.Seasons -> {
                val rows: List<Pair<String, () -> Unit>> = vm.seasons.map { se -> se.name to { vm.openSeason(se) } }
                SimpleList(s.title, rows)
            }
            is Screen.Episodes -> {
                val se = s.season
                val rows: List<Pair<String, () -> Unit>> = se.episodes.map { n ->
                    "Episode $n" to { vm.play("vod", "${se.name} – Episode $n", se.cmd, n) }
                }
                SimpleList(se.name, rows)
            }
            Screen.ResumeList -> {
                val rows: List<Pair<String, () -> Unit>> = vm.resumeList.map { r ->
                    "${r.title}  ·  ${fmtTime(r.pos)}" to { vm.play("vod", r.title, r.cmd, r.ep) }
                }
                val empty: List<Pair<String, () -> Unit>> = listOf("Noch nichts angefangen" to { })
                SimpleList("Weiterschauen", if (rows.isEmpty()) empty else rows)
            }
            Screen.Guide -> Shell(vm, "epg") { GuideScreen(vm) }
            Screen.Favs -> Shell(vm, "fav") { FavsScreen(vm) }
            Screen.Watch -> Shell(vm, "watch") { WatchScreen(vm) }
            Screen.Settings -> Shell(vm, "settings") { SettingsScreen(vm) }
            Screen.AppSettings -> SettingsScreen(vm)
            is Screen.Detail -> DetailScreen(vm, s.item)
            Screen.EditCats -> EditCatsScreen(vm)
            Screen.EditChans -> EditChansScreen(vm)
            Screen.PhoneAdd -> PhoneAddScreen(vm)
            Screen.Play -> PlayerScreen(vm)
        }
        if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
        vm.notice?.let {
            Text(it, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
                    .background(Color(0xDD0D47A1), RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 8.dp))
        }
        vm.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(12.dp))
        }
    }
}

@Composable
fun ListRow(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Text(
        text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f)
            .clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent).padding(12.dp)
    )
}

@Composable
fun SimpleList(title: String, rows: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxSize().padding(32.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(rows) { (label, act) -> ListRow(label, false, act) } }
    }
}

@Composable
fun PortalsScreen(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    val accent = MaterialTheme.colorScheme.primary
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("TOM’S TV", fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
            letterSpacing = 6.sp)
        Box(Modifier.padding(vertical = 6.dp).width(120.dp).height(2.dp).background(accent))
        Text("PORTALE · ALLE SIND AKTIV", fontSize = 11.sp, letterSpacing = 4.sp, color = accent,
            modifier = Modifier.align(Alignment.Start).padding(top = 6.dp, bottom = 6.dp))
        if (vm.portals.isEmpty()) {
            Text("Noch kein Portal eingetragen. Füge unten dein erstes Portal hinzu.", color = gray,
                modifier = Modifier.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).widthIn(max = 900.dp).fillMaxWidth()) {
            items(vm.portals, key = { it.id }) { p ->
                PortalRow(vm, p, if (p.id == vm.portals.first().id) Modifier.focusRequester(fr) else Modifier)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.tvFocus()) { Text("+ Portal") }
            Button(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) { Text("📱 Per Handy") }
            OutlinedButton(onClick = { vm.refreshAllPortals() }, modifier = Modifier.tvFocus()) { Text("⟳ Aktualisieren") }
            OutlinedButton(onClick = { vm.push(Screen.AppSettings) }, modifier = Modifier.tvFocus()) { Text("⚙ Einstellungen") }
        }
    }
}

@Composable
fun PortalRow(vm: AppVM, p: Portal, modifier: Modifier = Modifier) {
    var confirm by remember { mutableStateOf(false) }
    val host = remember(p.url) { runCatching { java.net.URL(p.url).host }.getOrDefault(p.url) }
    val st = vm.status[p.id]
    val statusText = when {
        st == null || st == "loading" -> "⏳ lädt …"
        st == "ok" -> "● aktiv"
        else -> "⚠ nicht erreichbar"
    }
    val statusColor = when {
        st == null || st == "loading" -> Color(0xFFB0B7BF)
        st == "ok" -> Color(0xFF69F0AE)
        else -> Color(0xFFFF8A80)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(modifier.weight(1f).tvFocus(1.02f).clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF3A0F18), Color(0xFF14080B))))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .clickable { vm.push(Screen.Form(p)) }.padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("🎟", fontSize = 28.sp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(host, fontSize = 12.sp, color = Color(0xFFB0B7BF), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(statusText, fontSize = 12.sp, color = statusColor, maxLines = 1)
            }
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.push(Screen.Form(p)) }, modifier = Modifier.tvFocus()) { Text("Bearbeiten") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { if (confirm) vm.deletePortal(p) else confirm = true }, modifier = Modifier.tvFocus()) {
            Text(if (confirm) "Wirklich löschen?" else "Löschen")
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().tvFocus())
}

@Composable
fun FormScreen(vm: AppVM, edit: Portal?) {
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var url by remember { mutableStateOf(edit?.url ?: "http://") }
    var mac by remember { mutableStateOf(edit?.mac ?: "") }
    var login by remember { mutableStateOf(edit?.login ?: "") }
    var pw by remember { mutableStateOf(edit?.password ?: "") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (edit == null) "Portal hinzufügen" else "Portal bearbeiten", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Field("Name", name) { name = it }
        Field("Portal-URL (z. B. http://host/c/)", url) { url = it }
        Field("MAC-Adresse (00:1A:79:XX:XX:XX)", mac) { mac = it }
        Field("Login (optional)", login) { login = it }
        Field("Passwort (optional)", pw) { pw = it }
        err?.let { Text(it, color = Color(0xFFFF8A80)) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(modifier = Modifier.tvFocus(), onClick = {
                val m = mac.trim().uppercase()
                val u = url.trim()
                when {
                    name.isBlank() -> err = "Name fehlt"
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        vm.savePortal(Portal(edit?.id ?: UUID.randomUUID().toString(), name.trim(), u, m, login.trim(), pw))
                        vm.back()
                    }
                }
            }) { Text("Speichern") }
            OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Abbrechen") }
        }
    }
}

@Composable
fun HomeScreen(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    val hero = vm.homeNew.take(5)
    var idx by remember { mutableIntStateOf(0) }
    LaunchedEffect(hero.size) {
        while (hero.size > 1) {
            delay(8000)
            idx = (idx + 1) % hero.size
        }
    }
    val fr = remember { FocusRequester() }
    LaunchedEffect(hero.isNotEmpty()) {
        if (hero.isNotEmpty()) {
            delay(150)
            runCatching { fr.requestFocus() }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("ALLE PORTALE · ${vm.status.values.count { it == "ok" }} AKTIV", fontSize = 12.sp, letterSpacing = 4.sp, color = gray,
                modifier = Modifier.weight(1f))
            Clock()
        }
        if (hero.isNotEmpty()) {
            HeroBanner(vm, hero[idx % hero.size], idx % hero.size, hero.size, fr)
        } else {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (vm.portals.isEmpty()) {
                    Text("Noch kein Portal eingetragen.", color = gray)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                            Text("+ Portal hinzufügen")
                        }
                        OutlinedButton(onClick = { vm.push(Screen.PhoneAdd) }, modifier = Modifier.tvFocus()) {
                            Text("📱 Per Handy")
                        }
                    }
                } else {
                    Text(
                        if (vm.allLoading) "Portale werden verbunden …"
                        else "Keine Inhalte gefunden. Prüfe unter Portale, ob die Portale erreichbar sind.",
                        color = gray
                    )
                }
            }
        }
        if (vm.homeNew.isNotEmpty()) {
            SectionHeader("Neu im Angebot", "Alle anzeigen") { vm.goTo("vod") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.homeNew) { m -> MiniPoster(m) { vm.openHomeItem(m, "vod") } }
            }
        }
        val watch = remember { vm.watchFor("vod") + vm.watchFor("series") }
        if (watch.isNotEmpty()) {
            SectionHeader("Meine Merkliste", "Alle anzeigen") { vm.goTo("watch") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(watch) { w -> MiniPoster(w) { vm.openHomeItem(w, vm.watchType(w)) } }
            }
        }
        if (vm.homeChannels.isNotEmpty()) {
            SectionHeader("Live TV – Beliebte Sender", "Alle anzeigen") { vm.goTo("itv") }
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.homeChannels) { c -> ChannelTile(c) { vm.openHomeItem(c, "itv") } }
            }
        }
        if (vm.resumeList.isNotEmpty()) {
            SectionHeader("Weiterschauen")
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.resumeList) { r ->
                    Column(Modifier.width(190.dp).tvFocus(1.05f).clip(RoundedCornerShape(12.dp))
                        .background(Color(0x22FFFFFF)).clickable { vm.play("vod", r.title, r.cmd, r.ep) }.padding(12.dp)) {
                        Text("⏯  ${fmtTime(r.pos)}", fontSize = 12.sp, color = gray)
                        Text(r.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Tile(emoji: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(170.dp).tvFocus(1.08f).clip(RoundedCornerShape(18.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3A0F18), Color(0xFF14080B))))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 46.sp)
        Spacer(Modifier.height(10.dp))
        Text(label.uppercase(), fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BrowseScreen(vm: AppVM, type: String) {
    Row(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.width(260.dp).fillMaxHeight().padding(8.dp)) {
            items(vm.categories) { c -> ListRow(c.title, c.id == vm.selCat) { vm.selectCategory(c.id) } }
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.queryText,
                    onValueChange = { vm.queryText = it; if (type == "itv") vm.search(it) },
                    label = { Text("Suche") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(vm.queryText) }),
                    modifier = Modifier.weight(1f).tvFocus()
                )
                if (type == "itv") {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.push(Screen.Guide) }, modifier = Modifier.tvFocus()) { Text("Programm") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.openEditChannels() }, modifier = Modifier.tvFocus()) { Text("Kanäle") }
                }
                Spacer(Modifier.width(8.dp))
                if (type != "itv") {
                    OutlinedButton(onClick = { vm.toggleEditMode() }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.editMode) "Fertig" else "Ausblenden")
                    }
                    Spacer(Modifier.width(8.dp))
                }
                OutlinedButton(onClick = { vm.push(Screen.EditCats) }, modifier = Modifier.tvFocus()) { Text("Kategorien") }
            }
            Text(if (vm.editMode && type != "itv") "AUSBLENDEN-MODUS: OK blendet einen Eintrag aus oder wieder ein. Beenden mit Fertig."
                else "OK lange drücken oder Menü-Taste = Favorit", fontSize = 12.sp, color = Color(0xFF9AA4AE),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (type == "itv") {
                    LazyColumn(state = vm.listState, modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(vm.items) { ch -> ChannelRow(vm, ch) }
                    }
                } else {
                    val last by remember { derivedStateOf { vm.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 } }
                    val shown = vm.shownItems()
                    LaunchedEffect(last, shown.size, vm.hasMore) {
                        if (vm.hasMore && last >= shown.size - 6) vm.loadMore()
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(150.dp), state = vm.gridState,
                        modifier = Modifier.fillMaxSize().padding(8.dp)) {
                        items(shown) { entry -> PosterCard(vm, entry) }
                    }
                    if (vm.busyList) Text("Lade …", Modifier.align(Alignment.BottomCenter).padding(8.dp))
                }
                if (vm.items.isEmpty() && !vm.busyList && !vm.loading) Text("Keine Einträge", Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun ChannelRow(vm: AppVM, ch: Item) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).tvFocus(1.02f).clip(RoundedCornerShape(12.dp))
        .background(Color(0x1FFFFFFF)).favKey { vm.toggleFav(ch) }
        .combinedClickable(onClick = { vm.openItem(ch) }, onLongClick = { vm.toggleFav(ch) }).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(6.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text((if (vm.isFav(ch)) "★ " else "") + ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 13.sp, color = Color(0xFF9AA4AE),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                vm.epgProgress(now)?.let { p ->
                    LinearProgressIndicator(progress = { p },
                        modifier = Modifier.padding(top = 5.dp).fillMaxWidth().height(3.dp))
                }
            }
        }
    }
}

@Composable
fun PosterCard(vm: AppVM, entry: Item) {
    val hidden = vm.editMode && entry.id in vm.hiddenItems
    Box(Modifier.padding(6.dp)) {
        Box(Modifier.alpha(if (hidden) 0.35f else 1f).tvFocus(1.06f).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF222A33)).favKey { vm.toggleFav(entry) }
            .combinedClickable(onClick = { vm.openItem(entry) }, onLongClick = { vm.toggleFav(entry) })) {
            AsyncImage(model = entry.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                .padding(start = 10.dp, end = 10.dp, top = 30.dp, bottom = 10.dp)) {
                Text((if (hidden) "✗ " else if (vm.isFav(entry)) "★ " else "") + entry.name,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Color.White)
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val mac = vm.portal?.mac ?: ""
    val exo = remember {
        val ds = DefaultHttpDataSource.Factory().setUserAgent(UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000).setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(mapOf("Cookie" to "mac=$mac"))
        val selector = DefaultTrackSelector(ctx)
        val maxQ = vm.qualityMode == "max"
        if (maxQ) {
            // Immer die höchste Bild- und Tonqualität nehmen, die das Gerät kann (nicht an die Bildschirmgröße gebunden).
            selector.setParameters(
                selector.buildUponParameters()
                    .setForceHighestSupportedBitrate(true)
                    .setExceedVideoConstraintsIfNecessary(true)
                    .setConstrainAudioChannelCountToDeviceCapabilities(false)
                    .build()
            )
        }
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
            .setTrackSelector(selector)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply {
                playWhenReady = true
                if (maxQ) {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                        .setMaxVideoBitrate(Int.MAX_VALUE)
                        .setMaxAudioBitrate(Int.MAX_VALUE)
                        .setMaxAudioChannelCount(Int.MAX_VALUE)
                        .clearViewportSizeConstraints()
                        .build()
                }
            }
    }
    var retries by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf(false) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var qualityText by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (vm.isLive && retries < 5) { retries++; vm.reload() }
                else vm.error = "Wiedergabefehler: ${error.errorCodeName}"
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !vm.isLive) vm.clearResume()
            }
        }
        exo.addListener(l)
        onDispose {
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
            exo.removeListener(l); exo.release()
        }
    }

    LaunchedEffect(vm.playUrl) {
        vm.playUrl?.let { u ->
            val pos = if (vm.isLive) 0L else vm.resumePos()
            if (pos > 0) {
                exo.setMediaItem(MediaItem.fromUri(u), pos)
                vm.showNotice("Weiter bei ${fmtTime(pos)}")
            } else exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare(); exo.play()
        }
    }
    LaunchedEffect(Unit) { fr.requestFocus() }
    LaunchedEffect(Unit) {
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration
            qualityText = qualityLabel(exo)
            delay(1000)
        }
    }
    LaunchedEffect(vm.chanPanel) {
        if (!vm.chanPanel) {
            delay(120)
            runCatching { fr.requestFocus() }
        }
    }
    LaunchedEffect(vm.playChId, vm.isLive) {
        while (vm.isLive) { vm.loadEpg(vm.playChId); delay(60_000) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
        }
    }
    LaunchedEffect(tick, vm.playTitle) { info = true; delay(4000); if (!detail) info = false }

    // Wächter: Bei Hängern im Live-TV (Puffern oder Standbild > 20 s) neuen Link holen.
    LaunchedEffect(Unit) {
        var stuck = 0
        var lastPos = -1L
        while (true) {
            delay(5000)
            val pos = exo.currentPosition
            val bad = vm.isLive && !vm.loading && exo.playWhenReady &&
                (exo.playbackState == Player.STATE_BUFFERING ||
                    (exo.playbackState == Player.STATE_READY && pos == lastPos))
            lastPos = pos
            if (bad) stuck++ else stuck = 0
            if (stuck >= 4) { stuck = 0; vm.reload() }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
        if (vm.chanPanel) return@onKeyEvent false
        tick++
        when (e.key) {
            Key.DirectionUp, Key.ChannelUp -> if (vm.isLive) { detail = false; vm.zap(1); true } else false
            Key.DirectionDown, Key.ChannelDown -> if (vm.isLive) { detail = false; vm.zap(-1); true } else false
            Key.DirectionLeft, Key.MediaRewind ->
                if (!vm.isLive) { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); true } else { vm.openChannelPanel(); true }
            Key.DirectionRight, Key.MediaFastForward ->
                if (!vm.isLive) { exo.seekTo(exo.currentPosition + 10_000); true } else false
            Key.Menu -> if (vm.isLive) { vm.openChannelPanel(); true } else false
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                if (vm.isLive) detail = !detail else exo.playWhenReady = !exo.playWhenReady
                true
            }
            else -> false
        }
    }) {
        AndroidView(factory = { c ->
            PlayerView(c).apply {
                useController = false
                isFocusable = false
                isFocusableInTouchMode = false
                keepScreenOn = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = exo
            }
        }, modifier = Modifier.fillMaxSize())
        if ((info || detail) && !vm.chanPanel) InfoPanel(vm, detail, posMs, durMs, qualityText, Modifier.align(Alignment.BottomCenter))
        if (vm.chanPanel) ChannelPanel(vm, Modifier.align(Alignment.CenterStart))
    }
}

@Composable
fun InfoPanel(vm: AppVM, detail: Boolean, pos: Long, dur: Long, quality: String, modifier: Modifier) {
    val gray = Color(0xFFB0BAC4)
    val list = vm.epgList(vm.playChId)
    val now = if (vm.isLive) vm.currentEpg(vm.playChId) else null
    Box(modifier.fillMaxWidth()
        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
        .padding(start = 32.dp, end = 32.dp, top = 56.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            vm.playLogo?.let { logo ->
                AsyncImage(model = logo, contentDescription = null, contentScale = ContentScale.Fit,
                    modifier = Modifier.size(76.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(10.dp))
                Spacer(Modifier.width(18.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(vm.playTitle, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (quality.isNotEmpty()) {
                    Text(quality, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
                if (vm.isLive) {
                    if (now != null) {
                        Text("${now.start}–${now.end}  ${now.title}", fontSize = 18.sp, color = Color.White,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        vm.epgProgress(now)?.let { p ->
                            LinearProgressIndicator(progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                        }
                        if (detail && now.descr.isNotBlank()) {
                            Text(now.descr, fontSize = 14.sp, color = gray, maxLines = 5, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(bottom = 6.dp))
                        }
                        list.dropWhile { it != now }.drop(1).take(if (detail) 4 else 1).forEach { n ->
                            Text("${n.start}  ${n.title}", fontSize = 15.sp, color = gray, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    } else {
                        Text("Keine Programminfo", fontSize = 14.sp, color = gray)
                    }
                    if (!detail) Text("OK = Details   ·   ◀ = Senderliste", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                } else if (dur > 0) {
                    LinearProgressIndicator(progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(4.dp))
                    Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 14.sp, color = gray)
                }
            }
        }
    }
}

@Composable
fun GuideScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var focused by remember { mutableStateOf(vm.items.firstOrNull()) }
    val f = focused
    LaunchedEffect(f?.id) { f?.let { vm.loadEpg(it.id, 12) } }
    val list = if (f != null) vm.epgList(f.id) else emptyList()
    val now = if (f != null) vm.currentEpg(f.id) else null
    Row(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.width(320.dp).fillMaxHeight().padding(8.dp)) {
            items(vm.items) { ch ->
                Row(Modifier.fillMaxWidth().tvFocus().onFocusChanged { if (it.hasFocus) focused = ch }
                    .clickable { vm.openItem(ch) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = ch.logo, contentDescription = null, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 17.sp)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(16.dp)) {
            Text(f?.name ?: "Keine Sender", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("OK = Sender abspielen", fontSize = 12.sp, color = gray, modifier = Modifier.padding(bottom = 8.dp))
            if (list.isEmpty()) Text("Keine Programminfo (oder sie lädt noch)", color = gray)
            LazyColumn {
                items(list.dropWhile { it != now }) { e ->
                    val isNow = e == now
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text("${e.start}–${e.end}  ${e.title}", fontSize = 17.sp,
                            fontWeight = if (isNow) FontWeight.Bold else FontWeight.Normal)
                        if (isNow) {
                            vm.epgProgress(e)?.let { p ->
                                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                            }
                            if (e.descr.isNotBlank()) {
                                Text(e.descr, fontSize = 13.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditCatsScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var kw by remember { mutableStateOf("DE, German, Deutsch") }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kategorien auswählen", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.allCats.count { it.id !in vm.hiddenCats }} von ${vm.allCats.size} sichtbar",
            fontSize = 13.sp, color = gray)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = kw, onValueChange = { kw = it }, singleLine = true,
                label = { Text("Suchbegriffe, z. B. DE, German") }, modifier = Modifier.weight(1f).tvFocus())
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.showOnlyMatching(kw) }, modifier = Modifier.tvFocus()) { Text("Nur passende") }
        }
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setAllCats(true) }, modifier = Modifier.tvFocus()) { Text("Alle anzeigen") }
            OutlinedButton(onClick = { vm.setAllCats(false) }, modifier = Modifier.tvFocus()) { Text("Alle ausblenden") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(vm.allCats) { c ->
                val on = c.id !in vm.hiddenCats
                Text((if (on) "✓  " else "✗  ") + c.title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleCat(c.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun EditChansScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var filter by remember { mutableStateOf("") }
    val shown = vm.editChans.filter { filter.isBlank() || it.name.contains(filter.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kanäle ein-/ausblenden", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.editChans.count { it.id !in vm.hiddenChans }} von ${vm.editChans.size} sichtbar",
            fontSize = 13.sp, color = gray)
        OutlinedTextField(value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Filter nach Name") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).tvFocus())
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, true) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte ausblenden")
            }
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, false) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte einblenden")
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { ch ->
                val on = ch.id !in vm.hiddenChans
                Text((if (on) "✓  " else "✗  ") + ch.name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleChan(ch.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppVM, item: Item) {
    val gray = Color(0xFFB0B7BF)
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }
    val isSeries = vm.browseType == "series"
    Box(Modifier.fillMaxSize()) {
        AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(0.22f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0A0A0F), Color(0xCC0A0A0F), Color(0x330A0A0F)))))
        Row(Modifier.fillMaxSize().padding(40.dp)) {
            AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(240.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF222A33))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(16.dp)))
            Spacer(Modifier.width(32.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Text(if (isSeries) "SERIE" else "FILM", fontSize = 12.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.primary)
                Text(item.name, fontSize = 34.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
                    modifier = Modifier.padding(top = 4.dp))
                if (item.year.isNotBlank()) {
                    Text(item.year, fontSize = 16.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
                }
                Box(Modifier.padding(top = 12.dp).width(64.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.height(16.dp))
                Text(if (item.descr.isNotBlank()) item.descr else "Keine Beschreibung vorhanden.", fontSize = 16.sp,
                    color = if (item.descr.isNotBlank()) MaterialTheme.colorScheme.onSurface else gray)
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { vm.startItem(item) }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                        Text(if (isSeries) "Staffeln ansehen" else "▶ Abspielen", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleFav(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isFav(item)) "★ Favorit entfernen" else "☆ Zu Favoriten", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = { vm.toggleWatch(item) }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.isWatch(item)) "✓ In Merkliste" else "＋ Merkliste", fontSize = 18.sp)
                    }
                }
            }
        }
    }
}

/** Kurzer Vorspann: Logo blendet ein, Goldlinie zieht auf. Beliebige Taste oder Tippen überspringt ihn. */
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val fade = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(900))
        line.animateTo(1f, tween(700))
        delay(900)
        onDone()
    }
    Box(
        Modifier.fillMaxSize().focusRequester(fr).focusable()
            .onKeyEvent { e -> if (e.type == KeyEventType.KeyDown) { onDone(); true } else false }
            .clickable { onDone() },
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.alpha(fade.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🎬", fontSize = 56.sp)
            Spacer(Modifier.height(12.dp))
            Text("TOM’S TV", fontSize = 48.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
                letterSpacing = 10.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.width((240 * line.value).dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(14.dp))
            Text("DEIN KINO ZU HAUSE", fontSize = 13.sp, letterSpacing = 5.sp, color = Color(0xFFB0B7BF))
        }
    }
}

@Composable
fun Clock() {
    var time by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val f = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        while (true) {
            time = f.format(java.util.Date())
            delay(20_000)
        }
    }
    Text(time, fontSize = 14.sp, color = Color(0xFFB0B7BF))
}

@Composable
fun Shell(vm: AppVM, current: String, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Sidebar(vm, current)
        Box(Modifier.weight(1f).fillMaxHeight()) { content() }
    }
}

@Composable
fun Sidebar(vm: AppVM, current: String) {
    val accent = MaterialTheme.colorScheme.primary
    val compact = when (vm.sidebarMode) {
        "compact" -> true
        "normal" -> false
        else -> LocalConfiguration.current.screenHeightDp < 560
    }
    val menu = listOf(
        Triple("home", "🏠", "Startseite"), Triple("itv", "📺", "Live TV"), Triple("vod", "🎬", "Filme"),
        Triple("series", "🍿", "Serien"), Triple("fav", "★", "Favoriten"), Triple("watch", "🔖", "Merkliste"),
        Triple("epg", "🗓", "EPG"), Triple("portals", "🎟", "Portale"), Triple("settings", "⚙", "Einstellungen")
    )
    Column(Modifier.width(if (compact) 68.dp else 210.dp).fillMaxHeight().background(Color(0x66000000))
        .padding(horizontal = if (compact) 6.dp else 10.dp, vertical = 10.dp)) {
        if (!compact) {
            Text("TOM’S TV", fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
                letterSpacing = 3.sp, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            menu.forEach { (id, emoji, label) ->
                val sel = id == current
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(10.dp))
                    .background(if (sel) accent.copy(alpha = 0.9f) else Color.Transparent)
                    .clickable { vm.goTo(id) }
                    .padding(horizontal = if (compact) 0.dp else 12.dp, vertical = if (compact) 10.dp else 9.dp),
                    horizontalArrangement = if (compact) Arrangement.Center else Arrangement.Start,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(emoji, fontSize = if (compact) 20.sp else 16.sp)
                    if (!compact) {
                        Spacer(Modifier.width(10.dp))
                        Text(label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 24.dp, top = 18.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(16.dp).background(accent))
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text("$action ›", fontSize = 12.sp, color = Color(0xFFB0B7BF),
                modifier = Modifier.tvFocus(1.05f).clip(RoundedCornerShape(6.dp)).clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 4.dp))
        }
    }
}

@Composable
fun HeroBanner(vm: AppVM, item: Item, index: Int, count: Int, fr: FocusRequester) {
    val accent = MaterialTheme.colorScheme.primary
    val gray = Color(0xFFB0B7BF)
    Box(Modifier.fillMaxWidth().height(260.dp)) {
        AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(0.35f))
        Box(Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0A0A0F), Color(0xCC0A0A0F), Color(0x220A0A0F)))))
        Row(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("NEU IM ANGEBOT", fontSize = 11.sp, letterSpacing = 4.sp, color = accent)
                Text(item.name, fontSize = 32.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                if (item.year.isNotBlank()) Text(item.year, fontSize = 14.sp, color = gray)
                Text(item.descr, fontSize = 14.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp, end = 24.dp))
                Spacer(Modifier.height(16.dp))
                Button(onClick = { vm.openHomeItem(item, "vod") }, modifier = Modifier.focusRequester(fr).tvFocus()) {
                    Text("▶  Jetzt ansehen", fontSize = 16.sp)
                }
            }
            AsyncImage(model = item.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(150.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF222A33)))
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { i ->
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (i == index) accent else Color(0x66FFFFFF)))
            }
        }
    }
}

@Composable
fun MiniPoster(entry: Item, onClick: () -> Unit) {
    Box(Modifier.width(130.dp)) {
        Box(Modifier.tvFocus(1.06f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF222A33))
            .clickable(onClick = onClick)) {
            AsyncImage(model = entry.logo, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f))
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                .padding(start = 8.dp, end = 8.dp, top = 24.dp, bottom = 8.dp)) {
                Text(entry.name, fontSize = 12.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun ChannelTile(ch: Item, onClick: () -> Unit) {
    Column(Modifier.width(120.dp).tvFocus(1.06f).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF))
        .clickable(onClick = onClick).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.height(48.dp).fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(ch.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FavsScreen(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    val lists = remember {
        listOf("itv" to "Live TV", "vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.favsFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Text("FAVORITEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch keine Favoriten. Halte OK gedrückt oder nutze die Menü-Taste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { f ->
                        if (type == "itv") ChannelTile(f) { vm.openFavorite(type, f) }
                        else MiniPoster(f) { vm.openFavorite(type, f) }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVM) {
    Column(Modifier.fillMaxSize().padding(28.dp).verticalScroll(rememberScrollState())) {
        Text("EINSTELLUNGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(60.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
        Spacer(Modifier.height(16.dp))
        SettingsBlock(vm)
    }
}

@Composable
fun SettingsBlock(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    val accent = MaterialTheme.colorScheme.primary
    Column(Modifier.padding(top = 10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { vm.checkUpdate() }, modifier = Modifier.tvFocus()) { Text("Nach Updates suchen") }
            if (vm.updateInfo != null) {
                Button(onClick = { vm.installUpdate() }, modifier = Modifier.tvFocus()) { Text("Jetzt installieren") }
            }
        }
        vm.updateMsg?.let { Text(it, fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 6.dp)) }
        if (vm.updateProgress >= 0) {
            LinearProgressIndicator(progress = { vm.updateProgress / 100f },
                modifier = Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(top = 6.dp))
        }
        Text("SCHRIFTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Palette.textOptions.forEach { (name, c) ->
                OutlinedButton(onClick = { vm.setTextColor(name) }, modifier = Modifier.tvFocus()) {
                    Text((if (vm.textColorName == name) "● " else "") + name, color = c)
                }
            }
        }
        Text("AKZENTFARBE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Palette.accentOptions.forEach { (name, c) ->
                OutlinedButton(onClick = { vm.setAccent(name) }, modifier = Modifier.tvFocus()) {
                    Text((if (vm.accentName == name) "● " else "") + name, color = c)
                }
            }
        }
        Text("SEITENLEISTE", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.cycleSidebar() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text((when (vm.sidebarMode) {
                "compact" -> "Kompakt (nur Symbole)"
                "normal" -> "Normal (mit Namen)"
                else -> "Automatisch"
            }) + "  ⟳")
        }
        Text("BILD & TON", fontSize = 11.sp, letterSpacing = 4.sp, color = accent, modifier = Modifier.padding(top = 14.dp))
        OutlinedButton(onClick = { vm.cycleQuality() }, modifier = Modifier.padding(top = 4.dp).tvFocus()) {
            Text(if (vm.qualityMode == "max") "Maximale Qualität (Original vom Portal)  ⟳"
                else "Automatisch (an Bildschirm angepasst)  ⟳")
        }
        Text("Gilt ab dem nächsten gestarteten Stream. Bild und Ton werden nicht umgerechnet.",
            fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        OutlinedButton(onClick = { vm.toggleDedupe() }, modifier = Modifier.padding(top = 8.dp).tvFocus()) {
            Text(if (vm.dedupe) "Gleichnamige Sender: zusammenfassen  ⟳"
                else "Gleichnamige Sender: alle zeigen (mit Portalname)  ⟳")
        }
        Text("Version ${BuildConfig.RUN_NUMBER}", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun PhoneAddScreen(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    DisposableEffect(Unit) {
        vm.startPhoneAdd()
        onDispose { vm.stopPhoneAdd() }
    }
    val url = vm.qrUrl
    val bmp = remember(url) { url?.let { qrBitmap(it).asImageBitmap() } }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { fr.requestFocus() }
    }
    Row(Modifier.fillMaxSize().padding(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 32.dp)) {
            Text("PORTAL PER HANDY HINZUFÜGEN", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(80.dp).height(2.dp).background(MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(20.dp))
            Text("1.  Das Handy muss im selben WLAN sein wie diese Box.", fontSize = 16.sp)
            Text("2.  Kamera-App öffnen und den QR-Code scannen.", fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
            Text("3.  Formular ausfüllen und auf Portal hinzufügen tippen.", fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp))
            Text("Das Portal erscheint sofort in deiner Liste. Du kannst mehrere nacheinander eintragen.",
                fontSize = 14.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
            if (url != null) {
                Text("Oder im Handy-Browser öffnen:", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 16.dp))
                Text(url, fontSize = 13.sp, color = gray)
            }
            Text("Portale gesamt: ${vm.portals.size}", fontSize = 13.sp, color = gray, modifier = Modifier.padding(top = 12.dp))
            Spacer(Modifier.height(20.dp))
            Button(onClick = { vm.back() }, modifier = Modifier.focusRequester(fr).tvFocus()) { Text("Fertig") }
        }
        Box(Modifier.size(320.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(14.dp),
            contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(bitmap = bmp, contentDescription = "QR-Code", modifier = Modifier.fillMaxSize())
            } else {
                Text("…", color = Color.Black, fontSize = 24.sp)
            }
        }
    }
}

@Composable
fun ChannelPanel(vm: AppVM, modifier: Modifier) {
    val cats = remember(vm.chanPanel) { vm.panelCategories() }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250)
        runCatching { fr.requestFocus() }
    }
    Row(modifier.fillMaxHeight().width(640.dp)
        .background(Brush.horizontalGradient(listOf(Color(0xF2000000), Color(0xE6000000), Color(0x00000000))))
        .padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 70.dp)) {
        LazyColumn(Modifier.width(170.dp).fillMaxHeight()) {
            items(cats) { c -> ListRow(c.title, c.id == vm.panelCat) { vm.panelCat = c.id } }
        }
        Spacer(Modifier.width(10.dp))
        key(vm.panelCat) {
            val list = remember { vm.panelList() }
            val cur = list.indexOfFirst { it.id == vm.playChId }
            val state = rememberLazyListState(initialFirstVisibleItemIndex = cur.coerceAtLeast(0))
            if (list.isEmpty()) {
                Text("Keine Sender", color = Color(0xFFB0BAC4), modifier = Modifier.weight(1f).padding(12.dp))
            } else {
                LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxHeight()) {
                    items(list) { ch ->
                        val isCur = ch.id == vm.playChId
                        val anchor = isCur || (cur < 0 && ch.id == list.first().id)
                        PanelRow(vm, ch, isCur, if (anchor) Modifier.focusRequester(fr) else Modifier) {
                            vm.playFromPanel(ch, list)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PanelRow(vm: AppVM, ch: Item, current: Boolean, modifier: Modifier, onClick: () -> Unit) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    val accent = MaterialTheme.colorScheme.primary
    Row(modifier.fillMaxWidth().padding(vertical = 2.dp).tvFocus(1.02f).clip(RoundedCornerShape(10.dp))
        .background(if (current) accent.copy(alpha = 0.3f) else Color(0x22FFFFFF))
        .clickable(onClick = onClick).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0x33FFFFFF)).padding(4.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text((if (current) "▶ " else "") + ch.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal)
            if (now != null) {
                Text("${now.start}  ${now.title}", fontSize = 11.sp, color = Color(0xFFB0BAC4), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun WatchScreen(vm: AppVM) {
    val gray = Color(0xFFB0B7BF)
    val lists = remember {
        listOf("vod" to "Filme", "series" to "Serien").map { (t, l) -> Triple(t, l, vm.watchFor(t)) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 20.dp)) {
        Text("MERKLISTE", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.padding(horizontal = 24.dp))
        if (lists.all { it.third.isEmpty() }) {
            Text("Noch nichts gemerkt. Öffne einen Film oder eine Serie und wähle ＋ Merkliste.", color = gray,
                modifier = Modifier.padding(24.dp))
        }
        lists.forEach { (type, label, list) ->
            if (list.isNotEmpty()) {
                SectionHeader(label)
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list) { w -> MiniPoster(w) { vm.openWatch(type, w) } }
                }
            }
        }
    }
}

/** Zeigt die tatsächlich ankommende Qualität, zum Beispiel "4K 3840×2160 · 50 fps · HEVC | Dolby Digital Plus 5.1". */
fun qualityLabel(p: ExoPlayer): String {
    val parts = ArrayList<String>()
    val v = p.videoFormat
    if (v != null && v.height > 0) {
        val res = when {
            v.height >= 2000 -> "4K"
            v.height >= 1000 -> "FHD"
            v.height >= 700 -> "HD"
            else -> "SD"
        }
        val fps = if (v.frameRate > 0f) " · " + Math.round(v.frameRate) + " fps" else ""
        val codec = when (v.sampleMimeType) {
            "video/hevc" -> " · HEVC"
            "video/avc" -> " · H.264"
            "video/av01" -> " · AV1"
            "video/x-vnd.on2.vp9" -> " · VP9"
            "video/mpeg2" -> " · MPEG-2"
            else -> ""
        }
        parts.add(res + " " + v.width + "×" + v.height + fps + codec)
    }
    val a = p.audioFormat
    if (a != null) {
        val codec = when (a.sampleMimeType) {
            "audio/ac3" -> "Dolby Digital"
            "audio/eac3" -> "Dolby Digital Plus"
            "audio/eac3-joc" -> "Dolby Atmos"
            "audio/true-hd" -> "Dolby TrueHD"
            "audio/vnd.dts" -> "DTS"
            "audio/vnd.dts.hd" -> "DTS-HD"
            "audio/mp4a-latm" -> "AAC"
            "audio/mpeg" -> "MPEG-Audio"
            "audio/mpeg-L2" -> "MPEG-Audio"
            else -> "Audio"
        }
        val ch = when (a.channelCount) {
            1 -> "Mono"
            2 -> "Stereo"
            6 -> "5.1"
            8 -> "7.1"
            else -> if (a.channelCount > 0) a.channelCount.toString() + " Kanäle" else ""
        }
        parts.add((codec + " " + ch).trim())
    }
    return parts.joinToString("   |   ")
}
