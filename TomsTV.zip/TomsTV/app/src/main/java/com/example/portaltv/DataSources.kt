package com.example.portaltv

import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.okhttp.OkHttpDataSource
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * DNS mit Ausweichweg: Liefert das System für einen Namen nichts oder eine unbrauchbare Adresse
 * (0.0.0.0, 127.x – typisch bei DNS-Filtern, Werbeblockern oder Provider-Sperren), fragt die App
 * zusätzlich per DNS-über-HTTPS (Cloudflare, dann Google) nach.
 */
object SmartDns : Dns {
    private val boot = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(4, TimeUnit.SECONDS).build()
    private val cache = ConcurrentHashMap<String, Pair<Long, List<InetAddress>>>()
    val base: OkHttpClient = OkHttpClient.Builder().dns(this).build()

    private fun bad(a: InetAddress) = a.isAnyLocalAddress || a.isLoopbackAddress
    private fun isIpLiteral(h: String) = h.contains(':') || h.all { it.isDigit() || it == '.' }

    private fun system(host: String): List<InetAddress>? =
        try { Dns.SYSTEM.lookup(host) } catch (e: UnknownHostException) { null }

    override fun lookup(hostname: String): List<InetAddress> {
        val sys = system(hostname)
        val good = sys?.filter { !bad(it) }.orEmpty()
        if (good.isNotEmpty()) return good
        val d = doh(hostname)
        if (d.isNotEmpty()) return d
        if (!sys.isNullOrEmpty()) return sys
        throw UnknownHostException(hostname)
    }

    /** True, wenn das System den Namen nicht brauchbar auflöst, aber der Ausweichweg schon. */
    private val fixCache = ConcurrentHashMap<String, Pair<Long, Boolean>>()

    fun needsFix(host: String?): Boolean {
        if (host.isNullOrBlank() || isIpLiteral(host)) return false
        val now = System.currentTimeMillis()
        fixCache[host]?.let { if (now - it.first < 10 * 60_000L) return it.second }
        val r = needsFixRaw(host)
        fixCache[host] = now to r
        return r
    }

    private fun needsFixRaw(host: String): Boolean {
        val sys = system(host)
        if (sys != null && sys.any { !bad(it) }) return false
        return doh(host).isNotEmpty()
    }

    private fun doh(host: String): List<InetAddress> {
        val now = System.currentTimeMillis()
        cache[host]?.let { if (now - it.first < 10 * 60_000L) return it.second }
        val urls = listOf(
            "https://1.1.1.1/dns-query?name=" + host + "&type=A",
            "https://8.8.8.8/resolve?name=" + host + "&type=A"
        )
        for (u in urls) {
            try {
                val r = Request.Builder().url(u).header("Accept", "application/dns-json").build()
                val out = boot.newCall(r).execute().use { resp ->
                    if (!resp.isSuccessful) return@use emptyList<InetAddress>()
                    val ans = JSONObject(resp.body?.string().orEmpty()).optJSONArray("Answer") ?: return@use emptyList<InetAddress>()
                    val l = ArrayList<InetAddress>()
                    for (i in 0 until ans.length()) {
                        val a = ans.optJSONObject(i) ?: continue
                        if (a.optInt("type") != 1) continue
                        val ip = InetAddress.getByName(a.optString("data"))
                        if (!bad(ip)) l.add(ip)
                    }
                    l
                }
                if (out.isNotEmpty()) {
                    cache[host] = now to out
                    AppLog.add("DNS: " + host + " wurde lokal nicht brauchbar aufgelöst, per DoH gefunden: " + out.first().hostAddress)
                    return out
                }
            } catch (e: Exception) { }
        }
        return emptyList()
    }
}

/** Wählt je Adresse den passenden Weg: normal oder über OkHttp mit dem Ausweich-DNS. */
@UnstableApi
class SmartDataSource(private val def: DataSource, private val ok: DataSource) : DataSource {
    private var cur: DataSource = def
    override fun addTransferListener(l: TransferListener) { def.addTransferListener(l); ok.addTransferListener(l) }
    override fun open(dataSpec: DataSpec): Long {
        cur = if (SmartDns.needsFix(dataSpec.uri.host)) ok else def
        return cur.open(dataSpec)
    }
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int = cur.read(buffer, offset, length)
    override fun getUri(): Uri? = cur.uri
    override fun getResponseHeaders(): Map<String, List<String>> = cur.responseHeaders
    override fun close() { cur.close() }
}

@UnstableApi
class SmartHttpFactory : DataSource.Factory {
    private var ua = ""
    private var props: Map<String, String> = emptyMap()
    private var connectMs = 8000
    private var readMs = 8000
    private var client: OkHttpClient? = null
    private var compat = false

    /** Kompatibilitätsmodus: nur der Standard-Verbindungsweg, ohne eigene DNS-/OkHttp-Schicht. */
    fun setCompat(v: Boolean): SmartHttpFactory { compat = v; return this }
    fun setUserAgent(v: String): SmartHttpFactory { ua = v; return this }
    fun setAllowCrossProtocolRedirects(v: Boolean): SmartHttpFactory = this
    fun setConnectTimeoutMs(v: Int): SmartHttpFactory { connectMs = v; client = null; return this }
    fun setReadTimeoutMs(v: Int): SmartHttpFactory { readMs = v; client = null; return this }
    fun setDefaultRequestProperties(m: Map<String, String>): SmartHttpFactory { props = m; return this }

    override fun createDataSource(): DataSource {
        val def = DefaultHttpDataSource.Factory().setUserAgent(ua).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(connectMs).setReadTimeoutMs(readMs).setDefaultRequestProperties(props).createDataSource()
        if (compat) return def
        val cl = client ?: SmartDns.base.newBuilder()
            .connectTimeout(connectMs.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(readMs.toLong(), TimeUnit.MILLISECONDS)
            .followRedirects(true).followSslRedirects(true).build().also { client = it }
        val ok = OkHttpDataSource.Factory(cl).setUserAgent(ua).setDefaultRequestProperties(props).createDataSource()
        return SmartDataSource(def, ok)
    }
}
