package com.example.portaltv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class StalkerClient {

    // Verbesserte Netzwerk-Abfrage mit automatischem Timeout-Schutz
    suspend fun fetchPortalData(portalUrl: String): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL(portalUrl)
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000 // 8 Sekunden Limit statt unendlich
                    readTimeout = 8000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C)")
                }

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val text = connection.inputStream.bufferedReader().use { it.readText() }
                    Result.success(text)
                } else {
                    Result.failure(Exception("Server antwortet mit Fehler-Code: $responseCode"))
                }
            } catch (e: Exception) {
                Result.failure(Exception("Netzwerkfehler: ${e.localizedMessage}"))
            }
        }
    }
}