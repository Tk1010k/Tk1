package com.example.portaltv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

const val UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 4 rev: 2116 Mobile Safari/533.3"

data class Portal(
    val id: String, val name: String, val url: String, val mac: String,
    val login: String = "", val password: String = ""
)
data class Category(val id: String, val title: String)
data class Item(
    val id: String, val name: String, val cmd: String, val logo: String?,
    val cat: String, val episodes: List<Int> = emptyList()
)
data class PageResult(val items: List<Item>, val total: Int, val pageSize: Int)
data class Season(val name: String, val cmd: String, val episodes: List<Int>, val seriesTitle: String = name)
data class Epg(
    val title: String, val start: String, val end: String,
    val startTs: Long, val stopTs: Long, val descr: String
)

private fun hash(alg: String, s: String) =
    MessageDigest.getInstance(alg).digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Einfacher Client für das Stalker/Ministra-Middleware-Protokoll. */
class StalkerClient(private val portal: Portal) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private var endpoint: String? = null
    private var token = ""
    private val sn = hash("MD5", portal.mac).take(13).uppercase()
    private val deviceId = hash("SHA-256", portal.mac).uppercase()

    private fun candidates(): List<String> {
        val u = portal.url.trim()
        if (u.contains("load.php") || u.contains("portal.php")) return listOf(u.substringBefore('?'))
        var base = u.trimEnd('/')
        if (base.endsWith("/c")) base = base.removeSuffix("/c")
        return listOf("$base/server/load.php", "$base/portal.php")
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(ep: String, params: Map<String, String>, auth: Boolean): JSONObject {
        val q = (params + ("JsHttpRequest" to "1-xml")).entries.joinToString("&") { "${it.key}=${enc(it.value)}" }
        val b = Request.Builder().url("$ep?$q")
            .header("User-Agent", UA)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${portal.mac}; stb_lang=en; timezone=Europe/Berlin")
            .header("Accept", "*/*")
        if (auth && token.isNotEmpty()) b.header("Authorization", "Bearer $token")
        return http.newCall(b.build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            JSONObject(r.body?.string().orEmpty())
        }
    }

    private fun call(params: Map<String, String>): JSONObject =
        request(endpoint ?: error("Nicht verbunden"), params, true)

    fun connect() {
        var last: Exception? = null
        for (ep in candidates()) {
            try {
                val h = request(ep, mapOf("type" to "stb", "action" to "handshake", "token" to ""), false)
                val t = h.optJSONObject("js")?.optString("token").orEmpty()
                if (t.isNotEmpty()) { endpoint = ep; token = t; break }
            } catch (e: Exception) { last = e }
        }
        if (endpoint == null) throw last ?: IllegalStateException("Handshake fehlgeschlagen")
        if (portal.login.isNotEmpty()) {
            call(mapOf("type" to "stb", "action" to "do_auth", "login" to portal.login,
                "password" to portal.password, "device_id" to deviceId, "device_id2" to deviceId))
        }
        runCatching {
            call(mapOf("type" to "stb", "action" to "get_profile", "hd" to "1", "num_banks" to "2",
                "sn" to sn, "stb_type" to "MAG250", "client_type" to "STB", "image_version" to "218",
                "video_out" to "hdmi", "device_id" to deviceId, "device_id2" to deviceId,
                "signature" to "", "auth_second_step" to "1", "hw_version" to "1.7-BD-00",
                "not_valid_token" to "0", "api_signature" to "262", "prehash" to ""))
        }
    }

    private fun absUrl(s: String?): String? {
        if (s.isNullOrBlank()) return null
        if (s.startsWith("http")) return s
        return runCatching {
            val u = URL(portal.url)
            "${u.protocol}://${u.authority}" + (if (s.startsWith("/")) s else "/$s")
        }.getOrNull()
    }

    private fun parse(a: JSONArray?): List<Item> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            val eps = o.optJSONArray("series")?.let { s -> (0 until s.length()).map { s.optInt(it) } } ?: emptyList()
            val logo = absUrl(o.optString("logo").ifBlank { o.optString("screenshot_uri") })
            Item(o.optString("id"), o.optString("name"), o.optString("cmd"), logo, o.optString("tv_genre_id"), eps)
        }
    }

    fun categories(type: String): List<Category> {
        val action = if (type == "itv") "get_genres" else "get_categories"
        val a = call(mapOf("type" to type, "action" to action)).optJSONArray("js") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
            Category(it.optString("id"), it.optString("title").ifBlank { it.optString("name") })
        }
    }

    fun channels(): List<Item> =
        parse(call(mapOf("type" to "itv", "action" to "get_all_channels")).optJSONObject("js")?.optJSONArray("data"))

    fun list(type: String, category: String, page: Int, search: String = ""): PageResult {
        val params = mutableMapOf("type" to type, "action" to "get_ordered_list", "category" to category,
            "p" to page.toString(), "sortby" to "added")
        if (search.isNotBlank()) params["search"] = search
        val js = call(params).optJSONObject("js")
            ?: return PageResult(emptyList(), 0, 14)
        return PageResult(
            parse(js.optJSONArray("data")),
            js.optString("total_items").toIntOrNull() ?: 0,
            js.optString("max_page_items").toIntOrNull() ?: 14
        )
    }

    fun seasons(movieId: String, seriesTitle: String = ""): List<Season> {
        val a = call(mapOf("type" to "series", "action" to "get_ordered_list", "movie_id" to movieId,
            "season_id" to "0", "episode_id" to "0", "p" to "1")).optJSONObject("js")?.optJSONArray("data")
            ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            val eps = o.optJSONArray("series")?.let { s -> (0 until s.length()).map { s.optInt(it) } } ?: emptyList()
            Season(o.optString("name"), o.optString("cmd"), eps, seriesTitle.ifBlank { o.optString("name") })
        }
    }

    /** Aktuelle und kommende Sendungen eines Kanals. */
    fun epg(chId: String, size: Int = 5): List<Epg> {
        val r = call(mapOf("type" to "itv", "action" to "get_short_epg", "ch_id" to chId, "size" to size.toString()))
        val a = r.optJSONArray("js") ?: r.optJSONObject("js")?.optJSONArray("data") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            Epg(
                o.optString("name"),
                o.optString("time").takeLast(8).take(5),
                o.optString("time_to").takeLast(8).take(5),
                o.optLong("start_timestamp"), o.optLong("stop_timestamp"),
                o.optString("descr")
            )
        }
    }

    /** kind: "itv" für Live, "vod" für Filme und Episoden. */
    fun link(kind: String, cmd: String, episode: Int?): String {
        val js = call(mapOf("type" to kind, "action" to "create_link", "cmd" to cmd,
            "series" to (episode?.toString() ?: ""), "forced_storage" to "", "disable_ad" to "0",
            "download" to "0")).optJSONObject("js")
        val c = js?.optString("cmd").orEmpty().trim()
        val url = c.split(Regex("\\s+")).lastOrNull().orEmpty()
        if (!url.startsWith("http")) error("Kein Stream-Link erhalten")
        return url
    }
}
