package com.example.portaltv

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

const val UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 4 rev: 2116 Mobile Safari/533.3"

data class Portal(
    val id: String, val name: String, val url: String, val mac: String,
    val login: String = "", val password: String = ""
)
data class Category(val id: String, val title: String)
data class Item(
    val id: String, val name: String, val cmd: String, val logo: String?,
    val cat: String, val episodes: List<Int> = emptyList(),
    val descr: String = "", val year: String = "", val dup: Boolean = false,
    val backdrop: String? = null,
    val meta: String = "", val num: Int = 0,
    /** Archiv (Catch-up): so viele Stunden zurück kann der Sender nachgesehen werden, 0 = kein Archiv */
    val arch: Int = 0
)
private val deMarkRe = Regex("(?i)^[\\s\\[\\(|]*(de|ger|deu)[\\s\\]\\)]*[|:\\-–/»>_]")
private val deMarkUpRe = Regex("^[\\s\\[\\(|]*(DE|GER|DEU)\\s")
private val deBracketRe = Regex("(?i)[\\[\\(]\\s*(de|ger|deu)\\s*[\\]\\)]")
private val deWordRe = Regex("(?i)\\b(german|germany|deutsch\\w*)\\b")

/** Erkennt deutsche Kategorien und Titel: "DE | …", "GER: …", "[DE]", "German", "Deutsch". */
fun isGermanTitle(t: String): Boolean =
    deMarkRe.containsMatchIn(t) || deMarkUpRe.containsMatchIn(t) || deBracketRe.containsMatchIn(t) || deWordRe.containsMatchIn(t)

private val newCatRe = Regex("(?i)neu|new|latest|aktuell")

/**
 * Neueste Titel nur aus deutschen Kategorien (Kategorien mit „Neu“ im Namen zuerst).
 * Gibt null zurück, wenn das Portal keine deutschen Kategorien erkennbar benennt.
 */
fun germanNewest(cl: StalkerClient, type: String, max: Int = 14): List<Item>? {
    val cats = cl.categories(type).filter { it.id != "*" && isGermanTitle(it.title) }
        .sortedByDescending { newCatRe.containsMatchIn(it.title) }
    if (cats.isEmpty()) return null
    val lists = cats.take(6).map { cat -> try { cl.list(type, cat.id, 1).items } catch (e: Exception) { emptyList() } }
    val out = ArrayList<Item>()
    val seen = HashSet<String>()
    var i = 0
    while (out.size < max && lists.any { i < it.size }) {
        for (l in lists) {
            val it0 = l.getOrNull(i) ?: continue
            if (seen.add(it0.name.trim().lowercase())) out.add(it0)
            if (out.size >= max) break
        }
        i++
    }
    return out
}

data class PageResult(val items: List<Item>, val total: Int, val pageSize: Int)
data class Season(val name: String, val cmd: String, val episodes: List<Int>)
data class Epg(
    val title: String, val start: String, val end: String,
    val startTs: Long, val stopTs: Long, val descr: String,
    val id: String = "", val archive: Boolean = false
)

private object ChanMemo {
    val data = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<Item>>>()
    val locks = java.util.concurrent.ConcurrentHashMap<String, Any>()
}

private fun hash(alg: String, s: String) =
    MessageDigest.getInstance(alg).digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Einfacher Client für das Stalker/Ministra-Middleware-Protokoll. */
open class StalkerClient(private val portal: Portal) {
    fun portalUrl(): String = portal.url
    fun portalName(): String = portal.name

    private val http = OkHttpClient.Builder()
        .dns(SmartDns)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    // Für Stream-Links: schnell aufgeben statt lange warten, damit Umschalten flott bleibt
    /** Für schwaches Netz: deutlich längere Wartezeiten. */
    private val slowHttp = http.newBuilder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
    private val fastHttp = http.newBuilder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()
    private var endpoint: String? = null
    private var token = ""
    private val sn = hash("MD5", portal.mac).take(13).uppercase()
    private val deviceId = hash("SHA-256", portal.mac).uppercase()

    private fun candidates(): List<String> {
        val u = portal.url.trim()
        if (u.contains("load.php") || u.contains("portal.php")) return listOf(u.substringBefore('?'))
        var base = u.trimEnd('/')
        if (base.endsWith("/c")) base = base.removeSuffix("/c")
        return listOf("$base/server/load.php", "$base/portal.php", "$base/stalker_portal/server/load.php")
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(ep: String, params: Map<String, String>, auth: Boolean, fast: Boolean = false): JSONObject {
        val q = (params + ("JsHttpRequest" to "1-xml")).entries.joinToString("&") { "${it.key}=${enc(it.value)}" }
        val b = Request.Builder().url("$ep?$q")
            .header("User-Agent", UA)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${portal.mac}; stb_lang=en; timezone=Europe/Berlin")
            .header("Accept", "*/*")
        if (auth && token.isNotEmpty()) b.header("Authorization", "Bearer $token")
        val cl = when {
            NetState.weak && fast -> http
            NetState.weak -> slowHttp
            fast -> fastHttp
            else -> http
        }
        val req = b.build()
        // Manche Portale antworten gelegentlich leer: einmal kurz wiederholen, sonst klare Meldung
        for (attempt in 0..1) {
            val text = cl.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}")
                r.body?.string().orEmpty()
            }
            if (text.isNotBlank()) return JSONObject(text)
            if (attempt == 0) Thread.sleep(400)
        }
        throw java.io.IOException("Leere Antwort vom Portal. Bitte gleich nochmal versuchen.")
    }

    private fun call(params: Map<String, String>, fast: Boolean = false): JSONObject =
        request(endpoint ?: error("Nicht verbunden"), params, true, fast)

    /** Ablaufdatum des Abos, soweit das Portal es liefert (leer, wenn unbekannt). */
    @Volatile var accountEnd: String = ""
    /** Anzahl der zuletzt geladenen Sender (für die Portal-Übersicht). */
    @Volatile var chanCount: Int = 0

    fun accountInfo(): String {
        val js = call(mapOf("type" to "account_info", "action" to "get_main_info")).optJSONObject("js") ?: return ""
        for (k in listOf("end_date", "expire_billing_date", "account_end_date", "expiry_date")) {
            val v = js.optString(k)
            if (v.isNotBlank() && v != "null") return v
        }
        return ""
    }

    open fun connect() {
        var last: Exception? = null
        var firstEp: String? = null
        var firstTok = ""
        for (ep in candidates()) {
            try {
                val h = request(ep, mapOf("type" to "stb", "action" to "handshake", "token" to ""), false, true)
                val t = h.optJSONObject("js")?.optString("token").orEmpty()
                if (t.isEmpty()) continue
                endpoint = ep; token = t
                authAndProfile()
                // Liefert dieser Endpunkt auch Daten? Manche Portale geben auf einem Weg nur den Token, aber leere Antworten.
                val ok = runCatching { call(mapOf("type" to "itv", "action" to "get_genres")); true }.getOrDefault(false)
                if (ok) return
                if (firstEp == null) { firstEp = ep; firstTok = t }
            } catch (e: Exception) { last = e }
        }
        if (firstEp != null) { endpoint = firstEp; token = firstTok; return }
        endpoint = null
        throw last ?: IllegalStateException("Handshake fehlgeschlagen")
    }

    private fun authAndProfile() {
        if (portal.login.isNotEmpty()) {
            call(mapOf("type" to "stb", "action" to "do_auth", "login" to portal.login,
                "password" to portal.password, "device_id" to deviceId, "device_id2" to deviceId))
        }
        runCatching {
            call(mapOf("type" to "stb", "action" to "get_profile", "hd" to "1", "num_banks" to "2",
                "sn" to sn, "stb_type" to "MAG250", "client_type" to "STB", "image_version" to "218",
                "video_out" to "hdmi", "device_id" to deviceId, "device_id2" to deviceId,
                "signature" to "", "auth_second_step" to "1", "hw_version" to "1.7-BD-00",
                "not_valid_token" to "0", "api_signature" to "262", "prehash" to ""))
        }
    }

    private fun absUrl(s: String?): String? {
        if (s.isNullOrBlank()) return null
        if (s.startsWith("http")) return s
        return runCatching {
            val u = URL(portal.url)
            "${u.protocol}://${u.authority}" + (if (s.startsWith("/")) s else "/$s")
        }.getOrNull()
    }

    private fun parse(a: JSONArray?): List<Item> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            val eps = o.optJSONArray("series")?.let { s -> (0 until s.length()).map { s.optInt(it) } } ?: emptyList()
            val logo = absUrl(o.optString("logo").ifBlank { o.optString("screenshot_uri") })
            val big = absUrl(listOf("cover_big", "big_cover", "screenshot_big", "backdrop", "backdrop_path")
                .map { k -> o.optString(k) }.firstOrNull { v -> v.isNotBlank() && v != "null" })
            val metaLines = ArrayList<String>()
            o.optString("genres_str").takeIf { it.isNotBlank() && it != "null" }?.let { metaLines.add("Genre: $it") }
            o.optString("time").takeIf { it.isNotBlank() && it != "0" && it != "null" }?.let { metaLines.add("Laufzeit: $it Min.") }
            o.optString("director").takeIf { it.isNotBlank() && it != "null" }?.let { metaLines.add("Regie: $it") }
            o.optString("actors").takeIf { it.isNotBlank() && it != "null" }?.let { metaLines.add("Darsteller: $it") }
            val rating = o.optString("rating_imdb").ifBlank { o.optString("rating_kinopoisk") }
            if (rating.isNotBlank() && rating != "0" && rating != "null") metaLines.add("Bewertung: $rating")
            val archFlag = o.optString("tv_archive").ifEmpty { o.optString("archive") }
            val archH = if (archFlag == "1") (o.optString("tv_archive_duration").toIntOrNull() ?: 0).let { if (it > 0) it else 24 } else 0
            Item(o.optString("id"), o.optString("name"), o.optString("cmd"), logo, o.optString("tv_genre_id"), eps,
                o.optString("description"), o.optString("year"), false, big,
                metaLines.joinToString("\n"), o.optString("number").toIntOrNull() ?: 0, archH)
        }
    }

    open fun categories(type: String): List<Category> {
        val action = if (type == "itv") "get_genres" else "get_categories"
        val a = call(mapOf("type" to type, "action" to action)).optJSONArray("js") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
            Category(it.optString("id"), it.optString("title").ifBlank { it.optString("name") })
        }
    }

    /** Ordner für den Zwischenspeicher der Senderliste (wird von der App gesetzt). */
    var cacheDir: File? = null

    /** true: Zwischenspeicher ignorieren (zum Beispiel bei "Aktualisieren"). */
    var noCache: Boolean = false

    private fun fetchChannelsRaw(): List<Item> {
        val arr = call(mapOf("type" to "itv", "action" to "get_all_channels")).optJSONObject("js")?.optJSONArray("data")
        // Diagnose: wie viele Sender melden ein Archiv (Catch-up)?
        try {
            if (arr != null) {
                var n = 0
                var maxDur = 0
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val flag = o.optString("tv_archive").ifEmpty { o.optString("archive") }
                    if (flag == "1") {
                        n++
                        val d = o.optString("tv_archive_duration").toIntOrNull() ?: 0
                        if (d > maxDur) maxDur = d
                    }
                }
                AppLog.add("Archiv: " + n + " von " + arr.length() + " Sendern melden Archiv (" + portal.name +
                    (if (n > 0) ", bis " + maxDur + " Std." else "") + ")")
            }
        } catch (e: Exception) { }
        return parse(arr)
    }

    /** Alle Sender. Kategorien ohne Sender (zum Beispiel Adult oder +18) werden einzeln nachgeladen. */
    private fun fetchChannels(): List<Item> {
        val all = fetchChannelsRaw()
        val genres = try { categories("itv") } catch (e: Exception) { emptyList() }
        val have = all.map { it.cat }.toSet()
        val ids = all.map { it.id }.toHashSet()
        val extra = ArrayList<Item>()
        val todo = genres.filter { g -> !(g.id == "*" || g.id.isBlank() || g.id in have) }.take(30)
        if (todo.isNotEmpty()) {
            // Einzelne Kategorien parallel laden (4 gleichzeitig) statt nacheinander
            val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
            try {
                val futs = todo.map { g ->
                    pool.submit(java.util.concurrent.Callable<List<Item>> {
                        try {
                            val l = fetchGenre(g.id)
                            AppLog.add("Portal " + portal.name + ": Kategorie \"" + g.title + "\" einzeln geladen: " + l.size + " Sender")
                            l
                        } catch (e: Exception) {
                            AppLog.add("Portal " + portal.name + ": Kategorie \"" + g.title + "\" nicht ladbar: " + e.message)
                            emptyList<Item>()
                        }
                    })
                }
                for (f in futs) {
                    val list = f.get().filter { it.id !in ids }
                    list.forEach { ids.add(it.id) }
                    extra.addAll(list)
                }
            } finally {
                pool.shutdown()
            }
        }
        return all + extra
    }

    private fun fetchGenre(genre: String): List<Item> {
        val out = ArrayList<Item>()
        var page = 1
        var firstId = ""
        while (page <= 40) {
            val js = call(mapOf("type" to "itv", "action" to "get_ordered_list", "genre" to genre, "fav" to "0",
                "sortby" to "number", "hd" to "0", "p" to page.toString())).optJSONObject("js") ?: break
            val data = parse(js.optJSONArray("data"))
            if (data.isEmpty()) break
            if (page == 1) firstId = data.first().id else if (data.first().id == firstId) break
            out.addAll(data.map { it.copy(cat = genre) })
            val total = js.optString("total_items").toIntOrNull() ?: 0
            val per = js.optString("max_page_items").toIntOrNull() ?: data.size
            if (total > 0 && out.size >= total) break
            if (data.size < per) break
            page++
        }
        return out
    }

    /** Gleichzeitige Aufrufe für dasselbe Portal teilen sich ein Ergebnis (kein doppeltes Laden). */
    open fun channels(): List<Item> {
        val key = portal.id
        val lock = ChanMemo.locks.getOrPut(key) { Any() }
        synchronized(lock) {
            val m = ChanMemo.data[key]
            if (m != null && System.currentTimeMillis() - m.first < 20_000L) return m.second
            val r = channelsLoad()
            ChanMemo.data[key] = System.currentTimeMillis() to r
            return r
        }
    }

    private fun channelsLoad(): List<Item> {
        val dir = cacheDir
        val f = if (dir != null) File(dir, "ch3_" + portal.id + ".json") else null
        if (f != null && !noCache && f.exists() && System.currentTimeMillis() - f.lastModified() < 12L * 3600 * 1000) {
            val cached = readItems(f)
            if (cached.isNotEmpty()) {
                AppLog.add("Portal " + portal.name + ": " + cached.size + " Sender aus Zwischenspeicher")
                // Sofort die gespeicherte Liste liefern und im Hintergrund für das nächste Mal erneuern
                // Nur erneuern, wenn die Liste älter als 3 Stunden ist (schont das Netz beim Start)
                if (System.currentTimeMillis() - f.lastModified() > 3L * 3600 * 1000) {
                    thread(isDaemon = true) { try { writeItems(f, fetchChannels()) } catch (e: Exception) { } }
                }
                chanCount = cached.size
                return cached
            }
        }
        val fresh = fetchChannels()
        AppLog.add("Portal " + portal.name + ": " + fresh.size + " Sender frisch geladen")
        if (f != null && fresh.isNotEmpty()) writeItems(f, fresh)
        chanCount = fresh.size
        return fresh
    }

    private fun writeItems(f: File, list: List<Item>) {
        val a = JSONArray()
        for (c in list) {
            a.put(JSONObject().put("id", c.id).put("name", c.name).put("cmd", c.cmd)
                .put("logo", c.logo ?: "").put("cat", c.cat).put("num", c.num).put("arch", c.arch))
        }
        f.writeText(a.toString())
    }

    private fun readItems(f: File): List<Item> = try {
        val a = JSONArray(f.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Item(o.getString("id"), o.getString("name"), o.getString("cmd"),
                o.optString("logo").ifBlank { null }, o.optString("cat"), num = o.optInt("num"), arch = o.optInt("arch"))
        }
    } catch (e: Exception) { emptyList() }

    open fun list(type: String, category: String, page: Int, search: String = ""): PageResult {
        val params = mutableMapOf("type" to type, "action" to "get_ordered_list", "category" to category,
            "p" to page.toString(), "sortby" to "added")
        if (search.isNotBlank()) params["search"] = search
        val js = call(params).optJSONObject("js")
            ?: return PageResult(emptyList(), 0, 14)
        return PageResult(
            parse(js.optJSONArray("data")),
            js.optString("total_items").toIntOrNull() ?: 0,
            js.optString("max_page_items").toIntOrNull() ?: 14
        )
    }

    open fun seasons(movieId: String): List<Season> {
        val a = call(mapOf("type" to "series", "action" to "get_ordered_list", "movie_id" to movieId,
            "season_id" to "0", "episode_id" to "0", "p" to "1")).optJSONObject("js")?.optJSONArray("data")
            ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            val eps = o.optJSONArray("series")?.let { s -> (0 until s.length()).map { s.optInt(it) } } ?: emptyList()
            Season(o.optString("name"), o.optString("cmd"), eps)
        }
    }

    /** Aktuelle und kommende Sendungen eines Kanals. */
    open fun epg(chId: String, size: Int = 5): List<Epg> {
        val short = try {
            val r = call(mapOf("type" to "itv", "action" to "get_short_epg", "ch_id" to chId, "size" to size.toString()))
            parseEpg(r.optJSONArray("js") ?: r.optJSONObject("js")?.optJSONArray("data"))
        } catch (e: Exception) { emptyList() }
        if (short.isNotEmpty()) return short
        // Ersatzweg: manche Portale liefern nur get_epg_info
        return try {
            val r = call(mapOf("type" to "itv", "action" to "get_epg_info", "period" to "6"))
            val data = r.optJSONObject("js")?.optJSONObject("data")
            parseEpg(data?.optJSONArray(chId))
        } catch (e: Exception) { emptyList() }
    }

    private fun parseEpg(a: JSONArray?): List<Epg> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map { o ->
            Epg(
                o.optString("name"),
                o.optString("time").takeLast(8).take(5),
                o.optString("time_to").takeLast(8).take(5),
                o.optLong("start_timestamp"), o.optLong("stop_timestamp"),
                o.optString("descr"),
                o.optString("id"), o.optString("mark_archive") == "1"
            )
        }.filter { it.title.isNotBlank() }
    }

    /** Vergangene Sendungen eines Senders an einem Tag (yyyy-MM-dd) aus dem Programm des Portals. */
    open fun archiveDay(chId: String, date: String): List<Epg> {
        val out = ArrayList<Epg>()
        var page = 1
        while (page <= 4) {
            val js = call(mapOf("type" to "epg", "action" to "get_simple_data_table", "ch_id" to chId,
                "date" to date, "p" to page.toString())).optJSONObject("js") ?: break
            val data = parseEpg(js.optJSONArray("data"))
            if (data.isEmpty()) break
            out.addAll(data.filter { e -> out.none { it.id == e.id && it.startTs == e.startTs } })
            val per = js.optString("max_page_items").toIntOrNull() ?: data.size
            if (data.size < per) break
            page++
        }
        AppLog.add("Archiv: " + out.size + " Sendungen am " + date)
        return out
    }

    /** Link zu einer Sendung im Archiv. Probiert die üblichen Stalker-Wege und schreibt jeden Versuch ins Protokoll. */
    private fun archiveLink(progId: String): String {
        val cmd = "auto /media/" + progId + ".mpg"
        for (action in listOf("create_link", "get_link")) {
            try {
                val js = call(mapOf("type" to "tv_archive", "action" to action, "cmd" to cmd, "series" to "",
                    "forced_storage" to "", "disable_ad" to "0", "download" to "0"), true).optJSONObject("js")
                val c = js?.optString("cmd").orEmpty().trim()
                val url = c.split(Regex("\\s+")).lastOrNull().orEmpty()
                AppLog.add("Archiv-Link (" + action + "): " + (if (url.startsWith("http")) "ok" else "leer: " + c.take(80)))
                if (url.startsWith("http")) return url
            } catch (e: Exception) {
                AppLog.add("Archiv-Link (" + action + ") Fehler: " + (e.message ?: "?"))
            }
        }
        error("Das Portal liefert für diese Sendung kein Archiv.")
    }

    /** kind: "itv" für Live, "vod" für Filme und Episoden, "arch" für Archiv (cmd = Sender-cmd, \u0001, Sendungs-ID). */
    open fun link(kind: String, cmd: String, episode: Int?): String {
        if (kind == "arch") return archiveLink(cmd.substringAfter('\u0001', ""))
        val js = call(mapOf("type" to kind, "action" to "create_link", "cmd" to cmd,
            "series" to (episode?.toString() ?: ""), "forced_storage" to "", "disable_ad" to "0",
            "download" to "0"), true).optJSONObject("js")
        val c = js?.optString("cmd").orEmpty().trim()
        val url = c.split(Regex("\\s+")).lastOrNull().orEmpty()
        if (!url.startsWith("http")) error("Kein Stream-Link erhalten")
        if (url.contains("://localhost") || url.contains("://127.0.0.1")) {
            error("Der Anbieter liefert nur einen internen Link (localhost). Dieser Sender ist so nicht abspielbar.")
        }
        return fixEmptyStream(kind, cmd, url)
    }

    /**
     * Manche Portale liefern bei create_link einen Link mit leerer Sender-Nummer (…live.php?…&stream=&…), obwohl die Nummer im
     * ursprünglichen Befehl steht. Dann trägt die App die Nummer wieder ein (andere Apps nehmen den Befehl direkt).
     */
    private fun fixEmptyStream(kind: String, cmd: String, url: String): String {
        if (kind != "itv") return url
        val emptyRe = Regex("([?&]stream=)(&|$)")
        if (!emptyRe.containsMatchIn(url)) return url
        val orig = cmd.trim().split(Regex("\\s+")).lastOrNull().orEmpty()
        val id = Regex("[?&]stream=(\\d+)").find(orig)?.groupValues?.get(1)
            ?: Regex("/ch/(\\d+)").find(orig)?.groupValues?.get(1)
        if (id != null) {
            AppLog.add("Link repariert: Sender-Nummer $id fehlte in der Antwort des Portals")
            return url.replace(emptyRe) { m -> m.groupValues[1] + id + m.groupValues[2] }
        }
        if (orig.startsWith("http") && !orig.contains("://localhost") && !orig.contains("://127.0.0.1")) {
            AppLog.add("Link: Portal lieferte leere Sender-Nummer, Original-Adresse wird genommen")
            return orig
        }
        return url
    }

    /** Anfrage-Kopfzeilen für den Stream-Server dieses Portals (wie ein MAG-Gerät). */
    open fun streamHeadersFor(cmd: String, withAuth: Boolean): Map<String, String> {
        val h = HashMap<String, String>()
        h["Cookie"] = "mac=" + portal.mac + "; stb_lang=en; timezone=Europe/Berlin"
        h["X-User-Agent"] = "Model: MAG250; Link: WiFi"
        if (withAuth && token.isNotEmpty()) h["Authorization"] = "Bearer $token"
        return h
    }
}
