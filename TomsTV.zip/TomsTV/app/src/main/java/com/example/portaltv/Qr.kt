// QR code logic
class Qr {}