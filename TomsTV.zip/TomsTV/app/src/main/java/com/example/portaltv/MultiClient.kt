package com.example.portaltv

import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Ein verbundenes Portal im gemeinsamen Katalog. pfx steht vor allen IDs dieses Portals. */
class MultiPart(val pfx: String, val client: StalkerClient, val name: String = "")

/**
 * Fasst alle Portale zu einem Katalog zusammen. Alle IDs und Befehle tragen vorn das Kürzel
 * ihres Portals ("pfx|id"), damit Abspielen, Staffeln und Programm beim richtigen Portal landen.
 * Kategorien mit gleichem Namen werden zusammengelegt, doppelte Sender (gleicher Name) einmal gezeigt.
 */
class MultiClient(private val parts: List<MultiPart>, private val dedupe: Boolean = true) :
    StalkerClient(Portal("all", "Alle Portale", "http://", "00:00:00:00:00:00")) {

    // Typ -> Portal-Kürzel -> eigene Kategorie-ID -> gemeinsamer Schlüssel
    private val catMaps = HashMap<String, Map<String, Map<String, String>>>()
    // Typ -> gemeinsamer Schlüssel -> Liste (Portal-Kürzel, eigene Kategorie-ID)
    private val catTargets = HashMap<String, Map<String, List<Pair<String, String>>>>()

    private fun enc(pfx: String, raw: String) = "$pfx|$raw"

    private fun dec(s: String): Pair<String, String>? {
        val i = s.indexOf('|')
        return if (i <= 0) null else s.substring(0, i) to s.substring(i + 1)
    }

    private fun partOf(pfx: String): MultiPart? = parts.firstOrNull { it.pfx == pfx }

    /** Bei Fehler einmal neu anmelden (Token abgelaufen) und wiederholen. */
    private fun <T> retry(part: MultiPart, block: () -> T): T {
        return try {
            block()
        } catch (e: Exception) {
            part.client.connect()
            block()
        }
    }

    private fun <A, T> parMap(items: List<A>, block: (A) -> T): List<T?> {
        if (items.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(items.size.coerceAtMost(6))
        try {
            val futures = items.map { item ->
                pool.submit(Callable<T?> { try { block(item) } catch (e: Exception) { null } })
            }
            return futures.map { it.get() }
        } finally {
            pool.shutdown()
        }
    }

    override fun connect() { /* Die einzelnen Portale sind bereits verbunden. */ }

    override fun categories(type: String): List<Category> {
        val results = parMap(parts) { part -> retry(part) { part.client.categories(type) } }
        val order = LinkedHashMap<String, String>()
        val targets = HashMap<String, MutableList<Pair<String, String>>>()
        val maps = HashMap<String, Map<String, String>>()
        parts.forEachIndexed { i, part ->
            val cats = results[i] ?: return@forEachIndexed
            val m = HashMap<String, String>()
            for (c in cats) {
                val key = if (c.id == "*") "*" else "m:" + c.title.trim().lowercase()
                if (key !in order) order[key] = c.title.trim()
                targets.getOrPut(key) { mutableListOf() }.add(part.pfx to c.id)
                m[c.id] = key
            }
            maps[part.pfx] = m
        }
        catMaps[type] = maps
        catTargets[type] = targets
        return order.map { Category(it.key, it.value) }
    }

    override fun channels(): List<Item> {
        if (catMaps["itv"] == null) categories("itv")
        val maps = catMaps["itv"] ?: emptyMap()
        val results = parMap(parts) { part -> retry(part) { part.client.channels() } }
        // Namen, die in mehreren Portalen vorkommen (nur relevant, wenn nichts zusammengefasst wird)
        val multi: Set<String> = if (dedupe) emptySet() else {
            val counts = HashMap<String, MutableSet<String>>()
            parts.forEachIndexed { i, part ->
                results[i]?.forEach { counts.getOrPut(it.name.trim().lowercase()) { mutableSetOf() }.add(part.pfx) }
            }
            counts.filter { it.value.size > 1 }.keys
        }
        val seen = HashSet<String>()
        val out = ArrayList<Item>()
        parts.forEachIndexed { i, part ->
            val list = results[i] ?: return@forEachIndexed
            val m = maps[part.pfx]
            for (ch in list) {
                val nameKey = ch.name.trim().lowercase()
                if (dedupe && nameKey.isNotEmpty() && !seen.add(nameKey)) continue
                val cat = m?.get(ch.cat) ?: ch.cat
                val shownName = if (nameKey in multi) ch.name + " · " + part.name else ch.name
                out.add(ch.copy(id = enc(part.pfx, ch.id), cmd = enc(part.pfx, ch.cmd), cat = cat, name = shownName))
            }
        }
        return out
    }

    override fun list(type: String, category: String, page: Int, search: String): PageResult {
        if (catTargets[type] == null) categories(type)
        val targets: List<Pair<String, String>> =
            if (category == "*") parts.map { it.pfx to "*" } else catTargets[type]?.get(category) ?: emptyList()
        val jobs = targets.mapNotNull { t -> partOf(t.first)?.let { Pair(it, t.second) } }
        val results = parMap(jobs) { job -> retry(job.first) { job.first.client.list(type, job.second, page, search) } }
        val items = ArrayList<Item>()
        var total = 0
        var size = 0
        jobs.forEachIndexed { i, job ->
            val r = results[i] ?: return@forEachIndexed
            total += r.total
            size += r.pageSize
            for (it0 in r.items) {
                items.add(it0.copy(id = enc(job.first.pfx, it0.id), cmd = enc(job.first.pfx, it0.cmd)))
            }
        }
        return PageResult(items, total, size.coerceAtLeast(1))
    }

    override fun seasons(movieId: String): List<Season> {
        val d = dec(movieId) ?: return emptyList()
        val part = partOf(d.first) ?: return emptyList()
        return retry(part) { part.client.seasons(d.second) }.map { it.copy(cmd = enc(d.first, it.cmd)) }
    }

    override fun epg(chId: String, size: Int): List<Epg> {
        val d = dec(chId) ?: return emptyList()
        val part = partOf(d.first) ?: return emptyList()
        return retry(part) { part.client.epg(d.second, size) }
    }

    override fun link(kind: String, cmd: String, episode: Int?): String {
        val d = dec(cmd) ?: error("Unbekanntes Portal. Bitte den Eintrag neu auswählen.")
        val part = partOf(d.first) ?: error("Dieses Portal ist nicht mehr aktiv.")
        return retry(part) { part.client.link(kind, d.second, episode) }
    }
}
