// Updater logic
class Updater {}