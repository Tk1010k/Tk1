package com.example.portaltv

import android.app.Application
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Portals : Screen
    data class Form(val edit: Portal?) : Screen
    data object Home : Screen
    data class Browse(val type: String) : Screen
    data class Seasons(val title: String) : Screen
    data class Episodes(val season: Season) : Screen
    data object ResumeList : Screen
    data object Guide : Screen
    data object Favs : Screen
    data object Settings : Screen
    data object PhoneAdd : Screen
    data object Watch : Screen
    data object AppSettings : Screen
    data object LogView : Screen
    data object EditCats : Screen
    data object EditChans : Screen
    data class Detail(val item: Item) : Screen
    data object Play : Screen
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = PortalStore(app)
    private val userData = UserData(app)
    private val settings = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var textColorName by mutableStateOf(settings.getString("textColor", "Weiß") ?: "Weiß")

    fun setTextColor(name: String) {
        textColorName = name
        settings.edit().putString("textColor", name).apply()
    }

    var accentName by mutableStateOf(settings.getString("accent", "Rot") ?: "Rot")

    fun setAccent(name: String) {
        accentName = name
        settings.edit().putString("accent", name).apply()
    }

    var sidebarMode by mutableStateOf(settings.getString("sidebar", "auto") ?: "auto")

    fun cycleSidebar() {
        sidebarMode = when (sidebarMode) { "auto" -> "compact"; "compact" -> "normal"; else -> "auto" }
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    /** "max": Bild und Ton so, wie das Portal sie sendet. "auto": an den Bildschirm angepasst. */
    var qualityMode by mutableStateOf(settings.getString("quality", "max") ?: "max")

    fun cycleQuality() {
        qualityMode = when (qualityMode) {
            "max" -> "adaptive"
            "adaptive" -> "auto"
            else -> "max"
        }
        settings.edit().putString("quality", qualityMode).apply()
    }

    /** Pufferung: "fast" (kurz), "balanced" (ausgewogen), "stable" (groß, für 4K). */
    var bufferMode by mutableStateOf(settings.getString("buffer", "balanced") ?: "balanced")

    fun cycleBuffer() {
        bufferMode = when (bufferMode) {
            "balanced" -> "stable"
            "stable" -> "fast"
            else -> "balanced"
        }
        settings.edit().putString("buffer", bufferMode).apply()
    }

    /** 4K-Hilfe: Tunneling und schnellere Decoder-Warteschlange (hilft auf manchen Boxen gegen Ruckler). */
    var fourKHelp by mutableStateOf(settings.getBoolean("fourK", false))

    fun toggle4kHelp() {
        fourKHelp = !fourKHelp
        settings.edit().putBoolean("fourK", fourKHelp).apply()
    }

    var dedupe by mutableStateOf(settings.getBoolean("dedupe", true))

    fun toggleDedupe() {
        dedupe = !dedupe
        settings.edit().putBoolean("dedupe", dedupe).apply()
        refreshAllPortals()
    }

    // Aufklappbare Portal-Gruppen und seitliches Einklappen
    var portalGroups by mutableStateOf<List<PortalGroup>>(emptyList())
    var expandedPortals by mutableStateOf<Set<String>>(settings.getStringSet("expanded", null)?.toSet() ?: emptySet())
    private var expandedInit = settings.contains("expanded")
    var groupedView by mutableStateOf(settings.getBoolean("grouped", true))
    var catPaneOpen by mutableStateOf(settings.getBoolean("catPane", true))

    fun toggleGroup(pfx: String) {
        expandedPortals = if (pfx in expandedPortals) expandedPortals - pfx else expandedPortals + pfx
        expandedInit = true
        settings.edit().putStringSet("expanded", expandedPortals).apply()
    }

    fun toggleGrouped() {
        groupedView = !groupedView
        settings.edit().putBoolean("grouped", groupedView).apply()
    }

    fun toggleCatPane() {
        catPaneOpen = !catPaneOpen
        settings.edit().putBoolean("catPane", catPaneOpen).apply()
    }

    var designMode by mutableStateOf(settings.getString("design", "cinema")?.takeIf { it == "oled" || it == "night" } ?: "cinema")

    fun toggleDesign() {
        designMode = when (designMode) {
            "cinema" -> "oled"
            "oled" -> "night"
            else -> "cinema"
        }
        settings.edit().putString("design", designMode).apply()
    }

    /** Leistungsmodus: keine Animationen, keine Vorschau, kein Banner-Wechsel. */
    var perfMode by mutableStateOf(settings.getBoolean("perf", false))

    fun togglePerf() {
        perfMode = !perfMode
        settings.edit().putBoolean("perf", perfMode).apply()
        if (perfMode) stopPreview()
    }

    // Live-Vorschau in der Senderliste
    var previewOn by mutableStateOf(settings.getBoolean("preview", true))
    var previewUrl by mutableStateOf<String?>(null)
    var previewChannel by mutableStateOf<Item?>(null)
    private var previewJob: Job? = null

    fun togglePreview() {
        previewOn = !previewOn
        settings.edit().putBoolean("preview", previewOn).apply()
        if (!previewOn) stopPreview()
    }

    fun requestPreview(ch: Item) {
        previewChannel = ch
        if (!previewOn) return
        val c = client ?: return
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            delay(1200)
            try {
                previewUrl = withContext(Dispatchers.IO) { c.link("itv", ch.cmd, null) }
            } catch (e: Exception) {
                previewUrl = null
            }
        }
    }

    fun stopPreview() {
        previewJob?.cancel()
        previewUrl = null
    }

    fun setSidebar(mode: String) {
        sidebarMode = mode
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    // ---------- Weiterschauen: Anzeige, Abspielen, Löschen ----------
    var resumeEntries by mutableStateOf<List<Resume>>(emptyList())
    private var resumePfx = ""
    private var resumeLogo: String? = null
    private var playGen = 0
    private var hdrMode = 0
    private var reloading = false
    var playNonce by mutableIntStateOf(0)
    private val linkCache = HashMap<String, Pair<String, Long>>()
    private val prefetching = HashSet<String>()
    private val triedIds = HashSet<String>()
    private var liveContext = "*"

    private fun loadResumeShown() {
        val p = portal ?: return
        resumeEntries = userData.resumes(p.id).filter { it.type == browseType && it.cmd.startsWith("$resumePfx|") }
    }

    fun refreshResumeShown() { loadResumeShown() }

    fun removeResume(r: Resume) {
        val p = portal ?: return
        userData.removeResume(p.id, r.key)
        loadResumeShown()
        resumeList = userData.resumes(p.id)
    }

    fun clearResumeShown() {
        val p = portal ?: return
        resumeEntries.forEach { userData.removeResume(p.id, it.key) }
        loadResumeShown()
        resumeList = userData.resumes(p.id)
    }

    fun playResume(r: Resume) {
        resumeLogo = r.logo
        browseType = r.type
        if (r.type == "series") seriesName = r.title.substringBefore(" – ", "")
        currentSeason = seasons.firstOrNull { it.cmd == r.cmd }
            ?: (if (r.eps.isNotEmpty()) Season(r.sname, r.cmd, r.eps.split(",").mapNotNull { it.toIntOrNull() }) else null)
        play("vod", r.title, r.cmd, r.ep)
    }

    fun toggleWatchOf(item: Item, type: String) {
        browseType = type
        toggleWatch(item)
    }
    val portals = mutableStateListOf<Portal>().apply { addAll(store.load()) }
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var portal by mutableStateOf<Portal?>(null)
    private var client: StalkerClient? = null

    var loading by mutableStateOf(false)
    var busyList by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)

    var categories by mutableStateOf<List<Category>>(emptyList())
    var selCat by mutableStateOf<String?>(null)
    var items by mutableStateOf<List<Item>>(emptyList())
    var hasMore by mutableStateOf(false)
    var seasons by mutableStateOf<List<Season>>(emptyList())
    var favs by mutableStateOf<List<Item>>(emptyList())
    var allCats by mutableStateOf<List<Category>>(emptyList())
    var hiddenCats by mutableStateOf<Set<String>>(emptySet())
    var hiddenChans by mutableStateOf<Set<String>>(emptySet())
    var editChans by mutableStateOf<List<Item>>(emptyList())
    var hiddenItems by mutableStateOf<Set<String>>(emptySet())
    var editMode by mutableStateOf(false)
    var introDone by mutableStateOf(false)
    var qrUrl by mutableStateOf<String?>(null)
    var chanPanel by mutableStateOf(false)
    var panelCat by mutableStateOf("*")
    var watchIds by mutableStateOf<Set<String>>(emptySet())
    private var liveCats: List<Category> = emptyList()
    private var panelHiddenCats: Set<String> = emptySet()
    private var panelHiddenChans: Set<String> = emptySet()
    private var panelFavs: List<Item> = emptyList()
    private var phoneServer: PortalServer? = null
    var homeNew by mutableStateOf<List<Item>>(emptyList())
    var homeChannels by mutableStateOf<List<Item>>(emptyList())
    private var cachedChannels: List<Item>? = null

    // Hintergrund-Aktualisierung aller Portale beim Start
    private class PortalCache(val client: StalkerClient, val at: Long, val channels: List<Item>)
    private val caches = HashMap<String, PortalCache>()
    private val refreshSem = Semaphore(2)
    val status = mutableStateMapOf<String, String>()
    private val clients = HashMap<String, StalkerClient>()
    private val cacheRoot: File = File(app.cacheDir, "lists").apply { mkdirs() }
    private var forceRefresh = false
    private var refreshJob: Job? = null
    var allLoading by mutableStateOf(false)
    var updateInfo by mutableStateOf<Updater.Info?>(null)
    var updateMsg by mutableStateOf<String?>(null)
    var updateProgress by mutableIntStateOf(-1)
    var updatePrompt by mutableStateOf<Updater.Info?>(null)
    var resumeList by mutableStateOf<List<Resume>>(emptyList())
    var queryText by mutableStateOf("")
    var playUrl by mutableStateOf<String?>(null)
    var playTitle by mutableStateOf("")
    var isLive by mutableStateOf(false)
    var playChId by mutableStateOf("")
    var playLogo by mutableStateOf<String?>(null)
    var epgTick by mutableIntStateOf(0)

    val listState = LazyListState()
    val gridState = LazyGridState()

    private var allChannels = emptyList<Item>()
    private var page = 0
    private var loaded = 0
    private var gen = 0
    private var query = ""
    var browseType = "itv"
    private var zapList = emptyList<Item>()
    private var zapIndex = 0
    private var lastKind = "itv"
    private var lastCmd = ""
    private var lastEp: Int? = null
    private var resumeKey = ""
    private var noticeJob: Job? = null

    private fun <T> io(block: () -> T, ok: (T) -> Unit) {
        loading = true; error = null
        viewModelScope.launch {
            try { ok(withContext(Dispatchers.IO) { block() }) }
            catch (e: Exception) { error = e.message ?: e.javaClass.simpleName; AppLog.add("Fehler: " + (e.message ?: e.javaClass.simpleName)) }
            finally { loading = false }
        }
    }

    fun showNotice(msg: String) {
        notice = msg
        noticeJob?.cancel()
        noticeJob = viewModelScope.launch { delay(2500); notice = null }
    }

    fun push(s: Screen) { stack.add(s) }

    fun back(): Boolean {
        if (updatePrompt != null) { updatePrompt = null; return true }
        if (upNext != null) { cancelUpNext(); return true }
        if (chanPanel) { chanPanel = false; return true }
        if (stack.size <= 1) return false
        val top = stack.last()
        if (top is Screen.Play) { playUrl = null; chanPanel = false; cancelUpNext() }
        if (top is Screen.Browse) editMode = false
        stack.removeAt(stack.size - 1)
        error = null
        if (top is Screen.EditCats || top is Screen.EditChans) refreshAfterEdit()
        return true
    }

    private fun refreshAfterEdit() {
        val valid = categories.any { it.id == selCat }
        selectCategory(if (valid) selCat!! else categories.firstOrNull { it.id != "fav" }?.id ?: "fav")
    }

    // ---------- Portale ----------
    fun savePortal(p: Portal) {
        val i = portals.indexOfFirst { it.id == p.id }
        if (i >= 0) portals[i] = p else portals.add(p)
        store.save(portals.toList())
        refreshAllPortals(true)
    }

    fun deletePortal(p: Portal) {
        portals.removeAll { it.id == p.id }
        store.save(portals.toList())
        status.remove(p.id)
        clients.remove(p.id)
        refreshAllPortals()
    }

    /** Verbindet ALLE Portale und legt sie zu einem gemeinsamen Katalog zusammen. */
    fun refreshAllPortals(force: Boolean = false) {
        forceRefresh = force
        refreshJob?.cancel()
        if (portals.isEmpty()) {
            client = null; portal = null
            homeNew = emptyList(); homeChannels = emptyList(); cachedChannels = null
            allLoading = false
            return
        }
        refreshJob = viewModelScope.launch {
            allLoading = true
            try {
                portals.toList().map { p -> async { connectOne(p) } }.awaitAll()
                buildMerged()
            } finally {
                allLoading = false
            }
        }
    }

    private suspend fun connectOne(p: Portal) {
        status[p.id] = "loading"
        try {
            val c = refreshSem.withPermit {
                withContext(Dispatchers.IO) {
                    val sc = StalkerClient(p)
                    sc.cacheDir = cacheRoot
                    sc.noCache = forceRefresh
                    sc.connect()
                    sc
                }
            }
            clients[p.id] = c
            status[p.id] = "ok"
        } catch (e: Exception) {
            clients.remove(p.id)
            status[p.id] = "err:" + (e.message ?: "Fehler")
            AppLog.add("Portal " + p.name + ": " + (e.message ?: "nicht erreichbar"))
        }
    }

    private fun buildMerged() {
        val parts = portals.mapNotNull { p -> clients[p.id]?.let { MultiPart(p.id.take(8), it, p.name) } }
        if (parts.isEmpty()) {
            client = null
            homeNew = emptyList(); homeChannels = emptyList()
            return
        }
        client = MultiClient(parts, dedupe)
        portal = Portal("all", "Alle Portale", "", "")
        epgCache.clear()
        linkCache.clear()
        cachedChannels = null
        liveCats = emptyList()
        homeNew = emptyList(); homeChannels = emptyList()
        refreshWatchIds()
        refreshSeen()
        loadHome()
    }

    /** Verbindet ein Portal im Hintergrund und lädt die Senderliste vor. */
    fun refreshPortal(p: Portal) {
        status[p.id] = "loading"
        viewModelScope.launch {
            try {
                val cache = refreshSem.withPermit {
                    withContext(Dispatchers.IO) {
                        val c = StalkerClient(p)
                        c.connect()
                        val ch = try { c.channels() } catch (e: Exception) { emptyList() }
                        PortalCache(c, System.currentTimeMillis(), ch)
                    }
                }
                caches[p.id] = cache
                status[p.id] = "ok:${cache.channels.size}"
            } catch (e: Exception) {
                caches.remove(p.id)
                status[p.id] = "err:" + (e.message ?: "Fehler")
            }
        }
    }

    fun openPortal(p: Portal) {
        val cache = caches[p.id]
        if (cache != null && System.currentTimeMillis() - cache.at < 10 * 60_000) {
            client = cache.client
            portal = p
            epgCache.clear()
            cachedChannels = cache.channels
            homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            loadHome()
            return
        }
        val c = StalkerClient(p)
        io({ c.connect() }) {
            client = c; portal = p; epgCache.clear()
            cachedChannels = null; homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            loadHome()
        }
    }

    // ---------- Durchsuchen ----------
    fun openBrowse(type: String, thenGuide: Boolean = false) {
        val c = client ?: return
        val p = portal ?: return
        io({
            val cats = c.categories(type)
            val ch: List<Item> = if (type == "itv") (cachedChannels ?: c.channels().also { cachedChannels = it }) else emptyList()
            cats to ch
        }) { (cats, ch) ->
            browseType = type; allChannels = ch; items = emptyList(); query = ""; queryText = ""
            favs = userData.favs(p.id, type)
            allCats = cats
            if (type == "itv") liveCats = cats
            portalGroups = (c as? MultiClient)?.groups(type) ?: emptyList()
            if (!expandedInit && portalGroups.isNotEmpty()) {
                expandedPortals = portalGroups.map { it.pfx }.toSet()
                expandedInit = true
                settings.edit().putStringSet("expanded", expandedPortals).apply()
            }
            hiddenCats = userData.hiddenCats(p.id, type)
            hiddenChans = userData.hiddenChans(p.id)
            hiddenItems = userData.hiddenItems(p.id, type)
            editMode = false
            applyCategories()
            push(Screen.Browse(type))
            selectCategory(if (groupedView && portalGroups.isNotEmpty()) "*" else (categories.firstOrNull { it.id != "fav" }?.id ?: "fav"))
            if (thenGuide) push(Screen.Guide)
        }
    }

    private fun channelOk(c: Item): Boolean = !(dedupe && c.dup)

    private fun visibleChannels(): List<Item> =
        allChannels.filter { it.id !in hiddenChans && it.cat !in hiddenCats && channelOk(it) }

    private fun listFor(id: String): List<Item> = when (id) {
        "fav" -> favs
        "*" -> visibleChannels()
        else -> if (id.startsWith("p:")) {
            val rest = id.removePrefix("p:")
            val pfx = rest.substringBefore(':')
            val key = rest.substringAfter(':')
            if (key == "fav") favs.filter { it.id.startsWith("$pfx|") }
            else allChannels.filter {
                it.id.startsWith("$pfx|") && (key == "*" || it.cat == key) && it.id !in hiddenChans
            }
        } else allChannels.filter { it.cat == id && it.id !in hiddenChans && channelOk(it) }
    }

    fun selectCategory(id: String) {
        selCat = id; gen++; query = ""; queryText = ""
        viewModelScope.launch { listState.scrollToItem(0); gridState.scrollToItem(0) }
        if (id.endsWith(":resume")) {
            items = emptyList(); hasMore = false
            resumePfx = id.removePrefix("p:").substringBefore(':')
            loadResumeShown()
        } else if (id == "fav" || id.endsWith(":fav") || browseType == "itv") {
            items = listFor(id); hasMore = false
        } else {
            items = emptyList(); hasMore = false; page = 0; loaded = 0
            loadMore()
        }
    }

    fun search(q: String) {
        val t = q.trim()
        if (browseType == "itv") {
            items = if (t.isEmpty()) listFor(selCat ?: "*")
            else visibleChannels().filter { it.name.contains(t, ignoreCase = true) }
            return
        }
        if (t == query) return
        query = t; gen++; page = 0; loaded = 0; items = emptyList(); hasMore = false
        if (t.isEmpty()) {
            categories.firstOrNull { it.id != "fav" }?.let { selectCategory(it.id) }
        } else {
            selCat = "*"
            loadMore()
        }
    }

    fun loadMore() {
        val c = client ?: return
        val cat = selCat ?: return
        if (browseType == "itv" || cat == "fav" || cat.endsWith(":fav") || cat.endsWith(":resume") || busyList) return
        val g = gen; val next = page + 1; val t = browseType; val qy = query
        busyList = true
        viewModelScope.launch {
            try {
                val pg = withContext(Dispatchers.IO) { c.list(t, cat, next, qy) }
                if (g == gen) {
                    page = next; loaded += pg.items.size; items = items + pg.items
                    hasMore = pg.items.isNotEmpty() &&
                        (if (pg.total > 0) loaded < pg.total else pg.items.size >= pg.pageSize)
                }
            } catch (e: Exception) {
                if (g == gen) { error = e.message ?: "Fehler"; hasMore = false; AppLog.add("Liste laden: " + e.message) }
            } finally {
                busyList = false
                if (g != gen) loadMore()
            }
        }
    }

    // ---------- Kategorien und Kanäle bearbeiten ----------
    private fun applyCategories() {
        categories = listOf(Category("fav", "★ Favoriten")) + allCats.filter { it.id !in hiddenCats }
    }

    private fun saveHiddenCats() { portal?.let { userData.saveHiddenCats(it.id, browseType, hiddenCats) } }
    private fun saveHiddenChans() { portal?.let { userData.saveHiddenChans(it.id, hiddenChans) } }

    fun toggleCat(id: String) {
        hiddenCats = if (id in hiddenCats) hiddenCats - id else hiddenCats + id
        saveHiddenCats(); applyCategories()
    }

    fun setAllCats(show: Boolean) {
        hiddenCats = if (show) emptySet() else allCats.map { it.id }.toSet()
        saveHiddenCats(); applyCategories()
    }

    private fun catMatches(title: String, kws: List<String>): Boolean {
        val tokens = title.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        return kws.any { k -> tokens.any { t -> t == k || (k.length >= 4 && t.startsWith(k)) } }
    }

    /** Zeigt nur Kategorien, in denen eines der Suchwörter als Wort vorkommt (z. B. DE, German). */
    fun showOnlyMatching(keywords: String) {
        val kws = keywords.lowercase().split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
        if (kws.isEmpty()) return
        val match = allCats.filter { catMatches(it.title, kws) }
        if (match.isEmpty()) { showNotice("Keine passende Kategorie gefunden"); return }
        var keep = match.map { it.id }.toSet()
        if (browseType == "itv") keep = keep + "*"
        hiddenCats = allCats.map { it.id }.filter { it !in keep }.toSet()
        saveHiddenCats(); applyCategories()
        showNotice("${match.size} Kategorien sichtbar")
    }

    fun openEditChannels() {
        editChans = when (selCat) {
            null, "fav", "*" -> allChannels.filter { it.cat !in hiddenCats }
            else -> allChannels.filter { it.cat == selCat }
        }
        push(Screen.EditChans)
    }

    fun toggleChan(id: String) {
        hiddenChans = if (id in hiddenChans) hiddenChans - id else hiddenChans + id
        saveHiddenChans()
    }

    fun setChansHidden(ids: List<String>, hide: Boolean) {
        hiddenChans = if (hide) hiddenChans + ids else hiddenChans - ids.toSet()
        saveHiddenChans()
    }

    // ---------- Filme und Serien ausblenden ----------
    fun toggleEditMode() { editMode = !editMode }

    /** Anzeige-Liste: im Ausblenden-Modus und bei Favoriten ungefiltert. */
    fun shownItems(): List<Item> =
        if (editMode || selCat == "fav" || selCat?.endsWith(":fav") == true) items else items.filter { it.id !in hiddenItems }

    fun toggleItemHidden(item: Item) {
        val p = portal ?: return
        val was = item.id in hiddenItems
        hiddenItems = if (was) hiddenItems - item.id else hiddenItems + item.id
        userData.saveHiddenItems(p.id, browseType, hiddenItems)
        showNotice(if (was) "Wieder eingeblendet" else "Ausgeblendet")
    }

    // ---------- Portal per Handy hinzufügen (QR-Code) ----------
    fun startPhoneAdd() {
        stopPhoneAdd()
        val ip = PortalServer.localIp()
        if (ip == null) {
            error = "Keine Netzwerkverbindung gefunden. Verbinde die Box mit dem WLAN oder LAN."
            return
        }
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val token = (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        val srv = PortalServer(token, onBackup = { exportBackup() }, onRestore = { importBackup(it) },
            onLog = { AppLog.text() }) { p ->
            viewModelScope.launch {
                savePortal(p)
                showNotice("Portal „${p.name}“ hinzugefügt")
            }
        }
        try {
            val port = srv.start()
            phoneServer = srv
            qrUrl = "http://$ip:$port/$token"
        } catch (e: Exception) {
            error = "Server konnte nicht gestartet werden: ${e.message}"
        }
    }

    fun stopPhoneAdd() {
        phoneServer?.stop()
        phoneServer = null
        qrUrl = null
    }

    override fun onCleared() {
        stopPhoneAdd()
        super.onCleared()
    }

    // ---------- Navigation über die Seitenleiste ----------
    fun goTo(id: String) {
        playUrl = null
        chanPanel = false
        while (stack.size > 1) stack.removeAt(stack.size - 1)
        editMode = false
        error = null
        when (id) {
            "portals" -> push(Screen.Portals)
            "itv", "vod", "series" -> openBrowse(id)
            "epg" -> openBrowse("itv", true)
            "fav" -> push(Screen.Favs)
            "watch" -> push(Screen.Watch)
            "settings" -> push(Screen.Settings)
        }
    }

    // ---------- Fernsehkomfort: letzter Sender, Nummern, Quelle, Sleep-Timer ----------
    var numberBuffer by mutableStateOf("")
    private var numberJob: Job? = null
    private var prevChId = ""
    var sleepMinutes by mutableStateOf(0)
    private var sleepJob: Job? = null
    var resumeLastOnStart by mutableStateOf(settings.getBoolean("resumeLast", false))
    private var startupResumeDone = false

    private fun nameKey(c: Item): String = c.name.trim().lowercase()

    /** Wechselt direkt zu einem Sender (Zahleneingabe, letzter Sender, Quellenwahl). */
    private fun switchTo(ch: Item) {
        if (zapList.none { it.id == ch.id }) zapList = listOf(ch)
        zapIndex = zapList.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        startLive()
    }

    fun toggleLast() {
        val prev = cachedChannels?.firstOrNull { it.id == prevChId }
        if (prev == null) {
            showNotice("Kein letzter Sender")
            return
        }
        switchTo(prev)
    }

    fun digit(d: Int) {
        if (numberBuffer.length >= 4) return
        numberBuffer += d.toString()
        numberJob?.cancel()
        numberJob = viewModelScope.launch {
            delay(1500)
            commitNumber()
        }
    }

    fun commitNumber() {
        numberJob?.cancel()
        val n = numberBuffer.toIntOrNull()
        numberBuffer = ""
        if (n == null) return
        if (n == 0) {
            toggleLast()
            return
        }
        val all = cachedChannels ?: return
        val hit = zapList.firstOrNull { it.num == n } ?: all.firstOrNull { it.num == n && !it.dup }
        if (hit == null) showNotice("Kein Sender mit Nummer $n") else switchTo(hit)
    }

    /** Alle Quellen (Portale) für den gerade laufenden Sender. */
    fun alternativesFor(id: String): List<Pair<String, Item>> {
        val all = cachedChannels ?: return emptyList()
        val cur = all.firstOrNull { it.id == id } ?: return emptyList()
        val key = nameKey(cur)
        return all.filter { nameKey(it) == key }.map { c ->
            val pfx = c.id.substringBefore('|')
            (portals.firstOrNull { it.id.take(8) == pfx }?.name ?: "Portal") to c
        }
    }

    fun sourceName(): String {
        val pfx = playChId.substringBefore('|')
        return portals.firstOrNull { it.id.take(8) == pfx }?.name ?: "-"
    }

    fun chooseSource(ch: Item) {
        settings.edit().putString("src:" + nameKey(ch), ch.id.substringBefore('|')).apply()
        showNotice("Quelle gemerkt")
        switchTo(ch)
    }

    fun cycleSleep() {
        sleepMinutes = when (sleepMinutes) {
            0 -> 30
            30 -> 60
            60 -> 90
            else -> 0
        }
        sleepJob?.cancel()
        if (sleepMinutes > 0) {
            val m = sleepMinutes
            showNotice("Sleep-Timer: $m Minuten")
            sleepJob = viewModelScope.launch {
                delay(m * 60_000L)
                sleepMinutes = 0
                showNotice("Sleep-Timer: Gute Nacht")
                goTo("home")
            }
        } else {
            showNotice("Sleep-Timer aus")
        }
    }

    fun toggleResumeLast() {
        resumeLastOnStart = !resumeLastOnStart
        settings.edit().putBoolean("resumeLast", resumeLastOnStart).apply()
    }

    // ---------- Serien: gesehen, nächste Folge, Intro, Weiterschauen ----------
    var seenKeys by mutableStateOf<Set<String>>(emptySet())
    var upNext by mutableStateOf<String?>(null)
    private var upNextJob: Job? = null
    private var currentSeason: Season? = null
    private var seriesName = ""

    var autoNext by mutableStateOf(settings.getBoolean("autoNext", true))
    var introSeconds by mutableStateOf(settings.getInt("introSec", 90))
    var autoSkipIntro by mutableStateOf(settings.getBoolean("autoIntro", false))

    val isEpisode: Boolean get() = !isLive && lastEp != null

    fun toggleAutoNext() {
        autoNext = !autoNext
        settings.edit().putBoolean("autoNext", autoNext).apply()
    }

    fun cycleIntro() {
        introSeconds = when (introSeconds) {
            60 -> 75
            75 -> 90
            90 -> 105
            105 -> 120
            else -> 60
        }
        settings.edit().putInt("introSec", introSeconds).apply()
    }

    fun toggleAutoIntro() {
        autoSkipIntro = !autoSkipIntro
        settings.edit().putBoolean("autoIntro", autoSkipIntro).apply()
    }

    private fun refreshSeen() { seenKeys = portal?.let { userData.seen(it.id) } ?: emptySet() }

    fun isSeen(se: Season, ep: Int): Boolean = ("${se.cmd}|$ep") in seenKeys

    private fun markSeen() {
        val p = portal ?: return
        if (isLive || lastEp == null) return
        userData.addSeen(p.id, "$lastCmd|$lastEp")
        refreshSeen()
    }

    private fun episodeTitle(se: Season, ep: Int): String {
        val head = if (seriesName.isNotEmpty()) "$seriesName – " else ""
        return head + se.name + " – Episode " + ep
    }

    fun playEpisode(se: Season, ep: Int) {
        currentSeason = se
        play("vod", episodeTitle(se, ep), se.cmd, ep)
    }

    /** Gespeicherter Fortschritt für diesen Film bzw. diese Serie (für den Weiter-Knopf). */
    fun resumeFor(item: Item): Resume? {
        val p = portal ?: return null
        val all = userData.resumes(p.id)
        return if (browseType == "series") all.firstOrNull { it.type == "series" && it.title.startsWith(item.name + " – ") }
        else all.firstOrNull { it.type != "series" && it.cmd == item.cmd }
    }

    fun startFresh(item: Item) {
        val p = portal
        if (p != null) resumeFor(item)?.let { userData.removeResume(p.id, it.key) }
        startItem(item)
    }

    /** Am Ende einer Wiedergabe: Fortschritt löschen, als gesehen markieren, nächste Folge anbieten. */
    fun onEnded() {
        clearResume()
        markSeen()
        if (!autoNext) return
        val se = currentSeason ?: return
        val ep = lastEp ?: return
        val i = se.episodes.indexOf(ep)
        var nextSeason = se
        var nextEp: Int? = se.episodes.getOrNull(i + 1)
        if (nextEp == null) {
            val si = seasons.indexOfFirst { it.cmd == se.cmd }
            val ns = if (si >= 0) seasons.getOrNull(si + 1) else null
            if (ns != null && ns.episodes.isNotEmpty()) {
                nextSeason = ns
                nextEp = ns.episodes.first()
            }
        }
        val ne = nextEp ?: return
        upNext = episodeTitle(nextSeason, ne)
        upNextJob?.cancel()
        upNextJob = viewModelScope.launch {
            delay(5000)
            upNext = null
            playEpisode(nextSeason, ne)
        }
    }

    fun cancelUpNext() {
        upNextJob?.cancel()
        upNext = null
    }

    // ---------- Sicherung ----------
    fun exportBackup(): String {
        val root = JSONObject()
        root.put("app", "TomsTV")
        root.put("v", 1)
        for (name in listOf("portals", "userdata", "settings")) {
            val sp = getApplication<Application>().getSharedPreferences(name, Context.MODE_PRIVATE)
            val o = JSONObject()
            for ((k, v) in sp.all) {
                val e = JSONObject()
                when (v) {
                    is String -> { e.put("t", "s"); e.put("v", v) }
                    is Boolean -> { e.put("t", "b"); e.put("v", v) }
                    is Int -> { e.put("t", "i"); e.put("v", v) }
                    is Long -> { e.put("t", "l"); e.put("v", v) }
                    is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                    is Set<*> -> { e.put("t", "set"); e.put("v", JSONArray(v.map { it.toString() })) }
                    else -> { }
                }
                if (e.has("t")) o.put(k, e)
            }
            root.put(name, o)
        }
        return root.toString()
    }

    fun importBackup(json: String): String {
        return try {
            val root = JSONObject(json)
            if (root.optString("app") != "TomsTV") return "Das ist keine Sicherung von Tom's TV."
            for (name in listOf("portals", "userdata", "settings")) {
                val o = root.optJSONObject(name) ?: continue
                val ed = getApplication<Application>().getSharedPreferences(name, Context.MODE_PRIVATE).edit()
                ed.clear()
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val e = o.getJSONObject(k)
                    when (e.optString("t")) {
                        "s" -> ed.putString(k, e.getString("v"))
                        "b" -> ed.putBoolean(k, e.getBoolean("v"))
                        "i" -> ed.putInt(k, e.getInt("v"))
                        "l" -> ed.putLong(k, e.getLong("v"))
                        "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                        "set" -> {
                            val a = e.getJSONArray("v")
                            ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                        }
                    }
                }
                ed.apply()
            }
            viewModelScope.launch {
                portals.clear()
                portals.addAll(store.load())
                refreshAllPortals(true)
                refreshSeen()
                refreshWatchIds()
            }
            "Wiederherstellung abgeschlossen. Starte die App neu, damit alle Einstellungen gelten."
        } catch (e: Exception) {
            "Fehler: " + (e.message ?: "ungültige Datei")
        }
    }

    // ---------- Merkliste (Filme und Serien) ----------
    fun watchFor(type: String): List<Item> = portal?.let { userData.favs(it.id, "w_$type") } ?: emptyList()

    private fun refreshWatchIds() {
        watchIds = (watchFor("vod").map { "vod:" + it.id } + watchFor("series").map { "series:" + it.id }).toSet()
    }

    fun isWatch(item: Item): Boolean = ("$browseType:${item.id}") in watchIds

    fun watchType(item: Item): String = if (("series:" + item.id) in watchIds) "series" else "vod"

    fun toggleWatch(item: Item) {
        val p = portal ?: return
        val t = browseType
        val cur = userData.favs(p.id, "w_$t")
        val was = cur.any { it.id == item.id }
        userData.saveFavs(p.id, "w_$t", if (was) cur.filterNot { it.id == item.id } else cur + item)
        refreshWatchIds()
        showNotice(if (was) "Aus der Merkliste entfernt" else "🔖 Zur Merkliste hinzugefügt")
    }

    fun openWatch(type: String, item: Item) {
        val p = portal ?: return
        browseType = type
        favs = userData.favs(p.id, type)
        push(Screen.Detail(item))
    }

    // ---------- Senderliste während Live-TV ----------
    fun openChannelPanel() {
        val c = client ?: return
        val p = portal ?: return
        if (cachedChannels == null || liveCats.isEmpty()) {
            showNotice("Senderliste wird geladen …")
            viewModelScope.launch {
                try {
                    val ch = cachedChannels ?: withContext(Dispatchers.IO) { c.channels() }
                    cachedChannels = ch
                    val cats = if (liveCats.isEmpty()) withContext(Dispatchers.IO) { c.categories("itv") } else liveCats
                    liveCats = cats
                } catch (e: Exception) {
                    error = "Senderliste nicht verfügbar: ${e.message}"
                    return@launch
                }
                showPanel(p)
            }
            return
        }
        showPanel(p)
    }

    private fun showPanel(p: Portal) {
        panelHiddenCats = userData.hiddenCats(p.id, "itv")
        panelHiddenChans = userData.hiddenChans(p.id)
        panelFavs = userData.favs(p.id, "itv")
        val visible = liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }.map { it.id }.toSet()
        panelGroups = (client as? MultiClient)?.groups("itv") ?: emptyList()
        val cur = cachedChannels?.firstOrNull { it.id == playChId }
        // Die Kategorie-Leiste zeigt die Liste, aus der der Sender gestartet wurde
        panelCat = liveContext.ifEmpty { "*" }
        val pfx = if (panelCat.startsWith("p:")) panelCat.removePrefix("p:").substringBefore(':')
                  else cur?.id?.substringBefore('|') ?: ""
        panelExpanded = expandedPortals + (if (pfx.isNotEmpty()) setOf(pfx) else emptySet())
        chanPanel = true
    }

    fun panelCategories(): List<Category> =
        listOf(Category("fav", "★ Favoriten"), Category("*", "Alle")) +
            liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }

    fun panelList(): List<Item> {
        val all = cachedChannels ?: return emptyList()
        return when {
            panelCat.startsWith("p:") -> {
                val rest = panelCat.removePrefix("p:")
                val pfx = rest.substringBefore(':')
                val key = rest.substringAfter(':')
                if (key == "fav") panelFavs.filter { it.id.startsWith("$pfx|") }
                else all.filter { it.id.startsWith("$pfx|") && (key == "*" || it.cat == key) && it.id !in panelHiddenChans }
            }
            panelCat == "fav" -> panelFavs
            panelCat == "*" -> all.filter { it.id !in panelHiddenChans && it.cat !in panelHiddenCats && channelOk(it) }
            else -> all.filter { it.cat == panelCat && it.id !in panelHiddenChans && channelOk(it) }
        }
    }

    var panelGroups by mutableStateOf<List<PortalGroup>>(emptyList())
    var panelExpanded by mutableStateOf<Set<String>>(emptySet())

    fun togglePanelGroup(pfx: String) {
        panelExpanded = if (pfx in panelExpanded) panelExpanded - pfx else panelExpanded + pfx
    }

    fun panelVisibleCats(g: PortalGroup): List<Category> = g.cats.filter { it.id !in panelHiddenCats }

    fun playFromPanel(ch: Item, list: List<Item>) {
        chanPanel = false
        liveContext = panelCat
        zapList = list
        zapIndex = list.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        if (ch.id == playChId) return
        startLive()
    }

    // ---------- Startseite ----------
    fun loadHome() {
        val c = client ?: return
        val p = portal ?: return
        resumeList = userData.resumes(p.id)
        val hiddenV = userData.hiddenItems(p.id, "vod")
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    var l = c.list("vod", "*", 1).items
                    if (l.isEmpty()) {
                        val first = c.categories("vod").firstOrNull { it.id != "*" }?.id
                        if (first != null) l = c.list("vod", first, 1).items
                    }
                    l
                }
                homeNew = list.filter { it.id !in hiddenV }.take(14)
            } catch (e: Exception) { }
            try {
                val ch = withContext(Dispatchers.IO) { cachedChannels ?: c.channels().also { cachedChannels = it } }
                val hc = userData.hiddenChans(p.id)
                val hcat = userData.hiddenCats(p.id, "itv")
                val favIds = userData.favs(p.id, "itv").map { it.id }.toSet()
                val vis = ch.filter { it.id !in hc && it.cat !in hcat && channelOk(it) }
                homeChannels = (vis.filter { it.id in favIds } + vis).distinctBy { it.id }.take(14)
                if (resumeLastOnStart && !startupResumeDone) {
                    startupResumeDone = true
                    val lastId = settings.getString("lastCh", null)
                    val lastCh = vis.firstOrNull { it.id == lastId } ?: ch.firstOrNull { it.id == lastId }
                    if (lastCh != null) {
                        liveContext = "*"
                        zapList = if (lastCh in vis) vis else listOf(lastCh)
                        zapIndex = zapList.indexOf(lastCh).coerceAtLeast(0)
                        startLive()
                    }
                }
            } catch (e: Exception) { }
            try {
                if (liveCats.isEmpty()) liveCats = withContext(Dispatchers.IO) { c.categories("itv") }
            } catch (e: Exception) { }
        }
    }

    fun openHomeItem(item: Item, type: String) {
        val p = portal ?: return
        browseType = type
        favs = userData.favs(p.id, type)
        if (type == "itv") {
            liveContext = "*"
            zapList = homeChannels
            zapIndex = homeChannels.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    fun favsFor(type: String): List<Item> = portal?.let { userData.favs(it.id, type) } ?: emptyList()

    fun openFavorite(type: String, item: Item) {
        val list = favsFor(type)
        browseType = type
        favs = list
        if (type == "itv") {
            liveContext = "fav"
            zapList = list
            zapIndex = list.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    // ---------- Favoriten ----------
    fun isFav(item: Item): Boolean = favs.any { it.id == item.id }

    fun toggleFav(item: Item) {
        val p = portal ?: return
        val was = isFav(item)
        favs = if (was) favs.filterNot { it.id == item.id } else favs + item
        userData.saveFavs(p.id, browseType, favs)
        showNotice(if (was) "Aus Favoriten entfernt" else "★ Zu Favoriten hinzugefügt")
        if (selCat == "fav") items = favs
    }

    // ---------- Weiterschauen ----------
    fun openResumes() {
        resumeList = portal?.let { userData.resumes(it.id) } ?: emptyList()
        push(Screen.ResumeList)
    }

    fun resumePos(): Long =
        portal?.let { p -> userData.resumes(p.id).firstOrNull { it.key == resumeKey }?.pos } ?: 0L

    fun savePosition(pos: Long, dur: Long) {
        val p = portal ?: return
        if (isLive || resumeKey.isEmpty()) return
        if (dur > 0 && pos > dur * 9 / 10) markSeen()
        if (pos < 15_000 || (dur > 0 && pos > dur - 60_000)) userData.removeResume(p.id, resumeKey)
        else userData.putResume(p.id, Resume(resumeKey, playTitle, lastCmd, lastEp, pos, resumeLogo, dur.coerceAtLeast(0L), browseType,
            currentSeason?.episodes?.joinToString(",") ?: "", currentSeason?.name ?: ""))
    }

    fun clearResume() { portal?.let { userData.removeResume(it.id, resumeKey) } }

    // ---------- Abspielen ----------
    /** Live-Sender starten direkt, Filme und Serien öffnen zuerst die Detailseite. */
    fun openItem(item: Item) {
        if (editMode && browseType != "itv") { toggleItemHidden(item); return }
        if (browseType == "itv") startItem(item) else push(Screen.Detail(item))
    }

    fun startItem(item: Item) {
        val c = client ?: return
        resumeLogo = item.logo
        if (browseType == "series") seriesName = item.name
        when {
            browseType == "series" -> io({ c.seasons(item.id) }) { seasons = it; push(Screen.Seasons(item.name)) }
            item.episodes.isNotEmpty() -> push(Screen.Episodes(Season(item.name, item.cmd, item.episodes)))
            browseType == "itv" -> {
                liveContext = selCat ?: "*"; zapList = items; zapIndex = items.indexOf(item).coerceAtLeast(0); startLive()
            }
            else -> play("vod", item.name, item.cmd, null)
        }
    }

    fun openSeason(s: Season) {
        if (s.episodes.isEmpty()) play("vod", s.name, s.cmd, null) else push(Screen.Episodes(s))
    }

    fun play(kind: String, title: String, cmd: String, ep: Int?) {
        val c = client ?: return
        stopPreview()
        if (!reloading) hdrMode = 0
        reloading = false
        lastKind = kind; lastCmd = cmd; lastEp = ep; playTitle = title; isLive = kind == "itv"
        if (kind != "itv") playLogo = null
        resumeKey = "$kind|$cmd|${ep ?: 0}"
        val g = ++playGen
        val hit = if (kind == "itv") linkCache.remove(cmd) else null
        if (hit != null && System.currentTimeMillis() - hit.second < 45_000) {
            playUrl = hit.first
            playNonce++
            if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
            prefetchNeighbors()
            return
        }
        io({ c.link(kind, cmd, ep) }) { url ->
            if (g == playGen) {
                playUrl = url
                playNonce++
                if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
                prefetchNeighbors()
            }
        }
    }

    private fun startLive() {
        var ch = zapList.getOrNull(zapIndex) ?: return
        // Bevorzugte Quelle (Portal) für diesen Sender anwenden
        val pref = settings.getString("src:" + nameKey(ch), null)
        if (pref != null && !ch.id.startsWith("$pref|")) {
            cachedChannels?.firstOrNull { nameKey(it) == nameKey(ch) && it.id.startsWith("$pref|") }?.let { ch = it }
        }
        triedIds.clear()
        if (playChId.isNotEmpty() && playChId != ch.id) prevChId = playChId
        playChId = ch.id
        playLogo = ch.logo
        settings.edit().putString("lastCh", ch.id).apply()
        play("itv", ch.name, ch.cmd, null)
    }

    fun zap(delta: Int) {
        if (zapList.isEmpty()) return
        zapIndex = (zapIndex + delta + zapList.size) % zapList.size
        startLive()
    }

    // ---------- EPG ----------
    private class EpgEntry(val at: Long, val list: List<Epg>, val size: Int)
    private val epgCache = mutableStateMapOf<String, EpgEntry>()
    private val epgBusy = HashSet<String>()
    private val epgSem = Semaphore(3)

    fun epgList(id: String): List<Epg> {
        return epgCache[id]?.list ?: emptyList()
    }

    fun currentEpg(id: String): Epg? {
        val l = epgList(id)
        val now = System.currentTimeMillis() / 1000
        return l.firstOrNull { it.startTs <= now && now < it.stopTs } ?: l.firstOrNull()
    }

    fun epgProgress(e: Epg): Float? {
        if (e.startTs <= 0 || e.stopTs <= e.startTs) return null
        val now = System.currentTimeMillis() / 1000
        return ((now - e.startTs).toFloat() / (e.stopTs - e.startTs)).coerceIn(0f, 1f)
    }

    fun loadEpg(id: String, size: Int = 5) {
        val c = client ?: return
        val old = epgCache[id]
        val fresh = old != null && old.size >= size && System.currentTimeMillis() - old.at < 180_000
        if (id.isEmpty() || id in epgBusy || fresh) return
        epgBusy.add(id)
        viewModelScope.launch {
            val list = try {
                epgSem.withPermit { withContext(Dispatchers.IO) { c.epg(id, size) } }
            } catch (e: Exception) { emptyList() }
            epgCache[id] = EpgEntry(System.currentTimeMillis(), list, size)
            epgBusy.remove(id)
            epgTick++
        }
    }

    /** Holt die Links der beiden Nachbarsender im Voraus, damit das Umschalten sofort geht. */
    private fun prefetchNeighbors() {
        if (!isLive || zapList.size < 2) return
        val c = client ?: return
        for (d in listOf(1, -1)) {
            val ch = zapList[(zapIndex + d + zapList.size) % zapList.size]
            val cached = linkCache[ch.cmd]
            if ((cached != null && System.currentTimeMillis() - cached.second < 45_000) || ch.cmd in prefetching) continue
            prefetching.add(ch.cmd)
            viewModelScope.launch {
                try {
                    val url = withContext(Dispatchers.IO) { c.link("itv", ch.cmd, null) }
                    if (linkCache.size > 16) linkCache.clear()
                    linkCache[ch.cmd] = url to System.currentTimeMillis()
                } catch (e: Exception) { }
                prefetching.remove(ch.cmd)
            }
        }
    }

    /** Fällt ein Sender aus, versucht die App denselben Sender bei einem anderen Portal. */
    fun tryAlternate(): Boolean {
        val all = cachedChannels ?: return false
        val cur = all.firstOrNull { it.id == playChId } ?: return false
        val key = cur.name.trim().lowercase()
        triedIds.add(cur.id)
        val alt = all.firstOrNull { it.id !in triedIds && it.name.trim().lowercase() == key } ?: return false
        playChId = alt.id
        playLogo = alt.logo
        showNotice("Wechsle zu einer anderen Quelle …")
        play("itv", alt.name, alt.cmd, null)
        return true
    }

    /** Fordert einen frischen Stream-Link an (bei Aussetzern/Hängern). */
    fun reload() {
        reloading = true
        play(lastKind, playTitle, lastCmd, lastEp)
    }

    // ---------- Stream-Anfrage: Stufen bei "bad http status" ----------
    fun streamHeaders(): Map<String, String> {
        val c = client ?: return emptyMap()
        return when (hdrMode) {
            0 -> c.streamHeadersFor(lastCmd, false)
            1 -> c.streamHeadersFor(lastCmd, true)
            else -> emptyMap()
        }
    }

    fun streamUserAgent(): String = when (hdrMode) {
        2 -> "Lavf/58.76.100"
        3 -> "VLC/3.0.20 LibVLC/3.0.20"
        else -> UA
    }

    fun nextHeaderMode(): Boolean {
        if (hdrMode >= 3) return false
        hdrMode++
        return true
    }

    fun headerStage(): Int = hdrMode

    // ---------- App-Update ----------
    fun checkUpdate(silent: Boolean = false) {
        if (!silent) { updateMsg = "Suche nach Updates …"; updateInfo = null }
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Updater.latest() }
                when {
                    info == null -> if (!silent) updateMsg = "Kein Update gefunden"
                    info.number > BuildConfig.RUN_NUMBER -> {
                        updateInfo = info
                        updateMsg = "Neue Version ${info.tag} verfügbar"
                        if (silent) updatePrompt = info
                    }
                    else -> if (!silent) updateMsg = "Du hast die neueste Version (v${BuildConfig.RUN_NUMBER})"
                }
            } catch (e: Exception) {
                if (!silent) updateMsg = "Fehler: ${e.message}"
            }
        }
    }

    fun installUpdate() {
        val info = updateInfo ?: return
        val app = getApplication<Application>()
        updateProgress = 0
        updateMsg = "Lade ${info.tag} herunter …"
        showNotice("Update wird geladen …")
        viewModelScope.launch {
            try {
                val apk = withContext(Dispatchers.IO) { Updater.download(app, info.url) { p -> updateProgress = p } }
                updateProgress = -1
                val started = Updater.install(app, apk)
                updateMsg = if (started) "Installation gestartet. Folge den Anweisungen des Systems."
                else "Erlaube Tom's TV in den Einstellungen, Apps zu installieren, und tippe dann erneut auf Jetzt installieren."
            } catch (e: Exception) {
                updateProgress = -1
                updateMsg = "Update nicht möglich: ${e.message}"
            }
        }
    }

    init {
        checkUpdate(silent = true)
        refreshAllPortals()
    }
}
