package com.example.portaltv

import android.app.Application
import android.content.Context
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Portals : Screen
    data class Form(val edit: Portal?) : Screen
    data object Home : Screen
    data class Browse(val type: String) : Screen
    data class Seasons(val title: String) : Screen
    data class Episodes(val season: Season) : Screen
    data object ResumeList : Screen
    data object Watchlist : Screen
    data object Guide : Screen
    data object EditCats : Screen
    data object EditChans : Screen
    data object Play : Screen
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = PortalStore(app)
    private val userData = UserData(app)
    private val settings = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var textColorName by mutableStateOf(settings.getString("textColor", "Weiß") ?: "Weiß")

    fun setTextColor(name: String) {
        textColorName = name
        settings.edit().putString("textColor", name).apply()
    }
    val portals = mutableStateListOf<Portal>().apply { addAll(store.load()) }
    val stack = mutableStateListOf<Screen>(Screen.Portals)
    var portal by mutableStateOf<Portal?>(null)
    private var client: StalkerClient? = null

    var loading by mutableStateOf(false)
    var busyList by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)

    var categories by mutableStateOf<List<Category>>(emptyList())
    var selCat by mutableStateOf<String?>(null)
    var items by mutableStateOf<List<Item>>(emptyList())
    var hasMore by mutableStateOf(false)
    var seasons by mutableStateOf<List<Season>>(emptyList())
    var favs by mutableStateOf<List<Item>>(emptyList())
    var allCats by mutableStateOf<List<Category>>(emptyList())
    var hiddenCats by mutableStateOf<Set<String>>(emptySet())
    var hiddenChans by mutableStateOf<Set<String>>(emptySet())
    var editChans by mutableStateOf<List<Item>>(emptyList())
    var hiddenItems by mutableStateOf<Set<String>>(emptySet())
    var editMode by mutableStateOf(false)
    var updateInfo by mutableStateOf<Updater.Info?>(null)
    var updateMsg by mutableStateOf<String?>(null)
    var updateProgress by mutableIntStateOf(-1)
    var resumeList by mutableStateOf<List<Resume>>(emptyList())
    var watchlist by mutableStateOf<List<WatchEntry>>(emptyList())
    var queryText by mutableStateOf("")
    var playUrl by mutableStateOf<String?>(null)
    var playTitle by mutableStateOf("")
    var isLive by mutableStateOf(false)
    var playChId by mutableStateOf("")
    var epgTick by mutableIntStateOf(0)

    val listState = LazyListState()
    val gridState = LazyGridState()

    private var allChannels = emptyList<Item>()
    private var page = 0
    private var loaded = 0
    private var gen = 0
    private var query = ""
    private var browseType = "itv"
    private var zapList = emptyList<Item>()
    private var zapIndex = 0
    private var lastKind = "itv"
    private var lastCmd = ""
    private var lastEp: Int? = null
    private var resumeKey = ""
    private var noticeJob: Job? = null

    private fun <T> io(block: () -> T, ok: (T) -> Unit) {
        loading = true; error = null
        viewModelScope.launch {
            try { ok(withContext(Dispatchers.IO) { block() }) }
            catch (e: Exception) { error = e.message ?: e.javaClass.simpleName }
            finally { loading = false }
        }
    }

    fun showNotice(msg: String) {
        notice = msg
        noticeJob?.cancel()
        noticeJob = viewModelScope.launch { delay(2500); notice = null }
    }

    fun push(s: Screen) { stack.add(s) }

    fun back(): Boolean {
        if (stack.size <= 1) return false
        val top = stack.last()
        if (top is Screen.Play) playUrl = null
        if (top is Screen.Browse) editMode = false
        stack.removeAt(stack.size - 1)
        error = null
        if (top is Screen.EditCats || top is Screen.EditChans) refreshAfterEdit()
        return true
    }

    private fun refreshAfterEdit() {
        val valid = categories.any { it.id == selCat }
        selectCategory(if (valid) selCat!! else categories.firstOrNull { it.id != "fav" }?.id ?: "fav")
    }

    // ---------- Portale ----------
    fun savePortal(p: Portal) {
        val i = portals.indexOfFirst { it.id == p.id }
        if (i >= 0) portals[i] = p else portals.add(p)
        store.save(portals.toList())
    }

    fun deletePortal(p: Portal) {
        portals.removeAll { it.id == p.id }
        store.save(portals.toList())
    }

    fun openPortal(p: Portal) {
        val c = StalkerClient(p)
        io({ c.connect() }) { client = c; portal = p; epgCache.clear(); watchlist = userData.watchlist(p.id); push(Screen.Home) }
    }

    // ---------- Durchsuchen ----------
    fun openBrowse(type: String) {
        val c = client ?: return
        val p = portal ?: return
        io({
            val cats = c.categories(type)
            val ch: List<Item> = if (type == "itv") c.channels() else emptyList()
            cats to ch
        }) { (cats, ch) ->
            browseType = type; allChannels = ch; items = emptyList(); query = ""; queryText = ""
            favs = userData.favs(p.id, type)
            allCats = cats
            hiddenCats = userData.hiddenCats(p.id, type)
            hiddenChans = userData.hiddenChans(p.id)
            hiddenItems = userData.hiddenItems(p.id, type)
            editMode = false
            applyCategories()
            push(Screen.Browse(type))
            selectCategory(categories.firstOrNull { it.id != "fav" }?.id ?: "fav")
        }
    }

    private fun visibleChannels(): List<Item> =
        allChannels.filter { it.id !in hiddenChans && it.cat !in hiddenCats }

    private fun listFor(id: String): List<Item> = when (id) {
        "fav" -> favs
        "*" -> visibleChannels()
        else -> allChannels.filter { it.cat == id && it.id !in hiddenChans }
    }

    fun selectCategory(id: String) {
        selCat = id; gen++; query = ""; queryText = ""
        viewModelScope.launch { listState.scrollToItem(0); gridState.scrollToItem(0) }
        if (id == "fav" || browseType == "itv") {
            items = listFor(id); hasMore = false
        } else {
            items = emptyList(); hasMore = false; page = 0; loaded = 0
            loadMore()
        }
    }

    fun search(q: String) {
        val t = q.trim()
        if (browseType == "itv") {
            items = if (t.isEmpty()) listFor(selCat ?: "*")
            else visibleChannels().filter { it.name.contains(t, ignoreCase = true) }
            return
        }
        if (t == query) return
        query = t; gen++; page = 0; loaded = 0; items = emptyList(); hasMore = false
        if (t.isEmpty()) {
            categories.firstOrNull { it.id != "fav" }?.let { selectCategory(it.id) }
        } else {
            selCat = "*"
            loadMore()
        }
    }

    fun loadMore() {
        val c = client ?: return
        val cat = selCat ?: return
        if (browseType == "itv" || cat == "fav" || busyList) return
        val g = gen; val next = page + 1; val t = browseType; val qy = query
        busyList = true
        viewModelScope.launch {
            try {
                val pg = withContext(Dispatchers.IO) { c.list(t, cat, next, qy) }
                if (g == gen) {
                    page = next; loaded += pg.items.size; items = items + pg.items
                    hasMore = pg.items.isNotEmpty() &&
                        (if (pg.total > 0) loaded < pg.total else pg.items.size >= pg.pageSize)
                }
            } catch (e: Exception) {
                if (g == gen) { error = e.message ?: "Fehler"; hasMore = false }
            } finally {
                busyList = false
                if (g != gen) loadMore()
            }
        }
    }

    // ---------- Kategorien und Kanäle bearbeiten ----------
    private fun applyCategories() {
        categories = listOf(Category("fav", "★ Favoriten")) + allCats.filter { it.id !in hiddenCats }
    }

    private fun saveHiddenCats() { portal?.let { userData.saveHiddenCats(it.id, browseType, hiddenCats) } }
    private fun saveHiddenChans() { portal?.let { userData.saveHiddenChans(it.id, hiddenChans) } }

    fun toggleCat(id: String) {
        hiddenCats = if (id in hiddenCats) hiddenCats - id else hiddenCats + id
        saveHiddenCats(); applyCategories()
    }

    fun setAllCats(show: Boolean) {
        hiddenCats = if (show) emptySet() else allCats.map { it.id }.toSet()
        saveHiddenCats(); applyCategories()
    }

    private fun catMatches(title: String, kws: List<String>): Boolean {
        val tokens = title.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        return kws.any { k -> tokens.any { t -> t == k || (k.length >= 4 && t.startsWith(k)) } }
    }

    /** Zeigt nur Kategorien, in denen eines der Suchwörter als Wort vorkommt (z. B. DE, German). */
    fun showOnlyMatching(keywords: String) {
        val kws = keywords.lowercase().split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
        if (kws.isEmpty()) return
        val match = allCats.filter { catMatches(it.title, kws) }
        if (match.isEmpty()) { showNotice("Keine passende Kategorie gefunden"); return }
        var keep = match.map { it.id }.toSet()
        if (browseType == "itv") keep = keep + "*"
        hiddenCats = allCats.map { it.id }.filter { it !in keep }.toSet()
        saveHiddenCats(); applyCategories()
        showNotice("${match.size} Kategorien sichtbar")
    }

    fun openEditChannels() {
        editChans = when (selCat) {
            null, "fav", "*" -> allChannels.filter { it.cat !in hiddenCats }
            else -> allChannels.filter { it.cat == selCat }
        }
        push(Screen.EditChans)
    }

    fun toggleChan(id: String) {
        hiddenChans = if (id in hiddenChans) hiddenChans - id else hiddenChans + id
        saveHiddenChans()
    }

    fun setChansHidden(ids: List<String>, hide: Boolean) {
        hiddenChans = if (hide) hiddenChans + ids else hiddenChans - ids.toSet()
        saveHiddenChans()
    }

    // ---------- Filme und Serien ausblenden ----------
    fun toggleEditMode() { editMode = !editMode }

    /** Anzeige-Liste: im Ausblenden-Modus und bei Favoriten ungefiltert. */
    fun shownItems(): List<Item> =
        if (editMode || selCat == "fav") items else items.filter { it.id !in hiddenItems }

    fun toggleItemHidden(item: Item) {
        val p = portal ?: return
        val was = item.id in hiddenItems
        hiddenItems = if (was) hiddenItems - item.id else hiddenItems + item.id
        userData.saveHiddenItems(p.id, browseType, hiddenItems)
        showNotice(if (was) "Wieder eingeblendet" else "Ausgeblendet")
    }

    // ---------- Favoriten ----------
    fun isSeriesScreen(): Boolean = browseType == "series"

    fun isFav(item: Item): Boolean = favs.any { it.id == item.id }

    fun toggleFav(item: Item) {
        val p = portal ?: return
        val was = isFav(item)
        favs = if (was) favs.filterNot { it.id == item.id } else favs + item
        userData.saveFavs(p.id, browseType, favs)
        showNotice(if (was) "Aus Favoriten entfernt" else "★ Zu Favoriten hinzugefügt")
        if (selCat == "fav") items = favs
    }

    // ---------- Watchlist für Filme und Serien ----------
    fun isInWatchlist(item: Item, type: String = browseType): Boolean =
        watchlist.any { it.type == type && it.item.id == item.id }

    fun toggleWatchlist(item: Item, type: String = browseType) {
        val p = portal ?: return
        val wasSaved = isInWatchlist(item, type)
        watchlist = if (wasSaved) watchlist.filterNot { it.type == type && it.item.id == item.id }
            else watchlist + WatchEntry(type, item)
        userData.saveWatchlist(p.id, watchlist)
        showNotice(if (wasSaved) "Aus Watchlist entfernt" else "Zur Watchlist hinzugefügt")
    }

    fun openWatchlist() {
        watchlist = portal?.let { userData.watchlist(it.id) } ?: emptyList()
        push(Screen.Watchlist)
    }

    fun openWatchEntry(entry: WatchEntry) {
        browseType = entry.type
        editMode = false
        openItem(entry.item)
    }

    // ---------- Weiterschauen ----------
    fun openResumes() {
        resumeList = portal?.let { userData.resumes(it.id) } ?: emptyList()
        push(Screen.ResumeList)
    }

    fun resumePos(): Long =
        portal?.let { p -> userData.resumes(p.id).firstOrNull { it.key == resumeKey }?.pos } ?: 0L

    fun savePosition(pos: Long, dur: Long) {
        val p = portal ?: return
        if (isLive || resumeKey.isEmpty()) return
        if (pos < 15_000 || (dur > 0 && pos > dur - 60_000)) userData.removeResume(p.id, resumeKey)
        else userData.putResume(p.id, Resume(resumeKey, playTitle, lastCmd, lastEp, pos))
    }

    fun clearResume() { portal?.let { userData.removeResume(it.id, resumeKey) } }

    // ---------- Abspielen ----------
    fun openItem(item: Item) {
        val c = client ?: return
        if (editMode && browseType != "itv") { toggleItemHidden(item); return }
        when {
            browseType == "series" -> io({ c.seasons(item.id) }) { seasons = it; push(Screen.Seasons(item.name)) }
            item.episodes.isNotEmpty() -> push(Screen.Episodes(Season(item.name, item.cmd, item.episodes)))
            browseType == "itv" -> {
                zapList = items; zapIndex = items.indexOf(item).coerceAtLeast(0); startLive()
            }
            else -> play("vod", item.name, item.cmd, null)
        }
    }

    fun openSeason(s: Season) {
        if (s.episodes.isEmpty()) play("vod", s.name, s.cmd, null) else push(Screen.Episodes(s))
    }

    fun play(kind: String, title: String, cmd: String, ep: Int?) {
        val c = client ?: return
        lastKind = kind; lastCmd = cmd; lastEp = ep; playTitle = title; isLive = kind == "itv"
        resumeKey = "$kind|$cmd|${ep ?: 0}"
        io({ c.link(kind, cmd, ep) }) { url ->
            playUrl = url
            if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
        }
    }

    private fun startLive() {
        val ch = zapList.getOrNull(zapIndex) ?: return
        playChId = ch.id
        play("itv", ch.name, ch.cmd, null)
    }

    /** Aktuelle Senderliste für den Schnellzugriff im laufenden Live-TV. */
    val liveChannels: List<Item> get() = zapList
    val currentLiveIndex: Int get() = zapIndex

    fun selectLiveChannel(index: Int) {
        if (index !in zapList.indices) return
        zapIndex = index
        startLive()
    }

    fun zap(delta: Int) {
        if (zapList.isEmpty()) return
        zapIndex = (zapIndex + delta + zapList.size) % zapList.size
        startLive()
    }

    // ---------- EPG ----------
    private class EpgEntry(val at: Long, val list: List<Epg>, val size: Int)
    private val epgCache = HashMap<String, EpgEntry>()
    private val epgBusy = HashSet<String>()
    private val epgSem = Semaphore(3)

    fun epgList(id: String): List<Epg> {
        if (epgTick < 0) return emptyList()   // liest den State, damit die UI sich aktualisiert
        return epgCache[id]?.list ?: emptyList()
    }

    fun currentEpg(id: String): Epg? {
        val l = epgList(id)
        val now = System.currentTimeMillis() / 1000
        return l.firstOrNull { it.startTs <= now && now < it.stopTs } ?: l.firstOrNull()
    }

    fun epgProgress(e: Epg): Float? {
        if (e.startTs <= 0 || e.stopTs <= e.startTs) return null
        val now = System.currentTimeMillis() / 1000
        return ((now - e.startTs).toFloat() / (e.stopTs - e.startTs)).coerceIn(0f, 1f)
    }

    fun loadEpg(id: String, size: Int = 5) {
        val c = client ?: return
        val old = epgCache[id]
        val fresh = old != null && old.size >= size && System.currentTimeMillis() - old.at < 180_000
        if (id.isEmpty() || id in epgBusy || fresh) return
        epgBusy.add(id)
        viewModelScope.launch {
            val list = try {
                epgSem.withPermit { withContext(Dispatchers.IO) { c.epg(id, size) } }
            } catch (e: Exception) { emptyList() }
            epgCache[id] = EpgEntry(System.currentTimeMillis(), list, size)
            epgBusy.remove(id)
            epgTick++
        }
    }

    /** Fordert einen frischen Stream-Link an (bei Aussetzern/Hängern). */
    fun reload() { play(lastKind, playTitle, lastCmd, lastEp) }

    // ---------- App-Update ----------
    fun checkUpdate(silent: Boolean = false) {
        if (!silent) { updateMsg = "Suche nach Updates …"; updateInfo = null }
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Updater.latest() }
                when {
                    info == null -> if (!silent) updateMsg = "Kein Update gefunden"
                    info.number > BuildConfig.RUN_NUMBER -> {
                        updateInfo = info
                        updateMsg = "Neue Version ${info.tag} verfügbar"
                        if (silent) showNotice("Update ${info.tag} verfügbar (unten auf der Startseite)")
                    }
                    else -> if (!silent) updateMsg = "Du hast die neueste Version (v${BuildConfig.RUN_NUMBER})"
                }
            } catch (e: Exception) {
                if (!silent) updateMsg = "Fehler: ${e.message}"
            }
        }
    }

    fun installUpdate() {
        val info = updateInfo ?: return
        val app = getApplication<Application>()
        updateProgress = 0
        updateMsg = "Lade ${info.tag} herunter …"
        viewModelScope.launch {
            try {
                val apk = withContext(Dispatchers.IO) { Updater.download(app, info.url) { p -> updateProgress = p } }
                updateProgress = -1
                val started = Updater.install(app, apk)
                updateMsg = if (started) "Installation gestartet. Folge den Anweisungen des Systems."
                else "Erlaube Tom's TV in den Einstellungen, Apps zu installieren, und tippe dann erneut auf Jetzt installieren."
            } catch (e: Exception) {
                updateProgress = -1
                updateMsg = "Update nicht möglich: ${e.message}"
            }
        }
    }

    init { checkUpdate(silent = true) }
}
