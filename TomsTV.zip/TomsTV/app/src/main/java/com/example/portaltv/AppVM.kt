// ViewModel
class AppVM {}