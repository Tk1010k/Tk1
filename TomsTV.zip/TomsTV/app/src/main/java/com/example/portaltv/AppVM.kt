package com.example.portaltv

import android.app.Application
import android.content.Context
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Portals : Screen
    data class Form(val edit: Portal?) : Screen
    data object Home : Screen
    data class Browse(val type: String) : Screen
    data class Seasons(val title: String) : Screen
    data class Episodes(val season: Season) : Screen
    data object ResumeList : Screen
    data object Guide : Screen
    data object Favs : Screen
    data object Settings : Screen
    data object PhoneAdd : Screen
    data object Watch : Screen
    data object AppSettings : Screen
    data object EditCats : Screen
    data object EditChans : Screen
    data class Detail(val item: Item) : Screen
    data object Play : Screen
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = PortalStore(app)
    private val userData = UserData(app)
    private val settings = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var textColorName by mutableStateOf(settings.getString("textColor", "Weiß") ?: "Weiß")

    fun setTextColor(name: String) {
        textColorName = name
        settings.edit().putString("textColor", name).apply()
    }

    var accentName by mutableStateOf(settings.getString("accent", "Rot") ?: "Rot")

    fun setAccent(name: String) {
        accentName = name
        settings.edit().putString("accent", name).apply()
    }

    var sidebarMode by mutableStateOf(settings.getString("sidebar", "auto") ?: "auto")

    fun cycleSidebar() {
        sidebarMode = when (sidebarMode) { "auto" -> "compact"; "compact" -> "normal"; else -> "auto" }
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    /** "max": Bild und Ton so, wie das Portal sie sendet. "auto": an den Bildschirm angepasst. */
    var qualityMode by mutableStateOf(settings.getString("quality", "max") ?: "max")

    fun cycleQuality() {
        qualityMode = if (qualityMode == "max") "auto" else "max"
        settings.edit().putString("quality", qualityMode).apply()
    }

    var dedupe by mutableStateOf(settings.getBoolean("dedupe", true))

    fun toggleDedupe() {
        dedupe = !dedupe
        settings.edit().putBoolean("dedupe", dedupe).apply()
        refreshAllPortals()
    }

    // Aufklappbare Portal-Gruppen und seitliches Einklappen
    var portalGroups by mutableStateOf<List<PortalGroup>>(emptyList())
    var expandedPortals by mutableStateOf<Set<String>>(emptySet())
    var groupedView by mutableStateOf(settings.getBoolean("grouped", true))
    var catPaneOpen by mutableStateOf(settings.getBoolean("catPane", true))

    fun toggleGroup(pfx: String) {
        expandedPortals = if (pfx in expandedPortals) expandedPortals - pfx else expandedPortals + pfx
    }

    fun toggleGrouped() {
        groupedView = !groupedView
        settings.edit().putBoolean("grouped", groupedView).apply()
    }

    fun toggleCatPane() {
        catPaneOpen = !catPaneOpen
        settings.edit().putBoolean("catPane", catPaneOpen).apply()
    }

    fun setSidebar(mode: String) {
        sidebarMode = mode
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    fun toggleWatchOf(item: Item, type: String) {
        browseType = type
        toggleWatch(item)
    }
    val portals = mutableStateListOf<Portal>().apply { addAll(store.load()) }
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var portal by mutableStateOf<Portal?>(null)
    private var client: StalkerClient? = null

    var loading by mutableStateOf(false)
    var busyList by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)

    var categories by mutableStateOf<List<Category>>(emptyList())
    var selCat by mutableStateOf<String?>(null)
    var items by mutableStateOf<List<Item>>(emptyList())
    var hasMore by mutableStateOf(false)
    var seasons by mutableStateOf<List<Season>>(emptyList())
    var favs by mutableStateOf<List<Item>>(emptyList())
    var allCats by mutableStateOf<List<Category>>(emptyList())
    var hiddenCats by mutableStateOf<Set<String>>(emptySet())
    var hiddenChans by mutableStateOf<Set<String>>(emptySet())
    var editChans by mutableStateOf<List<Item>>(emptyList())
    var hiddenItems by mutableStateOf<Set<String>>(emptySet())
    var editMode by mutableStateOf(false)
    var introDone by mutableStateOf(false)
    var qrUrl by mutableStateOf<String?>(null)
    var chanPanel by mutableStateOf(false)
    var panelCat by mutableStateOf("*")
    var watchIds by mutableStateOf<Set<String>>(emptySet())
    private var liveCats: List<Category> = emptyList()
    private var panelHiddenCats: Set<String> = emptySet()
    private var panelHiddenChans: Set<String> = emptySet()
    private var panelFavs: List<Item> = emptyList()
    private var phoneServer: PortalServer? = null
    var homeNew by mutableStateOf<List<Item>>(emptyList())
    var homeChannels by mutableStateOf<List<Item>>(emptyList())
    private var cachedChannels: List<Item>? = null

    // Hintergrund-Aktualisierung aller Portale beim Start
    private class PortalCache(val client: StalkerClient, val at: Long, val channels: List<Item>)
    private val caches = HashMap<String, PortalCache>()
    private val refreshSem = Semaphore(2)
    val status = mutableStateMapOf<String, String>()
    private val clients = HashMap<String, StalkerClient>()
    private var refreshJob: Job? = null
    var allLoading by mutableStateOf(false)
    var updateInfo by mutableStateOf<Updater.Info?>(null)
    var updateMsg by mutableStateOf<String?>(null)
    var updateProgress by mutableIntStateOf(-1)
    var resumeList by mutableStateOf<List<Resume>>(emptyList())
    var queryText by mutableStateOf("")
    var playUrl by mutableStateOf<String?>(null)
    var playTitle by mutableStateOf("")
    var isLive by mutableStateOf(false)
    var playChId by mutableStateOf("")
    var playLogo by mutableStateOf<String?>(null)
    var epgTick by mutableIntStateOf(0)

    val listState = LazyListState()
    val gridState = LazyGridState()

    private var allChannels = emptyList<Item>()
    private var page = 0
    private var loaded = 0
    private var gen = 0
    private var query = ""
    var browseType = "itv"
    private var zapList = emptyList<Item>()
    private var zapIndex = 0
    private var lastKind = "itv"
    private var lastCmd = ""
    private var lastEp: Int? = null
    private var resumeKey = ""
    private var noticeJob: Job? = null

    private fun <T> io(block: () -> T, ok: (T) -> Unit) {
        loading = true; error = null
        viewModelScope.launch {
            try { ok(withContext(Dispatchers.IO) { block() }) }
            catch (e: Exception) { error = e.message ?: e.javaClass.simpleName }
            finally { loading = false }
        }
    }

    fun showNotice(msg: String) {
        notice = msg
        noticeJob?.cancel()
        noticeJob = viewModelScope.launch { delay(2500); notice = null }
    }

    fun push(s: Screen) { stack.add(s) }

    fun back(): Boolean {
        if (chanPanel) { chanPanel = false; return true }
        if (stack.size <= 1) return false
        val top = stack.last()
        if (top is Screen.Play) { playUrl = null; chanPanel = false }
        if (top is Screen.Browse) editMode = false
        stack.removeAt(stack.size - 1)
        error = null
        if (top is Screen.EditCats || top is Screen.EditChans) refreshAfterEdit()
        return true
    }

    private fun refreshAfterEdit() {
        val valid = categories.any { it.id == selCat }
        selectCategory(if (valid) selCat!! else categories.firstOrNull { it.id != "fav" }?.id ?: "fav")
    }

    // ---------- Portale ----------
    fun savePortal(p: Portal) {
        val i = portals.indexOfFirst { it.id == p.id }
        if (i >= 0) portals[i] = p else portals.add(p)
        store.save(portals.toList())
        refreshAllPortals()
    }

    fun deletePortal(p: Portal) {
        portals.removeAll { it.id == p.id }
        store.save(portals.toList())
        status.remove(p.id)
        clients.remove(p.id)
        refreshAllPortals()
    }

    /** Verbindet ALLE Portale und legt sie zu einem gemeinsamen Katalog zusammen. */
    fun refreshAllPortals() {
        refreshJob?.cancel()
        if (portals.isEmpty()) {
            client = null; portal = null
            homeNew = emptyList(); homeChannels = emptyList(); cachedChannels = null
            allLoading = false
            return
        }
        refreshJob = viewModelScope.launch {
            allLoading = true
            try {
                portals.toList().map { p -> async { connectOne(p) } }.awaitAll()
                buildMerged()
            } finally {
                allLoading = false
            }
        }
    }

    private suspend fun connectOne(p: Portal) {
        status[p.id] = "loading"
        try {
            val c = refreshSem.withPermit {
                withContext(Dispatchers.IO) {
                    val sc = StalkerClient(p)
                    sc.connect()
                    sc
                }
            }
            clients[p.id] = c
            status[p.id] = "ok"
        } catch (e: Exception) {
            clients.remove(p.id)
            status[p.id] = "err:" + (e.message ?: "Fehler")
        }
    }

    private fun buildMerged() {
        val parts = portals.mapNotNull { p -> clients[p.id]?.let { MultiPart(p.id.take(8), it, p.name) } }
        if (parts.isEmpty()) {
            client = null
            homeNew = emptyList(); homeChannels = emptyList()
            return
        }
        client = MultiClient(parts, dedupe)
        portal = Portal("all", "Alle Portale", "", "")
        epgCache.clear()
        cachedChannels = null
        liveCats = emptyList()
        homeNew = emptyList(); homeChannels = emptyList()
        refreshWatchIds()
        loadHome()
    }

    /** Verbindet ein Portal im Hintergrund und lädt die Senderliste vor. */
    fun refreshPortal(p: Portal) {
        status[p.id] = "loading"
        viewModelScope.launch {
            try {
                val cache = refreshSem.withPermit {
                    withContext(Dispatchers.IO) {
                        val c = StalkerClient(p)
                        c.connect()
                        val ch = try { c.channels() } catch (e: Exception) { emptyList() }
                        PortalCache(c, System.currentTimeMillis(), ch)
                    }
                }
                caches[p.id] = cache
                status[p.id] = "ok:${cache.channels.size}"
            } catch (e: Exception) {
                caches.remove(p.id)
                status[p.id] = "err:" + (e.message ?: "Fehler")
            }
        }
    }

    fun openPortal(p: Portal) {
        val cache = caches[p.id]
        if (cache != null && System.currentTimeMillis() - cache.at < 10 * 60_000) {
            client = cache.client
            portal = p
            epgCache.clear()
            cachedChannels = cache.channels
            homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            loadHome()
            return
        }
        val c = StalkerClient(p)
        io({ c.connect() }) {
            client = c; portal = p; epgCache.clear()
            cachedChannels = null; homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            loadHome()
        }
    }

    // ---------- Durchsuchen ----------
    fun openBrowse(type: String, thenGuide: Boolean = false) {
        val c = client ?: return
        val p = portal ?: return
        io({
            val cats = c.categories(type)
            val ch: List<Item> = if (type == "itv") (cachedChannels ?: c.channels().also { cachedChannels = it }) else emptyList()
            cats to ch
        }) { (cats, ch) ->
            browseType = type; allChannels = ch; items = emptyList(); query = ""; queryText = ""
            favs = userData.favs(p.id, type)
            allCats = cats
            if (type == "itv") liveCats = cats
            portalGroups = (c as? MultiClient)?.groups(type) ?: emptyList()
            hiddenCats = userData.hiddenCats(p.id, type)
            hiddenChans = userData.hiddenChans(p.id)
            hiddenItems = userData.hiddenItems(p.id, type)
            editMode = false
            applyCategories()
            push(Screen.Browse(type))
            selectCategory(if (groupedView && portalGroups.isNotEmpty()) "*" else (categories.firstOrNull { it.id != "fav" }?.id ?: "fav"))
            if (thenGuide) push(Screen.Guide)
        }
    }

    private fun channelOk(c: Item): Boolean = !(dedupe && c.dup)

    private fun visibleChannels(): List<Item> =
        allChannels.filter { it.id !in hiddenChans && it.cat !in hiddenCats && channelOk(it) }

    private fun listFor(id: String): List<Item> = when (id) {
        "fav" -> favs
        "*" -> visibleChannels()
        else -> if (id.startsWith("p:")) {
            val rest = id.removePrefix("p:")
            val pfx = rest.substringBefore(':')
            val key = rest.substringAfter(':')
            allChannels.filter {
                it.id.startsWith("$pfx|") && (key == "*" || it.cat == key) && it.id !in hiddenChans
            }
        } else allChannels.filter { it.cat == id && it.id !in hiddenChans && channelOk(it) }
    }

    fun selectCategory(id: String) {
        selCat = id; gen++; query = ""; queryText = ""
        viewModelScope.launch { listState.scrollToItem(0); gridState.scrollToItem(0) }
        if (id == "fav" || browseType == "itv") {
            items = listFor(id); hasMore = false
        } else {
            items = emptyList(); hasMore = false; page = 0; loaded = 0
            loadMore()
        }
    }

    fun search(q: String) {
        val t = q.trim()
        if (browseType == "itv") {
            items = if (t.isEmpty()) listFor(selCat ?: "*")
            else visibleChannels().filter { it.name.contains(t, ignoreCase = true) }
            return
        }
        if (t == query) return
        query = t; gen++; page = 0; loaded = 0; items = emptyList(); hasMore = false
        if (t.isEmpty()) {
            categories.firstOrNull { it.id != "fav" }?.let { selectCategory(it.id) }
        } else {
            selCat = "*"
            loadMore()
        }
    }

    fun loadMore() {
        val c = client ?: return
        val cat = selCat ?: return
        if (browseType == "itv" || cat == "fav" || busyList) return
        val g = gen; val next = page + 1; val t = browseType; val qy = query
        busyList = true
        viewModelScope.launch {
            try {
                val pg = withContext(Dispatchers.IO) { c.list(t, cat, next, qy) }
                if (g == gen) {
                    page = next; loaded += pg.items.size; items = items + pg.items
                    hasMore = pg.items.isNotEmpty() &&
                        (if (pg.total > 0) loaded < pg.total else pg.items.size >= pg.pageSize)
                }
            } catch (e: Exception) {
                if (g == gen) { error = e.message ?: "Fehler"; hasMore = false }
            } finally {
                busyList = false
                if (g != gen) loadMore()
            }
        }
    }

    // ---------- Kategorien und Kanäle bearbeiten ----------
    private fun applyCategories() {
        categories = listOf(Category("fav", "★ Favoriten")) + allCats.filter { it.id !in hiddenCats }
    }

    private fun saveHiddenCats() { portal?.let { userData.saveHiddenCats(it.id, browseType, hiddenCats) } }
    private fun saveHiddenChans() { portal?.let { userData.saveHiddenChans(it.id, hiddenChans) } }

    fun toggleCat(id: String) {
        hiddenCats = if (id in hiddenCats) hiddenCats - id else hiddenCats + id
        saveHiddenCats(); applyCategories()
    }

    fun setAllCats(show: Boolean) {
        hiddenCats = if (show) emptySet() else allCats.map { it.id }.toSet()
        saveHiddenCats(); applyCategories()
    }

    private fun catMatches(title: String, kws: List<String>): Boolean {
        val tokens = title.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        return kws.any { k -> tokens.any { t -> t == k || (k.length >= 4 && t.startsWith(k)) } }
    }

    /** Zeigt nur Kategorien, in denen eines der Suchwörter als Wort vorkommt (z. B. DE, German). */
    fun showOnlyMatching(keywords: String) {
        val kws = keywords.lowercase().split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
        if (kws.isEmpty()) return
        val match = allCats.filter { catMatches(it.title, kws) }
        if (match.isEmpty()) { showNotice("Keine passende Kategorie gefunden"); return }
        var keep = match.map { it.id }.toSet()
        if (browseType == "itv") keep = keep + "*"
        hiddenCats = allCats.map { it.id }.filter { it !in keep }.toSet()
        saveHiddenCats(); applyCategories()
        showNotice("${match.size} Kategorien sichtbar")
    }

    fun openEditChannels() {
        editChans = when (selCat) {
            null, "fav", "*" -> allChannels.filter { it.cat !in hiddenCats }
            else -> allChannels.filter { it.cat == selCat }
        }
        push(Screen.EditChans)
    }

    fun toggleChan(id: String) {
        hiddenChans = if (id in hiddenChans) hiddenChans - id else hiddenChans + id
        saveHiddenChans()
    }

    fun setChansHidden(ids: List<String>, hide: Boolean) {
        hiddenChans = if (hide) hiddenChans + ids else hiddenChans - ids.toSet()
        saveHiddenChans()
    }

    // ---------- Filme und Serien ausblenden ----------
    fun toggleEditMode() { editMode = !editMode }

    /** Anzeige-Liste: im Ausblenden-Modus und bei Favoriten ungefiltert. */
    fun shownItems(): List<Item> =
        if (editMode || selCat == "fav") items else items.filter { it.id !in hiddenItems }

    fun toggleItemHidden(item: Item) {
        val p = portal ?: return
        val was = item.id in hiddenItems
        hiddenItems = if (was) hiddenItems - item.id else hiddenItems + item.id
        userData.saveHiddenItems(p.id, browseType, hiddenItems)
        showNotice(if (was) "Wieder eingeblendet" else "Ausgeblendet")
    }

    // ---------- Portal per Handy hinzufügen (QR-Code) ----------
    fun startPhoneAdd() {
        stopPhoneAdd()
        val ip = PortalServer.localIp()
        if (ip == null) {
            error = "Keine Netzwerkverbindung gefunden. Verbinde die Box mit dem WLAN oder LAN."
            return
        }
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val token = (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        val srv = PortalServer(token) { p ->
            viewModelScope.launch {
                savePortal(p)
                showNotice("Portal „${p.name}“ hinzugefügt")
            }
        }
        try {
            val port = srv.start()
            phoneServer = srv
            qrUrl = "http://$ip:$port/$token"
        } catch (e: Exception) {
            error = "Server konnte nicht gestartet werden: ${e.message}"
        }
    }

    fun stopPhoneAdd() {
        phoneServer?.stop()
        phoneServer = null
        qrUrl = null
    }

    override fun onCleared() {
        stopPhoneAdd()
        super.onCleared()
    }

    // ---------- Navigation über die Seitenleiste ----------
    fun goTo(id: String) {
        playUrl = null
        chanPanel = false
        while (stack.size > 1) stack.removeAt(stack.size - 1)
        editMode = false
        error = null
        when (id) {
            "portals" -> push(Screen.Portals)
            "itv", "vod", "series" -> openBrowse(id)
            "epg" -> openBrowse("itv", true)
            "fav" -> push(Screen.Favs)
            "watch" -> push(Screen.Watch)
            "settings" -> push(Screen.Settings)
        }
    }

    // ---------- Merkliste (Filme und Serien) ----------
    fun watchFor(type: String): List<Item> = portal?.let { userData.favs(it.id, "w_$type") } ?: emptyList()

    private fun refreshWatchIds() {
        watchIds = (watchFor("vod").map { "vod:" + it.id } + watchFor("series").map { "series:" + it.id }).toSet()
    }

    fun isWatch(item: Item): Boolean = ("$browseType:${item.id}") in watchIds

    fun watchType(item: Item): String = if (("series:" + item.id) in watchIds) "series" else "vod"

    fun toggleWatch(item: Item) {
        val p = portal ?: return
        val t = browseType
        val cur = userData.favs(p.id, "w_$t")
        val was = cur.any { it.id == item.id }
        userData.saveFavs(p.id, "w_$t", if (was) cur.filterNot { it.id == item.id } else cur + item)
        refreshWatchIds()
        showNotice(if (was) "Aus der Merkliste entfernt" else "🔖 Zur Merkliste hinzugefügt")
    }

    fun openWatch(type: String, item: Item) {
        val p = portal ?: return
        browseType = type
        favs = userData.favs(p.id, type)
        push(Screen.Detail(item))
    }

    // ---------- Senderliste während Live-TV ----------
    fun openChannelPanel() {
        val c = client ?: return
        val p = portal ?: return
        if (cachedChannels == null || liveCats.isEmpty()) {
            showNotice("Senderliste wird geladen …")
            viewModelScope.launch {
                try {
                    val ch = cachedChannels ?: withContext(Dispatchers.IO) { c.channels() }
                    cachedChannels = ch
                    val cats = if (liveCats.isEmpty()) withContext(Dispatchers.IO) { c.categories("itv") } else liveCats
                    liveCats = cats
                } catch (e: Exception) {
                    error = "Senderliste nicht verfügbar: ${e.message}"
                    return@launch
                }
                showPanel(p)
            }
            return
        }
        showPanel(p)
    }

    private fun showPanel(p: Portal) {
        panelHiddenCats = userData.hiddenCats(p.id, "itv")
        panelHiddenChans = userData.hiddenChans(p.id)
        panelFavs = userData.favs(p.id, "itv")
        val visible = liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }.map { it.id }.toSet()
        val cur = cachedChannels?.firstOrNull { it.id == playChId }
        panelCat = cur?.cat?.takeIf { it in visible } ?: "*"
        chanPanel = true
    }

    fun panelCategories(): List<Category> =
        listOf(Category("fav", "★ Favoriten"), Category("*", "Alle")) +
            liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }

    fun panelList(): List<Item> {
        val all = cachedChannels ?: return emptyList()
        return when (panelCat) {
            "fav" -> panelFavs
            "*" -> all.filter { it.id !in panelHiddenChans && it.cat !in panelHiddenCats && channelOk(it) }
            else -> all.filter { it.cat == panelCat && it.id !in panelHiddenChans && channelOk(it) }
        }
    }

    fun playFromPanel(ch: Item, list: List<Item>) {
        chanPanel = false
        zapList = list
        zapIndex = list.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        if (ch.id == playChId) return
        startLive()
    }

    // ---------- Startseite ----------
    fun loadHome() {
        val c = client ?: return
        val p = portal ?: return
        resumeList = userData.resumes(p.id)
        val hiddenV = userData.hiddenItems(p.id, "vod")
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    var l = c.list("vod", "*", 1).items
                    if (l.isEmpty()) {
                        val first = c.categories("vod").firstOrNull { it.id != "*" }?.id
                        if (first != null) l = c.list("vod", first, 1).items
                    }
                    l
                }
                homeNew = list.filter { it.id !in hiddenV }.take(14)
            } catch (e: Exception) { }
            try {
                val ch = withContext(Dispatchers.IO) { cachedChannels ?: c.channels().also { cachedChannels = it } }
                val hc = userData.hiddenChans(p.id)
                val hcat = userData.hiddenCats(p.id, "itv")
                val favIds = userData.favs(p.id, "itv").map { it.id }.toSet()
                val vis = ch.filter { it.id !in hc && it.cat !in hcat && channelOk(it) }
                homeChannels = (vis.filter { it.id in favIds } + vis).distinctBy { it.id }.take(14)
            } catch (e: Exception) { }
            try {
                if (liveCats.isEmpty()) liveCats = withContext(Dispatchers.IO) { c.categories("itv") }
            } catch (e: Exception) { }
        }
    }

    fun openHomeItem(item: Item, type: String) {
        val p = portal ?: return
        browseType = type
        favs = userData.favs(p.id, type)
        if (type == "itv") {
            zapList = homeChannels
            zapIndex = homeChannels.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    fun favsFor(type: String): List<Item> = portal?.let { userData.favs(it.id, type) } ?: emptyList()

    fun openFavorite(type: String, item: Item) {
        val list = favsFor(type)
        browseType = type
        favs = list
        if (type == "itv") {
            zapList = list
            zapIndex = list.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    // ---------- Favoriten ----------
    fun isFav(item: Item): Boolean = favs.any { it.id == item.id }

    fun toggleFav(item: Item) {
        val p = portal ?: return
        val was = isFav(item)
        favs = if (was) favs.filterNot { it.id == item.id } else favs + item
        userData.saveFavs(p.id, browseType, favs)
        showNotice(if (was) "Aus Favoriten entfernt" else "★ Zu Favoriten hinzugefügt")
        if (selCat == "fav") items = favs
    }

    // ---------- Weiterschauen ----------
    fun openResumes() {
        resumeList = portal?.let { userData.resumes(it.id) } ?: emptyList()
        push(Screen.ResumeList)
    }

    fun resumePos(): Long =
        portal?.let { p -> userData.resumes(p.id).firstOrNull { it.key == resumeKey }?.pos } ?: 0L

    fun savePosition(pos: Long, dur: Long) {
        val p = portal ?: return
        if (isLive || resumeKey.isEmpty()) return
        if (pos < 15_000 || (dur > 0 && pos > dur - 60_000)) userData.removeResume(p.id, resumeKey)
        else userData.putResume(p.id, Resume(resumeKey, playTitle, lastCmd, lastEp, pos))
    }

    fun clearResume() { portal?.let { userData.removeResume(it.id, resumeKey) } }

    // ---------- Abspielen ----------
    /** Live-Sender starten direkt, Filme und Serien öffnen zuerst die Detailseite. */
    fun openItem(item: Item) {
        if (editMode && browseType != "itv") { toggleItemHidden(item); return }
        if (browseType == "itv") startItem(item) else push(Screen.Detail(item))
    }

    fun startItem(item: Item) {
        val c = client ?: return
        when {
            browseType == "series" -> io({ c.seasons(item.id) }) { seasons = it; push(Screen.Seasons(item.name)) }
            item.episodes.isNotEmpty() -> push(Screen.Episodes(Season(item.name, item.cmd, item.episodes)))
            browseType == "itv" -> {
                zapList = items; zapIndex = items.indexOf(item).coerceAtLeast(0); startLive()
            }
            else -> play("vod", item.name, item.cmd, null)
        }
    }

    fun openSeason(s: Season) {
        if (s.episodes.isEmpty()) play("vod", s.name, s.cmd, null) else push(Screen.Episodes(s))
    }

    fun play(kind: String, title: String, cmd: String, ep: Int?) {
        val c = client ?: return
        lastKind = kind; lastCmd = cmd; lastEp = ep; playTitle = title; isLive = kind == "itv"
        if (kind != "itv") playLogo = null
        resumeKey = "$kind|$cmd|${ep ?: 0}"
        io({ c.link(kind, cmd, ep) }) { url ->
            playUrl = url
            if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
        }
    }

    private fun startLive() {
        val ch = zapList.getOrNull(zapIndex) ?: return
        playChId = ch.id
        playLogo = ch.logo
        play("itv", ch.name, ch.cmd, null)
    }

    fun zap(delta: Int) {
        if (zapList.isEmpty()) return
        zapIndex = (zapIndex + delta + zapList.size) % zapList.size
        startLive()
    }

    // ---------- EPG ----------
    private class EpgEntry(val at: Long, val list: List<Epg>, val size: Int)
    private val epgCache = HashMap<String, EpgEntry>()
    private val epgBusy = HashSet<String>()
    private val epgSem = Semaphore(3)

    fun epgList(id: String): List<Epg> {
        if (epgTick < 0) return emptyList()   // liest den State, damit die UI sich aktualisiert
        return epgCache[id]?.list ?: emptyList()
    }

    fun currentEpg(id: String): Epg? {
        val l = epgList(id)
        val now = System.currentTimeMillis() / 1000
        return l.firstOrNull { it.startTs <= now && now < it.stopTs } ?: l.firstOrNull()
    }

    fun epgProgress(e: Epg): Float? {
        if (e.startTs <= 0 || e.stopTs <= e.startTs) return null
        val now = System.currentTimeMillis() / 1000
        return ((now - e.startTs).toFloat() / (e.stopTs - e.startTs)).coerceIn(0f, 1f)
    }

    fun loadEpg(id: String, size: Int = 5) {
        val c = client ?: return
        val old = epgCache[id]
        val fresh = old != null && old.size >= size && System.currentTimeMillis() - old.at < 180_000
        if (id.isEmpty() || id in epgBusy || fresh) return
        epgBusy.add(id)
        viewModelScope.launch {
            val list = try {
                epgSem.withPermit { withContext(Dispatchers.IO) { c.epg(id, size) } }
            } catch (e: Exception) { emptyList() }
            epgCache[id] = EpgEntry(System.currentTimeMillis(), list, size)
            epgBusy.remove(id)
            epgTick++
        }
    }

    /** Fordert einen frischen Stream-Link an (bei Aussetzern/Hängern). */
    fun reload() { play(lastKind, playTitle, lastCmd, lastEp) }

    // ---------- App-Update ----------
    fun checkUpdate(silent: Boolean = false) {
        if (!silent) { updateMsg = "Suche nach Updates …"; updateInfo = null }
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Updater.latest() }
                when {
                    info == null -> if (!silent) updateMsg = "Kein Update gefunden"
                    info.number > BuildConfig.RUN_NUMBER -> {
                        updateInfo = info
                        updateMsg = "Neue Version ${info.tag} verfügbar"
                        if (silent) showNotice("Update ${info.tag} verfügbar (Einstellungen > Nach Updates suchen)")
                    }
                    else -> if (!silent) updateMsg = "Du hast die neueste Version (v${BuildConfig.RUN_NUMBER})"
                }
            } catch (e: Exception) {
                if (!silent) updateMsg = "Fehler: ${e.message}"
            }
        }
    }

    fun installUpdate() {
        val info = updateInfo ?: return
        val app = getApplication<Application>()
        updateProgress = 0
        updateMsg = "Lade ${info.tag} herunter …"
        viewModelScope.launch {
            try {
                val apk = withContext(Dispatchers.IO) { Updater.download(app, info.url) { p -> updateProgress = p } }
                updateProgress = -1
                val started = Updater.install(app, apk)
                updateMsg = if (started) "Installation gestartet. Folge den Anweisungen des Systems."
                else "Erlaube Tom's TV in den Einstellungen, Apps zu installieren, und tippe dann erneut auf Jetzt installieren."
            } catch (e: Exception) {
                updateProgress = -1
                updateMsg = "Update nicht möglich: ${e.message}"
            }
        }
    }

    init {
        checkUpdate(silent = true)
        refreshAllPortals()
    }
}
