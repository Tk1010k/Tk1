package com.example.portaltv

import android.app.Application
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Portals : Screen
    data class Form(val edit: Portal?) : Screen
    data object Home : Screen
    data class Browse(val type: String) : Screen
    data class Seasons(val title: String) : Screen
    data class Episodes(val season: Season) : Screen
    data object ResumeList : Screen
    data object Guide : Screen
    data object Favs : Screen
    data object Settings : Screen
    data object PhoneAdd : Screen
    data object RemoteAccess : Screen
    data object Watch : Screen
    data object AppSettings : Screen
    data object LogView : Screen
    data object EditCats : Screen
    data object EditChans : Screen
    data object DesignScale : Screen
    data object ResumeAll : Screen
    data object HomeLayout : Screen
    data class HomeAddRow(val type: String) : Screen
    data object FavLists : Screen
    data class FavListEdit(val id: String) : Screen
    data class Detail(val item: Item) : Screen
    data object Play : Screen
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val store = PortalStore(app)
    private val userData = UserData(app)
    private val settings = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var textColorName by mutableStateOf(settings.getString("textColor", "Weiß") ?: "Weiß")

    // ---------- Profile ----------
    data class Profile(val id: String, val name: String, val avatar: String = "g0")
    var profiles by mutableStateOf(loadProfiles())
    var profileId by mutableStateOf(settings.getString("profileId", "") ?: "")
    init { userData.profile = profileId }

    private var lastFrameNs = 0L
    private val jankCb = object : android.view.Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val prev = lastFrameNs
            lastFrameNs = frameTimeNanos
            if (prev != 0L) {
                val ms = (frameTimeNanos - prev) / 1_000_000L
                if (ms in 400..20_000 && System.currentTimeMillis() - lastJankLog > 1000) {
                    lastJankLog = System.currentTimeMillis()
                    AppLog.add("Zeit: Bild hing " + ms + " ms (" + (stack.lastOrNull()?.let { it::class.simpleName } ?: "?") + ")")
                }
            }
            android.view.Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private var lastJankLog = 0L
    init { try { android.view.Choreographer.getInstance().postFrameCallback(jankCb) } catch (e: Throwable) {} }

    private fun loadProfiles(): List<Profile> = try {
        val a = org.json.JSONArray(settings.getString("profiles", "[]"))
        val l = (0 until a.length()).map { i -> a.getJSONObject(i).let {
            Profile(it.optString("id"), it.optString("name"), it.optString("av").let { v ->
                if (v.isBlank()) AVATARS[i % AVATARS.size] else if (v.startsWith("g")) v
                else "g" + listOf("lion", "robot", "astro", "panda", "fox", "ninja", "owl", "cat").indexOf(v).coerceAtLeast(0)
            }) } }
        if (l.none { it.id.isEmpty() }) listOf(Profile("", "Profil 1", "g0")) + l else l
    } catch (e: Exception) { listOf(Profile("", "Profil 1", "g0")) }

    private fun saveProfiles() {
        val a = org.json.JSONArray()
        profiles.forEach { a.put(org.json.JSONObject().put("id", it.id).put("name", it.name).put("av", it.avatar)) }
        settings.edit().putString("profiles", a.toString()).apply()
    }

    fun profileAvatar(): String = profiles.firstOrNull { it.id == profileId }?.avatar ?: "g0"

    fun setAvatar(kind: String) {
        profiles = profiles.map { if (it.id == profileId) it.copy(avatar = kind) else it }
        saveProfiles()
    }

    /** Profilwahl beim Start: nur bei mehr als einem Profil und wenn eingeschaltet. */
    var askProfile by mutableStateOf(settings.getBoolean("askProfile", true))
    var profilePicked by mutableStateOf(profiles.size < 2 || !askProfile)
    fun toggleAskProfile() {
        askProfile = !askProfile
        settings.edit().putBoolean("askProfile", askProfile).apply()
    }

    /** Zuletzt gezeigte Startseiten-Neuheiten: erscheinen sofort beim Start, bis die frischen Daten da sind. */
    var homeCached by mutableStateOf<List<Item>>(userData.favs("_home", "new"))
    var swallowBackAt = 0L

    fun profileName(): String = profiles.firstOrNull { it.id == profileId }?.name ?: "Profil 1"

    fun switchProfile(id: String) {
        if (id == profileId) return
        profileId = id
        userData.profile = id
        settings.edit().putString("profileId", id).apply()
        while (stack.size > 1) stack.removeAt(stack.size - 1)
        refreshWatchIds(); refreshSeen(); loadHome()
        showNotice("Profil: " + profileName())
    }

    fun nextProfile() {
        if (profiles.size < 2) return
        val i = profiles.indexOfFirst { it.id == profileId }
        switchProfile(profiles[(i + 1) % profiles.size].id)
    }

    fun addProfile(name: String) {
        val n = name.trim().ifBlank { "Profil " + (profiles.size + 1) }
        val av = AVATARS.firstOrNull { k -> profiles.none { it.avatar == k } } ?: AVATARS[profiles.size % AVATARS.size]
        if (profiles.size >= 6) { showNotice("Maximal 6 Profile"); return }
        val id = ((profiles.mapNotNull { it.id.toIntOrNull() }.maxOrNull() ?: 0) + 1).toString()
        profiles = profiles + Profile(id, n, av)
        saveProfiles()
        switchProfile(id)
    }

    fun renameProfile(name: String) {
        val n = name.trim()
        if (n.isBlank()) return
        profiles = profiles.map { if (it.id == profileId) it.copy(name = n) else it }
        saveProfiles()
        showNotice("Umbenannt in $n")
    }

    fun deleteProfile() {
        if (profileId.isEmpty()) { showNotice("Das erste Profil kann nicht gelöscht werden"); return }
        val gone = profileId
        switchProfile("")
        userData.wipeProfile(gone)
        profiles = profiles.filterNot { it.id == gone }
        saveProfiles()
    }

    fun setTextColor(name: String) {
        textColorName = name
        settings.edit().putString("textColor", name).apply()
    }

    var accentName by mutableStateOf(settings.getString("accent", "Rot") ?: "Rot")

    fun setAccent(name: String) {
        accentName = name
        settings.edit().putString("accent", name).apply()
    }

    var sidebarMode by mutableStateOf(settings.getString("sidebar", "auto") ?: "auto")

    fun cycleSidebar() {
        sidebarMode = when (sidebarMode) { "auto" -> "compact"; "compact" -> "normal"; else -> "auto" }
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    /** "max": Bild und Ton so, wie das Portal sie sendet. "auto": an den Bildschirm angepasst. */
    var qualityMode by mutableStateOf(settings.getString("quality", "max") ?: "max")

    fun cycleQuality() {
        qualityMode = when (qualityMode) {
            "max" -> "adaptive"
            "adaptive" -> "auto"
            else -> "max"
        }
        settings.edit().putString("quality", qualityMode).apply()
    }

    // ---------- Wiedergabe: Bildwiederholrate, Ton, Decoder ----------
    /** "off", "vod" (nur Filme/Serien), "all" (auch Live) */
    var afrMode by mutableStateOf(settings.getString("afr", "vod") ?: "vod")
    fun afrLabel(): String = when (afrMode) { "vod" -> "nur Filme & Serien"; "all" -> "auch Live-TV"; else -> "aus" }
    // HDR-Ausgabe: auto = nur wenn das Video HDR10/HLG ist, on = im Player immer, off = nie anfordern
    var hdrOut by mutableStateOf(settings.getString("hdrOut", "auto") ?: "auto")
    fun hdrLabel(): String = when (hdrOut) { "on" -> "immer an"; "off" -> "aus"; else -> "automatisch (bei HDR-Videos)" }
    fun cycleHdr() { hdrOut = when (hdrOut) { "auto" -> "on"; "on" -> "off"; else -> "auto" }; settings.edit().putString("hdrOut", hdrOut).apply() }
    fun cycleAfr() { afrMode = when (afrMode) { "off" -> "vod"; "vod" -> "all"; else -> "off" }; settings.edit().putString("afr", afrMode).apply() }

    /** "auto" oder "stereo" */
    var audioMode by mutableStateOf(settings.getString("audioMode", "auto") ?: "auto")
    fun audioLabel(): String = if (audioMode == "stereo") "immer Stereo" else "automatisch (Surround, wenn möglich)"
    fun cycleAudio() { audioMode = if (audioMode == "auto") "stereo" else "auto"; settings.edit().putString("audioMode", audioMode).apply() }

    /** "hw" (Hardware zuerst) oder "sw" (Software zuerst) */
    var decoderMode by mutableStateOf(settings.getString("decoder", "hw") ?: "hw")
    fun decoderLabel(): String = if (decoderMode == "sw") "Software zuerst (bei Bildfehlern)" else "Hardware zuerst (empfohlen)"
    fun cycleDecoder() { decoderMode = if (decoderMode == "hw") "sw" else "hw"; settings.edit().putString("decoder", decoderMode).apply() }

    // ---------- Netz-Anpassung ----------
    /** "auto": erkennt schwaches Netz selbst. "stable": immer sparsam. "best": nie einschränken. */
    var netMode by mutableStateOf(settings.getString("netMode", "auto") ?: "auto")
    var weakNet by mutableStateOf(false)
    private var netHint = false
    private var bwEma = 0L
    private val stallTimes = ArrayDeque<Long>()
    private var weakSince = 0L

    fun effectiveWeak(): Boolean = when (netMode) { "stable" -> true; "best" -> false; else -> weakNet }
    fun netLabel(): String = when (netMode) {
        "stable" -> "immer stabil (niedrigere Qualität)"
        "best" -> "immer beste Qualität"
        else -> "automatisch"
    }
    private fun applyNet() { NetState.weak = effectiveWeak() }
    init { applyNet() }

    fun cycleNetMode() {
        netMode = when (netMode) { "auto" -> "stable"; "stable" -> "best"; else -> "auto" }
        settings.edit().putString("netMode", netMode).apply()
        applyNet()
    }

    fun reportBandwidth(bps: Long) {
        if (bps <= 0) return
        bwEma = if (bwEma == 0L) bps else (bwEma * 7 + bps * 3) / 10
        evalNet()
    }

    fun reportStall() {
        stallTimes.addLast(System.currentTimeMillis())
        evalNet()
    }

    fun setNetHint(h: Boolean) { netHint = h; evalNet() }

    private fun evalNet() {
        val now = System.currentTimeMillis()
        while (stallTimes.isNotEmpty() && now - stallTimes.first() > 60_000) stallTimes.removeFirst()
        // Nur echte Aussetzer zählen; WLAN-Signal und Bandwidth-Schätzung sind zu unzuverlässig (z.B. Starlink)
        val bad = stallTimes.size >= 4
        val good = stallTimes.isEmpty()
        if (bad && !weakNet) {
            weakNet = true; weakSince = now
            AppLog.add("Schwaches Netz erkannt – sparsamer Modus")
            applyNet()
        } else if (good && weakNet && now - weakSince > 45_000) {
            weakNet = false
            AppLog.add("Netz wieder gut – normaler Modus")
            applyNet()
        }
    }

    /** Pufferung: "fast" (kurz), "balanced" (ausgewogen), "stable" (groß, für 4K). */
    var bufferMode by mutableStateOf(settings.getString("buffer", "balanced")?.takeIf { it != "auto" } ?: "balanced")

    fun cycleBuffer() {
        bufferMode = when (bufferMode) {
            "balanced" -> "stable"
            "stable" -> "fast"
            else -> "balanced"
        }
        settings.edit().putString("buffer", bufferMode).apply()
    }

    /** 4K-Hilfe: Tunneling und schnellere Decoder-Warteschlange (hilft auf manchen Boxen gegen Ruckler). */
    var fourKHelp by mutableStateOf(settings.getBoolean("fourK", false))
    /** Schwaches Gerät (Fire TV, wenig Arbeitsspeicher): Kompatibilitätsmodus ist dort von Anfang an an. */
    private fun weakDevice(): Boolean = runCatching {
        android.os.Build.MANUFACTURER.equals("Amazon", true) ||
            (getApplication<Application>().getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).isLowRamDevice
    }.getOrDefault(false)
    var compat by mutableStateOf(settings.getBoolean("compat", weakDevice()))
    fun toggleCompat() {
        compat = !compat
        settings.edit().putBoolean("compat", compat).apply()
        markCustom()
    }

    fun toggle4kHelp() {
        fourKHelp = !fourKHelp
        settings.edit().putBoolean("fourK", fourKHelp).apply()
    }

    var dedupe by mutableStateOf(settings.getBoolean("dedupe", true))

    fun toggleDedupe() {
        dedupe = !dedupe
        settings.edit().putBoolean("dedupe", dedupe).apply()
        refreshAllPortals()
    }

    // Aufklappbare Portal-Gruppen und seitliches Einklappen
    var portalGroups by mutableStateOf<List<PortalGroup>>(emptyList())
    var expandedPortals by mutableStateOf<Set<String>>(settings.getStringSet("expanded", null)?.toSet() ?: emptySet())
    private var expandedInit = settings.contains("expanded")
    var groupedView by mutableStateOf(settings.getBoolean("grouped", true))
    var catPaneOpen by mutableStateOf(settings.getBoolean("catPane", true))

    fun toggleGroup(pfx: String) {
        expandedPortals = if (pfx in expandedPortals) expandedPortals - pfx else expandedPortals + pfx
        expandedInit = true
        settings.edit().putStringSet("expanded", expandedPortals).apply()
    }

    fun toggleGrouped() {
        groupedView = !groupedView
        settings.edit().putBoolean("grouped", groupedView).apply()
    }

    fun toggleCatPane() {
        catPaneOpen = !catPaneOpen
        settings.edit().putBoolean("catPane", catPaneOpen).apply()
    }

    var designMode by mutableStateOf(
        settings.getString("design", "premium")?.takeIf { it == "oled" || it == "night" || it == "neon" || it == "cinema" || it == "premium" || it == "flat" } ?: "premium")

    /** Ansichtsgröße: 0 = Kompakt, 1 = Standard, 2 = Groß */
    var uiSize by mutableIntStateOf(settings.getInt("uiSize", 1))
    // Startseite: „Neu im Angebot“ und „Neu bei …“ nur mit deutschen Titeln
    var homeGerman by mutableStateOf(settings.getBoolean("homeDe", true))
    fun toggleHomeGerman() {
        homeGerman = !homeGerman
        settings.edit().putBoolean("homeDe", homeGerman).apply()
        homeNew = emptyList(); homeNewByPortal = emptyList(); homeCached = emptyList()
        loadHome()
    }
    // Stufenlose Größe: Layout (Kacheln) und Schrift getrennt, in Prozent
    var uiPct by mutableIntStateOf(settings.getInt("uiPct", when (settings.getInt("uiSize", 1)) { 0 -> 72; 2 -> 100; else -> 86 }))
    var fontPct by mutableIntStateOf(settings.getInt("fontPct", 100))
    fun uiScale(): Float = uiPct / 100f
    fun changeUiPct(v: Int) { uiPct = v.coerceIn(60, 110); settings.edit().putInt("uiPct", uiPct).apply() }
    fun changeFontPct(v: Int) { fontPct = v.coerceIn(80, 140); settings.edit().putInt("fontPct", fontPct).apply() }
    fun resetScale() { changeUiPct(86); changeFontPct(100) }
    fun uiSizeLabel(): String = "Kacheln " + uiPct + " %  ·  Schrift " + fontPct + " %"
    var badges by mutableStateOf(settings.getBoolean("badges", true))
    fun toggleBadges() { badges = !badges; settings.edit().putBoolean("badges", badges).apply() }
    fun cycleUiSize() {
        uiSize = (uiSize + 1) % 3
        settings.edit().putInt("uiSize", uiSize).apply()
    }

    /** Glow & Rand: 0 aus, 1 dezent, 2 stark */
    var glowLevel by mutableIntStateOf(settings.getInt("glow", 2))
    fun glowFactor(): Float = when (glowLevel) { 0 -> 0f; 1 -> 0.5f; else -> 1f }
    fun glowLabel(): String = when (glowLevel) { 0 -> "aus"; 1 -> "dezent"; else -> "stark" }
    fun cycleGlow() { glowLevel = (glowLevel + 1) % 3; settings.edit().putInt("glow", glowLevel).apply() }

    // ---------- Sicherung ----------
    private fun ctxApp() = getApplication<Application>()
    fun backupFile(): java.io.File = java.io.File(ctxApp().getExternalFilesDir(null) ?: ctxApp().filesDir, "TomsTV-Sicherung.json")
    var lastBackupText by mutableStateOf(backupInfo())
    private fun backupInfo(): String {
        val t = settings.getLong("lastBackup", 0L)
        return if (t == 0L) "Noch keine Sicherung" else "Letzte Sicherung: " +
            java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.GERMANY).format(java.util.Date(t))
    }

    fun createBackup(): Boolean = try {
        val root = org.json.JSONObject()
        for (name in listOf("portals", "settings", "userdata")) {
            val sp = ctxApp().getSharedPreferences(name, Context.MODE_PRIVATE)
            val po = org.json.JSONObject()
            for ((k, v) in sp.all) {
                if (name == "settings" && k == "lastBackup") continue
                val e = org.json.JSONObject()
                when (v) {
                    is String -> e.put("t", "s").put("v", v)
                    is Int -> e.put("t", "i").put("v", v)
                    is Long -> e.put("t", "l").put("v", v)
                    is Boolean -> e.put("t", "b").put("v", v)
                    is Float -> e.put("t", "f").put("v", v.toDouble())
                    is Set<*> -> e.put("t", "x").put("v", org.json.JSONArray(v.map { it.toString() }))
                    else -> continue
                }
                po.put(k, e)
            }
            root.put(name, po)
        }
        backupFile().writeText(root.toString())
        settings.edit().putLong("lastBackup", System.currentTimeMillis()).apply()
        lastBackupText = backupInfo()
        true
    } catch (e: Exception) { AppLog.add("Sicherung fehlgeschlagen: " + (e.message ?: "")); false }

    fun restoreBackup(): Boolean = try {
        val f = backupFile()
        if (!f.exists()) { showNotice("Keine Sicherung gefunden"); false } else {
            val root = org.json.JSONObject(f.readText())
            for (name in listOf("portals", "settings", "userdata")) {
                val po = root.optJSONObject(name) ?: continue
                val ed = ctxApp().getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
                for (k in po.keys()) {
                    val e = po.getJSONObject(k)
                    when (e.getString("t")) {
                        "s" -> ed.putString(k, e.getString("v"))
                        "i" -> ed.putInt(k, e.getInt("v"))
                        "l" -> ed.putLong(k, e.getLong("v"))
                        "b" -> ed.putBoolean(k, e.getBoolean("v"))
                        "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                        "x" -> { val a = e.getJSONArray("v"); ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
                    }
                }
                ed.commit()
            }
            showNotice("Wiederhergestellt – bitte die App beenden und neu starten")
            true
        }
    } catch (e: Exception) { showNotice("Sicherung konnte nicht geladen werden"); false }

    var autostart by mutableStateOf(settings.getBoolean("autostart", false))
    fun toggleAutostart() { autostart = !autostart; settings.edit().putBoolean("autostart", autostart).apply() }

    init {
        // Wöchentliche automatische Sicherung, ohne den Start zu bremsen
        viewModelScope.launch(Dispatchers.IO) {
            delay(15_000)
            if (System.currentTimeMillis() - settings.getLong("lastBackup", 0L) > 7L * 24 * 3600 * 1000) createBackup()
        }
    }

    // Neon-Glas: Hintergrundfarbe folgt dem Poster, das gerade im Fokus ist
    var ambient by mutableStateOf(androidx.compose.ui.graphics.Color(0xFF5B6BFF))
    private var ambientJob: Job? = null
    private val ambientCache = HashMap<String, androidx.compose.ui.graphics.Color>()
    fun focusAmbient(url: String?) {
        if (designMode != "neon" || perfMode || url.isNullOrBlank()) return
        ambientCache[url]?.let { ambient = it; return }
        ambientJob?.cancel()
        ambientJob = viewModelScope.launch {
            delay(220)
            val c = withContext(Dispatchers.IO) { dominantColor(url) } ?: return@launch
            if (ambientCache.size > 200) ambientCache.clear()
            ambientCache[url] = c
            ambient = c
        }
    }
    private suspend fun dominantColor(url: String): androidx.compose.ui.graphics.Color? {
        try {
            val app = getApplication<Application>()
            val req = coil.request.ImageRequest.Builder(app).data(url).size(48, 48).allowHardware(false).build()
            val res = coil.Coil.imageLoader(app).execute(req)
            val dr = (res as? coil.request.SuccessResult)?.drawable ?: return null
            val bmp = android.graphics.Bitmap.createBitmap(24, 24, android.graphics.Bitmap.Config.ARGB_8888)
            dr.setBounds(0, 0, 24, 24)
            dr.draw(android.graphics.Canvas(bmp))
            var r = 0f; var g = 0f; var b = 0f; var wsum = 0f
            val hsv = FloatArray(3)
            for (y in 0 until 24) for (x in 0 until 24) {
                val p = bmp.getPixel(x, y)
                android.graphics.Color.colorToHSV(p, hsv)
                val w = hsv[1] * hsv[2] + 0.02f
                r += android.graphics.Color.red(p) * w
                g += android.graphics.Color.green(p) * w
                b += android.graphics.Color.blue(p) * w
                wsum += w
            }
            if (wsum <= 0f) return null
            val avg = android.graphics.Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (b / wsum).toInt())
            android.graphics.Color.colorToHSV(avg, hsv)
            hsv[1] = hsv[1].coerceIn(0.55f, 1f)
            hsv[2] = hsv[2].coerceIn(0.8f, 1f)
            return androidx.compose.ui.graphics.Color(android.graphics.Color.HSVToColor(hsv))
        } catch (e: Exception) { return null }
    }

    fun toggleDesign() {
        designMode = when (designMode) {
            "premium" -> "flat"
            "flat" -> "cinema"
            "cinema" -> "oled"
            "oled" -> "night"
            "night" -> "neon"
            else -> "premium"
        }
        settings.edit().putString("design", designMode).apply()
        // Nur ein Hinweis: aufwendige Designs können auf schwächeren Geräten ruckeln
        val eff = if (deviceProfile == "strong" || deviceProfile == "mid" || deviceProfile == "weak") deviceProfile else detectProfile()
        if ((designMode == "neon" && eff != "strong") || (designMode == "cinema" && eff == "weak"))
            showNotice("Kann auf diesem Gerät ruckeln – bei Problemen Flat oder Premium wählen")
    }

    /** Leistungsmodus: keine Animationen, keine Vorschau, kein Banner-Wechsel. */
    var perfMode by mutableStateOf(settings.getBoolean("perf", false))

    fun togglePerf() {
        perfMode = !perfMode
        settings.edit().putBoolean("perf", perfMode).apply()
        if (perfMode) stopPreview()
        markCustom()
    }

    // Live-Vorschau in der Senderliste
    /** Live-Vorschau ist entfernt (viele Anbieter erlauben nur einen Stream gleichzeitig). */
    var previewOn by mutableStateOf(false)
    var previewUrl by mutableStateOf<String?>(null)
    var previewChannel by mutableStateOf<Item?>(null)
    private var previewJob: Job? = null

    fun togglePreview() {
        previewOn = !previewOn
        if (!previewOn) stopPreview()
    }

    fun requestPreview(ch: Item) {
        previewChannel = ch
        if (!previewOn) return
        val c = client ?: return
        previewJob?.cancel()
        previewJob = viewModelScope.launch {
            delay(1200)
            try {
                previewUrl = withContext(Dispatchers.IO) { c.link("itv", ch.cmd, null) }
            } catch (e: Exception) {
                previewUrl = null
            }
        }
    }

    fun stopPreview() {
        previewJob?.cancel()
        previewUrl = null
    }

    /** Geräteprofil: "auto", "strong", "mid", "weak" oder "custom" (einzelne Schalter von Hand geändert). */
    var deviceProfile by mutableStateOf(settings.getString("profile", "custom") ?: "custom")

    private fun markCustom() {
        if (deviceProfile == "custom") return
        deviceProfile = "custom"
        settings.edit().putString("profile", "custom").apply()
    }

    /** Erkennt aus Hersteller, Arbeitsspeicher, Prozessor und Hardware-Decodern, welches Profil zum Gerät passt. */
    fun detectProfile(): String = runCatching {
        val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = mi.totalMem / 1073741824.0
        val maker = android.os.Build.MANUFACTURER
        when {
            maker.equals("NVIDIA", true) -> "strong"
            maker.equals("Amazon", true) -> if (am.isLowRamDevice || gb < 1.2) "weak" else "mid"
            maker.contains("Skyworth", true) || maker.equals("Strong", true) -> "weak"
            am.isLowRamDevice || gb < 1.8 -> "weak"
            // Unbekannte Geräte: vorsichtig „Schwach“. Der Messwert schwankt stark und sagt nichts über die Grafik, er dient nur zur Anzeige.
            else -> "weak"
        }
    }.getOrDefault("mid")

    /** Kurzbeschreibung des Geräts für Einstellungen und Fehlerprotokoll. */
    fun deviceSummary(): String = runCatching {
        val am = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val gb = Math.round(mi.totalMem / 1073741824.0 * 10) / 10.0
        val hevc = hwDecoder("video/hevc")
        val av1 = hwDecoder("video/av01")
        android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " · " + gb + " GB RAM · " +
            Runtime.getRuntime().availableProcessors() + " Kerne · Android " + android.os.Build.VERSION.RELEASE +
            " (API " + android.os.Build.VERSION.SDK_INT + ")" +
            " · HEVC " + (if (hevc) "HW" else "SW") + " · AV1 " + (if (av1) "HW" else "–") +
            (if (benchScore > 0) " · Messwert $benchScore" else "")
    }.getOrDefault("unbekannt")

    private fun hwDecoder(mime: String): Boolean = runCatching {
        android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
            !ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } &&
                !ci.name.startsWith("OMX.google.") && !ci.name.startsWith("c2.android.") && !ci.name.contains(".sw.", true)
        }
    }.getOrDefault(false)

    /** Einfacher Geschwindigkeitstest (höher = schneller), zum Abgleichen der Profile auf echten Geräten. */
    private val benchKey = "bench:" + android.os.Build.MODEL
    var benchScore by mutableStateOf(settings.getLong("bench:" + android.os.Build.MODEL, 0L))

    private fun runBench() {
        viewModelScope.launch(Dispatchers.Default) {
            delay(4000)
            val t0 = System.nanoTime()
            val arr = IntArray(300_000) { ((it * 2654435761L) % 1000003L).toInt() }
            arr.sort()
            var x = 0L
            for (i in 0 until 8_000_000) x += (i * 31L) xor (i shr 3).toLong()
            val ms = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
            // Last verlangsamt die Messung nur, deshalb zählt der beste Wert
            val score = maxOf(100_000L / ms + (if (x == 42L) 1 else 0), settings.getLong(benchKey, 0L))
            settings.edit().putLong(benchKey, score).apply()
            withContext(Dispatchers.Main) { benchScore = score }
            AppLog.add("Gerät: " + deviceSummary() + " · Profil " + profileName(deviceProfile) + " (erkannt: " + profileName(detectProfile()) + ")")
        }
    }

    fun profileName(p: String): String = when (p) {
        "auto" -> "Auto"
        "strong" -> "Stark (Shield)"
        "mid" -> "Mittel (Fire TV, Cube)"
        "weak" -> "Schwach (Strong Box)"
        else -> "Angepasst"
    }

    fun applyProfile(p: String, withDesign: Boolean = true) {
        val eff = if (p == "auto") detectProfile() else p
        perfMode = eff == "weak"
        compat = eff != "strong"
        if (eff == "weak") { previewOn = false; stopPreview() }
        if (withDesign && eff != "strong" && designMode != "premium" && designMode != "flat") {
            designMode = "flat"
            settings.edit().putString("design", "flat").apply()
        }
        deviceProfile = p
        settings.edit().putString("profile", p).putBoolean("perf", perfMode)
            .putBoolean("compat", compat).putBoolean("preview", previewOn).apply()
    }

    fun cycleProfile() = applyProfile(when (deviceProfile) {
        "auto" -> "strong"
        "strong" -> "mid"
        "mid" -> "weak"
        else -> "auto"
    })

    init {
        // Einmalig für schon gewählte Profile: Mittel und Schwach verwenden das leichte Design „premium“
        if (settings.contains("profile") && !settings.getBoolean("profDesign", false)) {
            settings.edit().putBoolean("profDesign", true).apply()
            val eff = if (deviceProfile == "auto") detectProfile() else deviceProfile
            if ((eff == "mid" || eff == "weak") && designMode != "premium") {
                designMode = "premium"
                settings.edit().putString("design", "premium").apply()
            }
        }
        if (!settings.contains("profile")) {
            // Erster Start mit Geräteprofil (frische Installation oder Update): Profil automatisch wählen
            applyProfile("auto")
        } else if (deviceProfile == "auto") {
            // Bei „Auto“ wird bei jedem Start neu erkannt (z. B. nach Gerätewechsel durch Backup oder neuer Erkennung)
            applyProfile("auto", withDesign = false)
        }
        runBench()
    }

    fun setSidebar(mode: String) {
        sidebarMode = mode
        settings.edit().putString("sidebar", sidebarMode).apply()
    }

    // ---------- Weiterschauen: Anzeige, Abspielen, Löschen ----------
    var resumeEntries by mutableStateOf<List<Resume>>(emptyList())
    private var resumePfx = ""
    private var resumeLogo: String? = null
    private var playGen = 0
    private var hdrMode = 0
    private var reloading = false
    var playNonce by mutableIntStateOf(0)
    private val linkCache = HashMap<String, Pair<String, Long>>()

    /** Java-Heap fast voll? */
    fun memoryTight(): Boolean {
        val r = Runtime.getRuntime()
        return (r.totalMemory() - r.freeMemory()) > r.maxMemory() * 0.82
    }

    /** Bild-, EPG- und Link-Zwischenspeicher leeren, um Speicher freizugeben. */
    fun trimMemory() {
        runCatching { coil.Coil.imageLoader(getApplication<Application>()).memoryCache?.clear() }
        runCatching { epgCache.clear() }
        runCatching { linkCache.clear() }
        System.gc()
    }
    private val prefetching = HashSet<String>()
    private val triedIds = HashSet<String>()
    private var liveContext = "*"

    private fun loadResumeShown() {
        val p = portal ?: return
        resumeEntries = userData.resumes(p.id).filter { it.type == browseType && it.cmd.startsWith("$resumePfx|") }
    }

    fun refreshResumeShown() { loadResumeShown() }

    fun clearAllResumes() {
        resumeList.toList().forEach { removeResume(it) }
    }

    fun removeResume(r: Resume) {
        val p = portal ?: return
        userData.removeResume(p.id, r.key)
        loadResumeShown()
        resumeList = userData.resumes(p.id)
    }

    fun clearResumeShown() {
        val p = portal ?: return
        resumeEntries.forEach { userData.removeResume(p.id, it.key) }
        loadResumeShown()
        resumeList = userData.resumes(p.id)
    }

    fun playResume(r: Resume) {
        resumeLogo = r.logo
        browseType = r.type
        if (r.type == "series") seriesName = r.title.substringBefore(" – ", "")
        if (r.sall.isNotEmpty() && seasons.none { it.cmd == r.cmd }) {
            val parsed = r.sall.split("\n").mapNotNull { ln ->
                val f = ln.split("\t")
                if (f.size < 3) null else Season(f[0], f[1], f[2].split(",").mapNotNull { it.toIntOrNull() })
            }
            if (parsed.any { it.cmd == r.cmd }) seasons = parsed
        }
        currentSeason = seasons.firstOrNull { it.cmd == r.cmd }
            ?: (if (r.eps.isNotEmpty()) Season(r.sname, r.cmd, r.eps.split(",").mapNotNull { it.toIntOrNull() }) else null)
        play("vod", r.title, r.cmd, r.ep)
    }

    fun toggleWatchOf(item: Item, type: String) {
        browseType = type
        toggleWatch(item)
    }
    val portals = mutableStateListOf<Portal>().apply { addAll(store.load()) }
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var portal by mutableStateOf<Portal?>(null)
    private var client: StalkerClient? = null

    var loading by mutableStateOf(false)
    var busyList by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var notice by mutableStateOf<String?>(null)

    var categories by mutableStateOf<List<Category>>(emptyList())
    var selCat by mutableStateOf<String?>(null)
    var items by mutableStateOf<List<Item>>(emptyList())
    var hasMore by mutableStateOf(false)
    var seasons by mutableStateOf<List<Season>>(emptyList())
    var favs by mutableStateOf<List<Item>>(emptyList())
    var allCats by mutableStateOf<List<Category>>(emptyList())
    var hiddenCats by mutableStateOf<Set<String>>(emptySet())
    var hiddenChans by mutableStateOf<Set<String>>(emptySet())
    var editChans by mutableStateOf<List<Item>>(emptyList())
    var hiddenItems by mutableStateOf<Set<String>>(emptySet())
    var editMode by mutableStateOf(false)
    var introDone by mutableStateOf(false)
    var qrUrl by mutableStateOf<String?>(null)
    var chanPanel by mutableStateOf(false)
    var panelCat by mutableStateOf("*")
    var watchIds by mutableStateOf<Set<String>>(emptySet())
    private var liveCats: List<Category> = emptyList()
    private var panelHiddenCats: Set<String> = emptySet()
    private var panelHiddenChans: Set<String> = emptySet()
    private var panelFavs: List<Item> = emptyList()
    private var phoneServer: PortalServer? = null
    var homeNew by mutableStateOf<List<Item>>(emptyList())
    var homeChannels by mutableStateOf<List<Item>>(emptyList())
    var homeNewByPortal by mutableStateOf<List<Pair<String, List<Item>>>>(emptyList())
    private var cachedChannels: List<Item>? = null

    // Hintergrund-Aktualisierung aller Portale beim Start
    private class PortalCache(val client: StalkerClient, val at: Long, val channels: List<Item>)
    private val caches = HashMap<String, PortalCache>()
    private val refreshSem = Semaphore(3)
    val status = mutableStateMapOf<String, String>()
    private val clients = HashMap<String, StalkerClient>()
    private val cacheRoot: File = File(app.cacheDir, "lists").apply { mkdirs() }
    private var forceRefresh = false
    private var refreshJob: Job? = null
    var allLoading by mutableStateOf(false)
    var updateInfo by mutableStateOf<Updater.Info?>(null)
    var updateMsg by mutableStateOf<String?>(null)
    var updateProgress by mutableIntStateOf(-1)
    var updatePrompt by mutableStateOf<Updater.Info?>(null)
    var resumeList by mutableStateOf<List<Resume>>(emptyList())
    var queryText by mutableStateOf("")
    var playUrl by mutableStateOf<String?>(null)
    var playTitle by mutableStateOf("")
    var isLive by mutableStateOf(false)
    var playChId by mutableStateOf("")
    var playLogo by mutableStateOf<String?>(null)
    var epgTick by mutableIntStateOf(0)

    val listState = LazyListState()
    val gridState = LazyGridState()

    private var allChannels = emptyList<Item>()
    private var page = 0
    private var loaded = 0
    private var gen = 0
    private var query = ""
    var browseType = "itv"
    private var zapList = emptyList<Item>()
    private var zapIndex = 0
    private var lastKind = "itv"
    private var lastCmd = ""
    private var lastEp: Int? = null
    private var resumeKey = ""
    private var noticeJob: Job? = null

    private fun <T> io(block: () -> T, ok: (T) -> Unit) {
        loading = true; error = null
        viewModelScope.launch {
            try { ok(withContext(Dispatchers.IO) { block() }) }
            catch (e: Exception) { error = e.message ?: e.javaClass.simpleName; AppLog.add("Fehler: " + (e.message ?: e.javaClass.simpleName)) }
            finally { loading = false }
        }
    }

    fun showNotice(msg: String) {
        notice = msg
        noticeJob?.cancel()
        noticeJob = viewModelScope.launch { delay(2500); notice = null }
    }

    /** Scroll-Position der Einstellungen: bleibt beim Wechsel in Unterseiten und zurück erhalten. */
    val settingsScroll = androidx.compose.foundation.ScrollState(0)
    val navScroll = androidx.compose.foundation.ScrollState(0)
    val catListState = androidx.compose.foundation.lazy.LazyListState()
    /** Zuletzt fokussierter Eintrag der linken Seiten ("nav:id" oder "cat:id"); null = Fokus war woanders. */
    var leftFocus: String? = null
    /** Fokus liegt gerade im Inhalt einer Seite mit Seitenleiste (Merkliste, Favoriten, Weiterschauen). */
    var contentFocus: String? = null
    /** Zuletzt fokussierter Eintrag im Inhalt, wird nach dem Zurückkehren wiederhergestellt. */
    var itemFocus: String? = null
    var navFocusReq by mutableStateOf<String?>(null)
    /** Nach dem Löschen: Schlüssel des Eintrags, der den Fokus bekommen soll (siehe delFocus). */
    var pendingFocus by mutableStateOf<String?>(null)
    /** Eintrag der Seitenleiste, mit dem der Bereich geöffnet wurde: Dorthin geht der Cursor beim Zurückkehren. */
    var homeAnchor: String? = null
    /** EPG wurde direkt aus der Seitenleiste geöffnet (Zurück soll dann nicht in der Senderliste landen). */
    var guideDirect = false
    val rowStates = HashMap<String, androidx.compose.foundation.lazy.LazyListState>()
    val pageScrolls = HashMap<String, androidx.compose.foundation.ScrollState>()
    fun rowState(k: String) = rowStates.getOrPut(k) { androidx.compose.foundation.lazy.LazyListState() }
    fun pageScroll(k: String) = pageScrolls.getOrPut(k) { androidx.compose.foundation.ScrollState(0) }

    /** Zurück im Inhalt einer Seite: erst in die Seitenleiste auf den Eintrag dieser Seite. */
    fun backToNav(): Boolean {
        val n = when (stack.lastOrNull()) { Screen.Watch -> "watch"; Screen.Favs -> "fav"; Screen.ResumeAll -> "resume"; Screen.Guide -> "epg"; Screen.Settings -> "settings"; else -> null }
        if (n == null || contentFocus == null) return false
        contentFocus = null
        leftFocus = "nav:" + n
        navFocusReq = "nav:" + n
        return true
    }
    var settingsTab by mutableStateOf(0)

    fun push(s: Screen) { stack.add(s) }

    fun back(): Boolean {
        if (favPick != null) { favPick = null; return true }
        if (updatePrompt != null) { updatePrompt = null; return true }
        if (upNext != null) { cancelUpNext(); return true }
        if (chanPanel) { chanPanel = false; return true }
        if (stack.size <= 1) return false
        val top = stack.last()
        if (top is Screen.Play) { playUrl = null; chanPanel = false; cancelUpNext() }
        if (top is Screen.Browse) editMode = false
        stack.removeAt(stack.size - 1)
        if (top is Screen.Guide && guideDirect && stack.size > 1 && stack.last() is Screen.Browse) stack.removeAt(stack.size - 1)
        error = null
        if (stack.lastOrNull() == Screen.Home) homeAnchor?.let { leftFocus = "nav:" + it }
        if (top is Screen.EditCats || top is Screen.EditChans) refreshAfterEdit()
        return true
    }

    private fun refreshAfterEdit() {
        val valid = categories.any { it.id == selCat }
        selectCategory(if (valid) selCat!! else categories.firstOrNull { it.id != "fav" }?.id ?: "fav")
    }

    // ---------- Portale ----------
    fun savePortal(p: Portal) {
        val i = portals.indexOfFirst { it.id == p.id }
        if (i >= 0) portals[i] = p else portals.add(p)
        store.save(portals.toList())
        refreshAllPortals(true)
    }

    private var moveJob: Job? = null

    /** Portal in der Reihenfolge verschieben (d = -1 hoch, +1 runter). Gilt danach überall. */
    fun movePortal(p: Portal, d: Int) {
        val i = portals.indexOfFirst { it.id == p.id }
        val j = i + d
        if (i < 0 || j !in portals.indices) return
        portals.add(j, portals.removeAt(i))
        store.save(portals.toList())
        // Zusammengeführte Listen erst neu aufbauen, wenn nicht mehr weiterverschoben wird
        moveJob?.cancel()
        moveJob = viewModelScope.launch {
            delay(1200)
            if (portals.any { status[it.id] == "ok" }) buildMerged()
        }
    }

    fun deletePortal(p: Portal) {
        portals.removeAll { it.id == p.id }
        store.save(portals.toList())
        status.remove(p.id)
        clients.remove(p.id)
        refreshAllPortals()
    }

    /** Verbindet ALLE Portale und legt sie zu einem gemeinsamen Katalog zusammen. */
    fun refreshAllPortals(force: Boolean = false) {
        forceRefresh = force
        refreshJob?.cancel()
        if (portals.isEmpty()) {
            client = null; portal = null
            homeNew = emptyList(); homeChannels = emptyList(); cachedChannels = null
            allLoading = false
            return
        }
        refreshJob = viewModelScope.launch {
            allLoading = true
            try {
                val jobs = portals.toList().map { p -> async { connectOne(p) } }
                // Nicht ewig auf ein langsames Portal warten: nach 12 s mit den fertigen starten
                kotlinx.coroutines.withTimeoutOrNull(12_000) { jobs.awaitAll() }
                buildMerged()
                allLoading = false
                if (jobs.any { !it.isCompleted }) {
                    jobs.forEach { it.join() }
                    if (portals.any { status[it.id] == "ok" }) buildMerged()
                }
            } finally {
                allLoading = false
            }
        }
    }

    private suspend fun connectOne(p: Portal) {
        status[p.id] = "loading"
        try {
            val c = refreshSem.withPermit {
                withContext(Dispatchers.IO) {
                    val sc = StalkerClient(p)
                    sc.cacheDir = cacheRoot
                    sc.noCache = forceRefresh
                    sc.connect()
                    sc
                }
            }
            clients[p.id] = c
            status[p.id] = "ok"
            // Abo-Info im Hintergrund holen, damit sie den Start nicht bremst
            viewModelScope.launch {
                val raw = withContext(Dispatchers.IO) { runCatching { c.accountInfo() }.getOrDefault("") }
                c.accountEnd = raw
                portalInfoRaw[p.id] = raw
                val expMs = parseExpiry(raw)
                if (expMs > 0) portalExpiry[p.id] = expMs else portalExpiry.remove(p.id)
                infoTick++
            }
        } catch (e: Exception) {
            clients.remove(p.id)
            status[p.id] = "err:" + (e.message ?: "Fehler")
            AppLog.add("Portal " + p.name + ": " + (e.message ?: "nicht erreichbar"))
        }
    }

    /** Aktualisiert nur ein einzelnes Portal (ohne Zwischenspeicher), die anderen bleiben unberührt. */
    fun refreshSingle(p: Portal) {
        if (status[p.id] == "loading") return
        viewModelScope.launch {
            forceRefresh = true
            try { connectOne(p) } finally { forceRefresh = false }
            if (portals.any { status[it.id] == "ok" }) buildMerged()
            showNotice(if (status[p.id] == "ok") p.name + " aktualisiert" else p.name + ": nicht erreichbar")
        }
    }

    private fun buildMerged() {
        val parts = portals.mapNotNull { p -> clients[p.id]?.let { MultiPart(p.id.take(8), it, p.name) } }
        if (parts.isEmpty()) {
            client = null
            homeNew = emptyList(); homeChannels = emptyList()
            return
        }
        client = MultiClient(parts, dedupe)
        portal = Portal("all", "Alle Portale", "", "")
        epgCache.clear()
        linkCache.clear()
        cachedChannels = null
        liveCats = emptyList()
        homeNew = emptyList(); homeChannels = emptyList()
        refreshWatchIds()
        refreshSeen()
        loadHome()
    }

    /** Verbindet ein Portal im Hintergrund und lädt die Senderliste vor. */
    fun refreshPortal(p: Portal) {
        status[p.id] = "loading"
        viewModelScope.launch {
            try {
                val cache = refreshSem.withPermit {
                    withContext(Dispatchers.IO) {
                        val c = StalkerClient(p)
                        c.connect()
                        val ch = try { c.channels() } catch (e: Exception) { emptyList() }
                        PortalCache(c, System.currentTimeMillis(), ch)
                    }
                }
                caches[p.id] = cache
                status[p.id] = "ok:${cache.channels.size}"
            } catch (e: Exception) {
                caches.remove(p.id)
                status[p.id] = "err:" + (e.message ?: "Fehler")
            }
        }
    }

    fun openPortal(p: Portal) {
        val tPortal = System.currentTimeMillis()
        val cache = caches[p.id]
        if (cache != null && System.currentTimeMillis() - cache.at < 10 * 60_000) {
            client = cache.client
            portal = p
            epgCache.clear()
            cachedChannels = cache.channels
            homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            AppLog.add("Zeit: Portal " + p.name + " geöffnet in " + (System.currentTimeMillis() - tPortal) + " ms (Zwischenspeicher)")
            loadHome()
            return
        }
        val c = StalkerClient(p)
        io({ c.connect() }) {
            client = c; portal = p; epgCache.clear()
            cachedChannels = null; homeNew = emptyList(); homeChannels = emptyList()
            liveCats = emptyList(); refreshWatchIds()
            push(Screen.Home)
            AppLog.add("Zeit: Portal " + p.name + " verbunden in " + (System.currentTimeMillis() - tPortal) + " ms")
            loadHome()
        }
    }

    // ---------- Durchsuchen ----------
    private class BrowseData(val cats: List<Category>, val ch: List<Item>, val favs: List<Item>,
                             val hiddenCats: Set<String>, val hiddenChans: Set<String>, val hiddenItems: Set<String>, val userMs: Long,
                             val tStart: Long, val tCats: Long, val tEnd: Long)

    private class CatEntry(val client: Any, val at: Long, val cats: List<Category>)
    private val catCache = java.util.concurrent.ConcurrentHashMap<String, CatEntry>()
    private var warming = false

    private fun catsFresh(c: Any, type: String): List<Category>? {
        val e = catCache[type] ?: return null
        return if (e.client === c && System.currentTimeMillis() - e.at < 10 * 60_000L) e.cats else null
    }

    /** Nur vollständige Antworten merken (alle aktiven Portale haben geantwortet). */
    private fun rememberCats(c: StalkerClient, type: String, cats: List<Category>) {
        if (cats.isEmpty()) return
        if (c is MultiClient && c.groups(type).size < portals.count { clients[it.id] != null }) return
        catCache[type] = CatEntry(c, System.currentTimeMillis(), cats)
    }

    private fun loadCats(c: StalkerClient, type: String): List<Category> =
        catsFresh(c, type) ?: c.categories(type).also { rememberCats(c, type, it) }

    /** Lädt die Kategorien der anderen Bereiche schon im Hintergrund, damit der Menüwechsel sofort geht. */
    private fun warmCats() {
        val c = client ?: return
        if (warming) return
        warming = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                for (t in listOf("vod", "series", "itv")) {
                    delay(if (t == "vod") 500L else 800L)
                    if (client !== c) break
                    if (t != "itv") {
                        val cats = catsFresh(c, t) ?: runCatching { loadCats(c, t) }.getOrNull() ?: continue
                        runCatching { warmFirstPage(c, t, cats) }
                    } else if (catsFresh(c, t) == null) runCatching { loadCats(c, t) }
                }
            } finally { warming = false }
        }
    }

    /** Seite 1 der Kategorie, die beim Öffnen des Bereichs zuerst gezeigt wird, schon im Voraus holen. */
    private fun warmFirstPage(c: StalkerClient, t: String, cats: List<Category>) {
        val p = portal ?: return
        val groups = (c as? MultiClient)?.groups(t) ?: emptyList()
        val cat = if (groupedView && groups.isNotEmpty()) "*" else {
            val hidden = userData.hiddenCats(p.id, t)
            orderCats(cats.filter { it.id !in hidden }, t).firstOrNull { it.id != "fav" }?.id ?: return
        }
        prefetchPage(c, t, cat, "", 1)
        prefetchPage(c, t, cat, "", 2)
    }

    private fun gcMs(): Long = try { android.os.Debug.getRuntimeStat("art.gc.blocking-gc-time")?.toLongOrNull() ?: 0L } catch (e: Throwable) { 0L }

    fun openBrowse(type: String, thenGuide: Boolean = false) {
        val c = client ?: return
        val p = portal ?: return
        val tOpen = System.currentTimeMillis()
        val gc0 = gcMs()
        val freshCats = catsFresh(c, type)
        val wasCached = freshCats != null
        // Alles schon im Speicher: sofort anzeigen, ohne Umweg über den Hintergrund und ohne Ladekreis
        if (freshCats != null && (type != "itv" || cachedChannels != null)) {
            val now = System.currentTimeMillis()
            val bd = BrowseData(freshCats, if (type == "itv") (cachedChannels ?: emptyList()) else emptyList(),
                userData.favs(p.id, type), userData.hiddenCats(p.id, type), userData.hiddenChans(p.id),
                userData.hiddenItems(p.id, type), System.currentTimeMillis() - now, now, now, System.currentTimeMillis())
            applyBrowse(type, c, bd, tOpen, gc0, true, thenGuide)
            return
        }
        io({
            val tStart = System.currentTimeMillis()
            val cats = loadCats(c, type)
            val tCats = System.currentTimeMillis()
            val ch: List<Item> = if (type == "itv") (cachedChannels ?: c.channels().also { cachedChannels = it }) else emptyList()
            // Gespeicherte Listen schon hier im Hintergrund einlesen, nicht auf dem Hauptthread
            val tU = System.currentTimeMillis()
            BrowseData(cats, ch, userData.favs(p.id, type), userData.hiddenCats(p.id, type),
                userData.hiddenChans(p.id), userData.hiddenItems(p.id, type), System.currentTimeMillis() - tU,
                tStart, tCats, System.currentTimeMillis())
        }) { bd -> applyBrowse(type, c, bd, tOpen, gc0, wasCached, thenGuide) }
    }

    private fun applyBrowse(type: String, c: StalkerClient, bd: BrowseData, tOpen: Long, gc0: Long, wasCached: Boolean, thenGuide: Boolean) {
        val tApply = System.currentTimeMillis()
        val cats = bd.cats; val ch = bd.ch
        browseType = type; allChannels = ch; items = emptyList(); query = ""; queryText = ""
        favs = bd.favs
        allCats = cats
        if (type == "itv") liveCats = cats
        portalGroups = (c as? MultiClient)?.groups(type) ?: emptyList()
        if (!expandedInit && portalGroups.isNotEmpty()) {
            expandedPortals = portalGroups.map { it.pfx }.toSet()
            expandedInit = true
            settings.edit().putStringSet("expanded", expandedPortals).apply()
        }
        hiddenCats = bd.hiddenCats
        hiddenChans = bd.hiddenChans
        hiddenItems = bd.hiddenItems
        editMode = false
        applyCategories()
        push(Screen.Browse(type))
        val tEnd = System.currentTimeMillis()
        val rt = Runtime.getRuntime()
        AppLog.add("Zeit: Bereich " + type + " geöffnet in " + (tEnd - tOpen) + " ms (Start " + (bd.tStart - tOpen) + ", Kategorien " + (bd.tCats - bd.tStart) +
            ", Rückkehr " + (tApply - bd.tEnd) + ", Aufbau " + (tEnd - tApply) + ", GC " + (gcMs() - gc0) + ", Heap " +
            ((rt.totalMemory() - rt.freeMemory()) / 1048576) + "/" + (rt.maxMemory() / 1048576) + " MB)" + (if (wasCached) " (Zwischenspeicher)" else ""))
        selectCategory(if (groupedView && portalGroups.isNotEmpty()) "*" else (categories.firstOrNull { it.id != "fav" }?.id ?: "fav"))
        if (thenGuide) push(Screen.Guide)
        warmCats()
    }

    private fun channelOk(c: Item): Boolean = !(dedupe && c.dup)

    private fun visibleChannels(): List<Item> =
        allChannels.filter { it.id !in hiddenChans && it.cat !in hiddenCats && channelOk(it) }

    private fun listFor(id: String): List<Item> = when (id) {
        "fav" -> favs
        "*" -> visibleChannels()
        else -> if (id.startsWith("fl:")) listItems(id.removePrefix("fl:")) else if (id.startsWith("p:")) {
            val rest = id.removePrefix("p:")
            val pfx = rest.substringBefore(':')
            val key = rest.substringAfter(':')
            if (key == "fav") favs.filter { it.id.startsWith("$pfx|") }
            else allChannels.filter {
                it.id.startsWith("$pfx|") && (key == "*" || it.cat == key) && it.id !in hiddenChans
            }
        } else allChannels.filter { it.cat == id && it.id !in hiddenChans && channelOk(it) }
    }

    fun selectCategory(id: String) {
        selCat = id; gen++; query = ""; queryText = ""
        viewModelScope.launch { listState.scrollToItem(0); gridState.scrollToItem(0) }
        if (id.endsWith(":resume")) {
            items = emptyList(); hasMore = false
            resumePfx = id.removePrefix("p:").substringBefore(':')
            loadResumeShown()
        } else if (id == "fav" || id.endsWith(":fav") || browseType == "itv") {
            items = listFor(id); hasMore = false
        } else {
            items = emptyList(); hasMore = false; page = 0; loaded = 0
            loadMore()
        }
    }

    fun search(q: String) {
        val t = q.trim()
        if (browseType == "itv") {
            items = if (t.isEmpty()) listFor(selCat ?: "*")
            else visibleChannels().filter { it.name.contains(t, ignoreCase = true) }
            return
        }
        if (t == query) return
        query = t; gen++; page = 0; loaded = 0; items = emptyList(); hasMore = false
        if (t.isEmpty()) {
            categories.firstOrNull { it.id != "fav" }?.let { selectCategory(it.id) }
        } else {
            selCat = "*"
            loadMore()
        }
    }

    private class PageEntry(val client: Any, val at: Long, val pg: PageResult)
    private val pageCache = java.util.concurrent.ConcurrentHashMap<String, PageEntry>()

    private fun pageKey(t: String, cat: String, qy: String, n: Int) = "$t|$cat|$qy|$n"

    private fun cachedPage(c: Any, key: String): PageResult? {
        val e = pageCache[key] ?: return null
        return if (e.client === c && System.currentTimeMillis() - e.at < 8 * 60_000L) e.pg else null
    }

    private fun rememberPage(c: Any, key: String, pg: PageResult) {
        if (pg.items.isEmpty()) return
        if (pageCache.size > 80) {
            pageCache.entries.sortedBy { it.value.at }.take(30).forEach { pageCache.remove(it.key) }
        }
        pageCache[key] = PageEntry(c, System.currentTimeMillis(), pg)
    }

    /** Holt die nächste Seite im Hintergrund, damit das Weiterscrollen nicht wartet. */
    private fun prefetchPage(c: StalkerClient, t: String, cat: String, qy: String, n: Int) {
        if (NetState.weak) return
        val key = pageKey(t, cat, qy, n)
        if (cachedPage(c, key) != null) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { c.list(t, cat, n, qy) }.getOrNull()?.let { rememberPage(c, key, it) }
        }
    }

    fun loadMore() {
        val c = client ?: return
        val cat = selCat ?: return
        if (browseType == "itv" || cat == "fav" || cat.endsWith(":fav") || cat.endsWith(":resume") || busyList) return
        val g = gen; val next = page + 1; val t = browseType; val qy = query
        busyList = true
        viewModelScope.launch {
            try {
                val t0 = System.currentTimeMillis()
                val key = pageKey(t, cat, qy, next)
                val hit = cachedPage(c, key)
                val pg = hit ?: withContext(Dispatchers.IO) { c.list(t, cat, next, qy) }.also { rememberPage(c, key, it) }
                if (next <= 2) AppLog.add("Zeit: Liste " + t + " Seite " + next + " in " + (System.currentTimeMillis() - t0) + " ms" + (if (hit != null) " (Zwischenspeicher)" else ""))
                if (g == gen) {
                    page = next; loaded += pg.items.size; items = items + pg.items
                    hasMore = pg.items.isNotEmpty() &&
                        (if (pg.total > 0) loaded < pg.total else pg.items.size >= pg.pageSize)
                    if (hasMore) prefetchPage(c, t, cat, qy, next + 1)
                }
            } catch (e: Exception) {
                if (g == gen) { error = e.message ?: "Fehler"; hasMore = false; AppLog.add("Liste laden: " + e.message) }
            } finally {
                busyList = false
                if (g != gen) loadMore()
            }
        }
    }

    // ---------- Kategorien und Kanäle bearbeiten ----------
    private fun applyCategories() {
        val extra = if (browseType == "itv") favLists.map { Category("fl:" + it.id, "★ " + it.name) } else emptyList()
        categories = listOf(Category("fav", "★ Favoriten")) + extra + orderCats(allCats.filter { it.id !in hiddenCats })
    }

    // ----- Reihenfolge der Kategorien (pro Bereich gespeichert) -----
    private val catOrderMap = mutableStateMapOf<String, List<String>>()
    var orderTick by mutableIntStateOf(0)
    init {
        for (t in listOf("itv", "vod", "series")) {
            catOrderMap[t] = try {
                val a = org.json.JSONArray(settings.getString("corder_$t", "[]"))
                (0 until a.length()).map { a.getString(it) }
            } catch (e: Exception) { emptyList() }
        }
    }

    fun orderCats(list: List<Category>, type: String = browseType): List<Category> {
        val o = catOrderMap[type] ?: return list
        if (o.isEmpty()) return list
        val idx = HashMap<String, Int>()
        o.forEachIndexed { i, id -> idx[id] = i }
        return list.withIndex()
            .sortedWith(compareBy({ idx[it.value.id] ?: Int.MAX_VALUE }, { it.index }))
            .map { it.value }
    }

    private fun saveOrder(ids: List<String>) {
        catOrderMap[browseType] = ids
        settings.edit().putString("corder_$browseType", org.json.JSONArray(ids).toString()).apply()
        orderTick++
        applyCategories()
    }

    fun moveCat(id: String, delta: Int) {
        val cur = orderCats(allCats).map { it.id }.toMutableList()
        val i = cur.indexOf(id)
        val j = i + delta
        if (i < 0 || j < 0 || j >= cur.size) return
        cur.removeAt(i); cur.add(j, id)
        saveOrder(cur)
    }

    /** "provider" = Reihenfolge des Anbieters, "az" = alphabetisch, "de" = deutsche Gruppen zuerst. */
    fun sortCats(mode: String) {
        when (mode) {
            "provider" -> {
                catOrderMap[browseType] = emptyList()
                settings.edit().remove("corder_$browseType").apply()
                orderTick++
                applyCategories()
            }
            "az" -> saveOrder(allCats.sortedBy { it.title.lowercase() }.map { it.id })
            else -> {
                val pref = listOf("DE", "AT", "CH")
                val first = allCats.filter { countryOf(it.title) in pref }
                    .sortedBy { pref.indexOf(countryOf(it.title)) }
                saveOrder((first + allCats.filter { it !in first }).map { it.id })
            }
        }
    }

    // ----- Länder erkennen (Kategorien wie "DE | Sport") -----
    private val notCountry = setOf("TV", "HD", "SD", "FHD", "UHD", "VOD", "PPV", "XXX", "HEVC", "RAW", "NEW", "TOP")
    private val countryRe = Regex("^[\\s\\[\\(|]*([A-Za-z]{2,3})[\\s\\]\\)]*[|:\\-–/»>_]")

    fun countryOf(title: String): String {
        val m = countryRe.find(title) ?: return ""
        val c = m.groupValues[1]
        return if (c == c.uppercase() && c !in notCountry) c else ""
    }

    /** Erkannte Länder mit Anzahl der Kategorien, größte zuerst. */
    fun countryGroups(): List<Pair<String, Int>> =
        allCats.map { countryOf(it.title) }.filter { it.isNotEmpty() }
            .groupingBy { it }.eachCount().filter { it.value >= 2 }.toList().sortedByDescending { it.second }

    /** 2 = alle sichtbar, 0 = alle ausgeblendet, 1 = gemischt */
    fun countryState(code: String): Int {
        val ids = allCats.filter { countryOf(it.title) == code }.map { it.id }
        val vis = ids.count { it !in hiddenCats }
        return if (vis == ids.size) 2 else if (vis == 0) 0 else 1
    }

    fun toggleCountry(code: String) {
        val ids = allCats.filter { countryOf(it.title) == code }.map { it.id }
        hiddenCats = if (countryState(code) == 2) hiddenCats + ids else hiddenCats - ids.toSet()
        saveHiddenCats(); applyCategories()
    }

    private fun saveHiddenCats() { portal?.let { userData.saveHiddenCats(it.id, browseType, hiddenCats) } }
    private fun saveHiddenChans() { portal?.let { userData.saveHiddenChans(it.id, hiddenChans) } }

    fun toggleCat(id: String) {
        hiddenCats = if (id in hiddenCats) hiddenCats - id else hiddenCats + id
        saveHiddenCats(); applyCategories()
    }

    fun setCats(ids: List<String>, show: Boolean) {
        hiddenCats = if (show) hiddenCats - ids.toSet() else hiddenCats + ids
        saveHiddenCats(); applyCategories()
    }

    fun setAllCats(show: Boolean) {
        hiddenCats = if (show) emptySet() else allCats.map { it.id }.toSet()
        saveHiddenCats(); applyCategories()
    }

    private fun catMatches(title: String, kws: List<String>): Boolean {
        val tokens = title.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
        return kws.any { k -> tokens.any { t -> t == k || (k.length >= 4 && t.startsWith(k)) } }
    }

    /** Zeigt nur Kategorien, in denen eines der Suchwörter als Wort vorkommt (z. B. DE, German). */
    fun showOnlyMatching(keywords: String) {
        val kws = keywords.lowercase().split(Regex("[,;\\s]+")).filter { it.isNotEmpty() }
        if (kws.isEmpty()) return
        val match = allCats.filter { catMatches(it.title, kws) }
        if (match.isEmpty()) { showNotice("Keine passende Kategorie gefunden"); return }
        var keep = match.map { it.id }.toSet()
        if (browseType == "itv") keep = keep + "*"
        hiddenCats = allCats.map { it.id }.filter { it !in keep }.toSet()
        saveHiddenCats(); applyCategories()
        showNotice("${match.size} Kategorien sichtbar")
    }

    fun openEditChannels() {
        editChans = when (selCat) {
            null, "fav", "*" -> allChannels.filter { it.cat !in hiddenCats }
            else -> allChannels.filter { it.cat == selCat }
        }
        push(Screen.EditChans)
    }

    fun toggleChan(id: String) {
        hiddenChans = if (id in hiddenChans) hiddenChans - id else hiddenChans + id
        saveHiddenChans()
    }

    fun setChansHidden(ids: List<String>, hide: Boolean) {
        hiddenChans = if (hide) hiddenChans + ids else hiddenChans - ids.toSet()
        saveHiddenChans()
    }

    // ---------- Filme und Serien ausblenden ----------
    fun toggleEditMode() { editMode = !editMode }

    /** Anzeige-Liste: im Ausblenden-Modus und bei Favoriten ungefiltert. */
    private var shownKey: Array<Any?>? = null
    private var shownVal: List<Item> = emptyList()
    private val yearRx = Regex("\\d{4}")

    /** Gefilterte und sortierte Liste – wird nur neu berechnet, wenn sich etwas geändert hat. */
    fun shownItems(): List<Item> {
        val key = arrayOf<Any?>(items, editMode, selCat, hiddenItems, qualFilter, hideSeen, seenKeys, sortMode, browseType)
        val old = shownKey
        if (old != null && old.size == key.size && key.indices.all { i ->
                val a = old[i]; val b = key[i]
                if (a is Collection<*> || b is Collection<*>) a === b else a == b
            }) return shownVal
        val r = computeShown()
        shownKey = key; shownVal = r
        return r
    }

    private fun computeShown(): List<Item> {
        val base = if (editMode || selCat == "fav" || selCat?.endsWith(":fav") == true) items
            else items.filter { it.id !in hiddenItems }
        if (browseType == "itv" || editMode) return base
        var l = base
        when (qualFilter) {
            1 -> l = l.filter { "4K" in qualityBadges(it.name) }
            2 -> l = l.filter { "HDR" in qualityBadges(it.name) }
            3 -> l = l.filter { val b = qualityBadges(it.name); "4K" in b || "FHD" in b }
        }
        if (hideSeen && browseType == "vod") l = l.filter { ("mv|" + it.cmd) !in seenKeys }
        val yr = { it: Item -> yearRx.find(it.year)?.value?.toIntOrNull() ?: 0 }
        return when (sortMode) {
            1 -> l.map { it.name.lowercase() to it }.sortedBy { it.first }.map { it.second }
            2 -> l.map { it.name.lowercase() to it }.sortedByDescending { it.first }.map { it.second }
            3 -> l.map { yr(it) to it }.sortedByDescending { it.first }.map { it.second }
            4 -> l.map { (yr(it).let { y -> if (y == 0) 9999 else y }) to it }.sortedBy { it.first }.map { it.second }
            else -> l
        }
    }

    var sortMode by mutableIntStateOf(settings.getInt("sortMode", 0))
    var qualFilter by mutableIntStateOf(0)
    var hideSeen by mutableStateOf(false)
    fun sortLabel(): String = when (sortMode) { 1 -> "A–Z"; 2 -> "Z–A"; 3 -> "Jahr neu → alt"; 4 -> "Jahr alt → neu"; else -> "Portal-Reihenfolge" }
    fun qualLabel(): String = when (qualFilter) { 1 -> "nur 4K"; 2 -> "nur HDR"; 3 -> "FHD und 4K"; else -> "alle" }
    fun cycleSort() { sortMode = (sortMode + 1) % 5; settings.edit().putInt("sortMode", sortMode).apply() }
    fun cycleQual() { qualFilter = (qualFilter + 1) % 4 }
    fun toggleHideSeen() { hideSeen = !hideSeen }

    fun toggleItemHidden(item: Item) {
        val p = portal ?: return
        val was = item.id in hiddenItems
        hiddenItems = if (was) hiddenItems - item.id else hiddenItems + item.id
        userData.saveHiddenItems(p.id, browseType, hiddenItems)
        showNotice(if (was) "Wieder eingeblendet" else "Ausgeblendet")
    }

    // ---------- Portal per Handy hinzufügen (QR-Code) ----------
    fun startPhoneAdd() {
        stopPhoneAdd()
        val ip = PortalServer.localIp()
        if (ip == null) {
            error = "Keine Netzwerkverbindung gefunden. Verbinde die Box mit dem WLAN oder LAN."
            return
        }
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val token = (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
        val srv = PortalServer(token, onBackup = { exportBackup() }, onRestore = { importBackup(it) },
            onLog = { AppLog.text() }) { p ->
            viewModelScope.launch {
                savePortal(p)
                showNotice("Portal „${p.name}“ hinzugefügt")
            }
        }
        try {
            val port = srv.start()
            phoneServer = srv
            qrUrl = "http://$ip:$port/$token"
        } catch (e: Exception) {
            error = "Server konnte nicht gestartet werden: ${e.message}"
        }
    }

    fun stopPhoneAdd() {
        phoneServer?.stop()
        phoneServer = null
        qrUrl = null
    }

    // ---------- Fernzugriff per Handy (anderes Netzwerk, über Koppel-Code) ----------
    var remoteOn by mutableStateOf(settings.getBoolean("remoteOn", false))
    var remoteCode by mutableStateOf(settings.getString("remoteCode", "") ?: "")
    var remoteSeen by mutableStateOf(0L)
    var remoteStatus by mutableStateOf("")
    private var remoteLastErr = ""
    private var remoteJob: Job? = null
    private val remoteDone = ArrayList<String>()
    init { remoteStart() }

    fun remoteSwitch() {
        if (!remoteOn && remoteCode.isEmpty()) remoteCode = RemoteRelay.newCode()
        remoteOn = !remoteOn
        settings.edit().putBoolean("remoteOn", remoteOn).putString("remoteCode", remoteCode).apply()
        remoteStart()
    }

    fun remoteRenew() {
        remoteCode = RemoteRelay.newCode()
        settings.edit().putString("remoteCode", remoteCode).remove("remoteLast").remove("remoteDone").apply()
        remoteDone.clear()
        remoteStart()
    }

    private fun remoteStart() {
        remoteJob?.cancel()
        remoteJob = null
        if (!remoteOn || remoteCode.isEmpty()) return
        val code = remoteCode
        if (remoteDone.isEmpty()) remoteDone.addAll((settings.getString("remoteDone", "") ?: "").split(",").filter { it.isNotEmpty() })
        remoteJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                try { remotePoll(code) }
                catch (e: kotlinx.coroutines.CancellationException) { throw e }
                catch (e: Exception) {
                    val em = e.javaClass.simpleName + " " + (e.message ?: "")
                    if (em != remoteLastErr) { remoteLastErr = em; AppLog.add("Fernzugriff: " + em) }
                    withContext(Dispatchers.Main) { remoteStatus = "Relay nicht erreichbar: " + em.take(80) }
                    if ((e.message ?: "").contains("HTTP 4")) settings.edit().remove("remoteLast").apply()
                    delay(15_000)
                }
                delay(6_000)
            }
        }
    }

    private suspend fun remotePoll(code: String) {
        val last = settings.getString("remoteLast", null)
        // Ohne gemerkte ID alles Gespeicherte holen (unabhängig von der Uhr der Box); bereits erledigte Befehle werden übersprungen
        val msgs = RemoteRelay.fetch(code, "c", last ?: "all")
        val bad = msgs.count { it.text == null }
        withContext(Dispatchers.Main) {
            remoteStatus = "Relay erreichbar, letzte Abfrage " +
                java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.GERMANY).format(java.util.Date()) +
                (if (bad > 0) " · $bad Nachricht(en) mit falschem Code" else "")
        }
        for (m in msgs) {
            settings.edit().putString("remoteLast", m.id).apply()
            val t = m.text ?: continue
            val j = try { JSONObject(t) } catch (e: Exception) { continue }
            val n = j.optString("n")
            if (n.isEmpty() || n in remoteDone) continue
            remoteDone.add(n)
            if (remoteDone.size > 60) remoteDone.removeAt(0)
            settings.edit().putString("remoteDone", remoteDone.joinToString(",")).apply()
            val reply = withContext(Dispatchers.Main) { remoteSeen = System.currentTimeMillis(); remoteExec(j) }
            RemoteRelay.publish(code, "r", reply)
        }
    }

    private fun remoteExec(j: JSONObject): JSONObject {
        var ok = true
        var msg = ""
        when (j.optString("op")) {
            "add" -> {
                val name = j.optString("name").trim()
                val url = j.optString("url").trim()
                val mac = j.optString("mac").trim().uppercase().replace('-', ':')
                val err = when {
                    name.isEmpty() -> "Bitte einen Namen eingeben."
                    !url.startsWith("http", ignoreCase = true) -> "Die Portal-URL muss mit http:// oder https:// beginnen."
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(mac) -> "Die MAC-Adresse muss so aussehen: 00:1A:79:XX:XX:XX"
                    else -> null
                }
                if (err != null) { ok = false; msg = err }
                else {
                    savePortal(Portal(java.util.UUID.randomUUID().toString(), name, url, mac, j.optString("login").trim(), j.optString("password")))
                    msg = "✓ „$name“ hinzugefügt"
                    showNotice("Portal „$name“ per Fernzugriff hinzugefügt")
                }
            }
            "del" -> {
                val p = portals.firstOrNull { it.id == j.optString("id") }
                if (p == null) { ok = false; msg = "Portal nicht gefunden (Liste aktualisieren)." }
                else {
                    deletePortal(p)
                    msg = "✓ „${p.name}“ gelöscht"
                    showNotice("Portal „${p.name}“ per Fernzugriff gelöscht")
                }
            }
            "list" -> msg = "Verbunden"
            else -> { ok = false; msg = "Unbekannter Befehl" }
        }
        val r = JSONObject()
        r.put("n", j.optString("n"))
        r.put("ok", ok)
        r.put("msg", msg)
        val arr = JSONArray()
        portals.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url.take(60))) }
        r.put("portals", arr)
        return r
    }

    override fun onCleared() {
        stopPhoneAdd()
        super.onCleared()
    }

    // ---------- Navigation über die Seitenleiste ----------
    fun goTo(id: String) {
        leftFocus = null
        contentFocus = null
        itemFocus = null
        homeAnchor = if (id == "home") null else id
        guideDirect = id == "epg"
        rowStates.clear()
        pageScrolls.clear()
        playUrl = null
        chanPanel = false
        while (stack.size > 1) stack.removeAt(stack.size - 1)
        editMode = false
        error = null
        when (id) {
            "portals" -> push(Screen.Portals)
            "itv", "vod", "series" -> openBrowse(id)
            "epg" -> openBrowse("itv", true)
            "fav" -> push(Screen.Favs)
            "watch" -> push(Screen.Watch)
            "resume" -> { resumeList = portal?.let { userData.resumes(it.id) } ?: emptyList(); push(Screen.ResumeAll) }
            "settings" -> push(Screen.Settings)
        }
    }

    // ---------- Fernsehkomfort: letzter Sender, Nummern, Quelle, Sleep-Timer ----------
    var numberBuffer by mutableStateOf("")
    private var numberJob: Job? = null
    private var prevChId = ""
    var sleepMinutes by mutableStateOf(0)
    private var sleepJob: Job? = null
    var resumeLastOnStart by mutableStateOf(settings.getBoolean("resumeLast", false))
    private var startupResumeDone = false

    private fun nameKey(c: Item): String = c.name.trim().lowercase()

    /** Wechselt direkt zu einem Sender (Zahleneingabe, letzter Sender, Quellenwahl). */
    private fun switchTo(ch: Item) {
        if (zapList.none { it.id == ch.id }) zapList = listOf(ch)
        zapIndex = zapList.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        startLive()
    }

    fun toggleLast() {
        val prev = cachedChannels?.firstOrNull { it.id == prevChId }
        if (prev == null) {
            showNotice("Kein letzter Sender")
            return
        }
        switchTo(prev)
    }

    fun digit(d: Int) {
        if (numberBuffer.length >= 4) return
        numberBuffer += d.toString()
        numberJob?.cancel()
        numberJob = viewModelScope.launch {
            delay(1500)
            commitNumber()
        }
    }

    fun commitNumber() {
        numberJob?.cancel()
        val n = numberBuffer.toIntOrNull()
        numberBuffer = ""
        if (n == null) return
        if (n == 0) {
            toggleLast()
            return
        }
        val all = cachedChannels ?: return
        val hit = zapList.firstOrNull { it.num == n } ?: all.firstOrNull { it.num == n && !it.dup }
        if (hit == null) showNotice("Kein Sender mit Nummer $n") else switchTo(hit)
    }

    /** Alle Quellen (Portale) für den gerade laufenden Sender. */
    fun alternativesFor(id: String): List<Pair<String, Item>> {
        val all = cachedChannels ?: return emptyList()
        val cur = all.firstOrNull { it.id == id } ?: return emptyList()
        val key = nameKey(cur)
        return all.filter { nameKey(it) == key }.map { c ->
            val pfx = c.id.substringBefore('|')
            (portals.firstOrNull { it.id.take(8) == pfx }?.name ?: "Portal") to c
        }
    }

    fun sourceName(): String {
        val pfx = playChId.substringBefore('|')
        return portals.firstOrNull { it.id.take(8) == pfx }?.name ?: "-"
    }

    fun chooseSource(ch: Item) {
        settings.edit().putString("src:" + nameKey(ch), ch.id.substringBefore('|')).apply()
        showNotice("Quelle gemerkt")
        switchTo(ch)
    }

    fun cycleSleep() {
        sleepMinutes = when (sleepMinutes) {
            0 -> 30
            30 -> 60
            60 -> 90
            else -> 0
        }
        sleepJob?.cancel()
        if (sleepMinutes > 0) {
            val m = sleepMinutes
            showNotice("Sleep-Timer: $m Minuten")
            sleepJob = viewModelScope.launch {
                delay(m * 60_000L)
                sleepMinutes = 0
                showNotice("Sleep-Timer: Gute Nacht")
                goTo("home")
            }
        } else {
            showNotice("Sleep-Timer aus")
        }
    }

    fun toggleResumeLast() {
        resumeLastOnStart = !resumeLastOnStart
        settings.edit().putBoolean("resumeLast", resumeLastOnStart).apply()
    }

    // ---------- Zuletzt gesehene Sender ----------
    var recentChans by mutableStateOf<List<Item>>(emptyList())
    private var recentJob: Job? = null

    private fun scheduleRecent(ch: Item) {
        recentJob?.cancel()
        // Erst nach 8 Sekunden merken, damit Durchzappen die Liste nicht füllt
        recentJob = viewModelScope.launch {
            delay(8000)
            userData.addRecentChan(ch)
            recentChans = userData.recentChans()
        }
    }

    fun openRecent(ch: Item) {
        browseType = "itv"
        favs = portal?.let { userData.favs(it.id, "itv") } ?: emptyList()
        liveContext = "*"
        zapList = recentChans
        zapIndex = recentChans.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        startLive()
    }

    // ---------- Sender-Gesundheit ----------
    private val chFails: MutableMap<String, Int> = HashMap<String, Int>().also { m ->
        runCatching {
            val o = JSONObject(settings.getString("chfail", "{}") ?: "{}")
            o.keys().forEach { k -> m[k] = o.optInt(k) }
        }
        // Einmalig: alte Fehlerlisten und Portal-Bewertungen verwerfen (stammen teils aus der Speicher-Panne)
        if (!settings.getBoolean("reset346", false)) {
            m.clear()
            settings.edit().putBoolean("reset346", true).putString("chfail", "{}").apply()
        }
    }

    private fun saveFails() {
        settings.edit().putString("chfail", JSONObject(chFails as Map<*, *>).toString()).apply()
    }

    fun markBad(id: String) {
        if (id.isEmpty()) return
        chFails[id] = (chFails[id] ?: 0) + 1
        if (chFails.size > 400) chFails.entries.removeAll { it.value <= 1 }
        saveFails()
    }

    fun markGood(id: String) {
        val n = chFails[id] ?: return
        if (n <= 1) chFails.remove(id) else chFails[id] = n - 1
        saveFails()
    }

    // ---------- Erinnerungen für Sendungen ----------
    var reminders by mutableStateOf<List<Reminder>>(loadReminders())
    var dueReminder by mutableStateOf<Reminder?>(null)

    private fun loadReminders(): List<Reminder> = try {
        val a = JSONArray(settings.getString("reminders", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Reminder(o.getString("ch"), o.getString("cn"), o.getString("t"), o.getLong("s"))
        }
    } catch (e: Exception) { emptyList() }

    private fun saveReminders() {
        val a = JSONArray()
        reminders.forEach { r ->
            a.put(JSONObject().put("ch", r.chId).put("cn", r.chName).put("t", r.title).put("s", r.startTs))
        }
        settings.edit().putString("reminders", a.toString()).apply()
    }

    fun isReminder(chId: String, startTs: Long): Boolean = reminders.any { it.chId == chId && it.startTs == startTs }

    fun toggleReminder(ch: Item, e: Epg) {
        if (isReminder(ch.id, e.startTs)) {
            reminders = reminders.filterNot { it.chId == ch.id && it.startTs == e.startTs }
            showNotice("Erinnerung entfernt")
        } else {
            reminders = reminders + Reminder(ch.id, ch.name, e.title, e.startTs)
            showNotice("Erinnerung gesetzt: " + e.title + " (" + e.start + ")")
        }
        saveReminders()
    }

    /** Wird regelmäßig aufgerufen: meldet Sendungen, die gleich beginnen. */
    fun checkReminders() {
        if (reminders.isEmpty()) return
        val now = System.currentTimeMillis() / 1000
        val old = reminders.filter { it.startTs + 900 < now }
        if (old.isNotEmpty()) { reminders = reminders - old.toSet(); saveReminders() }
        if (dueReminder != null) return
        val due = reminders.firstOrNull { it.startTs - 60 <= now && now < it.startTs + 900 } ?: return
        reminders = reminders - due
        saveReminders()
        dueReminder = due
    }

    fun acceptReminder() {
        val r = dueReminder ?: return
        dueReminder = null
        val all = cachedChannels ?: emptyList()
        val ch = all.firstOrNull { it.id == r.chId }
        if (ch == null) { showNotice("Sender nicht gefunden – Portale schon geladen?"); return }
        browseType = "itv"
        liveContext = "*"
        val base = all.filter { it.id !in hiddenChans && it.cat !in hiddenCats && channelOk(it) }
        zapList = if (base.any { it.id == ch.id }) base else listOf(ch)
        zapIndex = zapList.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        startLive()
    }

    fun dismissReminder() { dueReminder = null }

    // ---------- Sprache und Untertitel merken ----------
    var prefAudioLang by mutableStateOf(settings.getString("audioLang", "") ?: "")
    var prefTextLang by mutableStateOf(settings.getString("textLang", "off") ?: "off")

    /** Bei Serienfolgen wird die Wahl pro Serie gemerkt, sonst gilt sie für alles. */
    private fun serieKey(): String? = if (!isLive && lastEp != null && seriesName.isNotEmpty()) seriesName else null

    fun audioLangNow(): String =
        serieKey()?.let { settings.getString("sa|$it", null) } ?: prefAudioLang

    fun textLangNow(): String =
        serieKey()?.let { settings.getString("st|$it", null) } ?: prefTextLang

    fun setAudioLang(l: String) {
        val k = serieKey()
        if (k != null) { settings.edit().putString("sa|$k", l).apply(); return }
        prefAudioLang = l
        settings.edit().putString("audioLang", l).apply()
    }

    fun setTextLang(l: String) {
        val k = serieKey()
        if (k != null) { settings.edit().putString("st|$k", l).apply(); return }
        prefTextLang = l
        settings.edit().putString("textLang", l).apply()
    }

    // ---------- Portal-Status ----------
    val portalExpiry = mutableStateMapOf<String, Long>()
    val portalInfoRaw = mutableStateMapOf<String, String>()
    var infoTick by mutableIntStateOf(0)

    private fun parseExpiry(s: String): Long {
        val t = s.trim()
        if (t.isEmpty() || t == "0" || t == "null") return -1L
        t.toLongOrNull()?.let { return if (it > 10_000_000_000L) it else it * 1000 }
        val fmts = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd", "dd.MM.yyyy", "dd-MM-yyyy",
            "MMMM d, yyyy, h:mm a", "MMMM d, yyyy", "d MMMM yyyy", "MM/dd/yyyy")
        for (f in fmts) {
            try { return java.text.SimpleDateFormat(f, java.util.Locale.ENGLISH).parse(t)!!.time } catch (e: Exception) { }
        }
        return -1L
    }

    private fun daysLeft(ms: Long): Int = Math.floorDiv(ms - System.currentTimeMillis(), 86_400_000L).toInt()

    /** Zeile unter dem Portalnamen: Senderzahl und Ablauf des Abos. */
    fun portalLine(p: Portal): String {
        infoTick
        val parts = ArrayList<String>()
        val n = clients[p.id]?.chanCount ?: 0
        if (n > 0) parts.add("$n Sender")
        val ex = portalExpiry[p.id] ?: -1L
        if (ex > 0) {
            val d = daysLeft(ex)
            val date = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(ex))
            parts.add(if (d < 0) "Abo abgelaufen am $date" else "läuft ab $date (noch $d Tage)")
        } else {
            val raw = portalInfoRaw[p.id].orEmpty()
            if (raw.isNotBlank()) parts.add("Ablauf: " + raw.take(30))
        }
        return parts.joinToString("  ·  ")
    }

    fun portalWarn(p: Portal): Boolean {
        infoTick
        val ex = portalExpiry[p.id] ?: return false
        return ex > 0 && daysLeft(ex) < 14
    }

    fun portalShort(p: Portal): String {
        infoTick
        val ex = portalExpiry[p.id] ?: return ""
        if (ex <= 0) return ""
        val d = daysLeft(ex)
        return if (d < 0) " (abgelaufen)" else " (noch $d T.)"
    }

    // ---------- Zusatzinfos von TMDB ----------
    var tmdbKey by mutableStateOf(settings.getString("tmdbKey", "")?.takeIf { it.isNotBlank() } ?: DEFAULT_TMDB_KEY)

    fun updateTmdbKey(k: String) {
        tmdbKey = k.trim()
        settings.edit().putString("tmdbKey", tmdbKey).apply()
    }

    // ---------- Intro pro Serie merken ----------
    private fun introKey(): String = "intro:" + seriesName.ifEmpty { playTitle.substringBefore(" – ") }

    fun introEndMs(): Long = settings.getLong(introKey(), 0L)

    /** Serien ohne Intro: kein „Intro überspringen“ mehr anbieten. */
    fun noIntro(): Boolean = settings.getBoolean("no" + introKey(), false)

    fun setNoIntro() {
        settings.edit().putBoolean("no" + introKey(), true).apply()
        showNotice("Kein Intro bei dieser Serie – wird nicht mehr angeboten")
    }

    fun saveIntroEnd(pos: Long) {
        settings.edit().putLong(introKey(), pos).apply()
        showNotice("Intro-Ende gemerkt: " + fmtTime(pos))
    }

    /** Ziel beim Überspringen: gemerktes Intro-Ende dieser Serie, sonst feste Sekunden. */
    fun skipTarget(pos: Long): Long {
        val e = introEndMs()
        return if (e > pos + 2000) e else pos + introSeconds * 1000L
    }

    // ---------- Serien: gesehen, nächste Folge, Intro, Weiterschauen ----------
    var seenKeys by mutableStateOf<Set<String>>(emptySet())
    var upNext by mutableStateOf<String?>(null)
    private var upNextJob: Job? = null
    private var currentSeason: Season? = null
    private var endedHandled = false
    private var seriesName = ""

    var autoNext by mutableStateOf(settings.getBoolean("autoNext", true))
    var introSeconds by mutableStateOf(settings.getInt("introSec", 90))
    var autoSkipIntro by mutableStateOf(settings.getBoolean("autoIntro", false))

    val isEpisode: Boolean get() = !isLive && lastEp != null

    fun toggleAutoNext() {
        autoNext = !autoNext
        settings.edit().putBoolean("autoNext", autoNext).apply()
    }

    fun cycleIntro() {
        introSeconds = when (introSeconds) {
            60 -> 75
            75 -> 90
            90 -> 105
            105 -> 120
            else -> 60
        }
        settings.edit().putInt("introSec", introSeconds).apply()
    }

    fun toggleAutoIntro() {
        autoSkipIntro = !autoSkipIntro
        settings.edit().putBoolean("autoIntro", autoSkipIntro).apply()
    }

    private fun refreshSeen() { seenKeys = portal?.let { userData.seen(it.id) } ?: emptySet() }

    fun isSeen(se: Season, ep: Int): Boolean = ("${se.cmd}|$ep") in seenKeys

    private fun markSeen() {
        val p = portal ?: return
        if (isLive) return
        if (lastEp == null) {
            // Film: als gesehen merken (Haken auf dem Poster)
            if (browseType == "vod") { userData.addSeen(p.id, "mv|$lastCmd"); refreshSeen() }
            return
        }
        userData.addSeen(p.id, "$lastCmd|$lastEp")
        refreshSeen()
    }

    fun isMovieSeen(item: Item): Boolean = ("mv|" + item.cmd) in seenKeys

    fun toggleMovieSeen(item: Item) {
        val p = portal ?: return
        val key = "mv|" + item.cmd
        if (key in seenKeys) userData.removeSeen(p.id, key) else userData.addSeen(p.id, key)
        refreshSeen()
        showNotice(if (key in seenKeys) "Als gesehen markiert" else "Markierung entfernt")
    }

    /** Titel und Art (Serie oder Film) des laufenden Inhalts für X-Ray. */
    fun xrayTarget(): Pair<String, Boolean> =
        if (lastEp != null) Pair(seriesName.ifEmpty { playTitle.substringBefore(" – ") }, true) else Pair(playTitle, false)

    private fun episodeTitle(se: Season, ep: Int): String {
        val head = if (seriesName.isNotEmpty()) "$seriesName – " else ""
        return head + se.name + " – Episode " + ep
    }

    fun playEpisode(se: Season, ep: Int) {
        currentSeason = se
        play("vod", episodeTitle(se, ep), se.cmd, ep)
    }

    /** Gespeicherter Fortschritt für diesen Film bzw. diese Serie (für den Weiter-Knopf). */
    fun resumeFor(item: Item): Resume? {
        val p = portal ?: return null
        val all = userData.resumes(p.id)
        return if (browseType == "series") all.firstOrNull { it.type == "series" && it.title.startsWith(item.name + " – ") }
        else all.firstOrNull { it.type != "series" && it.cmd == item.cmd }
    }

    fun startFresh(item: Item) {
        val p = portal
        if (p != null) resumeFor(item)?.let { userData.removeResume(p.id, it.key) }
        startItem(item)
    }

    /** Am Ende einer Wiedergabe: Fortschritt löschen, als gesehen markieren, nächste Folge anbieten. */
    /** Nächste Folge (auch die erste der nächsten Staffel), sonst null. */
    fun nextTarget(): Pair<Season, Int>? {
        val ep = lastEp ?: return null
        if (isLive) return null
        val se = currentSeason ?: seasons.firstOrNull { it.cmd == lastCmd } ?: return null
        val sorted = se.episodes
        val i = sorted.indexOf(ep)
        if (i >= 0) sorted.getOrNull(i + 1)?.let { return Pair(se, it) }
        else sorted.filter { it > ep }.minOrNull()?.let { return Pair(se, it) }
        val si = seasons.indexOfFirst { it.cmd == se.cmd }
        val ns = if (si >= 0) seasons.getOrNull(si + 1) else null
        if (ns != null && ns.episodes.isNotEmpty()) return Pair(ns, ns.episodes.first())
        return null
    }

    fun nextLabel(): String? = nextTarget()?.let { episodeTitle(it.first, it.second) }

    fun playNext() {
        val t = nextTarget() ?: return
        upNextJob?.cancel(); upNext = null
        clearResume(); markSeen()
        playEpisode(t.first, t.second)
    }

    fun onEnded() {
        if (endedHandled) return
        endedHandled = true
        clearResume()
        markSeen()
        if (!autoNext) return
        val t = nextTarget() ?: return
        val nextSeason = t.first
        val ne = t.second
        upNext = episodeTitle(nextSeason, ne)
        upNextJob?.cancel()
        upNextJob = viewModelScope.launch {
            delay(5000)
            upNext = null
            playEpisode(nextSeason, ne)
        }
    }

    fun cancelUpNext() {
        upNextJob?.cancel()
        upNext = null
    }

    // ---------- Sicherung ----------
    fun exportBackup(): String {
        val root = JSONObject()
        root.put("app", "TomsTV")
        root.put("v", 1)
        for (name in listOf("portals", "userdata", "settings")) {
            val sp = getApplication<Application>().getSharedPreferences(name, Context.MODE_PRIVATE)
            val o = JSONObject()
            for ((k, v) in sp.all) {
                val e = JSONObject()
                when (v) {
                    is String -> { e.put("t", "s"); e.put("v", v) }
                    is Boolean -> { e.put("t", "b"); e.put("v", v) }
                    is Int -> { e.put("t", "i"); e.put("v", v) }
                    is Long -> { e.put("t", "l"); e.put("v", v) }
                    is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                    is Set<*> -> { e.put("t", "set"); e.put("v", JSONArray(v.map { it.toString() })) }
                    else -> { }
                }
                if (e.has("t")) o.put(k, e)
            }
            root.put(name, o)
        }
        return root.toString()
    }

    fun importBackup(json: String): String {
        return try {
            val root = JSONObject(json)
            if (root.optString("app") != "TomsTV") return "Das ist keine Sicherung von Tom's TV."
            for (name in listOf("portals", "userdata", "settings")) {
                val o = root.optJSONObject(name) ?: continue
                val ed = getApplication<Application>().getSharedPreferences(name, Context.MODE_PRIVATE).edit()
                ed.clear()
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val e = o.getJSONObject(k)
                    when (e.optString("t")) {
                        "s" -> ed.putString(k, e.getString("v"))
                        "b" -> ed.putBoolean(k, e.getBoolean("v"))
                        "i" -> ed.putInt(k, e.getInt("v"))
                        "l" -> ed.putLong(k, e.getLong("v"))
                        "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                        "set" -> {
                            val a = e.getJSONArray("v")
                            ed.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                        }
                    }
                }
                ed.apply()
            }
            viewModelScope.launch {
                portals.clear()
                portals.addAll(store.load())
                refreshAllPortals(true)
                refreshSeen()
                refreshWatchIds()
            }
            "Wiederherstellung abgeschlossen. Starte die App neu, damit alle Einstellungen gelten."
        } catch (e: Exception) {
            "Fehler: " + (e.message ?: "ungültige Datei")
        }
    }

    // ---------- Merkliste (Filme und Serien) ----------
    fun watchFor(type: String): List<Item> = portal?.let { userData.favs(it.id, "w_$type") } ?: emptyList()

    private fun refreshWatchIds() {
        watchIds = (watchFor("vod").map { "vod:" + it.id } + watchFor("series").map { "series:" + it.id }).toSet()
    }

    fun isWatch(item: Item): Boolean = ("$browseType:${item.id}") in watchIds

    fun watchType(item: Item): String = if (("series:" + item.id) in watchIds) "series" else "vod"

    fun toggleWatch(item: Item) {
        val p = portal ?: return
        val t = browseType
        val cur = userData.favs(p.id, "w_$t")
        val was = cur.any { it.id == item.id }
        userData.saveFavs(p.id, "w_$t", if (was) cur.filterNot { it.id == item.id } else cur + item)
        refreshWatchIds()
        showNotice(if (was) "Aus der Merkliste entfernt" else "🔖 Zur Merkliste hinzugefügt")
    }

    fun openWatch(type: String, item: Item) {
        val p = portal ?: return
        browseType = type
        favs = userData.favs(p.id, type)
        push(Screen.Detail(item))
    }

    // ---------- Senderliste während Live-TV ----------
    fun openChannelPanel() {
        val c = client ?: return
        val p = portal ?: return
        if (cachedChannels == null || liveCats.isEmpty()) {
            showNotice("Senderliste wird geladen …")
            viewModelScope.launch {
                try {
                    val ch = cachedChannels ?: withContext(Dispatchers.IO) { c.channels() }
                    cachedChannels = ch
                    val cats = if (liveCats.isEmpty()) withContext(Dispatchers.IO) { c.categories("itv") } else liveCats
                    liveCats = cats
                } catch (e: Exception) {
                    error = "Senderliste nicht verfügbar: ${e.message}"
                    return@launch
                }
                showPanel(p)
            }
            return
        }
        showPanel(p)
    }

    private fun showPanel(p: Portal) {
        panelHiddenCats = userData.hiddenCats(p.id, "itv")
        panelHiddenChans = userData.hiddenChans(p.id)
        panelFavs = userData.favs(p.id, "itv")
        val visible = liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }.map { it.id }.toSet()
        panelGroups = (client as? MultiClient)?.groups("itv") ?: emptyList()
        val cur = cachedChannels?.firstOrNull { it.id == playChId }
        // Die Kategorie-Leiste zeigt die Liste, aus der der Sender gestartet wurde
        panelCat = liveContext.ifEmpty { "*" }
        val pfx = if (panelCat.startsWith("p:")) panelCat.removePrefix("p:").substringBefore(':')
                  else cur?.id?.substringBefore('|') ?: ""
        panelExpanded = expandedPortals + (if (pfx.isNotEmpty()) setOf(pfx) else emptySet())
        chanPanel = true
    }

    fun panelCategories(): List<Category> =
        listOf(Category("fav", "★ Favoriten")) + favLists.map { Category("fl:" + it.id, "★ " + it.name) } +
            listOf(Category("*", "Alle")) +
            orderCats(liveCats.filter { it.id != "*" && it.id !in panelHiddenCats }, "itv")

    fun panelList(): List<Item> {
        val all = cachedChannels ?: return emptyList()
        return when {
            panelCat.startsWith("p:") -> {
                val rest = panelCat.removePrefix("p:")
                val pfx = rest.substringBefore(':')
                val key = rest.substringAfter(':')
                if (key == "fav") panelFavs.filter { it.id.startsWith("$pfx|") }
                else all.filter { it.id.startsWith("$pfx|") && (key == "*" || it.cat == key) && it.id !in panelHiddenChans }
            }
            panelCat.startsWith("fl:") -> listItems(panelCat.removePrefix("fl:"))
            panelCat == "fav" -> panelFavs
            panelCat == "*" -> all.filter { it.id !in panelHiddenChans && it.cat !in panelHiddenCats && channelOk(it) }
            else -> all.filter { it.cat == panelCat && it.id !in panelHiddenChans && channelOk(it) }
        }
    }

    var panelGroups by mutableStateOf<List<PortalGroup>>(emptyList())
    var panelExpanded by mutableStateOf<Set<String>>(emptySet())

    fun togglePanelGroup(pfx: String) {
        panelExpanded = if (pfx in panelExpanded) panelExpanded - pfx else panelExpanded + pfx
    }

    fun panelVisibleCats(g: PortalGroup): List<Category> = orderCats(g.cats.filter { it.id !in panelHiddenCats }, "itv")

    fun playFromPanel(ch: Item, list: List<Item>) {
        chanPanel = false
        liveContext = panelCat
        zapList = list
        zapIndex = list.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        if (ch.id == playChId) return
        startLive()
    }

    // ---------- Startseite ----------
    fun loadHome() {
        val c = client ?: return
        val p = portal ?: return
        refreshFavLists(); homeTick++
        resumeList = userData.resumes(p.id)
        recentChans = userData.recentChans()
        checkNewEpisodes()
        val hiddenV = userData.hiddenItems(p.id, "vod")
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    // Nur deutsche Titel: erst aus deutschen Kategorien, sonst nach Namen filtern
                    val de = if (homeGerman) germanNewest(c, "vod", 30)?.takeIf { it.isNotEmpty() } else null
                    if (de != null) return@withContext de
                    var l = c.list("vod", "*", 1).items
                    if (homeGerman) l = l.filter { isGermanTitle(it.name) }.ifEmpty { l }
                    if (l.isEmpty()) {
                        val first = c.categories("vod").firstOrNull { it.id != "*" }?.id
                        if (first != null) l = c.list("vod", first, 1).items
                    }
                    l
                }
                homeNew = list.filter { it.id !in hiddenV }.take(14)
                if (homeNew.isNotEmpty()) { userData.saveFavs("_home", "new", homeNew); homeCached = homeNew }
            } catch (e: Exception) { }
            try {
                val mc = c as? MultiClient
                homeNewByPortal = if (mc == null) emptyList() else
                    withContext(Dispatchers.IO) { mc.newestPerPortal("vod", homeGerman) }
                        .map { (n, l) -> n to l.filter { it.id !in hiddenV } }
            } catch (e: Exception) { }
            try {
                val ch = withContext(Dispatchers.IO) { cachedChannels ?: c.channels().also { cachedChannels = it } }
                // Kategorien für Live TV gleich mitladen, damit die Senderliste sofort aufgeht
                if (liveCats.isEmpty()) runCatching { liveCats = withContext(Dispatchers.IO) { c.categories("itv") } }
                val hc = userData.hiddenChans(p.id)
                val hcat = userData.hiddenCats(p.id, "itv")
                val favIds = userData.favs(p.id, "itv").map { it.id }.toSet()
                val vis = ch.filter { it.id !in hc && it.cat !in hcat && channelOk(it) }
                homeChannels = (vis.filter { it.id in favIds } + vis).distinctBy { it.id }.take(14)
                infoTick++
                if (resumeLastOnStart && !startupResumeDone) {
                    startupResumeDone = true
                    val lastId = settings.getString("lastCh", null)
                    val lastCh = vis.firstOrNull { it.id == lastId } ?: ch.firstOrNull { it.id == lastId }
                    if (lastCh != null) {
                        liveContext = "*"
                        zapList = if (lastCh in vis) vis else listOf(lastCh)
                        zapIndex = zapList.indexOf(lastCh).coerceAtLeast(0)
                        startLive()
                    }
                }
            } catch (e: Exception) { }
            try {
                if (liveCats.isEmpty()) liveCats = withContext(Dispatchers.IO) { c.categories("itv") }
            } catch (e: Exception) { }
        }
    }

    fun openHomeItem(item: Item, type: String) {
        val p = portal ?: run { showNotice("Portale werden noch verbunden …"); return }
        browseType = type
        favs = userData.favs(p.id, type)
        if (type == "itv") {
            liveContext = "*"
            zapList = homeChannels
            zapIndex = homeChannels.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    fun favsFor(type: String): List<Item> = portal?.let { userData.favs(it.id, type) } ?: emptyList()

    fun openFavorite(type: String, item: Item) {
        val list = favsFor(type)
        browseType = type
        favs = list
        if (type == "itv") {
            liveContext = "fav"
            zapList = list
            zapIndex = list.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
            startLive()
        } else push(Screen.Detail(item))
    }

    // ---------- Mehrere Favoritenlisten ----------
    var favLists by mutableStateOf<List<FavList>>(userData.favLists())
    var otherFavIds by mutableStateOf<Set<String>>(emptySet())
    var favPick by mutableStateOf<Item?>(null)
    var favTick by mutableIntStateOf(0)

    private fun listType(id: String) = if (id.isEmpty()) "itv" else "itv:$id"
    fun listItems(id: String): List<Item> = portal?.let { userData.favs(it.id, listType(id)) } ?: emptyList()
    fun listName(id: String): String = if (id.isEmpty()) "Favoriten" else favLists.firstOrNull { it.id == id }?.name ?: "Liste"

    fun refreshFavLists() {
        favLists = userData.favLists()
        val p = portal
        otherFavIds = if (p == null) emptySet()
            else favLists.flatMap { userData.favs(p.id, "itv:" + it.id) }.map { it.id }.toSet()
        favTick++
    }

    fun isFavAny(item: Item): Boolean = isFav(item) || (browseType == "itv" && item.id in otherFavIds)
    fun inList(id: String, item: Item): Boolean = listItems(id).any { it.id == item.id }

    private fun writeList(id: String, nl: List<Item>) {
        val p = portal ?: return
        userData.saveFavs(p.id, listType(id), nl)
        if (id.isEmpty() && browseType == "itv") favs = nl
        if (browseType == "itv" && selCat == (if (id.isEmpty()) "fav" else "fl:$id")) items = nl
        refreshFavLists()
    }

    fun toggleInList(id: String, item: Item) {
        val cur = listItems(id)
        val was = cur.any { it.id == item.id }
        writeList(id, if (was) cur.filterNot { it.id == item.id } else cur + item)
    }

    fun createFavList(): FavList {
        val n = (favLists.mapNotNull { it.id.toIntOrNull() }.maxOrNull() ?: 0) + 1
        val l = FavList(n.toString(), "Liste $n")
        userData.saveFavLists(favLists + l)
        refreshFavLists(); applyCategories()
        return l
    }

    fun renameFavList(id: String, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        userData.saveFavLists(favLists.map { if (it.id == id) it.copy(name = n) else it })
        refreshFavLists(); applyCategories()
    }

    fun deleteFavList(id: String) {
        userData.deleteFavList(id)
        refreshFavLists(); applyCategories()
        if (selCat == "fl:$id") selectCategory("fav")
    }

    fun moveFavList(id: String, d: Int) {
        val l = favLists.toMutableList()
        val i = l.indexOfFirst { it.id == id }
        val j = i + d
        if (i < 0 || j !in l.indices) return
        l.add(j, l.removeAt(i))
        userData.saveFavLists(l)
        refreshFavLists(); applyCategories()
    }

    fun moveInList(id: String, item: Item, d: Int) {
        val l = listItems(id).toMutableList()
        val i = l.indexOfFirst { it.id == item.id }
        val j = i + d
        if (i < 0 || j !in l.indices) return
        l.add(j, l.removeAt(i))
        writeList(id, l)
    }

    fun removeFromList(id: String, item: Item) = writeList(id, listItems(id).filterNot { it.id == item.id })

    fun sortListAz(id: String) = writeList(id, listItems(id).sortedBy { it.name.lowercase() })

    fun openFavoriteList(id: String, item: Item) {
        val list = listItems(id)
        browseType = "itv"
        favs = listItems("")
        liveContext = if (id.isEmpty()) "fav" else "fl:$id"
        zapList = list
        zapIndex = list.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
        startLive()
    }

    // ---------- Startseite einrichten ----------
    data class HomeCustom(val id: String, val type: String, val cat: String, val title: String)
    private val homeDefaultIds = listOf("eps", "new", "byportal", "watch", "recent", "live", "pop", "resume")
    private fun loadStrList(key: String): List<String> = try {
        val a = org.json.JSONArray(settings.getString(key, "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }
    private fun loadHomeCustom(): List<HomeCustom> = try {
        val a = org.json.JSONArray(settings.getString("homeCustom", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HomeCustom(o.getString("id"), o.getString("type"), o.getString("cat"), o.getString("title"))
        }
    } catch (e: Exception) { emptyList() }

    var homeOrder by mutableStateOf(loadStrList("homeOrder"))
    var homeOff by mutableStateOf(loadStrList("homeOff").toSet())
    var homeCustom by mutableStateOf(loadHomeCustom())
    var homeTick by mutableIntStateOf(0)
    val customItems = mutableStateMapOf<String, List<Item>>()
    var homeCatChoices by mutableStateOf<List<Category>>(emptyList())

    private fun saveHomeLayout() {
        val a = org.json.JSONArray()
        homeCustom.forEach { a.put(org.json.JSONObject().put("id", it.id).put("type", it.type).put("cat", it.cat).put("title", it.title)) }
        settings.edit().putString("homeOrder", org.json.JSONArray(homeOrder).toString())
            .putString("homeOff", org.json.JSONArray(homeOff.toList()).toString())
            .putString("homeCustom", a.toString()).apply()
    }

    private fun homeAvailable(): List<String> =
        homeDefaultIds + favLists.map { "live:" + it.id } + homeCustom.map { it.id }

    fun homeSections(): List<String> {
        val av = homeAvailable()
        val ord = homeOrder.filter { it in av }
        return ord + av.filter { it !in ord }
    }

    fun homeLabel(id: String): String = when {
        id == "eps" -> "Neue Folgen bei deinen Serien"
        id == "new" -> "Neu im Angebot"
        id == "byportal" -> "Neu bei … (je Portal)"
        id == "watch" -> "Meine Merkliste"
        id == "recent" -> "Zuletzt gesehene Sender"
        id == "live" -> "Jetzt live (Favoriten mit laufender Sendung)"
        id == "pop" -> "Live TV – Beliebte Sender"
        id == "resume" -> "Weiterschauen"
        id.startsWith("live:") -> "Jetzt live – " + listName(id.removePrefix("live:"))
        else -> homeCustom.firstOrNull { it.id == id }
            ?.let { (if (it.type == "series") "Serien: " else "Filme: ") + it.title } ?: id
    }

    fun moveHomeSection(id: String, d: Int) {
        val l = homeSections().toMutableList()
        val i = l.indexOf(id)
        val j = i + d
        if (i < 0 || j !in l.indices) return
        l.add(j, l.removeAt(i))
        homeOrder = l
        saveHomeLayout()
    }

    fun toggleHomeSection(id: String) {
        homeOff = if (id in homeOff) homeOff - id else homeOff + id
        saveHomeLayout()
    }

    fun openHomeAdd(type: String) {
        homeCatChoices = emptyList()
        push(Screen.HomeAddRow(type))
        val c = client ?: return
        val p = portal ?: return
        viewModelScope.launch {
            try {
                val hid = userData.hiddenCats(p.id, type)
                homeCatChoices = withContext(Dispatchers.IO) { c.categories(type).filter { it.id != "*" && it.id !in hid } }
            } catch (e: Exception) { showNotice("Kategorien konnten nicht geladen werden") }
        }
    }

    fun addHomeCustom(type: String, cat: Category) {
        val id = "c:$type:${cat.id}"
        if (homeCustom.none { it.id == id }) {
            homeCustom = homeCustom + HomeCustom(id, type, cat.id, cat.title)
            saveHomeLayout()
            showNotice("Reihe „" + cat.title + "“ hinzugefügt")
        } else showNotice("Diese Reihe gibt es schon")
        back()
    }

    fun removeHomeCustom(id: String) {
        homeCustom = homeCustom.filterNot { it.id == id }
        homeOrder = homeOrder - id
        homeOff = homeOff - id
        customItems.remove(id)
        saveHomeLayout()
    }

    private val customAt = HashMap<String, Long>()

    fun loadCustom(id: String) {
        val hc = homeCustom.firstOrNull { it.id == id } ?: return
        val c = client ?: return
        val now = System.currentTimeMillis()
        if (customItems[id] != null && now - (customAt[id] ?: 0L) < 5 * 60_000L) return
        customAt[id] = now
        viewModelScope.launch {
            try {
                val l = withContext(Dispatchers.IO) { c.list(hc.type, hc.cat, 1).items }
                customItems[id] = l.take(20)
            } catch (e: Exception) { }
        }
    }

    /** Sender für die Reihe „Jetzt live“: Favoriten oder eine eigene Liste. */
    fun liveItems(sid: String): List<Item> {
        if (sid == "live") {
            val l = listItems("")
            return if (l.isNotEmpty()) l.take(16) else homeChannels.take(12)
        }
        return listItems(sid.removePrefix("live:")).take(16)
    }

    fun openLiveFrom(sid: String, list: List<Item>, ch: Item) {
        browseType = "itv"
        favs = listItems("")
        liveContext = when {
            sid == "live" -> if (listItems("").isEmpty()) "*" else "fav"
            else -> "fl:" + sid.removePrefix("live:")
        }
        zapList = list
        zapIndex = list.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        startLive()
    }

    // ---------- Favoriten ----------
    fun isFav(item: Item): Boolean = favs.any { it.id == item.id }

    /** Der gerade laufende Live-Sender (für die Schnell-Leiste im Player). */
    fun currentChannel(): Item? = cachedChannels?.firstOrNull { it.id == playChId }

    fun isCurrentFav(): Boolean = currentChannel()?.let { isFav(it) } ?: false

    fun toggleCurrentFav() {
        val ch = currentChannel() ?: return
        if (browseType != "itv") {
            browseType = "itv"
            favs = portal?.let { userData.favs(it.id, "itv") } ?: emptyList()
        }
        toggleFav(ch)
    }

    fun toggleFav(item: Item) {
        val p = portal ?: return
        if (browseType == "itv" && favLists.isNotEmpty()) { favPick = item; return }
        val was = isFav(item)
        favs = if (was) favs.filterNot { it.id == item.id } else favs + item
        userData.saveFavs(p.id, browseType, favs)
        showNotice(if (was) "Aus Favoriten entfernt" else "★ Zu Favoriten hinzugefügt")
        if (selCat == "fav") items = favs
    }

    // ---------- Weiterschauen ----------
    fun openResumes() {
        resumeList = portal?.let { userData.resumes(it.id) } ?: emptyList()
        push(Screen.ResumeList)
    }

    fun resumePos(): Long =
        portal?.let { p -> userData.resumes(p.id).firstOrNull { it.key == resumeKey }?.pos } ?: 0L

    fun savePosition(pos: Long, dur: Long) {
        val p = portal ?: return
        if (isLive || resumeKey.isEmpty() || lastKind == "arch") return
        if (dur > 0 && pos > dur * 9 / 10) markSeen()
        if (pos < 15_000 || (dur > 0 && pos > dur - 60_000)) userData.removeResume(p.id, resumeKey)
        else userData.putResume(p.id, Resume(resumeKey, playTitle, lastCmd, lastEp, pos, resumeLogo, dur.coerceAtLeast(0L), browseType,
            currentSeason?.episodes?.joinToString(",") ?: "", currentSeason?.name ?: "",
            if (browseType == "series" && seasons.any { it.cmd == currentSeason?.cmd })
                seasons.joinToString("\n") { it.name + "\t" + it.cmd + "\t" + it.episodes.joinToString(",") } else ""))
    }

    fun clearResume() { portal?.let { userData.removeResume(it.id, resumeKey) } }

    // ---------- Abspielen ----------
    /** Live-Sender starten direkt, Filme und Serien öffnen zuerst die Detailseite. */
    fun openItem(item: Item) {
        if (editMode && browseType != "itv") { toggleItemHidden(item); return }
        if (browseType == "itv") startItem(item) else push(Screen.Detail(item))
    }

    fun startItem(item: Item) {
        val c = client ?: return
        resumeLogo = item.logo
        if (browseType == "series") seriesName = item.name
        when {
            browseType == "series" -> io({
                val t0 = System.currentTimeMillis()
                val sl = c.seasons(item.id)
                AppLog.add("Zeit: Serie öffnen " + (System.currentTimeMillis() - t0) + " ms")
                sl
            }) { seasons = it; acknowledgeSeries(item.id, it); push(Screen.Seasons(item.name)) }
            item.episodes.isNotEmpty() -> push(Screen.Episodes(Season(item.name, item.cmd, item.episodes)))
            browseType == "itv" -> {
                liveContext = selCat ?: "*"; zapList = items; zapIndex = items.indexOf(item).coerceAtLeast(0); startLive()
            }
            else -> play("vod", item.name, item.cmd, null)
        }
    }

    fun openSeason(s: Season) {
        if (s.episodes.isEmpty()) play("vod", s.name, s.cmd, null) else push(Screen.Episodes(s))
    }

    fun play(kind: String, title: String, cmd: String, ep: Int?) {
        val c = client ?: return
        stopPreview()
        val wasReload = reloading
        if (!wasReload) hdrMode = 0
        reloading = false
        lastKind = kind; lastCmd = cmd; lastEp = ep; playTitle = title; isLive = kind == "itv"
        endedHandled = false
        if (kind != "itv") playLogo = null
        resumeKey = "$kind|$cmd|${ep ?: 0}"
        val g = ++playGen
        val hit = if (kind == "itv") linkCache.remove(cmd) else null
        if (hit != null && System.currentTimeMillis() - hit.second < 45_000) {
            playUrl = hit.first
            playNonce++
            if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
            prefetchNeighbors()
            return
        }
        io({ c.link(kind, cmd, ep) }) { url ->
            if (g == playGen) {
                playUrl = url
                playNonce++
                if (stack.lastOrNull() !is Screen.Play) push(Screen.Play)
                prefetchNeighbors()
            }
        }
    }

    private fun startLive() {
        var ch = zapList.getOrNull(zapIndex) ?: return
        // Bevorzugte Quelle (Portal) für diesen Sender anwenden
        val pref = settings.getString("src:" + nameKey(ch), null)
        if (pref != null && !ch.id.startsWith("$pref|")) {
            cachedChannels?.firstOrNull { nameKey(it) == nameKey(ch) && it.id.startsWith("$pref|") }?.let { ch = it }
        }
        triedIds.clear()
        if (playChId.isNotEmpty() && playChId != ch.id) prevChId = playChId
        playChId = ch.id
        playLogo = ch.logo
        scheduleRecent(ch)
        settings.edit().putString("lastCh", ch.id).apply()
        play("itv", ch.name, ch.cmd, null)
    }

    /** Vergangene Sendungen des aktuellen Senders an einem Tag. */
    suspend fun archiveDay(chId: String, date: String): List<Epg> {
        val c = client ?: return emptyList()
        return try { withContext(Dispatchers.IO) { c.archiveDay(chId, date) } } catch (e: Exception) {
            AppLog.add("Archiv Fehler: " + (e.message ?: "?")); emptyList()
        }
    }

    /** Eine Sendung aus dem Archiv abspielen. */
    fun playArchive(ch: Item, e: Epg) {
        play("arch", ch.name + " · " + e.title, ch.cmd + "\u0001" + e.id, null)
    }

    fun zap(delta: Int) {
        if (zapList.isEmpty()) return
        zapIndex = (zapIndex + delta + zapList.size) % zapList.size
        startLive()
    }

    // ---------- EPG ----------
    private class EpgEntry(val at: Long, val list: List<Epg>, val size: Int)
    private val epgCache = mutableStateMapOf<String, EpgEntry>()
    private val epgBusy = HashSet<String>()
    private val epgSem = Semaphore(3)

    fun epgList(id: String): List<Epg> {
        return epgCache[id]?.list ?: emptyList()
    }

    fun currentEpg(id: String): Epg? {
        val l = epgList(id)
        val now = System.currentTimeMillis() / 1000
        return l.firstOrNull { it.startTs <= now && now < it.stopTs } ?: l.firstOrNull()
    }

    /** Laufende und kommende Sendungen eines Senders (für das Mini-EPG im Player). */
    fun upcomingEpg(id: String): List<Epg> {
        val l = epgList(id)
        val n = currentEpg(id) ?: return emptyList()
        return l.dropWhile { it != n }.take(6)
    }

    var infoSeconds by mutableIntStateOf(settings.getInt("infoSec", 4))

    fun cycleInfoSeconds() {
        infoSeconds = when (infoSeconds) { 3 -> 4; 4 -> 6; 6 -> 10; else -> 3 }
        settings.edit().putInt("infoSec", infoSeconds).apply()
    }

    fun epgProgress(e: Epg): Float? {
        if (e.startTs <= 0 || e.stopTs <= e.startTs) return null
        val now = System.currentTimeMillis() / 1000
        return ((now - e.startTs).toFloat() / (e.stopTs - e.startTs)).coerceIn(0f, 1f)
    }

    fun loadEpg(id: String, size: Int = 5) {
        val c = client ?: return
        val old = epgCache[id]
        val fresh = old != null && old.size >= size && System.currentTimeMillis() - old.at < 180_000
        if (id.isEmpty() || id in epgBusy || fresh) return
        epgBusy.add(id)
        viewModelScope.launch {
            val list = try {
                epgSem.withPermit { withContext(Dispatchers.IO) { c.epg(id, size) } }
            } catch (e: Exception) { emptyList() }
            // leere Antworten nur kurz merken, damit es bald erneut versucht wird
            val stamp = if (list.isEmpty()) System.currentTimeMillis() - 150_000 else System.currentTimeMillis()
            if (list.isEmpty()) AppLog.add("EPG leer für Sender $id")
            epgCache[id] = EpgEntry(stamp, list, size)
            epgBusy.remove(id)
            epgTick++
        }
    }

    /** Holt die Links der beiden Nachbarsender im Voraus, damit das Umschalten sofort geht. */
    private fun prefetchNeighbors() {
        if (!isLive || zapList.size < 2 || NetState.weak) return
        val c = client ?: return
        for (d in listOf(1, -1)) {
            val ch = zapList[(zapIndex + d + zapList.size) % zapList.size]
            val cached = linkCache[ch.cmd]
            if ((cached != null && System.currentTimeMillis() - cached.second < 45_000) || ch.cmd in prefetching) continue
            prefetching.add(ch.cmd)
            viewModelScope.launch {
                try {
                    val url = withContext(Dispatchers.IO) { c.link("itv", ch.cmd, null) }
                    if (linkCache.size > 16) linkCache.clear()
                    linkCache[ch.cmd] = url to System.currentTimeMillis()
                } catch (e: Exception) { }
                prefetching.remove(ch.cmd)
            }
        }
    }

    /** Fällt ein Sender aus, versucht die App denselben Sender bei einem anderen Portal. */
    fun tryAlternate(): Boolean {
        val all = cachedChannels ?: return false
        val cur = all.firstOrNull { it.id == playChId } ?: return false
        val key = cur.name.trim().lowercase()
        triedIds.add(cur.id)
        markBad(cur.id)
        val alt = all.filter { it.id !in triedIds && it.name.trim().lowercase() == key }
            .minByOrNull { chFails[it.id] ?: 0 } ?: return false
        playChId = alt.id
        playLogo = alt.logo
        showNotice("Wechsle zu einer anderen Quelle …")
        play("itv", alt.name, alt.cmd, null)
        return true
    }

    /** Fordert einen frischen Stream-Link an (bei Aussetzern/Hängern). */
    fun reload(count: Boolean = true) {
        reloading = true
        play(lastKind, playTitle, lastCmd, lastEp)
    }

    // ---------- Stream-Anfrage: Stufen bei "bad http status" ----------
    fun streamHeaders(): Map<String, String> {
        val c = client ?: return emptyMap()
        return when (hdrMode) {
            0 -> c.streamHeadersFor(lastCmd, false)
            1 -> c.streamHeadersFor(lastCmd, true)
            else -> emptyMap()
        }
    }

    fun streamUserAgent(): String = when (hdrMode) {
        2 -> "Lavf/58.76.100"
        3 -> "VLC/3.0.20 LibVLC/3.0.20"
        else -> UA
    }

    fun nextHeaderMode(): Boolean {
        if (hdrMode >= 3) return false
        hdrMode++
        return true
    }

    fun headerStage(): Int = hdrMode

    // ---------- App-Update ----------
    fun checkUpdate(silent: Boolean = false) {
        if (!silent) { updateMsg = "Suche nach Updates …"; updateInfo = null }
        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { Updater.latest() }
                when {
                    info == null -> if (!silent) updateMsg = "Kein Update gefunden"
                    Updater.isNewer(info) -> {
                        updateInfo = info
                        updateMsg = "Neue Version ${info.tag} verfügbar"
                        if (silent) updatePrompt = info
                    }
                    else -> if (!silent) updateMsg = "Du hast die neueste Version (${BuildConfig.VERSION_NAME})"
                }
            } catch (e: Exception) {
                if (!silent) updateMsg = "Fehler: ${e.message}"
            }
        }
    }

    fun installUpdate() {
        val info = updateInfo ?: return
        val app = getApplication<Application>()
        updateProgress = 0
        updateMsg = "Lade ${info.tag} herunter …"
        showNotice("Update wird geladen …")
        viewModelScope.launch {
            try {
                val apk = withContext(Dispatchers.IO) { Updater.download(app, info.url) { p -> updateProgress = p } }
                updateProgress = -1
                val started = Updater.install(app, apk)
                updateMsg = if (started) "Installation gestartet. Folge den Anweisungen des Systems."
                else "Erlaube Tom's TV in den Einstellungen, Apps zu installieren, und tippe dann erneut auf Jetzt installieren."
            } catch (e: Exception) {
                updateProgress = -1
                updateMsg = "Update nicht möglich: ${e.message}"
            }
        }
    }

    // ---------- Startton ----------
    var introSound by mutableStateOf(settings.getBoolean("introSound", true))

    fun toggleIntroSound() {
        introSound = !introSound
        settings.edit().putBoolean("introSound", introSound).apply()
    }

    // ---------- Neue Folgen melden ----------
    var newEpisodes by mutableStateOf<List<Pair<Item, Int>>>(emptyList())
    private var lastEpCheck = 0L

    private fun epBase(): JSONObject = try {
        JSONObject(settings.getString("epBase", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }

    private fun epCount(l: List<Season>): Int = l.sumOf { if (it.episodes.isEmpty()) 1 else it.episodes.size }

    /** Serie geöffnet: aktuellen Stand als bekannt merken, Hinweis entfernen. */
    fun acknowledgeSeries(id: String, seasonList: List<Season>) {
        val o = epBase()
        o.put(id, epCount(seasonList))
        settings.edit().putString("epBase", o.toString()).apply()
        newEpisodes = newEpisodes.filterNot { it.first.id == id }
    }

    /** Prüft Lieblings- und Merklisten-Serien auf neue Folgen (höchstens alle 30 Minuten). */
    fun checkNewEpisodes() {
        val c = client ?: return
        val now = System.currentTimeMillis()
        if (now - lastEpCheck < 30 * 60_000L) return
        lastEpCheck = now
        viewModelScope.launch {
            delay(5000)
            val items = (favsFor("series") + watchFor("series")).distinctBy { it.id }.take(15)
            if (items.isEmpty()) { newEpisodes = emptyList(); return@launch }
            val found = withContext(Dispatchers.IO) {
                val base = epBase()
                val out = ArrayList<Pair<Item, Int>>()
                var changed = false
                for (s0 in items) {
                    try {
                        val cnt = epCount(c.seasons(s0.id))
                        if (cnt <= 0) continue
                        if (!base.has(s0.id)) {
                            base.put(s0.id, cnt)
                            changed = true
                        } else {
                            val old = base.optInt(s0.id)
                            if (cnt > old) out.add(s0 to (cnt - old))
                        }
                    } catch (e: Exception) { }
                }
                if (changed) settings.edit().putString("epBase", base.toString()).apply()
                out
            }
            newEpisodes = found
            if (found.isNotEmpty()) showNotice("Neue Folgen: " + found.joinToString(", ") { it.first.name }.take(80))
        }
    }

    // ---------- Ähnliche Titel ----------
    var similar by mutableStateOf<List<Item>>(emptyList())
    private var similarFor = ""
    private val stopWords = setOf("der", "die", "das", "den", "dem", "des", "ein", "eine", "und", "the", "of", "and",
        "a", "an", "in", "im", "am", "zum", "zur", "von", "vom", "mit", "für", "auf", "ist", "to", "for")

    /** Sucht Titel mit gleichem Anfang (Reihen, Fortsetzungen, Staffeln) im Katalog. */
    fun loadSimilar(item: Item) {
        val c = client ?: return
        similar = emptyList()
        similarFor = item.id
        val type = browseType
        val clean = item.name.replace(Regex("[\\(\\[].*?[\\)\\]]"), " ").replace(Regex("^[A-Za-z]{2}\\s*[-|:]\\s*"), "")
        val words = clean.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it.lowercase() !in stopWords }
        if (words.isEmpty()) return
        val term = if (words[0].length >= 5 || words.size < 2) words[0] else words[0] + " " + words[1]
        val hidden = portal?.let { userData.hiddenItems(it.id, type) } ?: emptySet()
        viewModelScope.launch {
            val found = try {
                withContext(Dispatchers.IO) { c.list(type, "*", 1, term).items }
            } catch (e: Exception) { emptyList() }
            if (similarFor != item.id) return@launch
            val own = item.name.trim().lowercase()
            similar = found.filter { it.id != item.id && it.name.trim().lowercase() != own && it.id !in hidden }
                .distinctBy { it.name.trim().lowercase() }.take(12)
            // Zusätzlich: Empfehlungen von TMDB, aber nur Titel, die dein Portal wirklich hat
            if (tmdbKey.isBlank()) return@launch
            val recs = try {
                withContext(Dispatchers.IO) {
                    Tmdb.lookup(tmdbKey, item.name, item.year, type == "series")
                        ?.let { Tmdb.recommendations(tmdbKey, it.id, type == "series") } ?: emptyList()
                }
            } catch (e: Exception) { emptyList() }
            if (similarFor != item.id || recs.isEmpty()) return@launch
            val sem = Semaphore(3)
            val matched = kotlinx.coroutines.coroutineScope {
                recs.take(12).map { r ->
                    async(Dispatchers.IO) {
                        sem.withPermit {
                            try {
                                val keys = setOf(normTitle(r.first), normTitle(r.second)).filter { it.length >= 2 }
                                c.list(type, "*", 1, r.first).items.firstOrNull {
                                    it.id != item.id && it.id !in hidden && normTitle(Tmdb.cleanName(it.name)) in keys
                                }
                            } catch (e: Exception) { null }
                        }
                    }
                }.awaitAll().filterNotNull()
            }
            if (similarFor != item.id) return@launch
            similar = (matched + similar).distinctBy { it.name.trim().lowercase() }
                .filter { it.name.trim().lowercase() != own }.take(14)
        }
    }

    // ---------- Bild und Ton ----------
    var picMode by mutableIntStateOf(settings.getInt("picMode", 0))
    var boostDb by mutableIntStateOf(settings.getInt("boostDb", 0))

    fun picLabel(): String = when (picMode) {
        1 -> "Zoom (Ränder abschneiden)"
        2 -> "Gestreckt (Vollbild)"
        else -> "Original"
    }

    fun cyclePic() {
        picMode = (picMode + 1) % 3
        settings.edit().putInt("picMode", picMode).apply()
    }

    fun cycleBoost() {
        boostDb = when (boostDb) { 0 -> 3; 3 -> 6; 6 -> 9; else -> 0 }
        settings.edit().putInt("boostDb", boostDb).apply()
    }

    // ---------- Portal-Test ----------
    var testResult by mutableStateOf<String?>(null)
    var testing by mutableStateOf(false)

    private fun friendlyError(e: Exception): String {
        val m = e.message ?: ""
        val all = (e.toString() + " " + m).lowercase()
        return when {
            "http 401" in all || "http 403" in all ->
                "Das Portal lehnt ab (HTTP 401/403). Die MAC-Adresse ist nicht freigeschaltet oder die Login-Daten stimmen nicht."
            "http 404" in all ->
                "Adresse nicht gefunden (404). Prüfe die URL, oft endet sie auf /c/ oder /stalker_portal/c/."
            "http 5" in all -> "Das Portal meldet einen Serverfehler (" + m + "). Später nochmal versuchen."
            "unable to resolve host" in all -> "Der Server-Name ist unbekannt. Prüfe die Adresse und die Internetverbindung."
            "timeout" in all || "timed out" in all -> "Zeitüberschreitung. Der Server ist nicht erreichbar oder die Adresse ist falsch."
            "handshake" in all -> "Das Portal gibt kein Token zurück. Prüfe URL und MAC-Adresse."
            "json" in all || "of type" in all -> "Das Portal antwortet nicht im erwarteten Format. Passt die URL?"
            else -> m.ifBlank { "Unbekannter Fehler" }
        }
    }

    fun testPortal(p: Portal) {
        if (testing) return
        testing = true
        testResult = null
        viewModelScope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    val sc = StalkerClient(p)
                    sc.connect()
                    val catsR = runCatching { sc.categories("itv").count { it.id != "*" } }
                    val chansR = runCatching { sc.channels().size }
                    val moviesR = runCatching { sc.list("vod", "*", 1).total }
                    val seriesR = runCatching { sc.list("series", "*", 1).total }
                    val cats = catsR.getOrDefault(-1)
                    val chans = chansR.getOrDefault(-1)
                    val movies = moviesR.getOrDefault(-1)
                    val series = seriesR.getOrDefault(-1)
                    fun why(r: Result<Int>): String = r.exceptionOrNull()?.let { t ->
                        " (" + (if (t is Exception) friendlyError(t) else (t.message ?: "Fehler")).take(90) + ")"
                    }.orEmpty()
                    val exp = runCatching { sc.accountInfo() }.getOrDefault("")
                    val expMs = parseExpiry(exp)
                    val sb = StringBuilder("✓ Verbindung und Anmeldung in Ordnung")
                    sb.append("\nLive TV: ").append(if (chans >= 0) "$chans Sender in $cats Kategorien" else "nicht abrufbar" + why(chansR))
                    sb.append("\nFilme: ").append(if (movies >= 0) movies.toString() else "nicht abrufbar" + why(moviesR))
                    sb.append("\nSerien: ").append(if (series >= 0) series.toString() else "nicht abrufbar" + why(seriesR))
                    if (expMs > 0) {
                        val d = daysLeft(expMs)
                        val date = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.GERMANY).format(java.util.Date(expMs))
                        sb.append("\nAbo: ").append(if (d < 0) "abgelaufen am $date" else "läuft ab $date (noch $d Tage)")
                    }
                    if (chans == 0) sb.append("\n⚠ Keine Sender gefunden. Das Portal liefert evtl. nur Filme/Serien oder das Abo ist abgelaufen.")
                    sb.toString()
                } catch (e: Exception) {
                    "✗ " + friendlyError(e)
                }
            }
            testResult = msg
            testing = false
            AppLog.add("Portal-Test " + p.name + ": " + msg.replace('\n', ' '))
        }
    }

    // ---------- Netzwerk-Wächter ----------
    @Volatile private var netLost = false

    private fun registerNetwork() {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return
        runCatching {
            cm.registerDefaultNetworkCallback(object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onLost(network: android.net.Network) {
                    netLost = true
                    AppLog.add("Netzwerk unterbrochen")
                    viewModelScope.launch { showNotice("Netzwerk unterbrochen …") }
                }

                override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
                    val wifi = caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
                    val sig = if (android.os.Build.VERSION.SDK_INT >= 29) caps.signalStrength else Int.MIN_VALUE
                    val weakWifi = wifi && sig != Int.MIN_VALUE && sig < -78
                    val slow = caps.linkDownstreamBandwidthKbps in 1..4999 && !wifi
                    viewModelScope.launch { setNetHint(weakWifi || slow) }
                }

                override fun onAvailable(network: android.net.Network) {
                    if (!netLost) return
                    netLost = false
                    AppLog.add("Netzwerk wieder da")
                    viewModelScope.launch { onNetworkBack() }
                }
            })
        }
    }

    /** Netz ist zurück: Stream und Portale selbst wieder aufsetzen. */
    private suspend fun onNetworkBack() {
        delay(1500)
        showNotice("Verbindung wieder da")
        val playing = stack.lastOrNull() is Screen.Play
        if (playing && (isLive || error != null)) { error = null; reload() }
        if (portals.any { status[it.id]?.startsWith("err") == true }) refreshAllPortals()
    }

    // ---------- Zwischenspeicher ----------
    var cacheLimitMb by mutableIntStateOf(settings.getInt("cacheLimitMb", 300))
    var cacheSizeText by mutableStateOf("")

    private fun dirSize(f: File): Long =
        if (f.isDirectory) (f.listFiles()?.sumOf { dirSize(it) } ?: 0L) else f.length()

    private fun fmtSize(b: Long): String =
        if (b >= 1024L * 1024 * 1024) String.format(java.util.Locale.GERMANY, "%.1f GB", b / 1073741824.0)
        else String.format(java.util.Locale.GERMANY, "%.0f MB", b / 1048576.0)

    fun refreshCacheSize() {
        viewModelScope.launch {
            val b = withContext(Dispatchers.IO) { dirSize(getApplication<Application>().cacheDir) }
            cacheSizeText = fmtSize(b)
        }
    }

    /** Bilder und Update-Dateien löschen; mit lists=true auch die gespeicherten Senderlisten. */
    private fun wipeCache(lists: Boolean) {
        val app = getApplication<Application>()
        runCatching {
            val loader = coil.Coil.imageLoader(app)
            loader.memoryCache?.clear()
            loader.diskCache?.clear()
        }
        runCatching { File(app.cacheDir, "updates").deleteRecursively() }
        if (lists) runCatching { cacheRoot.listFiles()?.forEach { it.delete() } }
    }

    /** Ein Klick: alles leeren. Die Senderlisten werden beim nächsten Start neu geladen. */
    fun clearCache() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { wipeCache(true) }
            refreshCacheSize()
            showNotice("Cache geleert")
        }
    }

    fun cycleCacheLimit() {
        cacheLimitMb = when (cacheLimitMb) {
            0 -> 100
            100 -> 300
            300 -> 500
            500 -> 1000
            else -> 0
        }
        settings.edit().putInt("cacheLimitMb", cacheLimitMb).apply()
    }

    /** Beim Start: ist der Cache über dem Limit, wird er geleert (Senderlisten nur, wenn es sonst nicht reicht). */
    private fun autoTrimCache() {
        if (cacheLimitMb <= 0) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val cache = getApplication<Application>().cacheDir
                val limit = cacheLimitMb * 1048576L
                if (dirSize(cache) > limit) {
                    wipeCache(false)
                    if (dirSize(cache) > limit) wipeCache(true)
                }
            }
        }
    }

    init {
        // Einmalig auf das neue Streaming-Premium-Design umstellen (mit Kino-Rot als Akzent).
        if (!settings.getBoolean("premiumV1", false)) {
            designMode = "premium"
            accentName = "Kino-Rot"
            settings.edit().putBoolean("premiumV1", true).putString("design", "premium")
                .putString("accent", "Kino-Rot").apply()
        }
        checkUpdate(silent = true)
        refreshAllPortals()
        autoTrimCache()
        registerNetwork()
    }
}


/** Vorgemerkte Sendung: beim Beginn erscheint eine Meldung mit Umschalt-Knopf. */
data class Reminder(val chId: String, val chName: String, val title: String, val startTs: Long)

/** Gemeinsamer Netzzustand, von allen Teilen der App lesbar. */
object NetState {
    @Volatile var weak = false
}

/** Eingebauter TMDB-Schlüssel (Besetzung, Trailer, Poster). Wird durch einen eigenen Eintrag in den Einstellungen ersetzt. */
const val DEFAULT_TMDB_KEY = "870e283eb2306087b8ed63d1e2b28378"

private fun normTitle(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
