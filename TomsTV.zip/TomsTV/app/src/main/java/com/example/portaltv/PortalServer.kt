package com.example.portaltv

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Winziger Webserver im WLAN/LAN: Das Handy öffnet über den QR-Code ein Formular
 * und schickt das Portal direkt an die Box. Läuft nur, solange die QR-Seite offen ist.
 */
class PortalServer(
    private val token: String,
    private val onBackup: () -> String,
    private val onRestore: (String) -> String,
    private val onLog: () -> String,
    private val onPortal: (Portal) -> Unit
) {
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start(): Int {
        val s = ServerSocket(0)
        server = s
        running = true
        thread(isDaemon = true) {
            while (running) {
                try {
                    val c = s.accept()
                    thread(isDaemon = true) {
                        // Ein hängender oder abgebrochener Browser-Zugriff darf nie die App beenden
                        try { handle(c) } catch (e: Throwable) {
                            if (e !is java.net.SocketTimeoutException) AppLog.add("Webserver: " + e.javaClass.simpleName + " " + (e.message ?: ""))
                            try { c.close() } catch (e2: Exception) { }
                        }
                    }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
        return s.localPort
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
    }

    private fun handle(sock: Socket) {
        sock.use { c ->
            c.soTimeout = 10_000
            val input = c.getInputStream()
            val out = c.getOutputStream()
            val head = readHead(input) ?: return
            val lines = head.split("\r\n")
            val parts = lines[0].split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1].substringBefore('?')
            var len = 0
            for (l in lines.drop(1)) {
                if (l.startsWith("Content-Length:", ignoreCase = true)) len = l.substringAfter(':').trim().toIntOrNull() ?: 0
            }
            val body = if (len > 0) readBody(input, len.coerceAtMost(if (path.endsWith("/restore")) 3_000_000 else 10_000)) else ByteArray(0)
            when {
                method == "GET" && path == "/$token" -> respond(out, 200, page(null, null))
                method == "POST" && path == "/$token/add" -> handleAdd(out, String(body, Charsets.UTF_8))
                method == "GET" && path == "/$token/backup" -> respondRaw(out, "application/json; charset=utf-8",
                    onBackup().toByteArray(Charsets.UTF_8), "Content-Disposition: attachment; filename=\"TomsTV-Backup.json\"\r\n")
                method == "POST" && path == "/$token/restore" -> respondRaw(out, "text/plain; charset=utf-8",
                    onRestore(String(body, Charsets.UTF_8)).toByteArray(Charsets.UTF_8), "")
                method == "GET" && path == "/$token/log" -> respondRaw(out, "text/plain; charset=utf-8",
                    onLog().toByteArray(Charsets.UTF_8), "")
                else -> respond(out, 404, "<h3>Nicht gefunden</h3>")
            }
        }
    }

    private fun handleAdd(out: OutputStream, raw: String) {
        val form = raw.split('&').mapNotNull {
            val i = it.indexOf('=')
            if (i < 0) null else URLDecoder.decode(it.substring(0, i), "UTF-8") to URLDecoder.decode(it.substring(i + 1), "UTF-8")
        }.toMap()
        val name = form["name"].orEmpty().trim()
        val url = form["url"].orEmpty().trim()
        val mac = normMac(form["mac"].orEmpty())
        val login = form["login"].orEmpty().trim()
        val pw = form["password"].orEmpty()
        val fbRows = (0 until 10).map { i -> form["fbu$i"].orEmpty() to form["fbm$i"].orEmpty() }
        val fr = parseFallbacks(fbRows, url, mac)
        val err = when {
            name.isEmpty() -> "Bitte einen Namen eingeben."
            !url.startsWith("http", ignoreCase = true) -> "Die Portal-URL muss mit http:// oder https:// beginnen."
            !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(mac) -> "Die MAC-Adresse muss so aussehen: 00:1A:79:XX:XX:XX"
            else -> fr.second
        }
        if (err != null) {
            respond(out, 400, page("err", err))
        } else {
            onPortal(Portal(UUID.randomUUID().toString(), name, url, mac, login, pw, fr.first))
            respond(out, 200, page("ok", "✓ „${esc(name)}“ wurde hinzugefügt. Du kannst unten ein weiteres Portal eintragen."))
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun page(kind: String?, msg: String?): String {
        val box = if (kind != null && msg != null) "<div class=\"msg $kind\">$msg</div>" else ""
        return "<!doctype html><html lang=\"de\"><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Tom’s TV</title><style>" +
            "body{margin:0;font-family:system-ui,sans-serif;background:#0a0a0f;color:#fff;padding:24px}" +
            "h1{font-family:Georgia,serif;letter-spacing:4px;margin:0 0 4px}" +
            ".line{width:80px;height:2px;background:#e5432d;margin:8px 0 18px}" +
            "label{display:block;margin:14px 0 6px;font-size:14px;color:#b0b7bf}" +
            "input{width:100%;box-sizing:border-box;padding:14px;border-radius:10px;border:1px solid #333;background:#16161d;color:#fff;font-size:16px}" +
            "button{margin-top:22px;width:100%;padding:16px;border:0;border-radius:12px;background:#e5432d;color:#fff;font-size:17px;font-weight:bold}" +
            ".msg{padding:12px;border-radius:10px;margin:12px 0}.ok{background:#12391f}.err{background:#4a1616}" +
            "</style></head><body><h1>TOM’S TV</h1><div class=\"line\"></div>" +
            "<p>Portal auf deinem TV hinzufügen</p>$box" +
            "<form method=\"post\" action=\"/$token/add\" accept-charset=\"utf-8\">" +
            "<label>Name</label><input name=\"name\" required>" +
            "<label>Portal-URL</label><input name=\"url\" type=\"url\" value=\"http://\" required autocapitalize=\"off\" autocorrect=\"off\">" +
            "<label>MAC-Adresse</label><input name=\"mac\" placeholder=\"00:1A:79:XX:XX:XX oder 001A79XXXXXX\" required autocapitalize=\"characters\" autocorrect=\"off\">" +
            "<label>Login (optional)</label><input name=\"login\" autocapitalize=\"off\" autocorrect=\"off\">" +
            "<label>Passwort (optional)</label><input name=\"password\" type=\"password\">" +
            "<div id=\"fbs\"></div>" +
            "<button type=\"button\" onclick=\"addFb()\" style=\"background:#2a2a33;margin-top:14px\">＋ Fallback (URL + MAC)</button>" +
            "<button type=\"submit\">Portal hinzufügen</button></form>" +
            "<hr style=\"border:0;border-top:1px solid #333;margin:28px 0\">" +
            "<h2 style=\"font-size:18px\">Backup &amp; Wiederherstellung</h2>" +
            "<p><a href=\"/$token/backup\" style=\"color:#e5432d\">Backup herunterladen</a></p>" +
            "<label>Backup-Datei wiederherstellen</label><input type=\"file\" id=\"bf\" accept=\".json,application/json\">" +
            "<button type=\"button\" onclick=\"rs()\">Wiederherstellen</button>" +
            "<div id=\"rm\" class=\"msg ok\" style=\"display:none\"></div>" +
            "<p style=\"margin-top:20px\"><a href=\"/$token/log\" style=\"color:#b0b7bf\">Fehlerprotokoll ansehen</a></p>" +
            "<script>var nf=0;function addFb(){var d=document.getElementById('fbs');var i=nf++;" +
            "function mk(t,n,c){var l=document.createElement('label');l.textContent=t;d.appendChild(l);var x=document.createElement('input');x.name=n;x.setAttribute('autocapitalize',c);x.setAttribute('autocorrect','off');d.appendChild(x);}" +
            "mk('Fallback '+(i+1)+': URL (leer = wie oben)','fbu'+i,'off');mk('Fallback '+(i+1)+': MAC (leer = wie oben)','fbm'+i,'characters');}" +
            "function rs(){var f=document.getElementById('bf').files[0];if(!f){return;}var r=new FileReader();" +
            "r.onload=function(){fetch('/$token/restore',{method:'POST',body:r.result}).then(function(x){return x.text();})" +
            ".then(function(t){var m=document.getElementById('rm');m.style.display='block';m.innerText=t;});};r.readAsText(f);}</script>" +
            "</body></html>"
    }

    private fun respondRaw(out: OutputStream, type: String, bytes: ByteArray, extra: String) {
        out.write(("HTTP/1.1 200 OK\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\n" + extra +
            "Connection: close\r\n\r\n").toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun respond(out: OutputStream, code: Int, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        val status = when (code) { 200 -> "200 OK"; 400 -> "400 Bad Request"; else -> "404 Not Found" }
        out.write(("HTTP/1.1 $status\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n").toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun readHead(input: InputStream): String? {
        val sb = ByteArrayOutputStream()
        var last4 = 0
        while (sb.size() < 8192) {
            val b = input.read()
            if (b < 0) return null
            sb.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return sb.toString("ISO-8859-1")
        }
        return null
    }

    private fun readBody(input: InputStream, len: Int): ByteArray {
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) break
            off += n
        }
        return buf.copyOf(off)
    }

    companion object {
        /** Lokale IPv4-Adresse der Box im Heimnetz. */
        fun localIp(): String? = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        } catch (e: Exception) { null }
    }
}
