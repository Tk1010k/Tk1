// Server logic
class PortalServer {}