package com.example.portaltv

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Winziger Webserver im WLAN/LAN: Das Handy öffnet über den QR-Code ein Formular
 * und schickt das Portal direkt an die Box. Läuft nur, solange die QR-Seite offen ist.
 */
class PortalServer(private val token: String, private val onPortal: (Portal) -> Unit) {
    private var server: ServerSocket? = null
    @Volatile private var running = false

    fun start(): Int {
        val s = ServerSocket(0)
        server = s
        running = true
        thread(isDaemon = true) {
            while (running) {
                try {
                    val c = s.accept()
                    thread(isDaemon = true) { handle(c) }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
        return s.localPort
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        server = null
    }

    private fun handle(sock: Socket) {
        sock.use { c ->
            c.soTimeout = 10_000
            val input = c.getInputStream()
            val out = c.getOutputStream()
            val head = readHead(input) ?: return
            val lines = head.split("\r\n")
            val parts = lines[0].split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val path = parts[1].substringBefore('?')
            var len = 0
            for (l in lines.drop(1)) {
                if (l.startsWith("Content-Length:", ignoreCase = true)) len = l.substringAfter(':').trim().toIntOrNull() ?: 0
            }
            val body = if (len > 0) readBody(input, len.coerceAtMost(10_000)) else ByteArray(0)
            when {
                method == "GET" && path == "/$token" -> respond(out, 200, page(null, null))
                method == "POST" && path == "/$token/add" -> handleAdd(out, String(body, Charsets.UTF_8))
                else -> respond(out, 404, "<h3>Nicht gefunden</h3>")
            }
        }
    }

    private fun handleAdd(out: OutputStream, raw: String) {
        val form = raw.split('&').mapNotNull {
            val i = it.indexOf('=')
            if (i < 0) null else URLDecoder.decode(it.substring(0, i), "UTF-8") to URLDecoder.decode(it.substring(i + 1), "UTF-8")
        }.toMap()
        val name = form["name"].orEmpty().trim()
        val url = form["url"].orEmpty().trim()
        val mac = form["mac"].orEmpty().trim().uppercase().replace('-', ':')
        val login = form["login"].orEmpty().trim()
        val pw = form["password"].orEmpty()
        val err = when {
            name.isEmpty() -> "Bitte einen Namen eingeben."
            !url.startsWith("http", ignoreCase = true) -> "Die Portal-URL muss mit http:// oder https:// beginnen."
            !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(mac) -> "Die MAC-Adresse muss so aussehen: 00:1A:79:XX:XX:XX"
            else -> null
        }
        if (err != null) {
            respond(out, 400, page("err", err))
        } else {
            onPortal(Portal(UUID.randomUUID().toString(), name, url, mac, login, pw))
            respond(out, 200, page("ok", "✓ „${esc(name)}“ wurde hinzugefügt. Du kannst unten ein weiteres Portal eintragen."))
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun page(kind: String?, msg: String?): String {
        val box = if (kind != null && msg != null) "<div class=\"msg $kind\">$msg</div>" else ""
        return "<!doctype html><html lang=\"de\"><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Tom’s TV</title><style>" +
            "body{margin:0;font-family:system-ui,sans-serif;background:#0a0a0f;color:#fff;padding:24px}" +
            "h1{font-family:Georgia,serif;letter-spacing:4px;margin:0 0 4px}" +
            ".line{width:80px;height:2px;background:#e5432d;margin:8px 0 18px}" +
            "label{display:block;margin:14px 0 6px;font-size:14px;color:#b0b7bf}" +
            "input{width:100%;box-sizing:border-box;padding:14px;border-radius:10px;border:1px solid #333;background:#16161d;color:#fff;font-size:16px}" +
            "button{margin-top:22px;width:100%;padding:16px;border:0;border-radius:12px;background:#e5432d;color:#fff;font-size:17px;font-weight:bold}" +
            ".msg{padding:12px;border-radius:10px;margin:12px 0}.ok{background:#12391f}.err{background:#4a1616}" +
            "</style></head><body><h1>TOM’S TV</h1><div class=\"line\"></div>" +
            "<p>Portal auf deinem TV hinzufügen</p>$box" +
            "<form method=\"post\" action=\"/$token/add\" accept-charset=\"utf-8\">" +
            "<label>Name</label><input name=\"name\" required>" +
            "<label>Portal-URL</label><input name=\"url\" type=\"url\" value=\"http://\" required autocapitalize=\"off\" autocorrect=\"off\">" +
            "<label>MAC-Adresse</label><input name=\"mac\" placeholder=\"00:1A:79:XX:XX:XX\" required autocapitalize=\"characters\" autocorrect=\"off\">" +
            "<label>Login (optional)</label><input name=\"login\" autocapitalize=\"off\" autocorrect=\"off\">" +
            "<label>Passwort (optional)</label><input name=\"password\" type=\"password\">" +
            "<button type=\"submit\">Portal hinzufügen</button></form></body></html>"
    }

    private fun respond(out: OutputStream, code: Int, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        val status = when (code) { 200 -> "200 OK"; 400 -> "400 Bad Request"; else -> "404 Not Found" }
        out.write(("HTTP/1.1 $status\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n").toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun readHead(input: InputStream): String? {
        val sb = ByteArrayOutputStream()
        var last4 = 0
        while (sb.size() < 8192) {
            val b = input.read()
            if (b < 0) return null
            sb.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return sb.toString("ISO-8859-1")
        }
        return null
    }

    private fun readBody(input: InputStream, len: Int): ByteArray {
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(buf, off, len - off)
            if (n < 0) break
            off += n
        }
        return buf.copyOf(off)
    }

    companion object {
        /** Lokale IPv4-Adresse der Box im Heimnetz. */
        fun localIp(): String? = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        } catch (e: Exception) { null }
    }
}
