plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.portaltv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.tom.tomstv"
        minSdk = 24
        targetSdk = 34
        // Jede neue Version bekommt automatisch eine höhere Nummer (Minuten seit 1970).
        versionCode = (System.currentTimeMillis() / 60000).toInt()
        versionName = "3.79"
        // GitHub liefert beim Bauen Bau-Nummer und Repository automatisch mit.
        buildConfigField("int", "RUN_NUMBER", System.getenv("GITHUB_RUN_NUMBER") ?: "0")
        buildConfigField("String", "UPDATE_REPO", "\"" + (System.getenv("GITHUB_REPOSITORY") ?: "") + "\"")
    }
    signingConfigs {
        create("tom") {
            storeFile = file("tomstv.jks")
            storeType = "pkcs12"
            storePassword = "pv4LvOGVwrBFhYY5Dz1K"
            keyAlias = "tomstv"
            keyPassword = "pv4LvOGVwrBFhYY5Dz1K"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("tom")
            // Nicht "debuggable": Android führt den Code sonst deutlich langsamer aus (vor allem Compose auf schwachen Boxen)
            isDebuggable = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
}
