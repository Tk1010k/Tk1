// Top-level build file
plugins {
    com.android.application version "8.2.0" apply false
    org.jetbrains.kotlin.android version "1.9.0" apply false
}
