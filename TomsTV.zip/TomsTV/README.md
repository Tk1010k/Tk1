# Tom's TV

Eigener Stalker/Ministra-Client für Android-TV-Boxen: mehrere Portale, Live-TV, Filme, Serien,
Suche, Favoriten, Weiterschauen und Programminfo (EPG). Keine Portal-Adressen enthalten.
Trage nur Portale ein, für die du ein gültiges Abo hast.

## APK bauen
**A) Android Studio:** Ordner öffnen, Sync abwarten, Build > Build APK(s).
Datei: app/build/outputs/apk/debug/app-debug.apk

**B) GitHub (ohne Installation):** Neues Repository anlegen, Inhalt dieses Ordners hochladen,
Reiter "Actions" > "Build APK" > Run workflow. Nach ca. 5 Minuten steht die APK unter "Releases" (rechte Spalte der Repo-Seite) als TomsTV.apk zum Download bereit. Auf der Box: App "Downloader" installieren und den Release-Link eingeben (Repository muss dafür öffentlich sein).

## Installieren
Per USB-Stick, "Send Files to TV" oder `adb install app-debug.apk`.

## Bedienung
- Portal: Name, URL (z. B. http://host/c/), MAC-Adresse vom Anbieter. Login/Passwort nur falls verlangt.
- Favorit: OK lange drücken oder Menü-Taste. Alle Favoriten stehen oben in der Kategorienliste.
- Suche: Feld über der Liste. Live-TV filtert sofort, Filme/Serien suchen beim Bestätigen.
- Weiterschauen: Startseite des Portals. Filme setzen automatisch an der letzten Stelle fort.
- EPG: In der Senderliste steht unter jedem Sender die laufende Sendung. Beim Schauen zeigt OK Details und die nächsten Sendungen.
- Programmübersicht: In der Live-Ansicht auf "Programm" gehen. Links die Sender, rechts das Programm des markierten Senders. OK spielt ab.
- Listen anpassen: In der Live-Ansicht "Kategorien" (Kategorien ein/aus, "Nur passende" zeigt z. B. nur DE/German) und "Kanäle" (einzelne Sender ausblenden, mit Namensfilter). Die Auswahl wird pro Portal gespeichert.
- Filme/Serien ausblenden: In der Ansicht auf "Ausblenden" tippen, dann blendet OK einzelne Einträge aus oder wieder ein. "Fertig" beendet den Modus. Kategorien (z. B. nur DE) gehen über "Kategorien".
- Updates: Die App wird mit einem festen Schlüssel signiert (app/tomstv.jks) und kann ohne Deinstallieren aktualisiert werden. Download immer aktuell: https://github.com/<NAME>/<REPO>/releases/latest/download/TomsTV.apk
- App-Update: Auf der Portal-Seite "Nach Updates suchen", dann "Jetzt installieren". Die App prüft beim Start auch selbst. Nötig: öffentliches Repository und die Erlaubnis "Unbekannte Apps installieren" für Tom's TV.
- Schriftfarbe: Auf der Portal-Seite unten wählbar (Gold, Weiß, Gelb, Hellblau, Grün, Orange, Pink). Wird gespeichert.
- Oberfläche: Kachel-Startseite, Fokus mit Zoom, Karten für Sender und Poster, Detailseite für Filme/Serien, Unterband im Player.
- Cinema-Style: Tiefes Schwarz, Kino-Gold als Akzent, Bordeaux-Kacheln, Serifen-Überschriften, Detailseite mit Poster-Hintergrund.
- Vorspann: Beim Start blendet das Logo ein (ca. 3 Sekunden). Beliebige Taste oder Tippen überspringt ihn.
- Layout: Seitenleiste (Startseite, Live TV, Filme, Serien, Favoriten, EPG, Portale, Einstellungen), Startseite mit Banner und Reihen. Farben: Einstellungen > Schrift- und Akzentfarbe (Standard Weiß/Rot).
- Portal per Handy: Portal-Seite > "Per Handy hinzufügen". QR-Code mit der Handy-Kamera scannen (gleiches WLAN), Formular ausfüllen.
- Merkliste: Auf der Detailseite von Filmen/Serien "＋ Merkliste". Anzeige in der Seitenleiste und auf der Startseite.
- Senderliste im Live-TV: Fernbedienung links (oder Menü-Taste) öffnet Kategorien und Sender, OK wechselt, Zurück schließt.
- Beim Start werden alle Portale automatisch im Hintergrund verbunden und die Senderlisten vorgeladen (Status auf der Portal-Karte). "⟳ Aktualisieren" lädt neu.
- Alle Portale sind gleichzeitig aktiv: Sender, Filme und Serien aller Portale erscheinen in einem gemeinsamen Katalog (Kategorien mit gleichem Namen werden zusammengelegt, gleichnamige Sender einmal gezeigt). Portale verwaltest du unter "Portale".
- Seitenleiste: Einstellungen > Seitenleiste (Automatisch, Kompakt, Normal). Sie ist scrollbar.
- Bild und Ton: Standard ist die Originalqualität vom Portal (4K/FHD/HD, Surround), ohne Umrechnung. Die ankommende Qualität steht im Info-Band des Players. Einstellungen > Bild & Ton.
- Kategorien nach Portal: Portalnamen klappen ihre Kategorien auf/zu; Seitenleiste und Kategorienliste lassen sich seitlich einklappen (◀/▶).
- Player: Bild und Ton in Originalqualität, Tonspur-Auswahl (Live: Taste rechts, Filme: Menü-Taste), deutsche Tonspur bevorzugt, größerer Puffer.
- EPG als Zeitleiste (alle Sender nebeneinander), Live-Vorschau in der Senderliste (abschaltbar), weiche Seitenübergänge, größere Bilder (falls das Portal sie liefert), zweites Design Hell/Dunkel (Einstellungen > Design).
- Kategorienleiste: Pro Portal aufklappbar (Favoriten, Weiterschauen, Alle, Kategorien). Weiterschauen mit Löschen unter Filme/Serien. Favoriten-Reiter links entfernt.
- Designs: Cinema, OLED-Schwarz, Mitternachtsblau (Einstellungen > Design). Leistungsmodus für ältere Boxen.
- Live-TV: Links der Nachbarsender werden vorgeladen (schnelles Umschalten); bei Ausfall wechselt die App zur gleichen Senderquelle eines anderen Portals. Senderliste im Player mit aufklappbaren Portalen, passend zur Startliste.
- Live: Hoch/Runter = Kanal wechseln. Filme: Links/Rechts = 10 s spulen, OK = Pause. Zurück = Liste.
