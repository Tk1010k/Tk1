# Tom's TV

Eigener Stalker/Ministra-Client für Android-TV-Boxen: mehrere Portale, Live-TV, Filme, Serien,
Suche, Favoriten, Weiterschauen und Programminfo (EPG). Keine Portal-Adressen enthalten.
Trage nur Portale ein, für die du ein gültiges Abo hast.

## APK bauen
**A) Android Studio:** Ordner öffnen, Sync abwarten, Build > Build APK(s).
Datei: app/build/outputs/apk/debug/app-debug.apk

**B) GitHub (ohne Installation):** Neues Repository anlegen, Inhalt dieses Ordners hochladen,
Reiter "Actions" > "Build APK" > Run workflow. Nach ca. 5 Minuten steht die APK unter "Releases" (rechte Spalte der Repo-Seite) als TomsTV.apk zum Download bereit. Auf der Box: App "Downloader" installieren und den Release-Link eingeben (Repository muss dafür öffentlich sein).

## Installieren
Per USB-Stick, "Send Files to TV" oder `adb install app-debug.apk`.

## Bedienung
- Portal: Name, URL (z. B. http://host/c/), MAC-Adresse vom Anbieter. Login/Passwort nur falls verlangt.
- Favorit: OK lange drücken oder Menü-Taste. Alle Favoriten stehen oben in der Kategorienliste.
- Suche: Feld über der Liste. Live-TV filtert sofort, Filme/Serien suchen beim Bestätigen.
- Weiterschauen: Startseite des Portals. Filme setzen automatisch an der letzten Stelle fort.
- EPG: In der Senderliste steht unter jedem Sender die laufende Sendung. Beim Schauen zeigt OK Details und die nächsten Sendungen.
- Programmübersicht: In der Live-Ansicht auf "Programm" gehen. Links die Sender, rechts das Programm des markierten Senders. OK spielt ab.
- Listen anpassen: In der Live-Ansicht "Kategorien" (Kategorien ein/aus, "Nur passende" zeigt z. B. nur DE/German) und "Kanäle" (einzelne Sender ausblenden, mit Namensfilter). Die Auswahl wird pro Portal gespeichert.
- Filme/Serien ausblenden: In der Ansicht auf "Ausblenden" tippen, dann blendet OK einzelne Einträge aus oder wieder ein. "Fertig" beendet den Modus. Kategorien (z. B. nur DE) gehen über "Kategorien".
- Updates: Die App wird mit einem festen Schlüssel signiert (app/tomstv.jks) und kann ohne Deinstallieren aktualisiert werden. Download immer aktuell: https://github.com/<NAME>/<REPO>/releases/latest/download/TomsTV.apk
- App-Update: Auf der Portal-Seite "Nach Updates suchen", dann "Jetzt installieren". Die App prüft beim Start auch selbst. Nötig: öffentliches Repository und die Erlaubnis "Unbekannte Apps installieren" für Tom's TV.
- Live: Hoch/Runter = Kanal wechseln. Filme: Links/Rechts = 10 s spulen, OK = Pause. Zurück = Liste.
