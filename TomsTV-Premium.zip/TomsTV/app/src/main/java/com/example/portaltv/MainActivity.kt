@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.portaltv

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: AppVM = viewModel()
            val tc = Palette.color(vm.textColorName)
            val bg = Color(0xFF101418)
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = tc, onPrimary = bg, onSurface = tc, onBackground = tc, onSurfaceVariant = tc
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = bg, contentColor = tc) { App(vm) }
            }
        }
    }
}

fun fmtTime(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}

/** Menü-Taste der Fernbedienung = Favorit umschalten. */
fun Modifier.favKey(onFav: () -> Unit): Modifier = onKeyEvent { e ->
    if (e.type == KeyEventType.KeyDown && e.key == Key.Menu) { onFav(); true } else false
}

/** Sichtbarer Fokus-Rahmen für die Fernbedienung. */
fun Modifier.tvFocus(): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    this.onFocusChanged { f = it.hasFocus }
        .border(if (f) 2.dp else 1.dp,
            if (f) Color(0xFF56D6C9) else Color(0x223E536E), RoundedCornerShape(14.dp))
}

private val AppBg = Color(0xFF080D18)
private val Panel = Color(0xFF111A2A)
private val Muted = Color(0xFFAAB7CA)
private val Accent = Color(0xFF56D6C9)

@Composable
fun App(vm: AppVM = viewModel()) {
    val activity = LocalContext.current as? Activity
    BackHandler { if (!vm.back()) activity?.finish() }
    Box(Modifier.fillMaxSize()) {
        when (val s = vm.stack.last()) {
            Screen.Portals -> PortalsScreen(vm)
            is Screen.Form -> FormScreen(vm, s.edit)
            Screen.Home -> HomeScreen(vm)
            is Screen.Browse -> BrowseScreen(vm, s.type)
            is Screen.Seasons -> {
                val rows: List<Pair<String, () -> Unit>> = vm.seasons.map { se -> se.name to { vm.openSeason(se) } }
                SimpleList(s.title, rows)
            }
            is Screen.Episodes -> {
                val se = s.season
                val rows: List<Pair<String, () -> Unit>> = se.episodes.map { n ->
                    "Episode $n" to { vm.play("vod", "${se.name} – Episode $n", se.cmd, n) }
                }
                SimpleList(se.name, rows)
            }
            Screen.ResumeList -> {
                val rows: List<Pair<String, () -> Unit>> = vm.resumeList.map { r ->
                    "${r.title}  ·  ${fmtTime(r.pos)}" to { vm.play("vod", r.title, r.cmd, r.ep) }
                }
                val empty: List<Pair<String, () -> Unit>> = listOf("Noch nichts angefangen" to { })
                SimpleList("Weiterschauen", if (rows.isEmpty()) empty else rows)
            }
            Screen.Guide -> GuideScreen(vm)
            Screen.EditCats -> EditCatsScreen(vm)
            Screen.EditChans -> EditChansScreen(vm)
            Screen.Play -> PlayerScreen(vm)
        }
        if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
        vm.notice?.let {
            Text(it, fontSize = 18.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
                    .background(Color(0xDD0D47A1), RoundedCornerShape(8.dp)).padding(horizontal = 16.dp, vertical = 8.dp))
        }
        vm.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp,
                modifier = Modifier.align(Alignment.BottomCenter).background(Color(0xCC000000)).padding(12.dp))
        }
    }
}

@Composable
fun ListRow(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).tvFocus().clickable(onClick = onClick)
            .background(if (selected) Color(0xFF203449) else Color(0x00111A2A), RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selected) Box(Modifier.width(3.dp).height(22.dp).background(Accent, RoundedCornerShape(3.dp)))
        if (selected) Spacer(Modifier.width(10.dp))
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 17.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
fun SimpleList(title: String, rows: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101D31), AppBg))).padding(30.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.width(54.dp).height(4.dp).background(Accent, RoundedCornerShape(4.dp)))
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) { items(rows) { (label, act) -> ListRow(label, false, act) } }
    }
}

@Composable
fun PortalsScreen(vm: AppVM) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14243A), AppBg))).padding(28.dp)) {
        Text("TOM'S TV", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 3.sp)
        Text("Deine Portale", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Verbinde dich mit deinem TV-Angebot", fontSize = 15.sp, color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
        if (vm.portals.isEmpty()) Text("Noch kein Portal eingetragen.", Modifier.padding(16.dp), color = Muted)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(vm.portals, key = { it.id }) { p -> PortalRow(vm, p) } }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.push(Screen.Form(null)) }, modifier = Modifier.tvFocus()) { Text("+ Portal hinzufügen") }
            OutlinedButton(onClick = { vm.checkUpdate() }, modifier = Modifier.tvFocus()) { Text("Nach Updates suchen") }
            if (vm.updateInfo != null) {
                Button(onClick = { vm.installUpdate() }, modifier = Modifier.tvFocus()) { Text("Jetzt installieren") }
            }
        }
        vm.updateMsg?.let { Text(it, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp)) }
        if (vm.updateProgress >= 0) {
            LinearProgressIndicator(progress = { vm.updateProgress / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
        }
        Text("DARSTELLUNG", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 16.dp))
        Text("Schriftfarbe", fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp), color = Muted)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Palette.options.forEach { (name, c) ->
                OutlinedButton(onClick = { vm.setTextColor(name) }, modifier = Modifier.tvFocus()) {
                    Text((if (vm.textColorName == name) "● " else "") + name, color = c)
                }
            }
        }
        Text("Version ${BuildConfig.RUN_NUMBER}", fontSize = 12.sp, color = Color(0xFF9AA4AE),
            modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun PortalRow(vm: AppVM, p: Portal) {
    var confirm by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = { vm.openPortal(p) }, modifier = Modifier.weight(1f).height(52.dp).tvFocus()) { Text(p.name, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { vm.push(Screen.Form(p)) }, modifier = Modifier.tvFocus()) { Text("Bearbeiten") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { if (confirm) vm.deletePortal(p) else confirm = true }, modifier = Modifier.tvFocus()) {
            Text(if (confirm) "Wirklich löschen?" else "Löschen")
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().tvFocus())
}

@Composable
fun FormScreen(vm: AppVM, edit: Portal?) {
    var name by remember { mutableStateOf(edit?.name ?: "") }
    var url by remember { mutableStateOf(edit?.url ?: "http://") }
    var mac by remember { mutableStateOf(edit?.mac ?: "") }
    var login by remember { mutableStateOf(edit?.login ?: "") }
    var pw by remember { mutableStateOf(edit?.password ?: "") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14243A), AppBg))).padding(30.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(if (edit == null) "Portal hinzufügen" else "Portal bearbeiten", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Trage die Zugangsdaten deines Anbieters ein.", fontSize = 14.sp, color = Muted)
        Field("Name", name) { name = it }
        Field("Portal-URL (z. B. http://host/c/)", url) { url = it }
        Field("MAC-Adresse (00:1A:79:XX:XX:XX)", mac) { mac = it }
        Field("Login (optional)", login) { login = it }
        Field("Passwort (optional)", pw) { pw = it }
        err?.let { Text(it, color = Color(0xFFFF8A80)) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(modifier = Modifier.tvFocus(), onClick = {
                val m = mac.trim().uppercase()
                val u = url.trim()
                when {
                    name.isBlank() -> err = "Name fehlt"
                    !u.startsWith("http", true) -> err = "URL muss mit http:// oder https:// beginnen"
                    !Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}").matches(m) -> err = "MAC-Format: 00:1A:79:XX:XX:XX"
                    else -> {
                        vm.savePortal(Portal(edit?.id ?: UUID.randomUUID().toString(), name.trim(), u, m, login.trim(), pw))
                        vm.back()
                    }
                }
            }) { Text("Speichern") }
            OutlinedButton(onClick = { vm.back() }, modifier = Modifier.tvFocus()) { Text("Abbrechen") }
        }
    }
}

@Composable
fun HomeScreen(vm: AppVM) {
    val tileData = listOf(
        Triple("▶", "Live TV", "Direkt einschalten"),
        Triple("▧", "Filme", "Große Geschichten"),
        Triple("▤", "Serien", "Deine nächste Folge")
    )
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF14243A), Color(0xFF0B1220), AppBg)))
            .padding(horizontal = 36.dp, vertical = 26.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Accent, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Text("T", color = Color(0xFF08111D), fontSize = 27.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("TOM'S TV", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = 3.sp)
                Text("DEIN ENTERTAINMENT", fontSize = 10.sp, color = Accent, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            Text(vm.portal?.name ?: "Willkommen", color = Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(
                Modifier.weight(1.55f).fillMaxHeight()
                    .background(Brush.linearGradient(listOf(Color(0xFF243E5D), Color(0xFF17283E), Color(0xFF111A2A))), RoundedCornerShape(24.dp))
                    .border(1.dp, Color(0x3356D6C9), RoundedCornerShape(24.dp))
                    .padding(28.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("DEIN STREAMING-ZUHAUSE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(12.dp))
                Text("Dein nächster
Lieblingsmoment.", color = Color.White, fontSize = 34.sp, lineHeight = 39.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                Text("Live-TV, Filme und Serien – übersichtlich an einem Ort.", color = Muted, fontSize = 16.sp, lineHeight = 22.sp)
                Spacer(Modifier.height(22.dp))
                Button(onClick = { vm.openBrowse("itv") }, modifier = Modifier.height(50.dp).tvFocus(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF08111D))) {
                    Text("▶   Live-TV öffnen", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                tileData.drop(1).forEachIndexed { index, item ->
                    val (symbol, title, subtitle) = item
                    Column(
                        Modifier.weight(1f).fillMaxWidth().tvFocus()
                            .background(if (index == 0) Color(0xFF1A2B40) else Color(0xFF171F31), RoundedCornerShape(20.dp))
                            .border(1.dp, Color(0x223E536E), RoundedCornerShape(20.dp))
                            .clickable { vm.openBrowse(if (title == "Filme") "vod" else "series") }
                            .padding(20.dp), verticalArrangement = Arrangement.Center
                    ) {
                        Text(symbol, fontSize = 28.sp, color = Accent, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(title, fontSize = 22.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(subtitle, fontSize = 13.sp, color = Muted)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("WEITERSCHAUEN", fontSize = 11.sp, color = Muted, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Dort weitermachen, wo du aufgehört hast", fontSize = 14.sp, color = Color.White)
            }
            OutlinedButton(onClick = { vm.openResumes() }, modifier = Modifier.height(46.dp).tvFocus(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                Text("↻   Weiterschauen", fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun BrowseScreen(vm: AppVM, type: String) {
    val title = when (type) { "itv" -> "Live-TV"; "series" -> "Serien"; else -> "Filme" }
    Row(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF101B2C), AppBg)))) {
        Column(
            Modifier.width(250.dp).fillMaxHeight().background(Color(0x99111A2A)).padding(horizontal = 12.dp, vertical = 18.dp)
        ) {
            Text("TOM'S TV", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 10.dp, bottom = 5.dp))
            Text("Kategorien", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White,
                modifier = Modifier.padding(start = 10.dp, bottom = 14.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                items(vm.categories) { c -> ListRow(c.title, c.id == vm.selCat) { vm.selectCategory(c.id) } }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(start = 16.dp, end = 20.dp, top = 18.dp, bottom = 10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text(if (type == "itv") "Finde deinen Sender" else "Entdecke etwas Neues", fontSize = 13.sp, color = Muted)
                }
                OutlinedTextField(
                    value = vm.queryText,
                    onValueChange = { vm.queryText = it; if (type == "itv") vm.search(it) },
                    label = { Text("Suchen") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search(vm.queryText) }),
                    modifier = Modifier.width(230.dp).tvFocus()
                )
                if (type == "itv") {
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.push(Screen.Guide) }, modifier = Modifier.tvFocus()) { Text("Programm") }
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(onClick = { vm.openEditChannels() }, modifier = Modifier.tvFocus()) { Text("Kanäle") }
                } else {
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { vm.toggleEditMode() }, modifier = Modifier.tvFocus()) {
                        Text(if (vm.editMode) "Fertig" else "Ausblenden")
                    }
                }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { vm.push(Screen.EditCats) }, modifier = Modifier.tvFocus()) { Text("Kategorien") }
            }
            Text(if (vm.editMode && type != "itv") "AUSBLENDEN-MODUS · OK blendet Einträge ein oder aus."
                else "OK öffnen · lange drücken oder Menü-Taste für Favoriten", fontSize = 12.sp, color = Muted,
                modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0x22111A2A), RoundedCornerShape(18.dp))) {
                if (type == "itv") {
                    LazyColumn(state = vm.listState, modifier = Modifier.fillMaxSize().padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        items(vm.items) { ch -> ChannelRow(vm, ch) }
                    }
                } else {
                    val last by remember { derivedStateOf { vm.gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 } }
                    val shown = vm.shownItems()
                    LaunchedEffect(last, shown.size, vm.hasMore) {
                        if (vm.hasMore && last >= shown.size - 6) vm.loadMore()
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(155.dp), state = vm.gridState,
                        modifier = Modifier.fillMaxSize().padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(shown, key = { it.id }) { entry -> PosterCard(vm, entry) }
                    }
                    if (vm.busyList) Text("Lade Inhalte …", Modifier.align(Alignment.BottomCenter).padding(12.dp), color = Color.White)
                }
                if (vm.items.isEmpty() && !vm.busyList && !vm.loading) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⌕", fontSize = 42.sp, color = Muted)
                        Text("Keine Einträge gefunden", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("Wähle eine andere Kategorie oder ändere die Suche.", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelRow(vm: AppVM, ch: Item) {
    LaunchedEffect(ch.id) { vm.loadEpg(ch.id) }
    val now = vm.currentEpg(ch.id)
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Panel, RoundedCornerShape(14.dp)).tvFocus().favKey { vm.toggleFav(ch) }
        .combinedClickable(onClick = { vm.openItem(ch) }, onLongClick = { vm.toggleFav(ch) }).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = ch.logo, contentDescription = null, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text((if (vm.isFav(ch)) "★ " else "") + ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp)
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 13.sp, color = Color(0xFF9AA4AE),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun PosterCard(vm: AppVM, entry: Item) {
    val hidden = vm.editMode && entry.id in vm.hiddenItems
    Column(
        Modifier.tvFocus().favKey { vm.toggleFav(entry) }
            .combinedClickable(onClick = { vm.openItem(entry) }, onLongClick = { vm.toggleFav(entry) })
            .alpha(if (hidden) 0.35f else 1f)
            .background(Color(0xFF141F30), RoundedCornerShape(16.dp))
            .padding(7.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Color(0xFF202B3B), RoundedCornerShape(11.dp))) {
            AsyncImage(model = entry.logo, contentDescription = entry.name, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize())
            if (vm.isFav(entry) || hidden) {
                Text(if (hidden) "×" else "★", color = if (hidden) Color.White else Accent,
                    fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopEnd).padding(7.dp)
                        .background(Color(0xDD080D18), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp))
            }
        }
        Text(entry.name, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis,
            fontSize = 14.sp, lineHeight = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 9.dp))
    }
}

@Composable
fun PlayerScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val mac = vm.portal?.mac ?: ""
    val exo = remember {
        val ds = DefaultHttpDataSource.Factory().setUserAgent(UA).setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000).setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(mapOf("Cookie" to "mac=$mac"))
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(ds)).build().apply { playWhenReady = true }
    }
    var retries by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(true) }
    var detail by remember { mutableStateOf(false) }
    val fr = remember { FocusRequester() }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (vm.isLive && retries < 5) { retries++; vm.reload() }
                else vm.error = "Wiedergabefehler: ${error.errorCodeName}"
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && !vm.isLive) vm.clearResume()
            }
        }
        exo.addListener(l)
        onDispose {
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
            exo.removeListener(l); exo.release()
        }
    }

    LaunchedEffect(vm.playUrl) {
        vm.playUrl?.let { u ->
            val pos = if (vm.isLive) 0L else vm.resumePos()
            if (pos > 0) {
                exo.setMediaItem(MediaItem.fromUri(u), pos)
                vm.showNotice("Weiter bei ${fmtTime(pos)}")
            } else exo.setMediaItem(MediaItem.fromUri(u))
            exo.prepare(); exo.play()
        }
    }
    LaunchedEffect(Unit) { fr.requestFocus() }
    LaunchedEffect(vm.playChId, vm.isLive) {
        while (vm.isLive) { vm.loadEpg(vm.playChId); delay(60_000) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (!vm.isLive && exo.playbackState == Player.STATE_READY) vm.savePosition(exo.currentPosition, exo.duration)
        }
    }
    LaunchedEffect(tick, vm.playTitle) { info = true; delay(4000); if (!detail) info = false }

    // Wächter: Bei Hängern im Live-TV (Puffern oder Standbild > 20 s) neuen Link holen.
    LaunchedEffect(Unit) {
        var stuck = 0
        var lastPos = -1L
        while (true) {
            delay(5000)
            val pos = exo.currentPosition
            val bad = vm.isLive && !vm.loading && exo.playWhenReady &&
                (exo.playbackState == Player.STATE_BUFFERING ||
                    (exo.playbackState == Player.STATE_READY && pos == lastPos))
            lastPos = pos
            if (bad) stuck++ else stuck = 0
            if (stuck >= 4) { stuck = 0; vm.reload() }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black).focusRequester(fr).focusable().onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
        tick++
        when (e.key) {
            Key.DirectionUp, Key.ChannelUp -> if (vm.isLive) { detail = false; vm.zap(1); true } else false
            Key.DirectionDown, Key.ChannelDown -> if (vm.isLive) { detail = false; vm.zap(-1); true } else false
            Key.DirectionLeft, Key.MediaRewind ->
                if (!vm.isLive) { exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); true } else false
            Key.DirectionRight, Key.MediaFastForward ->
                if (!vm.isLive) { exo.seekTo(exo.currentPosition + 10_000); true } else false
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                if (vm.isLive) detail = !detail else exo.playWhenReady = !exo.playWhenReady
                true
            }
            else -> false
        }
    }) {
        AndroidView(factory = { c ->
            PlayerView(c).apply {
                useController = false
                isFocusable = false
                isFocusableInTouchMode = false
                keepScreenOn = true
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                this.player = exo
            }
        }, modifier = Modifier.fillMaxSize())
        if (info || detail) InfoPanel(vm, detail, Modifier.align(Alignment.TopStart))
    }
}

@Composable
fun InfoPanel(vm: AppVM, detail: Boolean, modifier: Modifier) {
    val gray = Color(0xFF9AA4AE)
    val list = vm.epgList(vm.playChId)
    val now = if (vm.isLive) vm.currentEpg(vm.playChId) else null
    Column(modifier.padding(24.dp).widthIn(max = 640.dp)
        .background(Color(0xBB000000), RoundedCornerShape(8.dp)).padding(16.dp)) {
        Text(vm.playTitle, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (vm.isLive) {
            if (now != null) {
                Text("${now.start}–${now.end}  ${now.title}", fontSize = 18.sp)
                vm.epgProgress(now)?.let { p ->
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                }
                if (detail && now.descr.isNotBlank()) {
                    Text(now.descr, fontSize = 14.sp, maxLines = 6, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 6.dp))
                }
                list.dropWhile { it != now }.drop(1).take(if (detail) 4 else 1).forEach { n ->
                    Text("${n.start}  ${n.title}", fontSize = 15.sp, color = gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                Text("Keine Programminfo", fontSize = 14.sp, color = gray)
            }
            if (!detail) Text("OK = Details", fontSize = 12.sp, color = gray, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun GuideScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var focused by remember { mutableStateOf(vm.items.firstOrNull()) }
    val f = focused
    LaunchedEffect(f?.id) { f?.let { vm.loadEpg(it.id, 12) } }
    val list = if (f != null) vm.epgList(f.id) else emptyList()
    val now = if (f != null) vm.currentEpg(f.id) else null
    Row(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.width(320.dp).fillMaxHeight().padding(8.dp)) {
            items(vm.items) { ch ->
                Row(Modifier.fillMaxWidth().tvFocus().onFocusChanged { if (it.hasFocus) focused = ch }
                    .clickable { vm.openItem(ch) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = ch.logo, contentDescription = null, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(ch.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 17.sp)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight().padding(16.dp)) {
            Text(f?.name ?: "Keine Sender", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("OK = Sender abspielen", fontSize = 12.sp, color = gray, modifier = Modifier.padding(bottom = 8.dp))
            if (list.isEmpty()) Text("Keine Programminfo (oder sie lädt noch)", color = gray)
            LazyColumn {
                items(list.dropWhile { it != now }) { e ->
                    val isNow = e == now
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text("${e.start}–${e.end}  ${e.title}", fontSize = 17.sp,
                            fontWeight = if (isNow) FontWeight.Bold else FontWeight.Normal)
                        if (isNow) {
                            vm.epgProgress(e)?.let { p ->
                                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                            }
                            if (e.descr.isNotBlank()) {
                                Text(e.descr, fontSize = 13.sp, color = gray, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditCatsScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var kw by remember { mutableStateOf("DE, German, Deutsch") }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kategorien auswählen", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.allCats.count { it.id !in vm.hiddenCats }} von ${vm.allCats.size} sichtbar",
            fontSize = 13.sp, color = gray)
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = kw, onValueChange = { kw = it }, singleLine = true,
                label = { Text("Suchbegriffe, z. B. DE, German") }, modifier = Modifier.weight(1f).tvFocus())
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.showOnlyMatching(kw) }, modifier = Modifier.tvFocus()) { Text("Nur passende") }
        }
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setAllCats(true) }, modifier = Modifier.tvFocus()) { Text("Alle anzeigen") }
            OutlinedButton(onClick = { vm.setAllCats(false) }, modifier = Modifier.tvFocus()) { Text("Alle ausblenden") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(vm.allCats) { c ->
                val on = c.id !in vm.hiddenCats
                Text((if (on) "✓  " else "✗  ") + c.title, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleCat(c.id) }.padding(12.dp))
            }
        }
    }
}

@Composable
fun EditChansScreen(vm: AppVM) {
    val gray = Color(0xFF9AA4AE)
    var filter by remember { mutableStateOf("") }
    val shown = vm.editChans.filter { filter.isBlank() || it.name.contains(filter.trim(), ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Kanäle ein-/ausblenden", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("OK = ein/aus  ·  ${vm.editChans.count { it.id !in vm.hiddenChans }} von ${vm.editChans.size} sichtbar",
            fontSize = 13.sp, color = gray)
        OutlinedTextField(value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Filter nach Name") },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).tvFocus())
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, true) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte ausblenden")
            }
            OutlinedButton(onClick = { vm.setChansHidden(shown.map { it.id }, false) }, modifier = Modifier.tvFocus()) {
                Text("Gefilterte einblenden")
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { ch ->
                val on = ch.id !in vm.hiddenChans
                Text((if (on) "✓  " else "✗  ") + ch.name, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (on) MaterialTheme.colorScheme.onSurface else gray,
                    modifier = Modifier.fillMaxWidth().tvFocus().clickable { vm.toggleChan(ch.id) }.padding(12.dp))
            }
        }
    }
}
